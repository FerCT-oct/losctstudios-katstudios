package net.katlauncher.katcraft.common;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public final class KatCraftState {
    private static volatile JsonObject state = new JsonObject();
    private static volatile List<String> katPlayers = List.of();
    private static final Set<String> knownKatPlayers = ConcurrentHashMap.newKeySet();
    private static final ConcurrentHashMap<String, String> playerRanks =
            new ConcurrentHashMap<>();
    private static volatile String status = "Conectando con KatLauncher…";

    private KatCraftState() {}

    public static void update(JsonObject value) {
        state = value == null ? new JsonObject() : value;
        status = bool(state, "signed_in")
                ? "Kat Social conectado"
                : "Inicia sesión en Kat Social para usar amigos e invitaciones";
        for (Friend friend : friends()) {
            if (friend.katcraft() && !friend.gameNickname().isBlank()) {
                knownKatPlayers.add(normalize(friend.gameNickname()));
                playerRanks.put(normalize(friend.gameNickname()), friend.rank());
            }
        }
    }

    public static void updatePlayers(JsonObject value) {
        List<String> result = new ArrayList<>();
        if (value != null && value.has("players") && value.get("players").isJsonArray()) {
            for (JsonElement entry : value.getAsJsonArray("players")) {
                if (!entry.isJsonObject()) continue;
                String nickname = text(entry.getAsJsonObject(), "game_nickname");
                if (nickname.isBlank()) nickname = text(entry.getAsJsonObject(), "nickname");
                if (!nickname.isBlank()) {
                    result.add(nickname);
                    knownKatPlayers.add(normalize(nickname));
                    JsonObject player = entry.getAsJsonObject();
                    String rank = text(player, "rank");
                    if (rank.isBlank() && bool(player, "platinum")) rank = "platinum";
                    playerRanks.put(normalize(nickname), rank);
                }
            }
        }
        katPlayers = List.copyOf(result);
    }

    public static void markLocalPlayer(String nickname) {
        if (nickname != null && !nickname.isBlank()) {
            knownKatPlayers.add(normalize(nickname));
        }
    }

    public static void error(String value) { status = value; }
    public static String status() { return status; }
    public static boolean isKatPlayer(String nickname) {
        return nickname != null && (
                knownKatPlayers.contains(normalize(nickname))
                || katPlayers.stream().anyMatch(value -> value.equalsIgnoreCase(nickname))
        );
    }
    public static String rankForPlayer(String nickname) {
        return nickname == null ? "" : playerRanks.getOrDefault(normalize(nickname), "");
    }
    public static JsonArray trophies() { return array(state, "trophies"); }

    public static List<World> worlds() {
        List<World> result = new ArrayList<>();
        for (JsonElement value : array(state, "worlds")) {
            if (!value.isJsonObject()) continue;
            JsonObject item = value.getAsJsonObject();
            result.add(new World(
                    text(item, "id"), text(item, "name"), text(item, "source")
            ));
        }
        return result;
    }

    public static List<Mod> mods() {
        List<Mod> result = new ArrayList<>();
        for (JsonElement value : array(state, "mods")) {
            if (!value.isJsonObject()) continue;
            JsonObject item = value.getAsJsonObject();
            result.add(new Mod(
                    text(item, "id"), text(item, "name"),
                    bool(item, "client_only"), bool(item, "selected")
            ));
        }
        return result;
    }

    public static List<Skin> skins() {
        List<Skin> result = new ArrayList<>();
        for (JsonElement value : array(state, "skins")) {
            if (!value.isJsonObject()) continue;
            JsonObject item = value.getAsJsonObject();
            result.add(new Skin(text(item, "id"), text(item, "name"), bool(item, "active")));
        }
        return result;
    }

    public static List<Cape> capes() {
        List<Cape> result = new ArrayList<>();
        for (JsonElement value : array(state, "capes")) {
            if (!value.isJsonObject()) continue;
            JsonObject item = value.getAsJsonObject();
            result.add(new Cape(text(item, "id"), text(item, "name"),
                    text(item, "kind"), bool(item, "active")));
        }
        return result;
    }

    public static List<Player> serverPlayers() {
        List<Player> result = new ArrayList<>();
        for (JsonElement value : array(state, "server_players")) {
            if (!value.isJsonObject()) continue;
            JsonObject item = value.getAsJsonObject();
            result.add(new Player(
                    text(item, "id"), text(item, "display_name"),
                    text(item, "game_nickname"), text(item, "rank")
            ));
        }
        return result;
    }

    public static LastRoom lastRoom() {
        JsonElement value = state.get("last_room");
        JsonObject item = value != null && value.isJsonObject()
                ? value.getAsJsonObject() : new JsonObject();
        return new LastRoom(
                !text(item, "world_id").isBlank(), text(item, "name"),
                text(item, "description"), text(item, "world_name"),
                bool(item, "global"), "public".equals(text(item, "visibility")),
                bool(item, "hardcore")
        );
    }

    public static Tweaks tweaks() {
        JsonElement value = state.get("tweaks");
        JsonObject item = value != null && value.isJsonObject()
                ? value.getAsJsonObject() : new JsonObject();
        return new Tweaks(
                bool(item, "keystrokes"), bool(item, "fps_counter"),
                bool(item, "ultra_optimized")
        );
    }

    public static List<Friend> friends() {
        List<Friend> result = new ArrayList<>();
        for (JsonElement value : array(state, "friends")) {
            if (!value.isJsonObject()) continue;
            JsonObject item = value.getAsJsonObject();
            result.add(new Friend(
                    text(item, "id"), text(item, "display_name"),
                    bool(item, "online"), bool(item, "katcraft"),
                    text(item, "game_nickname"), text(item, "rank")
            ));
        }
        return result;
    }

    public static List<Invite> invites() {
        List<Invite> result = new ArrayList<>();
        for (JsonElement value : array(state, "invites")) {
            if (!value.isJsonObject()) continue;
            JsonObject item = value.getAsJsonObject();
            result.add(new Invite(
                    number(item, "id"), text(item, "display_name"),
                    text(item, "host"), (int) number(item, "port"),
                    text(item, "version"), text(item, "loader")
            ));
        }
        return result;
    }

    public static List<PublicRoom> publicRooms() {
        List<PublicRoom> result = new ArrayList<>();
        for (JsonElement value : array(state, "public_rooms")) {
            if (!value.isJsonObject()) continue;
            JsonObject item = value.getAsJsonObject();
            int modCount = item.has("mods") && item.get("mods").isJsonArray()
                    ? item.getAsJsonArray("mods").size() : 0;
            result.add(new PublicRoom(
                    text(item, "id"), text(item, "name"), text(item, "description"),
                    text(item, "owner_name"), text(item, "host"),
                    (int) number(item, "port"), text(item, "minecraft_version"),
                    text(item, "loader"), text(item, "loader_version"),
                    (int) number(item, "players_online"),
                    (int) number(item, "players_max"), modCount
            ));
        }
        return result;
    }

    public static Room room() {
        JsonElement value = state.get("room");
        JsonObject item = value != null && value.isJsonObject()
                ? value.getAsJsonObject() : new JsonObject();
        return new Room(
                bool(item, "active"), text(item, "host"),
                (int) number(item, "port"), (int) number(item, "local_port"),
                text(item, "status"),
                text(item, "error"), text(item, "world_name"),
                bool(item, "hardcore")
        );
    }

    public static String text(JsonObject object, String key) {
        try {
            JsonElement value = object.get(key);
            return value == null || value.isJsonNull() ? "" : value.getAsString();
        } catch (RuntimeException ignored) { return ""; }
    }

    public static boolean bool(JsonObject object, String key) {
        try {
            JsonElement value = object.get(key);
            return value != null && !value.isJsonNull() && value.getAsBoolean();
        } catch (RuntimeException ignored) { return false; }
    }

    private static long number(JsonObject object, String key) {
        try {
            JsonElement value = object.get(key);
            return value == null || value.isJsonNull() ? 0 : value.getAsLong();
        } catch (RuntimeException ignored) { return 0; }
    }

    private static JsonArray array(JsonObject object, String key) {
        JsonElement value = object.get(key);
        return value != null && value.isJsonArray() ? value.getAsJsonArray() : new JsonArray();
    }

    private static String normalize(String value) {
        return value.trim().toLowerCase(Locale.ROOT);
    }

    public record Friend(
            String id, String displayName, boolean online, boolean katcraft,
            String gameNickname, String rank
    ) {}
    public record Invite(
            long id, String displayName, String host, int port, String version, String loader
    ) {}
    public record Room(
            boolean active, String host, int port, int localPort,
            String status, String error, String worldName, boolean hardcore
    ) {}
    public record World(String id, String name, String source) {}
    public record Mod(String id, String name, boolean clientOnly, boolean selected) {}
    public record Skin(String id, String name, boolean active) {}
    public record Cape(String id, String name, String kind, boolean active) {}
    public record Player(String id, String displayName, String gameNickname, String rank) {}
    public record LastRoom(
            boolean available, String name, String description, String worldName,
            boolean global, boolean publicRoom, boolean hardcore
    ) {}
    public record Tweaks(boolean keystrokes, boolean fpsCounter, boolean ultraOptimized) {}
    public record PublicRoom(
            String id, String name, String description, String ownerName,
            String host, int port, String version, String loader,
            String loaderVersion, int playersOnline, int playersMax, int modCount
    ) {}
}
