package net.katlauncher.katcraft.common;

import com.google.gson.Gson;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

public record BridgeConfig(
        int schema, int port, String token, String nickname,
        String minecraft_version, String loader, String launcher_version
) {
    private static final Gson GSON = new Gson();

    public static BridgeConfig load(Path configDirectory) throws IOException {
        Path path = configDirectory.resolve("katcraft.json");
        return GSON.fromJson(Files.readString(path, StandardCharsets.UTF_8), BridgeConfig.class);
    }
}
