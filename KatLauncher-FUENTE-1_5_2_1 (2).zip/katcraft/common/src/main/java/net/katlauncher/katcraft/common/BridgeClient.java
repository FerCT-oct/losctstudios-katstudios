package net.katlauncher.katcraft.common;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Path;
import java.time.Duration;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.CompletableFuture;

public final class BridgeClient {
    private static final Gson GSON = new Gson();
    private static final HttpClient HTTP = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(2)).build();
    private static volatile BridgeConfig config;
    private static volatile Path configDirectory;

    private BridgeClient() {}

    public static void configure(Path directory) {
        configDirectory = directory;
        config = null;
        try {
            KatCraftState.markLocalPlayer(config().nickname());
        } catch (IOException ignored) {
        }
    }

    public static BridgeConfig config() throws IOException {
        BridgeConfig current = config;
        if (current == null) {
            if (configDirectory == null) throw new IOException("KatCraft no está configurado");
            current = BridgeConfig.load(configDirectory);
            config = current;
        }
        return current;
    }

    public static CompletableFuture<Void> refresh() {
        return request("GET", "/v1/state", null).thenAccept(KatCraftState::update);
    }

    public static CompletableFuture<Void> presence(Collection<String> players, boolean active) {
        JsonObject body = new JsonObject();
        body.addProperty("active", active);
        JsonArray names = new JsonArray();
        players.stream().limit(100).forEach(names::add);
        body.add("players", names);
        return request("POST", "/v1/presence", body).thenAccept(KatCraftState::updatePlayers);
    }

    public static CompletableFuture<Void> invite(
            String friendId, String host, int port, String version, String loader
    ) {
        JsonObject body = new JsonObject();
        body.addProperty("friend_id", friendId);
        body.addProperty("host", host);
        body.addProperty("port", port);
        body.addProperty("version", version);
        body.addProperty("loader", loader);
        return request("POST", "/v1/invites", body).thenAccept(ignored -> {});
    }

    public static CompletableFuture<Void> respond(long inviteId, boolean accept) {
        JsonObject body = new JsonObject();
        body.addProperty("invite_id", inviteId);
        body.addProperty("accept", accept);
        return request("POST", "/v1/invites/respond", body).thenAccept(ignored -> {});
    }

    public static CompletableFuture<Void> startRoom(
            int ramMb, int port, boolean global, boolean acceptEula,
            String worldId, String worldName, boolean createWorld,
            boolean hardcore
    ) {
        return startRoom(ramMb, port, global, global, acceptEula,
                "Sala de KatCraft", "Sala creada dentro de Minecraft",
                worldId, worldName, createWorld, hardcore, null);
    }

    public static CompletableFuture<Void> startRoom(
            int ramMb, int port, boolean global, boolean publicRoom,
            boolean acceptEula, String name, String description,
            String worldId, String worldName, boolean createWorld,
            boolean hardcore, Collection<String> selectedMods
    ) {
        JsonObject body = new JsonObject();
        body.addProperty("ram_mb", ramMb);
        body.addProperty("port", port);
        body.addProperty("global", global);
        body.addProperty("accept_eula", acceptEula);
        body.addProperty("name", name == null ? "Sala de KatCraft" : name);
        body.addProperty("description", description == null ? "" : description);
        body.addProperty("public", publicRoom);
        body.addProperty("world_id", worldId == null ? "" : worldId);
        body.addProperty("world_name", worldName == null ? "Nuevo mundo Kat" : worldName);
        body.addProperty("create_world", createWorld);
        body.addProperty("hardcore", hardcore);
        if (selectedMods != null) {
            JsonArray mods = new JsonArray();
            selectedMods.stream().limit(500).forEach(mods::add);
            body.add("selected_mods", mods);
        }
        return request("POST", "/v1/rooms/start", body).thenAccept(ignored -> {});
    }

    public static CompletableFuture<Void> continueLastRoom(boolean acceptEula) {
        JsonObject body = new JsonObject();
        body.addProperty("continue_last", true);
        body.addProperty("accept_eula", acceptEula);
        return request("POST", "/v1/rooms/start", body).thenAccept(ignored -> {});
    }

    public static CompletableFuture<Void> startRoom(
            int ramMb, int port, boolean global, boolean acceptEula
    ) {
        return startRoom(
                ramMb, port, global, acceptEula,
                "", "Nuevo mundo Kat", true, false
        );
    }

    public static CompletableFuture<Void> stopRoom() {
        return request("POST", "/v1/rooms/stop", new JsonObject())
                .thenAccept(ignored -> {});
    }

    public static CompletableFuture<Void> restartRoom() {
        return request("POST", "/v1/rooms/restart", new JsonObject())
                .thenAccept(ignored -> {});
    }

    public static CompletableFuture<Void> roomCommand(String command) {
        JsonObject body = new JsonObject();
        body.addProperty("command", command);
        return request("POST", "/v1/rooms/command", body).thenAccept(ignored -> {});
    }

    public static CompletableFuture<Void> joinRoom(KatCraftState.PublicRoom room) {
        JsonObject data = new JsonObject();
        data.addProperty("id", room.id());
        data.addProperty("name", room.name());
        data.addProperty("description", room.description());
        data.addProperty("owner_name", room.ownerName());
        data.addProperty("host", room.host());
        data.addProperty("port", room.port());
        data.addProperty("minecraft_version", room.version());
        data.addProperty("loader", room.loader());
        data.addProperty("loader_version", room.loaderVersion());
        JsonObject body = new JsonObject();
        body.add("room", data);
        return request("POST", "/v1/rooms/join", body).thenAccept(ignored -> {});
    }

    public static CompletableFuture<JsonObject> profile(String userId) {
        JsonObject body = new JsonObject();
        body.addProperty("user_id", userId);
        return request("POST", "/v1/profiles/get", body);
    }

    public static CompletableFuture<Void> friendRequest(String userId) {
        JsonObject body = new JsonObject();
        body.addProperty("user_id", userId);
        return request("POST", "/v1/friends/request", body).thenAccept(ignored -> {});
    }

    public static CompletableFuture<JsonObject> unlockTrophy(String trophyId) {
        JsonObject body = new JsonObject();
        body.addProperty("trophy_id", trophyId);
        return request("POST", "/v1/trophies/unlock", body);
    }

    public static CompletableFuture<Void> selectSkin(String skinId) {
        JsonObject body = new JsonObject();
        body.addProperty("skin_id", skinId);
        return request("POST", "/v1/skins/select", body).thenAccept(ignored -> {});
    }

    public static CompletableFuture<Void> updateTweaks(
            boolean keystrokes, boolean fpsCounter, boolean ultraOptimized
    ) {
        JsonObject body = new JsonObject();
        body.addProperty("keystrokes", keystrokes);
        body.addProperty("fps_counter", fpsCounter);
        body.addProperty("ultra_optimized", ultraOptimized);
        return request("POST", "/v1/tweaks", body).thenAccept(ignored -> {});
    }

    private static CompletableFuture<JsonObject> request(
            String method, String path, JsonObject body
    ) {
        try {
            BridgeConfig cfg = config();
            HttpRequest.Builder request = HttpRequest.newBuilder()
                    .uri(URI.create("http://127.0.0.1:" + cfg.port() + path))
                    .timeout(Duration.ofSeconds(4))
                    .header("X-KatCraft-Token", cfg.token())
                    .header("Accept", "application/json");
            if ("POST".equals(method)) {
                request.header("Content-Type", "application/json; charset=utf-8")
                        .POST(HttpRequest.BodyPublishers.ofString(GSON.toJson(body)));
            } else {
                request.GET();
            }
            return HTTP.sendAsync(request.build(), HttpResponse.BodyHandlers.ofString())
                    .thenApply(response -> {
                        if (response.statusCode() / 100 != 2) {
                            throw new IllegalStateException(
                                    "KatLauncher respondió " + response.statusCode());
                        }
                        return GSON.fromJson(response.body(), JsonObject.class);
                    })
                    .exceptionally(error -> {
                        KatCraftState.error("KatLauncher no está disponible");
                        throw new IllegalStateException(error);
                    });
        } catch (IOException | RuntimeException error) {
            KatCraftState.error("Abre KatLauncher para usar KatCraft");
            return CompletableFuture.failedFuture(error);
        }
    }
}
