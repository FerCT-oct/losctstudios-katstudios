# KatCraft

Pulsa `K` dentro de Minecraft para abrir KatCraft. Desde esa pantalla puedes
aceptar la EULA, elegir RAM, activar Kat Global, crear una sala dedicada,
entrar a ella, invitar amigos y detenerla. KatLauncher debe seguir abierto en
la bandeja porque ejecuta el servidor y el túnel autenticado.

Mod cliente oficial de KatLauncher. El código común habla únicamente con el
puente local autenticado de KatLauncher; nunca contiene tokens de Kat Social ni
claves privadas.

Cada combinación incompatible de Minecraft/loader genera su propio artefacto:

- `KatCraft-fabric-<minecraft>-<version>.jar`
- `KatCraft-quilt-<minecraft>-<version>.jar`
- `KatCraft-forge-<minecraft>-<version>.jar`
- `KatCraft-neoforge-<minecraft>-<version>.jar`

El launcher selecciona el `.jar` correcto. “Universal” significa una experiencia
automática para el usuario, no cargar el mismo bytecode en APIs incompatibles.
