package net.katlauncher.katcraft.forge120.mixin;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.resources.ResourceLocation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(AbstractContainerScreen.class)
public abstract class InventoryLogoMixin {
    private static final ResourceLocation KAT_LOGO =
            new ResourceLocation("katcraft", "textures/gui/kat_logo.png");
    @Inject(method = "render", at = @At("TAIL"))
    private void katcraft$inventoryLogo(
            GuiGraphics graphics, int mouseX, int mouseY, float delta, CallbackInfo ci
    ) {
        int size = 32;
        int x = Minecraft.getInstance().getWindow().getGuiScaledWidth() - size - 8;
        int y = 8;
        for (int glow = 5; glow >= 1; glow--) {
            int alpha = 5 + (5 - glow) * 2;
            graphics.fill(x - glow, y - glow, x + size + glow, y + size + glow,
                    (alpha << 24) | 0x9B5DFF);
        }
        graphics.blit(KAT_LOGO, x, y, 0, 0, size, size, 256, 256);
    }
}
