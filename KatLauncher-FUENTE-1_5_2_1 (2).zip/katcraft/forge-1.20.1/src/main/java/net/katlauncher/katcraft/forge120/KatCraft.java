package net.katlauncher.katcraft.forge120;

import com.mojang.blaze3d.platform.InputConstants;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;
import net.katlauncher.katcraft.common.BridgeClient;
import net.katlauncher.katcraft.common.BridgeConfig;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.lwjgl.glfw.GLFW;

@Mod(KatCraft.MOD_ID)
public final class KatCraft {
    public static final String MOD_ID = "katcraft";
    private static final AtomicLong NEXT_REFRESH = new AtomicLong();
    private static boolean rawKeyDown;
    private static final KeyMapping OPEN_KEY = new KeyMapping(
            "key.katcraft.open", InputConstants.Type.KEYSYM,
            InputConstants.KEY_K, "category.katcraft.social");

    public KatCraft() {
        FMLJavaModLoadingContext.get().getModEventBus().addListener(this::clientSetup);
        MinecraftForge.EVENT_BUS.register(this);
    }

    private void clientSetup(FMLClientSetupEvent event) {
        event.enqueueWork(() -> {
            BridgeClient.configure(Minecraft.getInstance().gameDirectory.toPath().resolve("config"));
            updateWindowTitle();
            BridgeClient.refresh();
        });
    }

    @SubscribeEvent
    public void clientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft client = Minecraft.getInstance();
        boolean rawPressed = GLFW.glfwGetKey(
                client.getWindow().getWindow(), GLFW.GLFW_KEY_K
        ) == GLFW.GLFW_PRESS;
        boolean requested = false;
        while (OPEN_KEY.consumeClick()) requested = true;
        if (rawPressed && !rawKeyDown) requested = true;
        rawKeyDown = rawPressed;
        if (requested && !(client.screen instanceof KatCraftScreen)) {
            client.setScreen(new KatCraftScreen(client.screen));
        }
        long now = System.currentTimeMillis();
        long next = NEXT_REFRESH.get();
        if (now >= next && NEXT_REFRESH.compareAndSet(next, now + 5000L)) {
            BridgeClient.refresh();
            if (client.getConnection() != null) {
                List<String> players = client.getConnection().getOnlinePlayers()
                        .stream().map(info -> info.getProfile().getName()).toList();
                BridgeClient.presence(players, true);
            }
        }
    }

    private static void updateWindowTitle() {
        Minecraft client = Minecraft.getInstance();
        try {
            BridgeConfig config = BridgeClient.config();
            GLFW.glfwSetWindowTitle(
                    client.getWindow().getWindow(),
                    "Minecraft " + config.minecraft_version() + " with KatLauncher");
        } catch (Exception ignored) {
            GLFW.glfwSetWindowTitle(
                    client.getWindow().getWindow(), "Minecraft with KatLauncher");
        }
    }

    @Mod.EventBusSubscriber(
            modid = MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static final class ModEvents {
        @SubscribeEvent
        public static void registerKeys(RegisterKeyMappingsEvent event) {
            event.register(OPEN_KEY);
        }
    }
}
