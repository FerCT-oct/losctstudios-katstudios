package net.katlauncher.katcraft.neoforge121;

import com.mojang.blaze3d.platform.InputConstants;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;
import net.katlauncher.katcraft.common.BridgeClient;
import net.katlauncher.katcraft.common.BridgeConfig;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import org.lwjgl.glfw.GLFW;

@Mod(value = KatCraft.MOD_ID, dist = Dist.CLIENT)
public final class KatCraft {
    public static final String MOD_ID = "katcraft";
    private static final AtomicLong NEXT_REFRESH = new AtomicLong();
    private static boolean rawKeyDown;
    private static final KeyMapping OPEN_KEY = new KeyMapping(
            "key.katcraft.open", InputConstants.Type.KEYSYM,
            InputConstants.KEY_K, "category.katcraft.social");

    public KatCraft(IEventBus modBus) {
        modBus.addListener(this::clientSetup);
        modBus.addListener(this::registerKeys);
        NeoForge.EVENT_BUS.addListener(this::clientTick);
    }

    private void registerKeys(RegisterKeyMappingsEvent event) {
        event.register(OPEN_KEY);
    }

    private void clientSetup(FMLClientSetupEvent event) {
        event.enqueueWork(() -> {
            Minecraft client = Minecraft.getInstance();
            BridgeClient.configure(client.gameDirectory.toPath().resolve("config"));
            updateWindowTitle(client);
            BridgeClient.refresh();
        });
    }

    private void clientTick(ClientTickEvent.Post event) {
        Minecraft client = Minecraft.getInstance();
        boolean rawPressed = GLFW.glfwGetKey(
                client.getWindow().getWindow(), GLFW.GLFW_KEY_K
        ) == GLFW.GLFW_PRESS;
        boolean requested = false;
        while (OPEN_KEY.consumeClick()) requested = true;
        if (rawPressed && !rawKeyDown) requested = true;
        rawKeyDown = rawPressed;
        if (requested && !(client.screen instanceof KatCraftScreen)) {
            client.setScreen(new KatCraftScreen(client.screen));
        }
        long now = System.currentTimeMillis();
        long next = NEXT_REFRESH.get();
        if (now >= next && NEXT_REFRESH.compareAndSet(next, now + 5000L)) {
            BridgeClient.refresh();
            if (client.getConnection() != null) {
                List<String> players = client.getConnection().getOnlinePlayers()
                        .stream().map(info -> info.getProfile().getName()).toList();
                BridgeClient.presence(players, true);
            }
        }
    }

    private static void updateWindowTitle(Minecraft client) {
        try {
            BridgeConfig config = BridgeClient.config();
            GLFW.glfwSetWindowTitle(
                    client.getWindow().getWindow(),
                    "Minecraft " + config.minecraft_version() + " with KatLauncher");
        } catch (Exception ignored) {
            GLFW.glfwSetWindowTitle(
                    client.getWindow().getWindow(), "Minecraft with KatLauncher");
        }
    }
}
