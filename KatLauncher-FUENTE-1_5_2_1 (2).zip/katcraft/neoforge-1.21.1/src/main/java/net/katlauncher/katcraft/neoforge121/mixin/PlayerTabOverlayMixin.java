package net.katlauncher.katcraft.neoforge121.mixin;

import net.katlauncher.katcraft.common.KatCraftState;
import net.minecraft.client.gui.components.PlayerTabOverlay;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PlayerTabOverlay.class)
public abstract class PlayerTabOverlayMixin {
    @Inject(method = "getNameForDisplay", at = @At("RETURN"), cancellable = true)
    private void katcraft$badge(
            PlayerInfo player, CallbackInfoReturnable<Component> callback
    ) {
        if (KatCraftState.isKatPlayer(player.getProfile().getName())) {
            String rank = KatCraftState.rankForPlayer(player.getProfile().getName());
            String label = switch (rank) {
                case "platinum" -> "[Kat Platinum] ";
                case "diamond" -> "[Kat Diamond] ";
                case "gold" -> "[Kat Gold] ";
                case "bronze" -> "[Kat Bronze] ";
                default -> "[Kat] ";
            };
            int color = switch (rank) {
                case "platinum" -> 0xD18CFF;
                case "diamond" -> 0x55FFFF;
                case "gold" -> 0xFFAA00;
                case "bronze" -> 0xD46A3A;
                default -> 0x55FF55;
            };
            callback.setReturnValue(
                    Component.literal(label).withColor(color)
                            .append(callback.getReturnValue())
            );
        }
    }
}
