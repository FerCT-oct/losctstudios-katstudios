package net.katlauncher.katcraft.neoforge121;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.List;
import net.katlauncher.katcraft.common.BridgeClient;
import net.katlauncher.katcraft.common.BridgeConfig;
import net.katlauncher.katcraft.common.KatCraftState;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.ConnectScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.multiplayer.resolver.ServerAddress;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;

public final class KatCraftScreen extends Screen {
    private static final ResourceLocation LOGO = ResourceLocation.fromNamespaceAndPath(
            "katcraft", "textures/gui/kat_logo.png");
    private final Screen parent;
    private final List<String> lines = new ArrayList<>();
    private String actionStatus = "";
    private boolean eulaAccepted;
    private boolean globalRoom = true;
    private boolean publicRoom;
    private boolean hardcore;
    private int roomRam = 2048;
    private int worldIndex;
    private String roomSignature = "";

    public KatCraftScreen(Screen parent) {
        super(Component.literal("KatCraft"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        rebuildLines();
        int buttonY = 50;
        ServerData current = minecraft.getCurrentServer();
        if (current != null) {
            for (KatCraftState.Friend friend : KatCraftState.friends()) {
                if (buttonY > height - 82) break;
                addRenderableWidget(Button.builder(
                        Component.literal("Invitar a " + friend.displayName()),
                        button -> sendInvite(friend, current)
                ).bounds(width / 2 + 35, buttonY, 145, 20).build());
                buttonY += 23;
            }
        }
        int playerY = 50;
        for (KatCraftState.Player player : KatCraftState.serverPlayers()) {
            if (playerY > height - 160) break;
            Button request = Button.builder(Component.literal("Amigar · " + player.gameNickname()),
                    button -> BridgeClient.friendRequest(player.id()).whenComplete(
                            (value,error) -> minecraft.execute(() -> {
                                actionStatus = error == null ? "Solicitud enviada" : "Solicitud fallida";
                                rebuildLines();
                            }))).bounds(width / 2 - 176, playerY, 145, 20).build();
            request.active = !player.id().isBlank();
            addRenderableWidget(request); playerY += 23;
        }
        int inviteY = Math.max(buttonY + 8, 150);
        for (KatCraftState.Invite invite : KatCraftState.invites()) {
            if (inviteY > height - 82) break;
            addRenderableWidget(Button.builder(
                    Component.literal("Unirse: " + invite.displayName()),
                    button -> acceptAndJoin(invite)
            ).bounds(width / 2 + 35, inviteY, 110, 20).build());
            addRenderableWidget(Button.builder(
                    Component.literal("×"), button -> reject(invite)
            ).bounds(width / 2 + 150, inviteY, 30, 20).build());
            inviteY += 23;
        }
        addRoomWidgets();
        addRenderableWidget(Button.builder(
                Component.literal("Actualizar"),
                button -> BridgeClient.refresh().whenComplete((ignored, error) ->
                        minecraft.execute(() -> {
                            actionStatus = error == null ? "Actualizado" : "No se pudo actualizar";
                            rebuild();
                        }))
        ).bounds(width / 2 - 105, height - 32, 100, 20).build());
        addRenderableWidget(Button.builder(
                Component.literal("Cerrar"), button -> onClose()
        ).bounds(width / 2 + 5, height - 32, 100, 20).build());
    }

    private void rebuild() { clearWidgets(); init(); }

    private void addRoomWidgets() {
        KatCraftState.Room room = KatCraftState.room();
        int y = height - 132;
        addRenderableWidget(Button.builder(Component.literal("RAM: " + roomRam + " MB"),
                button -> { roomRam = roomRam >= 6144 ? 2048 : roomRam + 2048; rebuild(); })
                .bounds(width / 2 - 176, y, 105, 20).build());
        addRenderableWidget(Button.builder(Component.literal(globalRoom ? "Global: Sí" : "Global: No"),
                button -> { globalRoom = !globalRoom; rebuild(); })
                .bounds(width / 2 - 66, y, 92, 20).build());
        addRenderableWidget(Button.builder(Component.literal(publicRoom ? "Pública: Sí" : "Privada: Sí"),
                button -> { publicRoom = !publicRoom; rebuild(); })
                .bounds(width / 2 - 66, y - 24, 92, 20).build());
        addRenderableWidget(Button.builder(Component.literal(eulaAccepted ? "EULA: Aceptada" : "Aceptar EULA"),
                button -> { eulaAccepted = !eulaAccepted; rebuild(); })
                .bounds(width / 2 + 31, y, 145, 20).build());
        KatCraftState.World selectedWorld = selectedWorld();
        addRenderableWidget(Button.builder(Component.literal(
                        selectedWorld == null ? "Mundo: Crear uno nuevo"
                                : "Mundo: " + selectedWorld.name()),
                button -> cycleWorld()).bounds(width / 2 - 176, y + 24, 242, 20).build());
        addRenderableWidget(Button.builder(Component.literal(
                        hardcore ? "Hardcore: Sí" : "Hardcore: No"),
                button -> { hardcore = !hardcore; rebuild(); })
                .bounds(width / 2 + 71, y + 24, 105, 20).build());
        if (room.active()) {
            addRenderableWidget(Button.builder(Component.literal("Entrar"),
                    button -> joinRoom(room)).bounds(width / 2 - 176, y + 48, 110, 20).build());
            addRenderableWidget(Button.builder(Component.literal("Reiniciar"),
                    button -> BridgeClient.restartRoom().whenComplete((v,e)->minecraft.execute(this::refreshRoom)))
                    .bounds(width / 2 - 61, y + 48, 110, 20).build());
            addRenderableWidget(Button.builder(Component.literal("Detener sala"),
                    button -> BridgeClient.stopRoom().whenComplete(
                            (ignored, error) -> minecraft.execute(this::refreshRoom)))
                    .bounds(width / 2 + 54, y + 48, 122, 20).build());
        } else {
            Button create = Button.builder(Component.literal("Crear sala dentro de Minecraft"),
                    button -> createRoom()).bounds(width / 2 - 176, y + 48, 352, 20).build();
            create.active = eulaAccepted && !"starting".equals(room.status());
            addRenderableWidget(create);
            Button resume = Button.builder(Component.literal("Continuar sala anterior"),
                    button -> BridgeClient.continueLastRoom(eulaAccepted).whenComplete(
                            (v,e)->minecraft.execute(this::refreshRoom)))
                    .bounds(width / 2 - 176, y + 72, 352, 20).build();
            resume.active = eulaAccepted && KatCraftState.lastRoom().available();
            addRenderableWidget(resume);
        }
    }

    private KatCraftState.World selectedWorld() {
        List<KatCraftState.World> worlds = KatCraftState.worlds();
        return worldIndex > 0 && worldIndex <= worlds.size()
                ? worlds.get(worldIndex - 1) : null;
    }

    private void cycleWorld() {
        int choices = KatCraftState.worlds().size() + 1;
        worldIndex = choices <= 1 ? 0 : (worldIndex + 1) % choices;
        rebuild();
    }

    private void createRoom() {
        actionStatus = "Preparando sala Kat Global…";
        KatCraftState.World world = selectedWorld();
        BridgeClient.startRoom(
                roomRam, 25565, globalRoom, publicRoom, eulaAccepted,
                "Sala de KatCraft", "Sala creada dentro de Minecraft",
                world == null ? "" : world.id(),
                world == null ? "Nuevo mundo Kat" : world.name(),
                world == null, hardcore, null)
                .whenComplete((ignored, error) -> minecraft.execute(() -> {
                    actionStatus = error == null ? "Sala solicitada; espera unos segundos"
                            : "No se pudo crear la sala";
                    refreshRoom();
                }));
    }

    private void refreshRoom() {
        BridgeClient.refresh().whenComplete((ignored, error) -> minecraft.execute(this::rebuild));
    }

    private void joinRoom(KatCraftState.Room room) {
        ServerAddress address = new ServerAddress(
                room.localPort() > 0 ? "127.0.0.1" : room.host(),
                room.localPort() > 0 ? room.localPort() : room.port());
        ServerData data = new ServerData(
                "Mi sala Kat Global", address.toString(), ServerData.Type.OTHER);
        ConnectScreen.startConnecting(this, minecraft, address, data, false, null);
    }

    @Override
    public void tick() {
        super.tick();
        KatCraftState.Room room = KatCraftState.room();
        String signature = room.status() + "|" + room.host() + "|" + room.port();
        if (!signature.equals(roomSignature)) { roomSignature = signature; rebuild(); }
    }

    private void sendInvite(KatCraftState.Friend friend, ServerData server) {
        ServerAddress address = ServerAddress.parseString(server.ip);
        try {
            BridgeConfig config = BridgeClient.config();
            BridgeClient.invite(
                    friend.id(), address.getHost(), address.getPort(),
                    config.minecraft_version(), config.loader()
            ).whenComplete((ignored, error) -> minecraft.execute(() -> {
                actionStatus = error == null
                        ? "Invitación enviada a " + friend.displayName()
                        : "No se pudo enviar la invitación";
                rebuildLines();
            }));
        } catch (Exception error) {
            actionStatus = "KatLauncher no está disponible";
            rebuildLines();
        }
    }

    private void acceptAndJoin(KatCraftState.Invite invite) {
        BridgeClient.respond(invite.id(), true);
        ServerAddress address = new ServerAddress(invite.host(), invite.port());
        ServerData data = new ServerData(
                "Invitación de " + invite.displayName(),
                address.toString(), ServerData.Type.OTHER);
        ConnectScreen.startConnecting(this, minecraft, address, data, false, null);
    }

    private void reject(KatCraftState.Invite invite) {
        BridgeClient.respond(invite.id(), false).whenComplete((ignored, error) ->
                minecraft.execute(() -> {
                    actionStatus = error == null ? "Invitación rechazada" : "No se pudo rechazar";
                    BridgeClient.refresh().whenComplete((value, refreshError) ->
                            minecraft.execute(this::rebuild));
                }));
    }

    private void rebuildLines() {
        lines.clear();
        lines.add(KatCraftState.status());
        KatCraftState.Room room = KatCraftState.room();
        lines.add("Sala: " + (room.active() ? room.host() + ":" + room.port()
                : room.status().isBlank() ? "inactiva" : room.status()));
        if (!room.error().isBlank()) lines.add("Error: " + room.error());
        if (!actionStatus.isBlank()) lines.add(actionStatus);
        lines.add("");
        lines.add("Insignias");
        int unlocked = 0;
        for (JsonElement value : KatCraftState.trophies()) {
            JsonObject trophy = value.getAsJsonObject();
            if (KatCraftState.bool(trophy, "unlocked")) {
                lines.add("★ " + KatCraftState.text(trophy, "title")
                        + " · " + KatCraftState.text(trophy, "tier"));
                unlocked++;
            }
        }
        if (unlocked == 0) lines.add("Aún no hay insignias desbloqueadas");
        lines.add("");
        lines.add("Amigos");
        for (KatCraftState.Friend friend : KatCraftState.friends()) {
            lines.add((friend.katcraft() ? "[KAT] " : "")
                    + (friend.online() ? "● " : "○ ") + friend.displayName());
        }
        if (KatCraftState.friends().isEmpty()) lines.add("No hay amigos para mostrar");
        lines.add("");
        lines.add("Invitaciones");
        for (KatCraftState.Invite invite : KatCraftState.invites()) {
            lines.add(invite.displayName() + " → " + invite.host() + ":"
                    + invite.port() + " · " + invite.version() + " " + invite.loader());
        }
        if (KatCraftState.invites().isEmpty()) lines.add("No tienes invitaciones activas");
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float delta) {
        graphics.fill(width / 2 - 190, 18, width / 2 + 190, height - 42, 0xE6101320);
        graphics.renderOutline(width / 2 - 190, 18, 380, height - 60, 0xFF7048FF);
        graphics.blit(LOGO, width / 2 - 176, 24, 0, 0, 42, 42, 256, 256);
        graphics.drawString(font, title, width / 2 - 126, 30, 0xFFFFFFFF, true);
        int y = 72;
        for (String line : lines) {
            if (y > height - 54) break;
            graphics.drawString(font, line, width / 2 - 176, y, 0xFFE7E2FF, false);
            y += 12;
        }
        super.render(graphics, mouseX, mouseY, delta);
    }

    @Override
    public void onClose() { minecraft.setScreen(parent); }
}
