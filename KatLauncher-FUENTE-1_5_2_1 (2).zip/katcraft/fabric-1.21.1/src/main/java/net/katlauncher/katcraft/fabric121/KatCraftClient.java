package net.katlauncher.katcraft.fabric121;

import com.mojang.blaze3d.platform.InputConstants;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.loader.api.FabricLoader;
import net.katlauncher.katcraft.common.BridgeClient;
import net.katlauncher.katcraft.common.BridgeConfig;
import net.katlauncher.katcraft.common.KatCraftState;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.toasts.SystemToast;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Items;
import org.lwjgl.glfw.GLFW;

public final class KatCraftClient implements ClientModInitializer {
    private static final AtomicLong NEXT_REFRESH = new AtomicLong();
    private KeyMapping openKey;
    private boolean rawKeyDown;
    private boolean eatingPotato;
    private int potatoCount;
    private boolean potatoUnlocked;

    @Override
    public void onInitializeClient() {
        BridgeClient.configure(FabricLoader.getInstance().getConfigDir());
        openKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.katcraft.open",
                InputConstants.Type.KEYSYM,
                InputConstants.KEY_K,
                "category.katcraft.social"
        ));
        ClientLifecycleEvents.CLIENT_STARTED.register(client -> {
            updateWindowTitle(client);
            BridgeClient.refresh();
        });
        ClientLifecycleEvents.CLIENT_STOPPING.register(client ->
                BridgeClient.presence(List.of(), false));
        HudRenderCallback.EVENT.register((graphics, tickCounter) -> renderHud(graphics));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            checkPotatoAchievement(client);
            boolean rawPressed = GLFW.glfwGetKey(
                    client.getWindow().getWindow(), GLFW.GLFW_KEY_K
            ) == GLFW.GLFW_PRESS;
            boolean requested = false;
            while (openKey.consumeClick()) requested = true;
            if (rawPressed && !rawKeyDown) requested = true;
            rawKeyDown = rawPressed;
            if (requested && !(client.screen instanceof KatCraftScreen)) {
                client.setScreen(new KatCraftScreen(client.screen));
            }
            long now = System.currentTimeMillis();
            long next = NEXT_REFRESH.get();
            if (now >= next && NEXT_REFRESH.compareAndSet(next, now + 5000L)) {
                BridgeClient.refresh();
                applyUltraOptimized(client);
                if (client.getConnection() != null) {
                    List<String> players = client.getConnection().getOnlinePlayers()
                            .stream().map(info -> info.getProfile().getName()).toList();
                    BridgeClient.presence(players, true);
                }
            }
        });
    }

    private void renderHud(GuiGraphics graphics) {
        Minecraft client = Minecraft.getInstance();
        KatCraftState.Tweaks tweaks = KatCraftState.tweaks();
        if (tweaks.fpsCounter()) {
            graphics.fill(5, 5, 75, 20, 0xB0101320);
            graphics.drawString(client.font, "FPS: " + client.getFps(), 10, 10,
                    0xFFFFFFFF, true);
        }
        if (tweaks.keystrokes()) {
            long window = client.getWindow().getWindow();
            String keys = key(window, GLFW.GLFW_KEY_W, "W") + " "
                    + key(window, GLFW.GLFW_KEY_A, "A") + " "
                    + key(window, GLFW.GLFW_KEY_S, "S") + " "
                    + key(window, GLFW.GLFW_KEY_D, "D");
            graphics.fill(5, 24, 92, 39, 0xB0101320);
            graphics.drawString(client.font, keys, 10, 29, 0xFFFFFFFF, true);
        }
    }

    private String key(long window, int code, String label) {
        return GLFW.glfwGetKey(window, code) == GLFW.GLFW_PRESS ? "[" + label + "]" : label;
    }

    private void applyUltraOptimized(Minecraft client) {
        if (!KatCraftState.tweaks().ultraOptimized()) return;
        client.options.renderDistance().set(Math.min(client.options.renderDistance().get(), 8));
        client.options.entityShadows().set(false);
    }

    private void checkPotatoAchievement(Minecraft client) {
        if (potatoUnlocked || client.player == null) return;
        boolean eating = client.player.isUsingItem()
                && client.player.getUseItem().is(Items.POTATO);
        int count = client.player.getInventory().countItem(Items.POTATO);
        if (eating && !eatingPotato) potatoCount = count;
        if (!eating && eatingPotato && count < potatoCount) {
            potatoUnlocked = true;
            BridgeClient.unlockTrophy("first_potato");
            SystemToast.add(client.getToasts(), SystemToast.SystemToastId.PERIODIC_NOTIFICATION,
                    Component.literal("¡Logro KatCraft!"),
                    Component.literal("Primero lo primero"));
        }
        eatingPotato = eating;
    }

    private static void updateWindowTitle(Minecraft client) {
        try {
            BridgeConfig config = BridgeClient.config();
            GLFW.glfwSetWindowTitle(
                    client.getWindow().getWindow(),
                    "Minecraft " + config.minecraft_version() + " with KatLauncher");
        } catch (Exception ignored) {
            GLFW.glfwSetWindowTitle(
                    client.getWindow().getWindow(), "Minecraft with KatLauncher");
        }
    }
}
