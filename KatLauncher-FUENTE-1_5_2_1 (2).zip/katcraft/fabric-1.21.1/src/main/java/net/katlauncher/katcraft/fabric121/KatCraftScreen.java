package net.katlauncher.katcraft.fabric121;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.katlauncher.katcraft.common.BridgeClient;
import net.katlauncher.katcraft.common.BridgeConfig;
import net.katlauncher.katcraft.common.KatCraftState;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.ConnectScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.multiplayer.resolver.ServerAddress;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;

public final class KatCraftScreen extends Screen {
    private static final ResourceLocation LOGO = ResourceLocation.fromNamespaceAndPath(
            "katcraft", "textures/gui/kat_logo.png");
    private static final String[] SECTIONS = {
            "Sala", "Salas", "Jugadores", "Mods", "Tweaks", "Skins", "Trofeos"
    };
    private final Screen parent;
    private final List<String> lines = new ArrayList<>();
    private String actionStatus = "";
    private boolean eulaAccepted;
    private boolean globalRoom = true;
    private boolean publicRoom;
    private boolean hardcore;
    private boolean keystrokes;
    private boolean fpsCounter;
    private boolean ultraOptimized;
    private boolean settingsLoaded;
    private int roomRam = 2048;
    private int worldIndex;
    private int section;
    private int trophyPage;
    private String roomSignature = "";
    private String roomName = "Sala de KatCraft";
    private String roomDescription = "Sala creada dentro de Minecraft";
    private String modQuery = "";
    private final Set<String> selectedMods = new HashSet<>();

    public KatCraftScreen(Screen parent) {
        super(Component.literal("KatCraft"));
        this.parent = parent;
    }

    private int panelWidth() { return Math.min(760, width - 24); }
    private int panelLeft() { return (width - panelWidth()) / 2; }

    @Override
    protected void init() {
        loadSettingsOnce();
        rebuildLines();
        addSectionTabs();
        if (section == 0) addRoomWidgets();
        if (section == 1) addPublicRoomWidgets();
        if (section == 2) addPlayerWidgets();
        if (section == 3) addModWidgets();
        if (section == 4) addTweakWidgets();
        if (section == 5) addSkinWidgets();
        if (section == 6) addTrophyPager();
        addRenderableWidget(Button.builder(
                Component.literal("Actualizar"), button -> refresh()
        ).bounds(width / 2 - 105, height - 32, 100, 20).build());
        addRenderableWidget(Button.builder(
                Component.literal("Cerrar"), button -> onClose()
        ).bounds(width / 2 + 5, height - 32, 100, 20).build());
    }

    private void addSectionTabs() {
        int left = panelLeft() + 14;
        int available = panelWidth() - 28;
        int buttonWidth = (available - (SECTIONS.length - 1) * 4) / SECTIONS.length;
        for (int index = 0; index < SECTIONS.length; index++) {
            final int target = index;
            Button button = Button.builder(
                    Component.literal((section == index ? "● " : "") + SECTIONS[index]),
                    ignored -> { section = target; rebuild(); }
            ).bounds(left + index * (buttonWidth + 4), 70, buttonWidth, 22).build();
            addRenderableWidget(button);
        }
    }

    private void addRoomWidgets() {
        KatCraftState.Room room = KatCraftState.room();
        int left = panelLeft() + 20;
        int available = panelWidth() - 40;
        EditBox name = new EditBox(font, left, 102, available, 20,
                Component.literal("Nombre de la sala"));
        name.setMaxLength(48);
        name.setValue(roomName);
        name.setResponder(value -> roomName = value);
        addRenderableWidget(name);
        EditBox description = new EditBox(font, left, 128, available, 20,
                Component.literal("Descripción"));
        description.setMaxLength(120);
        description.setValue(roomDescription);
        description.setResponder(value -> roomDescription = value);
        addRenderableWidget(description);
        int quarter = (available - 12) / 4;
        int y = 158;
        addRenderableWidget(Button.builder(
                Component.literal("RAM: " + roomRam + " MB"),
                ignored -> { roomRam = roomRam >= 6144 ? 2048 : roomRam + 2048; rebuild(); }
        ).bounds(left, y, quarter, 22).build());
        addRenderableWidget(Button.builder(
                Component.literal(globalRoom ? "Kat Global: Sí" : "Kat Global: No"),
                ignored -> { globalRoom = !globalRoom; rebuild(); }
        ).bounds(left + quarter + 4, y, quarter, 22).build());
        addRenderableWidget(Button.builder(
                Component.literal(publicRoom ? "Pública: Sí" : "Privada: Sí"),
                ignored -> { publicRoom = !publicRoom; rebuild(); }
        ).bounds(left + (quarter + 4) * 2, y, quarter, 22).build());
        addRenderableWidget(Button.builder(
                Component.literal(eulaAccepted ? "✓ EULA aceptada" : "Aceptar EULA"),
                ignored -> { eulaAccepted = !eulaAccepted; rebuild(); }
        ).bounds(left + (quarter + 4) * 3, y, quarter, 22).build());
        KatCraftState.World selectedWorld = selectedWorld();
        addRenderableWidget(Button.builder(Component.literal(
                        selectedWorld == null ? "Mundo: Crear uno nuevo"
                                : "Mundo: " + selectedWorld.name()),
                ignored -> { cycleWorld(); rebuild(); })
                .bounds(left, y + 28, available * 2 / 3 - 2, 22).build());
        addRenderableWidget(Button.builder(Component.literal(
                        hardcore ? "Hardcore: Sí" : "Hardcore: No"),
                ignored -> { hardcore = !hardcore; rebuild(); })
                .bounds(left + available * 2 / 3 + 2, y + 28,
                        available / 3 - 2, 22).build());
        if (room.active()) {
            addRenderableWidget(Button.builder(
                    Component.literal("▶ Entrar a mi sala"), ignored -> joinRoom(room)
            ).bounds(left, y + 56, available / 3 - 3, 24).build());
            addRenderableWidget(Button.builder(
                    Component.literal("↻ Reiniciar"),
                    ignored -> BridgeClient.restartRoom().whenComplete(
                            (value, error) -> minecraft.execute(this::refresh))
            ).bounds(left + available / 3 + 1, y + 56, available / 3 - 2, 24).build());
            addRenderableWidget(Button.builder(
                    Component.literal("■ Detener"),
                    ignored -> BridgeClient.stopRoom().whenComplete(
                            (value, error) -> minecraft.execute(this::refresh))
            ).bounds(left + available * 2 / 3 + 2, y + 56, available / 3 - 2, 24).build());
        } else {
            Button create = Button.builder(
                    Component.literal("Crear sala dentro de Minecraft"),
                    ignored -> createRoom()
            ).bounds(left, y + 56, available * 2 / 3 - 2, 24).build();
            create.active = eulaAccepted && !"starting".equals(room.status());
            addRenderableWidget(create);
            Button resume = Button.builder(Component.literal("Continuar anterior"),
                    ignored -> continueLastRoom())
                    .bounds(left + available * 2 / 3 + 2, y + 56,
                            available / 3 - 2, 24).build();
            resume.active = eulaAccepted && KatCraftState.lastRoom().available();
            addRenderableWidget(resume);
        }
    }

    private void loadSettingsOnce() {
        if (settingsLoaded) return;
        settingsLoaded = true;
        KatCraftState.Tweaks value = KatCraftState.tweaks();
        keystrokes = value.keystrokes();
        fpsCounter = value.fpsCounter();
        ultraOptimized = value.ultraOptimized();
        for (KatCraftState.Mod mod : KatCraftState.mods()) {
            if (mod.selected() && !mod.clientOnly()) selectedMods.add(mod.id());
        }
    }

    private KatCraftState.World selectedWorld() {
        List<KatCraftState.World> worlds = KatCraftState.worlds();
        return worldIndex > 0 && worldIndex <= worlds.size()
                ? worlds.get(worldIndex - 1) : null;
    }

    private void cycleWorld() {
        int choices = KatCraftState.worlds().size() + 1;
        worldIndex = choices <= 1 ? 0 : (worldIndex + 1) % choices;
    }

    private void addPublicRoomWidgets() {
        int y = 108;
        int left = panelLeft() + 20;
        int width = panelWidth() - 40;
        for (KatCraftState.PublicRoom room : KatCraftState.publicRooms()) {
            if (y > height - 70) break;
            addRenderableWidget(Button.builder(
                    Component.literal("Unirse · " + room.name() + " · "
                            + room.playersOnline() + "/" + room.playersMax()),
                    ignored -> joinPublicRoom(room)
            ).bounds(left, y, width, 20).build());
            y += 23;
        }
    }

    private void addPlayerWidgets() {
        int y = 108;
        int left = panelLeft() + panelWidth() / 2;
        int width = panelWidth() / 2 - 20;
        for (KatCraftState.Player player : KatCraftState.serverPlayers()) {
            if (y > height - 70) break;
            Button request = Button.builder(
                    Component.literal("Amigar · " + player.gameNickname()),
                    ignored -> BridgeClient.friendRequest(player.id()).whenComplete(
                            (value, error) -> minecraft.execute(() -> {
                                actionStatus = error == null ? "Solicitud enviada"
                                        : "No se pudo enviar la solicitud";
                                rebuildLines();
                            }))
            ).bounds(left, y, width, 20).build();
            request.active = !player.id().isBlank();
            addRenderableWidget(request);
            y += 23;
        }
        ServerData current = minecraft.getCurrentServer();
        if (current != null) addFriendButtons();
        addInviteButtons();
    }

    private void addModWidgets() {
        int left = panelLeft() + 20;
        int width = panelWidth() - 40;
        EditBox search = new EditBox(font, left, 102, width, 20,
                Component.literal("Buscar mods"));
        search.setValue(modQuery);
        search.setResponder(value -> modQuery = value);
        addRenderableWidget(search);
        int y = 128;
        String query = modQuery.trim().toLowerCase();
        for (KatCraftState.Mod mod : KatCraftState.mods()) {
            if (!query.isBlank() && !mod.name().toLowerCase().contains(query)) continue;
            if (y > height - 70) break;
            boolean enabled = selectedMods.contains(mod.id());
            Button button = Button.builder(Component.literal(
                    mod.clientOnly() ? "CLIENTE · " + mod.name()
                            : (enabled ? "✓ " : "○ ") + mod.name()),
                    ignored -> {
                        if (selectedMods.contains(mod.id())) selectedMods.remove(mod.id());
                        else selectedMods.add(mod.id());
                        rebuild();
                    }).bounds(left, y, width, 20).build();
            button.active = !mod.clientOnly();
            addRenderableWidget(button);
            y += 23;
        }
    }

    private void addTweakWidgets() {
        int left = panelLeft() + 20;
        int width = panelWidth() - 40;
        addRenderableWidget(Button.builder(Component.literal(
                        "Keystrokes: " + (keystrokes ? "Sí" : "No")),
                ignored -> { keystrokes = !keystrokes; saveTweaks(); })
                .bounds(left, 108, width, 22).build());
        addRenderableWidget(Button.builder(Component.literal(
                        "Contador FPS: " + (fpsCounter ? "Sí" : "No")),
                ignored -> { fpsCounter = !fpsCounter; saveTweaks(); })
                .bounds(left, 136, width, 22).build());
        addRenderableWidget(Button.builder(Component.literal(
                        "Ultra Optimized: " + (ultraOptimized ? "Sí" : "No")),
                ignored -> { ultraOptimized = !ultraOptimized; saveTweaks(); })
                .bounds(left, 164, width, 22).build());
    }

    private void saveTweaks() {
        BridgeClient.updateTweaks(keystrokes, fpsCounter, ultraOptimized);
        actionStatus = "Tweaks guardados";
        rebuild();
    }

    private void addSkinWidgets() {
        int left = panelLeft() + 20;
        int width = panelWidth() - 40;
        int y = 108;
        for (KatCraftState.Cape cape : KatCraftState.capes()) {
            addRenderableWidget(Button.builder(Component.literal(
                            "Capa visible · " + cape.name() + " · " + cape.kind()),
                    ignored -> {})
                    .bounds(left, y, width, 20).build()).active = false;
            y += 23;
        }
        for (KatCraftState.Skin skin : KatCraftState.skins()) {
            if (y > height - 70) break;
            addRenderableWidget(Button.builder(Component.literal(
                            (skin.active() ? "✓ Activa · " : "Usar · ") + skin.name()),
                    ignored -> BridgeClient.selectSkin(skin.id()).whenComplete(
                            (value, error) -> minecraft.execute(() -> {
                                actionStatus = error == null
                                        ? "Skin cambiada; KatSkin se está sincronizando"
                                        : "No se pudo cambiar la skin";
                                refresh();
                            })))
                    .bounds(left, y, width, 20).build());
            y += 23;
        }
    }

    private void addFriendButtons() {
        ServerData current = minecraft.getCurrentServer();
        if (current == null) return;
        int y = 108;
        int x = panelLeft() + panelWidth() / 2 + 12;
        int buttonWidth = panelWidth() / 2 - 32;
        for (KatCraftState.Friend friend : KatCraftState.friends()) {
            if (y > height - 70) break;
            addRenderableWidget(Button.builder(
                    Component.literal("Invitar a " + friend.displayName()),
                    ignored -> sendInvite(friend, current)
            ).bounds(x, y, buttonWidth, 20).build());
            y += 23;
        }
    }

    private void addInviteButtons() {
        int y = 108;
        int x = panelLeft() + panelWidth() / 2;
        int widthRight = panelWidth() / 2 - 24;
        for (KatCraftState.Invite invite : KatCraftState.invites()) {
            if (y > height - 70) break;
            addRenderableWidget(Button.builder(
                    Component.literal("Unirse: " + invite.displayName()),
                    ignored -> acceptAndJoin(invite)
            ).bounds(x, y, widthRight - 36, 20).build());
            addRenderableWidget(Button.builder(
                    Component.literal("×"), ignored -> reject(invite)
            ).bounds(x + widthRight - 32, y, 32, 20).build());
            y += 23;
        }
    }

    private void addTrophyPager() {
        int unlocked = unlockedTrophies().size();
        int pages = Math.max(1, (unlocked + 11) / 12);
        trophyPage = Math.max(0, Math.min(trophyPage, pages - 1));
        Button previous = Button.builder(Component.literal("◀"),
                ignored -> { trophyPage--; rebuild(); })
                .bounds(width / 2 - 105, height - 58, 45, 20).build();
        previous.active = trophyPage > 0;
        addRenderableWidget(previous);
        Button next = Button.builder(Component.literal("▶"),
                ignored -> { trophyPage++; rebuild(); })
                .bounds(width / 2 + 60, height - 58, 45, 20).build();
        next.active = trophyPage + 1 < pages;
        addRenderableWidget(next);
    }

    private void createRoom() {
        KatCraftState.World world = selectedWorld();
        actionStatus = "Preparando sala Kat Global…";
        BridgeClient.startRoom(
                roomRam, 25565, globalRoom, publicRoom, eulaAccepted,
                roomName, roomDescription,
                world == null ? "" : world.id(),
                world == null ? "Nuevo mundo Kat" : world.name(),
                world == null, hardcore, selectedMods
        )
                .whenComplete((value, error) -> minecraft.execute(() -> {
                    actionStatus = error == null
                            ? "Sala solicitada; espera unos segundos"
                            : "No se pudo crear la sala";
                    refresh();
                }));
    }

    private void continueLastRoom() {
        actionStatus = "Cargando tu sala anterior…";
        BridgeClient.continueLastRoom(eulaAccepted).whenComplete((value, error) ->
                minecraft.execute(() -> {
                    actionStatus = error == null ? "Sala anterior solicitada"
                            : "No se pudo continuar la sala";
                    refresh();
                }));
    }

    private void joinPublicRoom(KatCraftState.PublicRoom room) {
        try {
            BridgeConfig config = BridgeClient.config();
            if (config.minecraft_version().equals(room.version())
                    && config.loader().equalsIgnoreCase(room.loader())) {
                connect(room.host(), room.port(), room.name());
            } else {
                BridgeClient.joinRoom(room);
                actionStatus = "KatLauncher preparará la instancia compatible";
            }
        } catch (Exception error) {
            actionStatus = "Abre KatLauncher para entrar";
        }
        rebuildLines();
    }

    private void refresh() {
        BridgeClient.refresh().whenComplete((value, error) ->
                minecraft.execute(this::rebuild));
    }

    private void rebuild() { clearWidgets(); init(); }

    private void sendInvite(KatCraftState.Friend friend, ServerData server) {
        ServerAddress address = ServerAddress.parseString(server.ip);
        try {
            BridgeConfig config = BridgeClient.config();
            BridgeClient.invite(friend.id(), address.getHost(), address.getPort(),
                    config.minecraft_version(), config.loader())
                    .whenComplete((value, error) -> minecraft.execute(() -> {
                        actionStatus = error == null
                                ? "Invitación enviada a " + friend.displayName()
                                : "No se pudo enviar la invitación";
                        rebuildLines();
                    }));
        } catch (Exception error) {
            actionStatus = "KatLauncher no está disponible";
            rebuildLines();
        }
    }

    private void acceptAndJoin(KatCraftState.Invite invite) {
        BridgeClient.respond(invite.id(), true);
        connect(invite.host(), invite.port(), "Invitación de " + invite.displayName());
    }

    private void joinRoom(KatCraftState.Room room) {
        connect(room.localPort() > 0 ? "127.0.0.1" : room.host(),
                room.localPort() > 0 ? room.localPort() : room.port(),
                "Mi sala Kat Global");
    }

    private void connect(String host, int port, String name) {
        ServerAddress address = new ServerAddress(host, port);
        ServerData data = new ServerData(name, address.toString(), ServerData.Type.OTHER);
        ConnectScreen.startConnecting(this, minecraft, address, data, false, null);
    }

    private void reject(KatCraftState.Invite invite) {
        BridgeClient.respond(invite.id(), false).whenComplete((value, error) ->
                minecraft.execute(() -> {
                    actionStatus = error == null
                            ? "Invitación rechazada" : "No se pudo rechazar";
                    refresh();
                }));
    }

    private List<JsonObject> unlockedTrophies() {
        List<JsonObject> result = new ArrayList<>();
        for (JsonElement value : KatCraftState.trophies()) {
            if (value.isJsonObject() && KatCraftState.bool(value.getAsJsonObject(), "unlocked")) {
                result.add(value.getAsJsonObject());
            }
        }
        return result;
    }

    private void rebuildLines() {
        lines.clear();
        lines.add(KatCraftState.status());
        if (!actionStatus.isBlank()) lines.add(actionStatus);
        lines.add("");
        if (section == 0) {
            KatCraftState.Room room = KatCraftState.room();
            lines.add(room.active()
                    ? "Sala lista: " + room.host() + ":" + room.port()
                    : "Estado de sala: " + (room.status().isBlank() ? "inactiva" : room.status()));
            if (!room.error().isBlank()) lines.add("Error: " + room.error());
            lines.add("Configura la sala, acepta la EULA y créala sin salir de Minecraft.");
        } else if (section == 1) {
            lines.add("Amigos de Kat Social");
            for (KatCraftState.Friend friend : KatCraftState.friends()) {
                lines.add((friend.katcraft() ? "[KAT] " : "")
                        + (friend.online() ? "● " : "○ ") + friend.displayName());
            }
            if (KatCraftState.friends().isEmpty()) lines.add("No hay amigos para mostrar.");
            if (minecraft.getCurrentServer() == null) {
                lines.add("");
                lines.add("Entra a una sala o servidor para poder enviar invitaciones.");
            }
        } else if (section == 2) {
            lines.add("Invitaciones pendientes");
            for (KatCraftState.Invite invite : KatCraftState.invites()) {
                lines.add(invite.displayName() + " → " + invite.host() + ":"
                        + invite.port() + " · " + invite.version() + " " + invite.loader());
            }
            if (KatCraftState.invites().isEmpty()) lines.add("No tienes invitaciones activas.");
        } else {
            List<JsonObject> trophies = unlockedTrophies();
            int pages = Math.max(1, (trophies.size() + 11) / 12);
            trophyPage = Math.max(0, Math.min(trophyPage, pages - 1));
            lines.add("Trofeos desbloqueados · página " + (trophyPage + 1) + "/" + pages);
            int from = trophyPage * 12;
            int to = Math.min(trophies.size(), from + 12);
            for (int index = from; index < to; index++) {
                JsonObject trophy = trophies.get(index);
                lines.add("★ " + KatCraftState.text(trophy, "title")
                        + " · " + KatCraftState.text(trophy, "tier"));
            }
            if (trophies.isEmpty()) lines.add("Aún no hay trofeos desbloqueados.");
        }
    }

    @Override
    public void tick() {
        super.tick();
        KatCraftState.Room room = KatCraftState.room();
        String signature = room.status() + "|" + room.host() + "|" + room.port();
        if (!signature.equals(roomSignature)) {
            roomSignature = signature;
            rebuild();
        }
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float delta) {
        renderBackground(graphics, mouseX, mouseY, delta);
        int left = panelLeft();
        int panelWidth = panelWidth();
        graphics.fill(left, 18, left + panelWidth, height - 40, 0xF0101320);
        graphics.renderOutline(left, 18, panelWidth, height - 58, 0xFF8157FF);
        graphics.blit(LOGO, left + 12, 24, 0, 0, 42, 42, 256, 256);
        graphics.drawString(font, "KatCraft", left + 62, 30, 0xFFFFFFFF, true);
        graphics.drawString(font, SECTIONS[section], left + 62, 46, 0xFFBFA8FF, false);
        int y = section == 0 ? 108 : 108;
        for (String line : lines) {
            if (y > height - 68) break;
            graphics.drawString(font, line, left + 20, y, 0xFFE7E2FF, false);
            y += 13;
        }
        super.render(graphics, mouseX, mouseY, delta);
    }

    @Override
    public void onClose() { minecraft.setScreen(parent); }
}
