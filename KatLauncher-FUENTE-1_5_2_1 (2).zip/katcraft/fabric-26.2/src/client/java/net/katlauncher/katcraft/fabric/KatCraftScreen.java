package net.katlauncher.katcraft.fabric;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.List;
import java.util.HashSet;
import java.util.Set;
import net.katlauncher.katcraft.common.BridgeClient;
import net.katlauncher.katcraft.common.BridgeConfig;
import net.katlauncher.katcraft.common.KatCraftState;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.ConnectScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.multiplayer.resolver.ServerAddress;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.sounds.SoundEvents;

public final class KatCraftScreen extends Screen {
    private static final Identifier LOGO =
            Identifier.fromNamespaceAndPath("katcraft", "textures/gui/kat_logo.png");
    private static final String[] SECTIONS =
            {"Sala", "Públicas", "Jugadores", "Mods", "Tweaks", "Skins", "Trofeos"};
    private static final float[] KAT_MELODY =
            {1.00F, 1.26F, 1.50F, 1.26F, 1.68F, 1.50F, 1.26F, 1.00F};
    private final Screen parent;
    private final List<String> lines = new ArrayList<>();
    private String actionStatus = "";
    private boolean eulaAccepted;
    private boolean globalRoom = true;
    private boolean publicRoom;
    private boolean hardcore;
    private int roomRam = 2048;
    private int worldIndex;
    private String roomSignature = "";
    private int section;
    private int trophyPage;
    private int tutorialStep;
    private int catClicks;
    private int melodyStep = -1;
    private int melodyDelay;
    private String roomName = "Sala de KatCraft";
    private String roomDescription = "Sala creada dentro de Minecraft";
    private final Set<String> selectedMods = new HashSet<>();
    private boolean keystrokes, fpsCounter, ultraOptimized, settingsLoaded;

    public KatCraftScreen(Screen parent) {
        super(Component.literal("KatCraft"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        loadSettingsOnce();
        rebuildLines();
        addSectionTabs();
        int buttonY = 108;
        ServerData currentServer = minecraft.getCurrentServer();
        if (section == 2 && currentServer != null) {
            for (KatCraftState.Friend friend : KatCraftState.friends()) {
                if (buttonY > height - 82) break;
                KatCraftState.Friend target = friend;
                addRenderableWidget(Button.builder(
                        Component.literal("Invitar a " + friend.displayName()),
                        button -> sendInvite(target, currentServer)
                ).bounds(width / 2 + 35, buttonY, 145, 20).build());
                buttonY += 23;
            }
            int playerY = 108;
            for (KatCraftState.Player player : KatCraftState.serverPlayers()) {
                if (playerY > height - 82) break;
                Button request = Button.builder(
                        Component.literal("Amigar · " + player.gameNickname()),
                        button -> BridgeClient.friendRequest(player.id()).whenComplete(
                                (value, error) -> minecraft.execute(() -> {
                                    actionStatus = error == null ? "Solicitud enviada"
                                            : "No se pudo enviar la solicitud";
                                    rebuildLines();
                                }))
                ).bounds(panelLeft() + 20, playerY, panelWidth() / 2 - 30, 20).build();
                request.active = !player.id().isBlank();
                addRenderableWidget(request);
                playerY += 23;
            }
        }

        if (section == 1) addPublicRoomWidgets();
        if (section == 3) addModWidgets();
        if (section == 4) addTweakWidgets();
        if (section == 5) addSkinWidgets();
        if (section == 0) addRoomWidgets();
        if (section == 6) addTrophyPager();
        Button secretLogo = Button.builder(
                Component.empty(), button -> catEasterEgg()
        ).bounds(panelLeft() + 12, 24, 42, 42).build();
        secretLogo.setAlpha(0.0F);
        addRenderableWidget(secretLogo);

        addRenderableWidget(Button.builder(
                Component.literal("Actualizar"),
                button -> BridgeClient.refresh().whenComplete((ignored, error) ->
                        minecraft.execute(() -> {
                            actionStatus = error == null ? "Actualizado" : "No se pudo actualizar";
                            rebuild();
                        })
                )
        ).bounds(width / 2 - 105, height - 32, 100, 20).build());
        addRenderableWidget(Button.builder(
                Component.literal("Cerrar"), button -> onClose()
        ).bounds(width / 2 + 5, height - 32, 100, 20).build());
    }

    private void rebuild() {
        clearWidgets();
        init();
    }

    private int panelWidth() { return Math.min(760, width - 24); }
    private int panelLeft() { return (width - panelWidth()) / 2; }

    private void addSectionTabs() {
        int left = panelLeft() + 14;
        int available = panelWidth() - 28;
        int buttonWidth = (available - (SECTIONS.length - 1) * 4) / SECTIONS.length;
        for (int index = 0; index < SECTIONS.length; index++) {
            final int target = index;
            addRenderableWidget(Button.builder(
                    Component.literal((section == index ? "● " : "") + SECTIONS[index]),
                    ignored -> { section = target; rebuild(); }
            ).bounds(left + index * (buttonWidth + 4), 70, buttonWidth, 22).build());
        }
    }

    private void addRoomWidgets() {
        KatCraftState.Room room = KatCraftState.room();
        int left = panelLeft() + 20;
        int available = panelWidth() - 40;
        EditBox name = new EditBox(font, left, 102, available, 20, Component.literal("Nombre"));
        name.setMaxLength(48); name.setValue(roomName); name.setResponder(v -> roomName = v);
        addRenderableWidget(name);
        EditBox description = new EditBox(font, left, 128, available, 20, Component.literal("Descripción"));
        description.setMaxLength(120); description.setValue(roomDescription);
        description.setResponder(v -> roomDescription = v); addRenderableWidget(description);
        int third = (available - 8) / 3;
        int y = 158;
        addRenderableWidget(Button.builder(Component.literal("RAM: " + roomRam + " MB"),
                button -> { roomRam = roomRam >= 6144 ? 2048 : roomRam + 2048; rebuild(); })
                .bounds(left, y, third, 22).build());
        addRenderableWidget(Button.builder(Component.literal(globalRoom ? "Global: Sí" : "Global: No"),
                button -> { globalRoom = !globalRoom; rebuild(); })
                .bounds(left + third + 4, y, third, 22).build());
        addRenderableWidget(Button.builder(Component.literal(publicRoom ? "Pública: Sí" : "Privada: Sí"),
                button -> { publicRoom = !publicRoom; rebuild(); })
                .bounds(left + (third + 4) * 2, y, third, 22).build());
        addRenderableWidget(Button.builder(Component.literal(eulaAccepted ? "✓ EULA" : "Aceptar EULA"),
                button -> { eulaAccepted = !eulaAccepted; rebuild(); })
                .bounds(left + available - 92, y + 28, 92, 22).build());
        KatCraftState.World selectedWorld = selectedWorld();
        addRenderableWidget(Button.builder(Component.literal(
                        selectedWorld == null ? "Mundo: Crear uno nuevo"
                                : "Mundo: " + selectedWorld.name()),
                button -> { cycleWorld(); rebuild(); })
                .bounds(left, y + 28, available * 2 / 3 - 2, 22).build());
        addRenderableWidget(Button.builder(Component.literal(
                        hardcore ? "Hardcore: Sí" : "Hardcore: No"),
                button -> { hardcore = !hardcore; rebuild(); })
                .bounds(left + available * 2 / 3 + 2, y + 28,
                        available / 3 - 98, 22).build());
        if (room.active()) {
            addRenderableWidget(Button.builder(Component.literal("Entrar"),
                    button -> joinRoom(room)).bounds(left, y + 56, available / 3 - 3, 24).build());
            addRenderableWidget(Button.builder(Component.literal("Reiniciar"),
                    button -> BridgeClient.restartRoom().whenComplete((v,e)->minecraft.execute(this::refreshRoom)))
                    .bounds(left + available / 3 + 1, y + 56, available / 3 - 2, 24).build());
            addRenderableWidget(Button.builder(Component.literal("Detener sala"),
                    button -> BridgeClient.stopRoom().whenComplete(
                            (ignored, error) -> minecraft.execute(this::refreshRoom)))
                    .bounds(left + available * 2 / 3 + 2, y + 56, available / 3 - 2, 24).build());
        } else {
            Button create = Button.builder(Component.literal("Crear sala dentro de Minecraft"),
                    button -> createRoom()).bounds(left, y + 56, available * 2 / 3 - 2, 24).build();
            create.active = eulaAccepted && !"starting".equals(room.status());
            addRenderableWidget(create);
            Button resume = Button.builder(Component.literal("Continuar anterior"),
                    button -> BridgeClient.continueLastRoom(eulaAccepted)
                            .whenComplete((v,e)->minecraft.execute(this::refreshRoom)))
                    .bounds(left + available * 2 / 3 + 2, y + 56, available / 3 - 2, 24).build();
            resume.active = eulaAccepted && KatCraftState.lastRoom().available();
            addRenderableWidget(resume);
        }
        addRenderableWidget(Button.builder(
                Component.literal("Kat Tutorial"),
                button -> {
                    tutorialStep = (tutorialStep + 1) % 6;
                    actionStatus = switch (tutorialStep) {
                        case 1 -> "1/5: Crea una sala y acepta la EULA.";
                        case 2 -> "2/5: Pública aparece en KatLauncher y KatCraft.";
                        case 3 -> "3/5: Amigos permite invitar desde el servidor actual.";
                        case 4 -> "4/5: Perfiles muestra rango, versión y trofeos.";
                        case 5 -> "5/5: Pulsa K desde cualquier pantalla para volver.";
                        default -> "Tutorial reiniciado. ¡Disfruta KatCraft!";
                    };
                    rebuildLines();
                }
        ).bounds(left, y + 86, available, 22).build());
    }

    private void loadSettingsOnce() {
        if (settingsLoaded) return; settingsLoaded = true;
        KatCraftState.Tweaks t = KatCraftState.tweaks();
        keystrokes=t.keystrokes(); fpsCounter=t.fpsCounter(); ultraOptimized=t.ultraOptimized();
        for (KatCraftState.Mod m:KatCraftState.mods()) if(m.selected()&&!m.clientOnly())selectedMods.add(m.id());
    }
    private void addModWidgets(){int y=108,l=panelLeft()+20,w=panelWidth()-40;for(KatCraftState.Mod m:KatCraftState.mods()){if(y>height-70)break;Button b=Button.builder(Component.literal(m.clientOnly()?"CLIENTE · "+m.name():(selectedMods.contains(m.id())?"✓ ":"○ ")+m.name()),v->{if(selectedMods.contains(m.id()))selectedMods.remove(m.id());else selectedMods.add(m.id());rebuild();}).bounds(l,y,w,20).build();b.active=!m.clientOnly();addRenderableWidget(b);y+=23;}}
    private void addTweakWidgets(){int l=panelLeft()+20,w=panelWidth()-40;addRenderableWidget(Button.builder(Component.literal("Keystrokes: "+(keystrokes?"Sí":"No")),v->{keystrokes=!keystrokes;saveTweaks();}).bounds(l,108,w,22).build());addRenderableWidget(Button.builder(Component.literal("Contador FPS: "+(fpsCounter?"Sí":"No")),v->{fpsCounter=!fpsCounter;saveTweaks();}).bounds(l,136,w,22).build());addRenderableWidget(Button.builder(Component.literal("Ultra Optimized: "+(ultraOptimized?"Sí":"No")),v->{ultraOptimized=!ultraOptimized;saveTweaks();}).bounds(l,164,w,22).build());}
    private void saveTweaks(){BridgeClient.updateTweaks(keystrokes,fpsCounter,ultraOptimized);rebuild();}
    private void addSkinWidgets(){int y=108,l=panelLeft()+20,w=panelWidth()-40;for(KatCraftState.Cape c:KatCraftState.capes()){Button b=Button.builder(Component.literal("Capa · "+c.name()+" · "+c.kind()),v->{}).bounds(l,y,w,20).build();b.active=false;addRenderableWidget(b);y+=23;}for(KatCraftState.Skin s:KatCraftState.skins()){if(y>height-70)break;addRenderableWidget(Button.builder(Component.literal((s.active()?"✓ Activa · ":"Usar · ")+s.name()),v->BridgeClient.selectSkin(s.id()).whenComplete((x,e)->minecraft.execute(this::refreshRoom))).bounds(l,y,w,20).build());y+=23;}}

    private KatCraftState.World selectedWorld() {
        List<KatCraftState.World> worlds = KatCraftState.worlds();
        return worldIndex > 0 && worldIndex <= worlds.size()
                ? worlds.get(worldIndex - 1) : null;
    }

    private void cycleWorld() {
        int choices = KatCraftState.worlds().size() + 1;
        worldIndex = choices <= 1 ? 0 : (worldIndex + 1) % choices;
    }

    private void addPublicRoomWidgets() {
        int y = 108;
        for (KatCraftState.PublicRoom room : KatCraftState.publicRooms()) {
            if (y > height - 82) break;
            KatCraftState.PublicRoom target = room;
            addRenderableWidget(Button.builder(
                    Component.literal("Unirse · " + room.name()),
                    button -> joinPublicRoom(target)
            ).bounds(width / 2 + 5, y, Math.min(210, panelWidth() / 2 - 25), 20).build());
            y += 23;
        }
    }

    private void addProfileWidgets() {
        int y = 108;
        for (KatCraftState.Friend friend : KatCraftState.friends()) {
            if (y > height - 82) break;
            KatCraftState.Friend target = friend;
            addRenderableWidget(Button.builder(
                    Component.literal("Ver · " + friend.displayName()),
                    button -> BridgeClient.profile(target.id()).whenComplete(
                            (profile, error) -> minecraft.execute(() -> {
                                if (error != null || profile == null) {
                                    actionStatus = "No se pudo abrir el perfil";
                                } else {
                                    actionStatus = KatCraftState.text(profile, "display_name")
                                            + " · " + KatCraftState.text(profile, "rank")
                                            + " · KatLauncher "
                                            + KatCraftState.text(profile, "launcher_version");
                                }
                                rebuildLines();
                            })
                    )
            ).bounds(width / 2 + 20, y, Math.min(220, panelWidth() / 2 - 35), 20).build());
            y += 23;
        }
    }

    private void joinPublicRoom(KatCraftState.PublicRoom room) {
        try {
            BridgeConfig config = BridgeClient.config();
            boolean compatible = config.minecraft_version().equals(room.version())
                    && config.loader().equalsIgnoreCase(room.loader());
            if (compatible) {
                ServerAddress address = new ServerAddress(room.host(), room.port());
                ServerData data = new ServerData(
                        room.name(), address.toString(), ServerData.Type.OTHER);
                ConnectScreen.startConnecting(this, minecraft, address, data, false, null);
            } else {
                actionStatus = "KatLauncher creará/abrirá la instancia compatible";
                BridgeClient.joinRoom(room);
                rebuildLines();
            }
        } catch (Exception error) {
            actionStatus = "Abre KatLauncher para preparar esta sala";
            rebuildLines();
        }
    }

    private void catEasterEgg() {
        catClicks++;
        actionStatus = "Miau " + catClicks + "/5";
        if (catClicks >= 5) {
            catClicks = 0;
            melodyStep = 0;
            melodyDelay = 0;
            actionStatus = "♪ Kat tone desbloqueado dentro de Minecraft";
        }
        rebuildLines();
    }

    private void addTrophyPager() {
        int total = 0;
        for (JsonElement value : KatCraftState.trophies()) {
            if (value.isJsonObject()
                    && KatCraftState.bool(value.getAsJsonObject(), "unlocked")) total++;
        }
        int pages = Math.max(1, (total + 11) / 12);
        trophyPage = Math.max(0, Math.min(trophyPage, pages - 1));
        Button previous = Button.builder(Component.literal("◀"),
                ignored -> { trophyPage--; rebuild(); })
                .bounds(width / 2 - 105, height - 58, 45, 20).build();
        previous.active = trophyPage > 0;
        addRenderableWidget(previous);
        Button next = Button.builder(Component.literal("▶"),
                ignored -> { trophyPage++; rebuild(); })
                .bounds(width / 2 + 60, height - 58, 45, 20).build();
        next.active = trophyPage + 1 < pages;
        addRenderableWidget(next);
    }

    private void createRoom() {
        KatCraftState.World world = selectedWorld();
        actionStatus = "Preparando sala Kat Global…";
        BridgeClient.startRoom(
                roomRam, 25565, globalRoom, publicRoom, eulaAccepted,
                roomName, roomDescription,
                world == null ? "" : world.id(),
                world == null ? "Nuevo mundo Kat" : world.name(),
                world == null, hardcore, selectedMods
        )
                .whenComplete((ignored, error) -> minecraft.execute(() -> {
                    actionStatus = error == null ? "Sala solicitada; espera unos segundos"
                            : "No se pudo crear la sala";
                    refreshRoom();
                }));
    }

    private void refreshRoom() {
        BridgeClient.refresh().whenComplete((ignored, error) -> minecraft.execute(this::rebuild));
    }

    private void joinRoom(KatCraftState.Room room) {
        ServerAddress address = new ServerAddress(
                room.localPort() > 0 ? "127.0.0.1" : room.host(),
                room.localPort() > 0 ? room.localPort() : room.port());
        ServerData data = new ServerData(
                "Mi sala Kat Global", address.toString(), ServerData.Type.OTHER);
        ConnectScreen.startConnecting(this, minecraft, address, data, false, null);
    }

    @Override
    public void tick() {
        super.tick();
        if (melodyStep >= 0 && minecraft.player != null) {
            if (melodyDelay-- <= 0) {
                minecraft.player.playSound(
                        SoundEvents.NOTE_BLOCK_HARP.value(), 0.75F,
                        KAT_MELODY[melodyStep]
                );
                melodyStep++;
                melodyDelay = 3;
                if (melodyStep >= KAT_MELODY.length) melodyStep = -1;
            }
        }
        KatCraftState.Room room = KatCraftState.room();
        String signature = room.status() + "|" + room.host() + "|" + room.port();
        if (!signature.equals(roomSignature)) { roomSignature = signature; rebuild(); }
    }

    private void sendInvite(KatCraftState.Friend friend, ServerData server) {
        ServerAddress address = ServerAddress.parseString(server.ip);
        BridgeConfig config;
        try {
            config = BridgeClient.config();
        } catch (Exception error) {
            actionStatus = "KatLauncher no está disponible";
            rebuildLines();
            return;
        }
        BridgeClient.invite(
                friend.id(), address.getHost(), address.getPort(),
                config.minecraft_version(), config.loader()
        ).whenComplete((ignored, error) -> minecraft.execute(() -> {
            actionStatus = error == null
                    ? "Invitación enviada a " + friend.displayName()
                    : "No se pudo enviar la invitación";
            rebuildLines();
        }));
    }

    private void acceptAndJoin(KatCraftState.Invite invite) {
        BridgeClient.respond(invite.id(), true);
        ServerAddress address = new ServerAddress(invite.host(), invite.port());
        ServerData data = new ServerData(
                "Invitación de " + invite.displayName(),
                address.toString(),
                ServerData.Type.OTHER
        );
        ConnectScreen.startConnecting(this, minecraft, address, data, false, null);
    }

    private void reject(KatCraftState.Invite invite) {
        BridgeClient.respond(invite.id(), false).whenComplete((ignored, error) ->
                minecraft.execute(() -> {
                    actionStatus = error == null ? "Invitación rechazada" : "No se pudo rechazar";
                    BridgeClient.refresh().whenComplete((value, refreshError) ->
                            minecraft.execute(this::rebuild));
                })
        );
    }

    private void rebuildLines() {
        lines.clear();
        if (section == 0) {
            KatCraftState.Room room = KatCraftState.room();
            lines.add(KatCraftState.status());
            lines.add("Sala: " + (room.active() ? room.host() + ":" + room.port()
                    : room.status().isBlank() ? "inactiva" : room.status()));
            if (!room.error().isBlank()) lines.add("Error: " + room.error());
            lines.add("");
            lines.add("Crea una sala y comparte Minecraft sin programas externos.");
        } else if (section == 1) {
            lines.add("Salas públicas de KatLauncher");
            for (KatCraftState.PublicRoom room : KatCraftState.publicRooms()) {
                lines.add(room.name() + " · " + room.playersOnline() + "/"
                        + room.playersMax() + " · " + room.version() + " "
                        + room.loader() + " · " + room.modCount() + " mods");
            }
            if (KatCraftState.publicRooms().isEmpty()) lines.add("No hay salas públicas activas");
        } else if (section == 2) {
            lines.add("Amigos de Kat Social");
            for (KatCraftState.Friend friend : KatCraftState.friends()) {
                lines.add((friend.katcraft() ? "[KAT] " : "")
                        + (friend.online() ? "● " : "○ ")
                        + friend.displayName()
                        + (friend.gameNickname().isBlank()
                        ? "" : " · " + friend.gameNickname()));
            }
            if (KatCraftState.friends().isEmpty()) lines.add("No hay amigos para mostrar");
        } else if (section == 3) {
            lines.add("Invitaciones activas");
            for (KatCraftState.Invite invite : KatCraftState.invites()) {
                lines.add(invite.displayName() + " → " + invite.host() + ":"
                        + invite.port() + " · " + invite.version() + " "
                        + invite.loader());
            }
            if (KatCraftState.invites().isEmpty()) lines.add("No tienes invitaciones activas");
        } else if (section == 4) {
            lines.add("Perfiles de Kat Social dentro de KatCraft");
            lines.add("Selecciona un amigo para ver su rango y versión.");
            for (KatCraftState.Friend friend : KatCraftState.friends()) {
                lines.add(friend.displayName() + " · "
                        + (friend.rank().isBlank() ? "Kat" : friend.rank()));
            }
        } else {
            List<String> trophies = new ArrayList<>();
            for (JsonElement value : KatCraftState.trophies()) {
                JsonObject trophy = value.getAsJsonObject();
                if (KatCraftState.bool(trophy, "unlocked")) {
                    trophies.add("★ " + KatCraftState.text(trophy, "title")
                            + " · " + KatCraftState.text(trophy, "tier"));
                }
            }
            int pages = Math.max(1, (trophies.size() + 11) / 12);
            trophyPage = Math.max(0, Math.min(trophyPage, pages - 1));
            lines.add("Trofeos desbloqueados · página " + (trophyPage + 1)
                    + "/" + pages);
            int from = trophyPage * 12;
            int to = Math.min(trophies.size(), from + 12);
            lines.addAll(trophies.subList(from, to));
            if (trophies.isEmpty()) lines.add("Aún no hay insignias desbloqueadas");
        }
        if (!actionStatus.isBlank()) lines.add(actionStatus);
    }

    @Override
    public void extractRenderState(
            GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta
    ) {
        int left = panelLeft();
        int panelWidth = panelWidth();
        graphics.fill(left, 18, left + panelWidth, height - 42, 0xE6101320);
        graphics.outline(left, 18, panelWidth, height - 60, 0xFF7048FF);
        graphics.blit(RenderPipelines.GUI_TEXTURED, LOGO, left + 12, 24,
                0.0F, 0.0F, 42, 42, 256, 256);
        graphics.text(font, title, left + 60, 30, 0xFFFFFFFF, true);
        graphics.text(font, Component.literal(SECTIONS[section]),
                left + 60, 46, 0xFFB7A8E8, false);
        int y = 104;
        for (String line : lines) {
            if (y > height - 68) break;
            graphics.text(font, line, left + 20, y, 0xFFE7E2FF, false);
            y += 12;
        }
        super.extractRenderState(graphics, mouseX, mouseY, delta);
    }

    @Override
    public void onClose() {
        minecraft.setScreenAndShow(parent);
    }
}
