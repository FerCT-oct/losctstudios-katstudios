package net.katlauncher.katcraft.fabric;

import com.mojang.blaze3d.platform.InputConstants;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.loader.api.FabricLoader;
import net.katlauncher.katcraft.common.BridgeClient;
import net.katlauncher.katcraft.common.BridgeConfig;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

public final class KatCraftClient implements ClientModInitializer {
    public static final String MOD_ID = "katcraft";
    private static final AtomicLong NEXT_REFRESH = new AtomicLong();
    private KeyMapping openKey;
    private boolean rawKeyDown;

    @Override
    public void onInitializeClient() {
        BridgeClient.configure(FabricLoader.getInstance().getConfigDir());
        KeyMapping.Category category = KeyMapping.Category.register(
                Identifier.fromNamespaceAndPath(MOD_ID, "social")
        );
        openKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.katcraft.open",
                InputConstants.Type.KEYSYM,
                InputConstants.KEY_K,
                category
        ));

        ClientLifecycleEvents.CLIENT_STARTED.register(client -> {
            updateWindowTitle(client);
            BridgeClient.refresh();
        });
        ClientLifecycleEvents.CLIENT_STOPPING.register(client ->
                BridgeClient.presence(List.of(), false)
        );
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            boolean rawPressed = GLFW.glfwGetKey(
                    client.getWindow().handle(), GLFW.GLFW_KEY_K
            ) == GLFW.GLFW_PRESS;
            boolean requested = false;
            while (openKey.consumeClick()) requested = true;
            if (rawPressed && !rawKeyDown) requested = true;
            rawKeyDown = rawPressed;
            if (requested) {
                client.setScreenAndShow(new KatCraftScreen(null));
            }
            long now = System.currentTimeMillis();
            if (now >= NEXT_REFRESH.get() && NEXT_REFRESH.compareAndSet(
                    NEXT_REFRESH.get(), now + 5000L
            )) {
                BridgeClient.refresh();
                if (client.getConnection() != null) {
                    List<String> players = client.getConnection().getOnlinePlayers()
                            .stream()
                            .map(info -> info.getProfile().name())
                            .toList();
                    BridgeClient.presence(players, true);
                }
            }
        });
    }

    private static void updateWindowTitle(Minecraft client) {
        try {
            BridgeConfig config = BridgeClient.config();
            GLFW.glfwSetWindowTitle(
                    client.getWindow().handle(),
                    "Minecraft " + config.minecraft_version() + " with KatLauncher"
            );
        } catch (Exception ignored) {
            GLFW.glfwSetWindowTitle(
                    client.getWindow().handle(), "Minecraft with KatLauncher"
            );
        }
    }
}
