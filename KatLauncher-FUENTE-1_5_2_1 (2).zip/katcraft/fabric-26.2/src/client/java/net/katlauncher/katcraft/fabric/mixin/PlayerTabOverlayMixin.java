package net.katlauncher.katcraft.fabric.mixin;

import net.katlauncher.katcraft.common.KatCraftState;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.components.PlayerTabOverlay;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PlayerTabOverlay.class)
public abstract class PlayerTabOverlayMixin {
    @Inject(method = "getNameForDisplay", at = @At("RETURN"), cancellable = true)
    private void katcraft$decorate(
            PlayerInfo player, CallbackInfoReturnable<Component> callback
    ) {
        String nickname = player.getProfile().name();
        if (KatCraftState.isKatPlayer(nickname)) {
            String rank = KatCraftState.rankForPlayer(nickname);
            String label = switch (rank) {
                case "platinum" -> "[Kat Platinum] ";
                case "diamond" -> "[Kat Diamond] ";
                case "gold" -> "[Kat Gold] ";
                case "bronze" -> "[Kat Bronze] ";
                default -> "[Kat] ";
            };
            ChatFormatting color = switch (rank) {
                case "platinum" -> ChatFormatting.LIGHT_PURPLE;
                case "diamond" -> ChatFormatting.AQUA;
                case "gold" -> ChatFormatting.GOLD;
                case "bronze" -> ChatFormatting.RED;
                default -> ChatFormatting.GREEN;
            };
            callback.setReturnValue(
                    Component.literal(label)
                            .withStyle(color)
                            .append(callback.getReturnValue())
            );
        }
    }
}
