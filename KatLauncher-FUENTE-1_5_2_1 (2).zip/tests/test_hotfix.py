import json
import sqlite3
import tempfile
import types
import unittest
from pathlib import Path
from unittest import mock

from PySide6.QtWidgets import QApplication, QLineEdit, QPushButton, QWidget

from katlauncher.core import modrinth_api, skins_manager
from katlauncher.core.social_service import SocialHistoryArchive
from katlauncher.core.trophy_manager import PLATINUM, TROPHIES, TrophyManager
from katlauncher.gui.controller_navigation import (
    ControllerFocusIndicator, ControllerNavigator, VirtualKeyboardDialog,
)


class KatSocialHotfixTests(unittest.TestCase):
    def test_local_history_is_deduplicated_and_stays_local(self):
        rows = [{
            "id": 42,
            "sender_id": "kat-user",
            "display_name": "Kat",
            "body": "miau",
            "created_at": "2026-07-23T12:00:00Z",
        }]
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "history.sqlite3"
            archive = SocialHistoryArchive(path)
            self.assertEqual(archive.save(rows, "global"), 1)
            self.assertEqual(archive.save(rows, "global"), 0)
            database = sqlite3.connect(path)
            try:
                saved = database.execute(
                    "select id,scope,body from messages"
                ).fetchall()
            finally:
                database.close()
        self.assertEqual(saved, [(42, "global", "miau")])

    def test_katskin_is_first_and_local_skin_remains_offline_fallback(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source = root / "skin.png"
            source.write_bytes(b"\x89PNG\r\n\x1a\nskin")
            game = root / "game"
            skins_manager.install_local_skin_for_profile(
                str(game),
                "KatPlayer",
                str(source),
                "https://example.supabase.co/storage/v1/object/public/"
                "kat-skins/skins",
            )
            config = json.loads((
                game / "CustomSkinLoader" / "CustomSkinLoader.json"
            ).read_text(encoding="utf-8"))
        self.assertEqual(config["loadlist"][0]["name"], "KatSkin")
        self.assertEqual(
            config["loadlist"][0]["skin"],
            "https://example.supabase.co/storage/v1/object/public/"
            "kat-skins/skins/{USERNAME}.png",
        )
        self.assertEqual(config["loadlist"][1]["name"], "KatLauncherLocal")


class ControlifyHotfixTests(unittest.TestCase):
    def test_controlify_installs_only_when_missing(self):
        with tempfile.TemporaryDirectory() as directory:
            mods = Path(directory)
            profile = types.SimpleNamespace(
                loader="fabric", version="1.21.1", mods_dir=str(mods),
            )
            with mock.patch.object(
                modrinth_api,
                "install_project_latest",
                return_value=str(mods / "controlify.jar"),
            ) as install:
                result = modrinth_api.ensure_controlify(profile)
            self.assertEqual(result, str(mods / "controlify.jar"))
            install.assert_called_once_with(
                "controlify", "fabric", "1.21.1", str(mods),
            )

            existing = mods / "controlify-2.0.jar"
            existing.write_bytes(b"jar")
            with mock.patch.object(
                modrinth_api, "install_project_latest",
            ) as install_again:
                self.assertEqual(
                    modrinth_api.ensure_controlify(profile), str(existing)
                )
            install_again.assert_not_called()

    def test_controlify_rejects_vanilla_without_downloading(self):
        profile = types.SimpleNamespace(
            loader="vanilla", version="1.21.1", mods_dir="mods",
        )
        with mock.patch.object(modrinth_api, "install_project_latest") as install:
            with self.assertRaises(modrinth_api.ModrinthError):
                modrinth_api.ensure_controlify(profile)
        install.assert_not_called()

    def test_controlify_installed_detects_existing_mod(self):
        with tempfile.TemporaryDirectory() as directory:
            mods = Path(directory)
            profile = types.SimpleNamespace(mods_dir=str(mods))
            self.assertFalse(modrinth_api.controlify_installed(profile))
            (mods / "controlify-2.0.jar").write_bytes(b"jar")
            self.assertTrue(modrinth_api.controlify_installed(profile))


class ControllerNavigationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def test_direction_normalizes_stick_and_pov(self):
        self.assertEqual(
            ControllerNavigator._direction({"x": 0, "y": 0, "pov": 9000}),
            "right",
        )
        self.assertEqual(
            ControllerNavigator._direction({"x": 0, "y": -0.8, "pov": -1}),
            "up",
        )

    def test_konami_sequence_emits_secret(self):
        navigator = ControllerNavigator()
        navigator._timer.stop()
        unlocked = mock.Mock()
        navigator.secret_unlocked.connect(unlocked)
        results = []
        for token in (
            "up", "up", "down", "down", "left",
            "right", "left", "right", "b", "a",
        ):
            results.append(navigator._record(token))
        self.assertEqual(results, [False] * 9 + [True])
        unlocked.assert_called_once_with()

    def test_virtual_keyboard_applies_text_and_can_request_enter(self):
        target = QLineEdit("Kat")
        keyboard = VirtualKeyboardDialog(target)
        keyboard.preview.setText("KatLauncher")
        keyboard._finish(True)
        keyboard.apply()
        self.assertEqual(target.text(), "KatLauncher")
        self.assertTrue(keyboard.submit_on_accept)

    def test_controller_focus_indicator_wraps_and_blinks_around_widget(self):
        window = QWidget()
        window.resize(320, 180)
        button = QPushButton("Jugar", window)
        button.setGeometry(40, 50, 120, 42)
        window.show()
        self.app.processEvents()
        indicator = ControllerFocusIndicator()
        indicator.show_for(button)
        self.assertTrue(indicator._overlay.isVisible())
        self.assertTrue(indicator._overlay.geometry().contains(button.geometry()))
        indicator._pulse()
        indicator.hide()
        self.assertFalse(indicator._overlay.isVisible())
        window.close()


class TrophyTests(unittest.TestCase):
    def test_trophies_persist_and_platinum_requires_every_base_trophy(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "trophies.json"
            manager = TrophyManager(path)
            unlocked = []
            for _index in range(5):
                unlocked.extend(manager.add_playtime(20 * 3600))
            self.assertEqual(
                [item.id for item in unlocked],
                ["play_10h", "play_50h", "play_100h"],
            )
            for trophy in TROPHIES:
                manager.unlock(trophy.id)
            self.assertIn(PLATINUM.id, manager.unlocked)
            restored = TrophyManager(path)
            self.assertEqual(restored.play_seconds, 100 * 3600)
            self.assertEqual(restored.complete_count, len(TROPHIES))

    def test_duplicate_unlock_does_not_repeat_notification(self):
        with tempfile.TemporaryDirectory() as directory:
            manager = TrophyManager(Path(directory) / "trophies.json")
            self.assertEqual(
                [item.id for item in manager.unlock("first_mod")],
                ["first_mod"],
            )
            self.assertEqual(manager.unlock("first_mod"), [])


if __name__ == "__main__":
    unittest.main()
