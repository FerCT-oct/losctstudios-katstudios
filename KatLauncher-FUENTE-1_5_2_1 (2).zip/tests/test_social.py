import os
import tempfile
import threading
import types
import unittest
from pathlib import Path
from unittest import mock

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from postgrest.exceptions import APIError

from katlauncher.core.social_service import (
    MAX_AVATAR_BYTES, SocialError, SocialService, is_expired_jwt_error,
    validate_display_name,
)


class _Result:
    def __init__(self, data=None, session=None):
        self.data = data
        self.session = session


class _RpcQuery:
    def __init__(self, client):
        self.client = client

    def execute(self):
        self.client.executions += 1
        if self.client.executions == 1:
            raise APIError({
                "message": "JWT expired", "code": "PGRST303",
                "hint": None, "details": None,
            })
        return _Result(data={"ok": True})


class _Auth:
    def __init__(self):
        self.session = types.SimpleNamespace(
            access_token="expired", refresh_token="refresh-1",
            user=types.SimpleNamespace(id="123e4567-e89b-42d3-a456-426614174000"),
        )
        self.refreshes = 0

    def get_session(self):
        return self.session

    def refresh_session(self, refresh_token):
        self.refreshes += 1
        self.session = types.SimpleNamespace(
            access_token="fresh", refresh_token="refresh-2",
            user=self.session.user,
        )
        return _Result(session=self.session)


class _Client:
    def __init__(self):
        self.auth = _Auth()
        self.executions = 0

    def rpc(self, _name, _params):
        return _RpcQuery(self)


class SocialServiceTests(unittest.TestCase):
    def _service(self):
        service = SocialService.__new__(SocialService)
        service.url = "https://example.supabase.co"
        service.key = "key"
        service.redirect_url = "http://127.0.0.1/callback"
        service.provider = "google"
        service._refresh_lock = threading.RLock()
        service._read_lock = threading.RLock()
        service._read_markers = {}
        service.client = _Client()
        service.me = None
        return service

    def test_display_name_is_trimmed_and_limited(self):
        self.assertEqual(validate_display_name("  Kat   Player  "), "Kat Player")
        for value in ("x", "x" * 33, "Kat\x00Player"):
            with self.subTest(value=value), self.assertRaises(SocialError):
                validate_display_name(value)

    def test_release_smoke_mode_never_opens_the_saved_social_session(self):
        config = {
            "project_url": "https://example.supabase.co",
            "publishable_key": "public-key",
            "redirect_url": "http://127.0.0.1:8765/callback",
            "provider": "google",
        }
        with mock.patch.dict(os.environ, {"KATLAUNCHER_SMOKE_TEST": "1"}), \
                mock.patch(
                    "katlauncher.core.social_service.load_config",
                    return_value=config,
                ), mock.patch(
                    "katlauncher.core.social_service.create_client",
                ) as create_client:
            service = SocialService()
        create_client.assert_not_called()
        self.assertIsNone(service.client)
        self.assertIsNone(service.session)

    def test_pgrst303_refreshes_and_retries_exactly_once(self):
        service = self._service()
        self.assertEqual(service.rpc("kat_test"), {"ok": True})
        self.assertEqual(service.client.executions, 2)
        self.assertEqual(service.client.auth.refreshes, 1)
        self.assertEqual(service.session.access_token, "fresh")

    def test_expired_jwt_detection_supports_sdk_and_rendered_errors(self):
        self.assertTrue(is_expired_jwt_error(APIError({
            "message": "JWT expired", "code": "PGRST303",
            "hint": None, "details": None,
        })))
        self.assertTrue(is_expired_jwt_error(RuntimeError("JWT expired")))
        self.assertFalse(is_expired_jwt_error(RuntimeError("permission denied")))

    def test_avatar_rejects_non_png_and_oversized_payloads_before_network(self):
        service = self._service()
        with self.assertRaises(SocialError):
            service.upload_avatar(b"not an image")
        with self.assertRaises(SocialError):
            service.upload_avatar(b"\x89PNG\r\n\x1a\n" + b"x" * MAX_AVATAR_BYTES)

    def test_avatar_urls_only_allow_owned_storage_paths_or_google_hosts(self):
        service = self._service()
        path = "123e4567-e89b-42d3-a456-426614174000/avatar.png"
        self.assertIn("/kat-avatars/" + path, service.avatar_url({
            "avatar_path": path, "avatar_updated_at": "2026-07-14T12:00:00Z",
        }))
        self.assertEqual(
            service.avatar_url({"avatar_url": "https://lh3.googleusercontent.com/a/test"}),
            "https://lh3.googleusercontent.com/a/test",
        )
        self.assertEqual(
            service.avatar_url({"avatar_url": "http://127.0.0.1/private"}), "",
        )


try:
    from PySide6.QtCore import Qt
    from PySide6.QtGui import QImage
    from PySide6.QtWidgets import QApplication
    from katlauncher.gui import social_tab
except ImportError:
    QImage = None


@unittest.skipIf(QImage is None, "PySide6 is not installed")
class SocialUiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def test_avatar_is_normalized_to_square_png(self):
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory) / "wide.png"
            image = QImage(900, 300, QImage.Format_RGB32)
            image.fill(0x8844FF)
            self.assertTrue(image.save(str(source), "PNG"))
            payload, normalized = social_tab.prepare_avatar_png(source)
        self.assertTrue(payload.startswith(b"\x89PNG\r\n\x1a\n"))
        self.assertLessEqual(len(payload), MAX_AVATAR_BYTES)
        self.assertEqual((normalized.width(), normalized.height()), (512, 512))

    def test_enter_sends_global_private_and_search_without_losing_busy_text(self):
        fake = mock.Mock()
        fake.configured = False
        fake.session = None
        fake.me = None
        fake.provider = "google"
        fake.avatar_url.return_value = ""
        with mock.patch.object(social_tab, "SocialService", return_value=fake):
            tab = social_tab.SocialTab(None)
        tab.timer.stop()
        tab.presence_timer.stop()
        tab._call = mock.Mock(return_value=True)

        tab.message.setText("hola global")
        tab.message.returnPressed.emit()
        self.assertEqual(tab.message.text(), "")
        self.assertEqual(tab._call.call_args.args[1], "kat_send_message")

        tab.user_search.setText("Oliver")
        tab.user_search.returnPressed.emit()
        self.assertEqual(tab._call.call_args.args[1], "kat_search_users")

        tab.dm_friend.addItem("Amigo", "friend-id")
        tab.dm_message.setText("hola privado")
        tab.dm_message.returnPressed.emit()
        self.assertEqual(tab.dm_message.text(), "")
        self.assertEqual(tab._call.call_args.args[1], "kat_send_message")
        self.assertEqual(
            tab._call.call_args.args[2]["p_recipient"], "friend-id",
        )

        tab._call.return_value = False
        tab.message.setText("no perder")
        tab.message.returnPressed.emit()
        self.assertEqual(tab.message.text(), "no perder")
        tab.shutdown()

    def test_every_user_list_has_a_right_click_profile_menu(self):
        fake = mock.Mock()
        fake.configured = False
        fake.session = None
        fake.me = None
        fake.provider = "google"
        fake.avatar_url.return_value = ""
        with mock.patch.object(social_tab, "SocialService", return_value=fake):
            tab = social_tab.SocialTab(None)
        tab.timer.stop()
        tab.presence_timer.stop()
        for widget in (
            tab.global_list, tab.dm_list, tab.posts_list, tab.search_results,
            tab.friends_list, tab.requests_list,
        ):
            self.assertEqual(widget.contextMenuPolicy(), Qt.CustomContextMenu)
        tab.shutdown()

    def test_cloudflare_html_is_replaced_with_a_short_friendly_error(self):
        raw = (
            "{'message': 'JSON could not be generated', 'code': 520, "
            "'details': '<!DOCTYPE html><html>cloudflare</html>'}"
        )
        message = social_tab.friendly_social_error(raw)
        self.assertIn("temporalmente", message)
        self.assertNotIn("<html>", message)
        self.assertLess(len(message), 160)

    def test_public_profile_accepts_single_row_rpc_shapes(self):
        service = object.__new__(social_tab.SocialService)
        service.rpc = mock.Mock(return_value=[{
            "id": "user-id", "display_name": "Kat",
            "launcher_version": "1.4.1",
        }])
        profile = service.public_profile("user-id")
        self.assertEqual(profile["display_name"], "Kat")
        self.assertEqual(profile["launcher_version"], "1.4.1")

        service.rpc.return_value = (
            '{"id":"user-id","display_name":"Kat JSON"}'
        )
        self.assertEqual(
            service.public_profile("user-id")["display_name"], "Kat JSON"
        )

    def test_public_profile_dialog_shows_launcher_version_and_avatar_slot(self):
        service = mock.Mock()
        service.avatar_url.return_value = ""
        dialog = social_tab.PublicProfileDialog(
            {
                "id": "user-id",
                "display_name": "Oliver",
                "launcher_version": "1.4.1",
                "presence": {},
                "trophies": [],
                "badges": [],
            },
            service,
            social_tab.I18n("es"),
        )
        labels = [
            widget.text() for widget in dialog.findChildren(social_tab.QLabel)
        ]
        self.assertTrue(any("KatLauncher 1.4.1" in text for text in labels))
        self.assertEqual(
            (dialog.avatar.width(), dialog.avatar.height()), (84, 84)
        )

    def test_game_mode_pauses_social_and_never_opens_error_dialogs(self):
        fake = mock.Mock()
        fake.configured = True
        fake.session = None
        fake.me = None
        fake.provider = "google"
        fake.avatar_url.return_value = ""
        with mock.patch.object(social_tab, "SocialService", return_value=fake):
            tab = social_tab.SocialTab(None)
        tab.timer.stop()
        tab.presence_timer.stop()
        tab.set_game_active(True)
        with mock.patch.object(social_tab.QMessageBox, "warning") as warning:
            tab._failed("<!DOCTYPE html><html>Error code 520</html>")
        warning.assert_not_called()
        self.assertFalse(tab.timer.isActive())
        self.assertFalse(tab.presence_timer.isActive())
        self.assertIn("temporalmente", tab._pending_notice)
        tab.shutdown()


if __name__ == "__main__":
    unittest.main()
