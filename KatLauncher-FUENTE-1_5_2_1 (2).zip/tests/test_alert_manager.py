import tempfile
import unittest
from pathlib import Path
from unittest import mock

from katlauncher.core import alert_manager


def make_row(**overrides):
    row = {
        "id": "2026-09-25-mantenimiento",
        "severity": "warning",
        "display": "banner",
        "sound": True,
        "title_es": "Aviso",
        "title_en": "Notice",
        "message_es": "Mensaje de prueba",
        "message_en": "Test message",
        "published_at": "2026-09-25T10:00:00Z",
    }
    row.update(overrides)
    return row


class FakeResponse:
    def __init__(self, data):
        self.data = data


class FakeRpc:
    def __init__(self, data=None, error=None):
        self.data = data
        self.error = error

    def execute(self):
        if self.error is not None:
            raise self.error
        return FakeResponse(self.data)


class FakeClient:
    def __init__(self, data=None, error=None):
        self._data = data
        self._error = error
        self.calls = []

    def rpc(self, name, params=None):
        self.calls.append((name, params))
        return FakeRpc(self._data, self._error)


class AlertPayloadTests(unittest.TestCase):
    def test_parses_a_valid_row(self):
        info = alert_manager.parse_alert_payload(make_row())
        self.assertEqual(info.id, "2026-09-25-mantenimiento")
        self.assertEqual(info.severity, "warning")
        self.assertEqual(info.display, "banner")
        self.assertTrue(info.sound)
        self.assertEqual(info.title_for("es"), "Aviso")
        self.assertEqual(info.message_for("en"), "Test message")

    def test_null_payload_means_no_active_alert(self):
        self.assertIsNone(alert_manager.parse_alert_payload(None))

    def test_empty_list_means_no_active_alert(self):
        self.assertIsNone(alert_manager.parse_alert_payload([]))

    def test_list_with_one_row_is_unwrapped(self):
        info = alert_manager.parse_alert_payload([make_row(id="from-list")])
        self.assertEqual(info.id, "from-list")

    def test_unknown_severity_and_display_fall_back_to_defaults(self):
        info = alert_manager.parse_alert_payload(
            make_row(severity="apocalipsis", display="popup")
        )
        self.assertEqual(info.severity, "info")
        self.assertEqual(info.display, "banner")

    def test_row_without_id_is_rejected(self):
        with self.assertRaises(alert_manager.AlertError):
            alert_manager.parse_alert_payload(make_row(id=""))

    def test_row_without_title_or_message_is_rejected(self):
        with self.assertRaises(alert_manager.AlertError):
            alert_manager.parse_alert_payload(
                make_row(title_es="", title_en="")
            )

    def test_unexpected_shape_is_rejected(self):
        with self.assertRaises(alert_manager.AlertError):
            alert_manager.parse_alert_payload("not a row")


class FetchAlertTests(unittest.TestCase):
    def test_fetch_alert_calls_the_rpc_and_parses(self):
        client = FakeClient(data=make_row())
        info = alert_manager.fetch_alert(client=client)
        self.assertEqual(info.id, "2026-09-25-mantenimiento")
        self.assertEqual(client.calls, [("kat_get_active_alert", {})])

    def test_fetch_alert_returns_none_when_nothing_active(self):
        client = FakeClient(data=None)
        self.assertIsNone(alert_manager.fetch_alert(client=client))

    def test_rpc_failure_raises_alert_error(self):
        client = FakeClient(error=RuntimeError("network down"))
        with self.assertRaises(alert_manager.AlertError):
            alert_manager.fetch_alert(client=client)


class ConfigurationTests(unittest.TestCase):
    def test_not_configured_when_social_config_is_empty(self):
        with mock.patch.object(
            alert_manager, "load_config",
            return_value={"project_url": "", "publishable_key": ""},
        ):
            self.assertFalse(alert_manager.is_configured())
            with self.assertRaises(alert_manager.AlertError):
                alert_manager.make_anon_client()

    def test_configured_when_social_config_has_https_url_and_key(self):
        with mock.patch.object(
            alert_manager, "load_config",
            return_value={
                "project_url": "https://example.supabase.co",
                "publishable_key": "anon-key",
            },
        ):
            self.assertTrue(alert_manager.is_configured())


class AlertStateTests(unittest.TestCase):
    def test_new_alert_is_reported_once(self):
        with tempfile.TemporaryDirectory() as directory:
            state_file = Path(directory) / "alert_state.json"
            client = FakeClient(data=make_row())

            first = alert_manager.check_for_new_alert(
                client=client, state_file=state_file
            )
            self.assertIsNotNone(first)
            alert_manager.record_seen_alert(first.id, state_file)

            second = alert_manager.check_for_new_alert(
                client=client, state_file=state_file
            )
            self.assertIsNone(second)

    def test_new_alert_id_is_reported_again(self):
        with tempfile.TemporaryDirectory() as directory:
            state_file = Path(directory) / "alert_state.json"
            alert_manager.record_seen_alert("old-id", state_file)
            client = FakeClient(data=make_row(id="new-id"))
            info = alert_manager.check_for_new_alert(
                client=client, state_file=state_file
            )
            self.assertEqual(info.id, "new-id")


if __name__ == "__main__":
    unittest.main()
