import json
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from katlauncher.core.account_manager import AccountManager
from katlauncher.core.news_service import NEWS_BASE_URL, NewsService
from katlauncher.core.server_manager import (
    ServerManager, _decode_varint, _description_text, _pack_varint,
    parse_server_address,
)


class _Response:
    def __init__(self, payload):
        self.content = json.dumps(payload).encode("utf-8")

    def raise_for_status(self):
        return None


class DiscoverServicesTests(unittest.TestCase):
    def test_news_validates_official_images_and_falls_back_to_cache(self):
        payload = {"entries": [{
            "id": "one", "title": "Snapshot", "shortText": "Novedades",
            "date": "2026-07-07T00:00:00Z", "version": "26.3-snapshot-3",
            "type": "snapshot", "image": {"url": "/v2/images/one.jpg"},
        }]}
        with tempfile.TemporaryDirectory() as directory:
            cache = Path(directory) / "news.json"
            session = mock.Mock()
            session.get.return_value = _Response(payload)
            service = NewsService(cache, session=session)
            items = service.fetch()
            self.assertEqual(items[0].title, "Snapshot")
            self.assertTrue(items[0].image_url.startswith(NEWS_BASE_URL))
            self.assertTrue(cache.is_file())

            session.get.side_effect = OSError("offline")
            self.assertEqual(service.fetch()[0].id, "one")

    def test_news_sorts_before_limiting_and_cache_failure_is_nonfatal(self):
        payload = {"entries": [
            {"id": "old", "title": "Old", "date": "2026-01-01T00:00:00Z"},
            {"id": "new", "title": "New", "date": "2026-07-01T00:00:00Z"},
            {"id": "middle", "title": "Middle", "date": "2026-04-01T00:00:00Z"},
        ]}
        session = mock.Mock()
        session.get.return_value = _Response(payload)
        service = NewsService(Path("unused.json"), session=session)
        with mock.patch.object(service, "_save_cache", side_effect=OSError("read only")):
            self.assertEqual([item.id for item in service.fetch(limit=2)], ["new", "middle"])

    def test_server_addresses_and_favorites_are_persisted(self):
        self.assertEqual(parse_server_address("example.org:25570"), ("example.org", 25570))
        self.assertEqual(parse_server_address("[::1]:25566"), ("::1", 25566))
        for value in ("https://example.org", "bad host", "example.org:99999", ""):
            with self.subTest(value=value), self.assertRaises((ValueError, TypeError)):
                parse_server_address(value)
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "servers.json"
            manager = ServerManager(path)
            first = manager.add("Casa", "localhost", 25565)
            duplicate = manager.add("Otra", "localhost", 25565)
            self.assertEqual(first.id, duplicate.id)
            self.assertEqual(ServerManager(path).list()[0].name, "Casa")

            payload = json.loads(path.read_text(encoding="utf-8"))
            payload["servers"].insert(0, {"id": "bad", "host": "bad host"})
            path.write_text(json.dumps(payload), encoding="utf-8")
            self.assertEqual([item.name for item in ServerManager(path).list()], ["Casa"])

    def test_status_protocol_helpers_are_bounded_and_flatten_description(self):
        for number in (0, 1, 127, 128, 25565, 2 ** 28):
            packed = _pack_varint(number)
            decoded, offset = _decode_varint(packed, 0)
            self.assertEqual(decoded, number)
            self.assertEqual(offset, len(packed))
        self.assertEqual(
            _description_text({"text": "Kat ", "extra": [{"text": "Server"}]}),
            "Kat Server",
        )

    def test_offline_accounts_never_store_credentials_and_apply_selection(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "accounts.json"
            manager = AccountManager(path, "Jugador")
            second = manager.add_offline("Oliver_2")
            self.assertEqual(manager.selected().id, second.id)
            payload = json.loads(path.read_text(encoding="utf-8"))
            self.assertNotIn("password", json.dumps(payload).lower())
            restarted = AccountManager(path)
            self.assertEqual(restarted.selected().nickname, "Oliver_2")
            restarted.remove(second.id)
            self.assertEqual(len(restarted.list()), 1)
            with self.assertRaises(ValueError):
                restarted.remove(restarted.selected_id)

    def test_one_corrupt_account_does_not_erase_valid_accounts(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "accounts.json"
            path.write_text(json.dumps({
                "selected_id": "good",
                "accounts": [
                    {"id": "bad", "nickname": "unsafe name", "account_type": "offline"},
                    {"id": "good", "nickname": "Kat_1", "account_type": "offline"},
                ],
            }), encoding="utf-8")
            manager = AccountManager(path)
            self.assertEqual([item.nickname for item in manager.list()], ["Kat_1"])
            self.assertEqual(manager.selected_id, "good")


if __name__ == "__main__":
    unittest.main()
