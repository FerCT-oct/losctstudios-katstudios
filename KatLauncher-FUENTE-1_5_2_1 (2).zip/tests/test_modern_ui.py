import json
import os
import tempfile
import types
import unittest
from pathlib import Path
from unittest import mock

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtWidgets import QApplication, QComboBox, QWidget

from katlauncher.gui.dashboard_tab import DashboardRoute, DashboardTab
from katlauncher.gui.modern_shell import CATEGORIES, ModernShell
from katlauncher.gui.alternate_shells import KatEpicShell, KatNormalShell
from katlauncher.gui.i18n import I18n
from katlauncher.gui.theme_manager import (
    AccentName, MODERN_STYLE, ThemeManager, ThemeName,
)


class FakeProfileManager:
    def __init__(self):
        self.profiles = {
            "alpha": types.SimpleNamespace(
                id="alpha",
                name="Cosmic Survival",
                nickname="Oliver",
                version="1.21.1",
                loader="fabric",
                skin_path="",
            ),
            "beta": types.SimpleNamespace(
                id="beta",
                name="Perfil sin versión",
                nickname="Kat",
                version="",
                loader="vanilla",
                skin_path="",
            ),
        }

    def list_profiles(self):
        return list(self.profiles.values())

    def get(self, profile_id):
        return self.profiles.get(profile_id)


class ModernUiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def test_dashboard_selects_profile_and_emits_delegated_actions(self):
        dashboard = DashboardTab(FakeProfileManager())
        self.addCleanup(dashboard.close)
        play = mock.Mock()
        navigate = mock.Mock()
        dashboard.play_requested.connect(play)
        dashboard.navigate_requested.connect(navigate)

        self.assertEqual(dashboard.active_profile_id, "alpha")
        self.assertTrue(dashboard.play_button.isEnabled())
        dashboard.play_button.click()
        play.assert_called_once_with("alpha")

        dashboard.quick_buttons[DashboardRoute.FRIENDS].click()
        navigate.assert_called_once_with(DashboardRoute.FRIENDS)

        self.assertTrue(dashboard.set_active_profile("beta"))
        self.assertFalse(dashboard.play_button.isEnabled())
        self.assertFalse(dashboard.set_active_profile("missing"))

    def test_dashboard_refresh_preserves_active_profile(self):
        manager = FakeProfileManager()
        dashboard = DashboardTab(manager)
        self.addCleanup(dashboard.close)
        dashboard.set_active_profile("beta")
        manager.profiles["gamma"] = types.SimpleNamespace(
            id="gamma", name="Nuevo", nickname="Gato", version="1.20.1",
            loader="forge", skin_path="",
        )
        dashboard.refresh_profiles()
        self.assertEqual(dashboard.active_profile_id, "beta")
        self.assertEqual(dashboard.profile_combo.count(), 3)

    def test_theme_manager_persists_and_binds_selector(self):
        with tempfile.TemporaryDirectory() as directory:
            state = Path(directory) / "appearance.json"
            target = QWidget()
            self.addCleanup(target.close)
            manager = ThemeManager(state_file=state)
            self.assertEqual(manager.theme, ThemeName.MODERN)
            changes = mock.Mock()
            manager.theme_changed.connect(changes)

            manager.use_classic(target=target)
            changes.reset_mock()
            selected = manager.use_modern(target=target)
            self.assertEqual(selected, ThemeName.MODERN)
            self.assertIn("#7048ff", target.styleSheet())
            self.assertEqual(json.loads(state.read_text())["theme"], "xmb")
            changes.assert_called_once_with("xmb")

            restored = ThemeManager(state_file=state)
            self.assertEqual(restored.theme, ThemeName.MODERN)
            combo = QComboBox()
            self.addCleanup(combo.close)
            restored.bind_combo(combo, target=target)
            combo.setCurrentIndex(combo.findData("classic"))
            self.assertEqual(restored.theme, ThemeName.CLASSIC)
            self.assertNotEqual(target.styleSheet(), MODERN_STYLE)

    def test_all_four_interfaces_are_selectable(self):
        with tempfile.TemporaryDirectory() as directory:
            target = QWidget()
            self.addCleanup(target.close)
            manager = ThemeManager(
                state_file=Path(directory) / "appearance.json"
            )
            combo = QComboBox()
            self.addCleanup(combo.close)
            manager.bind_combo(combo, target=target)
            self.assertEqual(
                {combo.itemData(index) for index in range(combo.count())},
                {"xmb", "normal", "epic", "classic"},
            )
            combo.setCurrentIndex(combo.findData("epic"))
            self.assertEqual(manager.theme, ThemeName.EPIC)

    def test_normal_and_epic_shells_host_real_pages(self):
        for shell_type in (KatNormalShell, KatEpicShell):
            with self.subTest(shell=shell_type.__name__):
                shell = shell_type()
                self.addCleanup(shell.close)
                home = QWidget()
                play = QWidget()
                shell.register_page(DashboardRoute.HOME, home)
                shell.register_page(DashboardRoute.PLAY, play)
                self.assertTrue(shell.navigate(DashboardRoute.PLAY))
                self.assertIs(shell.page_stack.currentWidget(), play)

    def test_custom_accent_is_persisted_and_applied(self):
        with tempfile.TemporaryDirectory() as directory:
            state = Path(directory) / "appearance.json"
            target = QWidget()
            self.addCleanup(target.close)
            manager = ThemeManager(state_file=state)
            manager.apply(target=target, persist=False)
            manager.apply_custom_accent("#123456", target=target)
            self.assertEqual(manager.accent, AccentName.CUSTOM)
            self.assertEqual(manager.accent_pair[0], "#123456")
            self.assertIn("#123456", target.styleSheet())
            self.assertEqual(
                json.loads(state.read_text())["custom_accent"], "#123456"
            )

    def test_accent_color_is_applied_and_persisted(self):
        with tempfile.TemporaryDirectory() as directory:
            state = Path(directory) / "appearance.json"
            target = QWidget()
            self.addCleanup(target.close)
            manager = ThemeManager(state_file=state)
            manager.apply(target=target, persist=False)
            manager.apply_accent(AccentName.BLUE, target=target)
            self.assertEqual(manager.accent, AccentName.BLUE)
            self.assertIn("#2563eb", target.styleSheet())
            self.assertEqual(json.loads(state.read_text())["accent"], "blue")

    def test_shell_routes_only_registered_pages(self):
        shell = ModernShell()
        self.addCleanup(shell.close)
        home = QWidget()
        friends = QWidget()
        shell.register_page(DashboardRoute.HOME, home)
        shell.register_page(DashboardRoute.FRIENDS, friends)
        missing = mock.Mock()
        shell.unknown_route_requested.connect(missing)

        self.assertTrue(shell.navigate(DashboardRoute.FRIENDS))
        self.assertIs(shell.stack.currentWidget(), shell.app_host)
        self.assertIs(shell.page_stack.currentWidget(), friends)
        self.assertFalse(shell.navigate(DashboardRoute.MODS))
        missing.assert_called_once_with(DashboardRoute.MODS)

    def test_xmb_matches_prototype_categories_and_returns_from_apps(self):
        self.assertEqual(
            [category.name for category in CATEGORIES],
            ["Usuarios", "Ajustes", "Juegos", "Música", "Fotos", "Red", "Debug"],
        )
        shell = ModernShell()
        self.addCleanup(shell.close)
        page = QWidget()
        shell.register_page(DashboardRoute.PLAY, page)
        self.assertTrue(shell.navigate(DashboardRoute.PLAY))
        self.assertIs(shell.stack.currentWidget(), shell.app_host)
        self.assertIs(shell.page_stack.currentWidget(), page)
        shell.show_menu()
        self.assertIs(shell.stack.currentWidget(), shell.menu)
        self.assertEqual(shell.menu.selected_route, DashboardRoute.PLAY)

    def test_xmb_minecraft_item_has_its_own_icon_and_launch_action(self):
        shell = ModernShell()
        self.addCleanup(shell.close)
        launch = mock.Mock()
        shell.launch_minecraft_requested.connect(launch)
        games = next(category for category in CATEGORIES if category.name == "Juegos")
        item = next(item for item in games.items if item.action == "launch_minecraft")
        self.assertEqual(item.icon, "minecraft")
        shell._activate("action:launch_minecraft")
        launch.assert_called_once_with()

    def test_legacy_style_launch_sequence_has_all_stages(self):
        shell = ModernShell()
        self.addCleanup(shell.close)
        self.assertGreaterEqual(shell.LAUNCH_SEQUENCE_MS, 5000)
        self.assertEqual(shell.menu.launch_phase(0.8), "kat")
        self.assertEqual(shell.menu.launch_phase(2.6), "transition")
        self.assertEqual(shell.menu.launch_phase(3.4), "mojang")
        self.assertEqual(shell.menu.launch_phase(5.0), "starting")

    def test_xmb_labels_use_selected_language(self):
        shell = ModernShell(i18n=I18n("en"))
        self.addCleanup(shell.close)
        self.assertEqual(shell.menu._t("Juegos"), "Games")
        self.assertEqual(
            shell.menu._t("Selecciona un perfil e inicia el juego"),
            "Select a profile and launch the game",
        )

    def test_theme_write_failure_does_not_leave_hybrid_state(self):
        with tempfile.TemporaryDirectory() as directory:
            target = QWidget()
            self.addCleanup(target.close)
            manager = ThemeManager(state_file=Path(directory) / "appearance.json")
            manager.apply(target=target, persist=False)
            modern_style = target.styleSheet()
            with mock.patch.object(manager, "_write_theme", side_effect=OSError("read only")):
                with self.assertRaises(OSError):
                    manager.use_classic(target=target)
            self.assertEqual(manager.theme, ThemeName.MODERN)
            self.assertEqual(target.styleSheet(), modern_style)


if __name__ == "__main__":
    unittest.main()
