import os
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtGui import QColor, QImage
from PySide6.QtWidgets import QApplication

from katlauncher.gui.i18n import I18n
from katlauncher.gui.screenshots_tab import ScreenshotsTab


class _Profiles:
    def __init__(self, profile):
        self.profile = profile

    def list_profiles(self):
        return [self.profile]

    def get(self, profile_id):
        return self.profile if profile_id == self.profile.id else None


class ScreenshotGalleryTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def test_gallery_loads_only_supported_profile_screenshots(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            screenshots = root / "screenshots"
            screenshots.mkdir()
            image = QImage(320, 180, QImage.Format_ARGB32)
            image.fill(QColor("#7048ff"))
            self.assertTrue(image.save(str(screenshots / "kat.png"), "PNG"))
            (screenshots / "ignore.txt").write_text("no", encoding="utf-8")
            profile = SimpleNamespace(
                id="profile-1", name="Kat", game_dir=str(root)
            )
            widget = ScreenshotsTab(_Profiles(profile), I18n("es"))
            self.addCleanup(widget.close)
            self.assertEqual(widget.list.count(), 1)
            self.assertEqual(widget.list.item(0).text(), "kat.png")
            self.assertEqual(widget._current_path.name, "kat.png")
            self.assertFalse(widget._current_pixmap.isNull())


if __name__ == "__main__":
    unittest.main()
