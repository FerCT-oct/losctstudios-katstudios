import hashlib
import json
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path
from unittest import mock

from katlauncher.core import update_manager


class FakeResponse:
    def __init__(self, body=b"", *, status=200, headers=None, chunks=None):
        self.body = body
        self.status_code = status
        self.headers = headers or {}
        self.chunks = chunks
        self.closed = False

    def raise_for_status(self):
        if self.status_code >= 400:
            raise update_manager.requests.RequestException(f"HTTP {self.status_code}")

    def iter_content(self, chunk_size=1):
        if self.chunks is not None:
            yield from self.chunks
            return
        for offset in range(0, len(self.body), chunk_size):
            yield self.body[offset:offset + chunk_size]

    def close(self):
        self.closed = True


class FakeSession:
    def __init__(self, *responses):
        self.responses = list(responses)
        self.calls = []

    def get(self, url, **kwargs):
        self.calls.append((url, kwargs))
        if not self.responses:
            raise AssertionError("Unexpected request")
        return self.responses.pop(0)


def make_channel():
    return update_manager.UpdateChannel(
        manifest_url="https://updates.example.com/stable.json",
        allowed_hosts=frozenset({"updates.example.com", "cdn.example.com"}),
    )


def make_info(data=b"installer", version="1.1.0"):
    return update_manager.UpdateInfo(
        version=version,
        installer_url=f"https://cdn.example.com/KatLauncher-Setup-{version}.exe",
        installer_size=len(data),
        installer_sha256=hashlib.sha256(data).hexdigest(),
        notes_es="Mejoras",
        notes_en="Improvements",
    )


class UpdateVersionTests(unittest.TestCase):
    def test_versions_are_compared_numerically(self):
        self.assertTrue(update_manager.is_newer_version("1.10.0", "1.9.0"))
        self.assertFalse(update_manager.is_newer_version("1.9.0", "1.10.0"))
        self.assertFalse(update_manager.is_newer_version("1.0.0", "1.0.0"))

    def test_prerelease_and_malformed_versions_are_rejected(self):
        for value in ("1.1", "v1.1.0", "1.1.0-beta", "01.1.0", "1.2.3.4"):
            with self.subTest(value=value), self.assertRaises(update_manager.UpdateError):
                update_manager.version_tuple(value)


class UpdateManifestTests(unittest.TestCase):
    def test_channel_configuration_is_fixed_and_requires_https(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "channel.json"
            path.write_text(json.dumps({
                "schema": 1,
                "manifest_url": "",
                "allowed_hosts": [],
            }), encoding="utf-8")
            self.assertIsNone(update_manager.load_update_channel(path))

            path.write_text(json.dumps({
                "schema": 1,
                "manifest_url": "http://updates.example.com/latest.json",
                "allowed_hosts": ["cdn.example.com"],
            }), encoding="utf-8")
            with self.assertRaises(update_manager.UpdateError):
                update_manager.load_update_channel(path)

            path.write_text(json.dumps({
                "schema": 1,
                "manifest_url": "https://updates.example.com/latest.json",
                "allowed_hosts": ["cdn.example.com"],
            }), encoding="utf-8")
            channel = update_manager.load_update_channel(path)
            self.assertEqual(channel.manifest_url, "https://updates.example.com/latest.json")
            self.assertEqual(
                channel.allowed_hosts, {"updates.example.com", "cdn.example.com"}
            )

    def test_frozen_application_ignores_environment_channel_override(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "channel.json"
            path.write_text(json.dumps({
                "schema": 1,
                "manifest_url": "",
                "allowed_hosts": [],
            }), encoding="utf-8")
            environment = {
                "KATLAUNCHER_UPDATE_MANIFEST_URL": "https://evil.example/latest.json",
                "KATLAUNCHER_UPDATE_ALLOWED_HOSTS": "evil.example",
            }
            with mock.patch.dict(update_manager.os.environ, environment), \
                    mock.patch.object(update_manager.sys, "frozen", True, create=True):
                self.assertIsNone(update_manager.load_update_channel(path))

    def test_valid_manifest_is_loaded_and_current_version_is_ignored(self):
        data = b"installer"
        manifest = json.dumps({
            "schema": 1,
            "channel": "stable",
            "version": "1.1.0",
            "installer": {
                "url": "https://cdn.example.com/KatLauncher-Setup-1.1.0.exe",
                "size": len(data),
                "sha256": hashlib.sha256(data).hexdigest(),
            },
            "notes": {"es": "Mejoras", "en": "Improvements"},
        }).encode()
        response = FakeResponse(manifest, headers={"Content-Length": str(len(manifest))})
        info = update_manager.check_for_update(
            make_channel(), current_version="1.0.0", session=FakeSession(response)
        )
        self.assertEqual(info.version, "1.1.0")
        self.assertEqual(info.notes_for("en"), "Improvements")

        current = FakeResponse(manifest)
        self.assertIsNone(update_manager.check_for_update(
            make_channel(), current_version="1.1.0", session=FakeSession(current)
        ))

    def test_manifest_rejects_bad_hash_size_scheme_and_host(self):
        base = {
            "schema": 1,
            "version": "1.1.0",
            "installer": {
                "url": "https://cdn.example.com/KatLauncher-Setup-1.1.0.exe",
                "size": 8,
                "sha256": "a" * 64,
            },
        }
        mutations = (
            ("hash", lambda item: item["installer"].update(sha256="bad")),
            ("size", lambda item: item["installer"].update(size=0)),
            ("scheme", lambda item: item["installer"].update(
                url="http://cdn.example.com/KatLauncher-Setup-1.1.0.exe"
            )),
            ("host", lambda item: item["installer"].update(
                url="https://evil.example/KatLauncher-Setup-1.1.0.exe"
            )),
        )
        for name, mutate in mutations:
            payload = json.loads(json.dumps(base))
            mutate(payload)
            with self.subTest(name=name), self.assertRaises(update_manager.UpdateError):
                update_manager.parse_manifest(payload, make_channel())

    def test_redirect_to_unapproved_host_is_rejected(self):
        redirect = FakeResponse(status=302, headers={"Location": "https://evil.example/a.json"})
        with self.assertRaises(update_manager.UpdateError):
            update_manager.check_for_update(make_channel(), session=FakeSession(redirect))

    def test_oversized_manifest_is_rejected_before_reading(self):
        response = FakeResponse(
            b"{}", headers={"Content-Length": str(update_manager.MAX_MANIFEST_SIZE + 1)}
        )
        with self.assertRaises(update_manager.UpdateError):
            update_manager.check_for_update(make_channel(), session=FakeSession(response))


class UpdateDownloadTests(unittest.TestCase):
    def test_download_is_atomic_and_verified(self):
        data = b"installer payload"
        info = make_info(data)
        response = FakeResponse(
            chunks=[data[:4], data[4:]], headers={"Content-Length": str(len(data))}
        )
        progress = []
        with tempfile.TemporaryDirectory() as directory:
            path = update_manager.download_update(
                info,
                make_channel(),
                updates_dir=directory,
                session=FakeSession(response),
                progress_cb=progress.append,
            )
            self.assertEqual(path.read_bytes(), data)
            self.assertEqual(progress[-1], len(data))
            self.assertFalse(list(path.parent.glob("*.part")))
            self.assertEqual(update_manager.verify_installer(path, info), path)

    def test_bad_hash_and_truncated_download_leave_no_file(self):
        data = b"installer payload"
        for name, body, info in (
            ("hash", data, make_info(b"different bytes")),
            ("truncated", data[:-2], make_info(data)),
        ):
            with self.subTest(name=name), tempfile.TemporaryDirectory() as directory:
                response = FakeResponse(body)
                with self.assertRaises(update_manager.UpdateError):
                    update_manager.download_update(
                        info, make_channel(), updates_dir=directory,
                        session=FakeSession(response),
                    )
                self.assertFalse(list(Path(directory).rglob("*.exe")))
                self.assertFalse(list(Path(directory).rglob("*.part")))

    def test_cancelled_download_removes_partial_file(self):
        data = b"installer payload"
        info = make_info(data)
        with tempfile.TemporaryDirectory() as directory:
            with self.assertRaises(update_manager.UpdateCancelled):
                update_manager.download_update(
                    info, make_channel(), updates_dir=directory,
                    session=FakeSession(FakeResponse(data)),
                    cancel_cb=lambda: True,
                )
            self.assertFalse(list(Path(directory).rglob("*.part")))

    def test_launch_reverifies_and_uses_argument_list_without_shell(self):
        data = b"installer payload"
        info = make_info(data)
        calls = []

        def fake_popen(command, **kwargs):
            calls.append((command, kwargs))
            return object()

        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            path = update_manager.installer_path(info, root / "updates")
            path.parent.mkdir(parents=True)
            path.write_bytes(data)
            with mock.patch.object(update_manager, "APP_DIR", root / "data"):
                update_manager.launch_update_installer(
                    path, info, language="en", parent_pid=123,
                    popen=fake_popen, require_frozen=False,
                )
            command, kwargs = calls[0]
            self.assertEqual(command[0], str(path))
            self.assertIn("/WAITFORPID=123", command)
            self.assertIn("/LANG=english", command)
            self.assertIn("/AUTOUPDATE=1", command)
            self.assertIs(kwargs["shell"], False)

    def test_log_directory_failure_is_reported_as_update_error(self):
        data = b"installer payload"
        info = make_info(data)
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            path = update_manager.installer_path(info, root / "updates")
            path.parent.mkdir(parents=True)
            path.write_bytes(data)
            blocked = root / "blocked"
            blocked.write_text("not a directory", encoding="utf-8")
            with mock.patch.object(update_manager, "APP_DIR", blocked), \
                    self.assertRaises(update_manager.UpdateError):
                update_manager.launch_update_installer(
                    path, info, require_frozen=False, popen=lambda *_a, **_k: None
                )


class UpdateStateTests(unittest.TestCase):
    def test_automatic_check_interval_is_twenty_four_hours(self):
        now = datetime(2026, 7, 13, tzinfo=timezone.utc)
        with tempfile.TemporaryDirectory() as directory:
            state = Path(directory) / "state.json"
            self.assertTrue(update_manager.should_check_automatically(
                state_file=state, now=now
            ))
            update_manager.record_successful_check(state_file=state, now=now)
            self.assertFalse(update_manager.should_check_automatically(
                state_file=state, now=now + timedelta(hours=23)
            ))
            self.assertTrue(update_manager.should_check_automatically(
                state_file=state, now=now + timedelta(hours=24)
            ))


if __name__ == "__main__":
    unittest.main()
