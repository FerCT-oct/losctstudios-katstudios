import os
import tempfile
import types
import unittest
from pathlib import Path
from unittest import mock

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QApplication

from katlauncher.core.discord_presence import DEFAULT_DISCORD_CLIENT_ID
from katlauncher.core.settings_manager import SettingsManager
from katlauncher.gui import sound_manager
from katlauncher.gui.i18n import I18n
from katlauncher.gui.play_tab import PlayTab
from katlauncher.gui.settings_tab import SettingsTab


class FakeAudioBackend:
    def __init__(self):
        self.plays = []
        self.closed = []

    def play(self, path, alias):
        self.plays.append((path, alias))
        return 250

    def close(self, alias):
        self.closed.append(alias)


class SoundManagerTests(unittest.TestCase):
    def test_all_three_user_sounds_use_the_expected_assets(self):
        backend = FakeAudioBackend()
        manager = sound_manager.SoundManager(enabled=True, backend=backend)
        with mock.patch.object(sound_manager.QTimer, "singleShot") as single_shot:
            self.assertTrue(manager.play_success())
            self.assertTrue(manager.play_cat_ringtone())
            self.assertTrue(manager.play_update_success())

        self.assertEqual(
            [path.name for path, _alias in backend.plays],
            ["success.mp3", "cat_ringtone.mp3", "update_success.wav"],
        )
        self.assertEqual(single_shot.call_count, 3)
        delay, callback = single_shot.call_args.args
        self.assertEqual(delay, 1000)
        callback()
        self.assertIn("katlauncher_update", backend.closed)

    def test_disabling_sounds_stops_aliases_and_prevents_playback(self):
        backend = FakeAudioBackend()
        manager = sound_manager.SoundManager(enabled=True, backend=backend)
        manager.set_enabled(False)
        self.assertFalse(manager.play_success())
        self.assertEqual(backend.plays, [])
        self.assertEqual(set(backend.closed), set(manager._ALIASES.values()))

    def test_new_sfx_have_distinct_assets(self):
        backend = FakeAudioBackend()
        manager = sound_manager.SoundManager(enabled=True, backend=backend)
        with mock.patch.object(sound_manager.QTimer, "singleShot"):
            manager.play_ui_click()
            manager.play_operation_success()
            manager.play_achievement()
            manager.play_error()
            manager.play_notification()
            manager.play_invite()
            manager.play_creeper()
        self.assertEqual(
            [path.name for path, _alias in backend.plays],
            [
                "ui_click.mp3", "soft_success.mp3", "achievement.mp3",
                "error.mp3", "notification.mp3", "invite.mp3", "creeper.mp3",
            ],
        )


class PlayTabInteractionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def test_logs_collapse_and_logo_emits_easter_egg_signal(self):
        profile_manager = types.SimpleNamespace(list_profiles=lambda: [], get=lambda _id: None)
        settings_manager = types.SimpleNamespace(
            settings=types.SimpleNamespace(log_max_lines=2000)
        )
        tab = PlayTab(profile_manager, settings_manager, I18n("es"))
        self.addCleanup(tab.close)
        easter_egg = mock.Mock()
        tab.logo_clicked.connect(easter_egg)

        self.assertFalse(tab.log_view.isHidden())
        tab.log_toggle.setChecked(False)
        self.assertTrue(tab.log_view.isHidden())
        self.assertEqual(tab.log_toggle.arrowType(), Qt.RightArrow)
        tab.log_toggle.setChecked(True)
        self.assertFalse(tab.log_view.isHidden())
        self.assertEqual(tab.log_toggle.arrowType(), Qt.DownArrow)

        tab.logo_label.clicked.emit()
        easter_egg.assert_called_once_with()

    def test_prepared_install_waits_for_visual_sequence_before_launch(self):
        profile = types.SimpleNamespace(
            id="kat", name="Kat Test", nickname="Oliver", version="1.21.1",
            loader="fabric", loader_version="0.16.9",
        )
        profile_manager = types.SimpleNamespace(
            list_profiles=lambda: [profile],
            get=lambda profile_id: profile if profile_id == "kat" else None,
        )
        settings_manager = types.SimpleNamespace(
            settings=types.SimpleNamespace(log_max_lines=2000)
        )
        tab = PlayTab(profile_manager, settings_manager, I18n("es"))
        self.addCleanup(tab.close)
        tab._pending_profile_id = "kat"
        tab._pending_install_signature = (
            profile.version, profile.loader, profile.loader_version,
        )
        prepared = mock.Mock()
        tab.launch_prepared.connect(prepared)
        with mock.patch.object(tab, "_start_game") as start:
            tab._on_install_finished("fabric-1.21.1")
        prepared.assert_called_once_with(profile, "fabric-1.21.1")
        start.assert_not_called()


class SettingsDiscordTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def test_discord_id_is_prefilled_read_only_and_enabled_by_default(self):
        with tempfile.TemporaryDirectory() as directory:
            manager = SettingsManager(Path(directory) / "settings.json")
            tab = SettingsTab(manager, I18n("es"))
            self.addCleanup(tab.close)

            self.assertEqual(
                tab.discord_client_id_edit.text(), DEFAULT_DISCORD_CLIENT_ID
            )
            self.assertTrue(tab.discord_client_id_edit.isReadOnly())
            self.assertTrue(tab.discord_presence_check.isChecked())

            tab.discord_presence_check.setChecked(False)
            self.assertFalse(tab.discord_client_id_edit.isEnabled())


if __name__ == "__main__":
    unittest.main()
