import tempfile
import types
import unittest
from pathlib import Path
from unittest import mock

from katlauncher.core import room_server
from katlauncher.core.profile_manager import Profile


class RoomServerTests(unittest.TestCase):
    def profile(self):
        return Profile(
            id="room-test",
            name="Sala",
            nickname="KatHost",
            version="1.21.1",
            loader="vanilla",
        )

    def test_prepare_writes_safe_lan_properties_and_eula(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)

            def fake_jar(_version, destination):
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_bytes(b"JAR" * 600)

            with mock.patch.object(room_server, "ROOM_ROOT", root), \
                    mock.patch.object(room_server, "port_available", return_value=True), \
                    mock.patch.object(
                        room_server.launcher_core,
                        "ensure_compatible_java",
                        return_value="C:/Java/bin/java.exe",
                    ), \
                    mock.patch.object(room_server, "_ensure_server_jar", fake_jar):
                server = room_server.DedicatedRoomServer(
                    self.profile(), ram_mb=3072, port=25570,
                    world_name="Mundo hardcore", create_world=True,
                    hardcore=True,
                )
                server.prepare()

            properties = (server.directory / "server.properties").read_text(
                encoding="utf-8"
            )
            self.assertIn("server-port=25570", properties)
            self.assertIn("server-ip=\n", properties)
            self.assertIn("online-mode=false", properties)
            self.assertIn("enable-rcon=false", properties)
            self.assertIn("hardcore=true", properties)
            self.assertIn("level-name=Mundo hardcore", properties)
            self.assertEqual(
                (server.directory / "eula.txt").read_text(encoding="utf-8"),
                "eula=true\n",
            )

    def test_cached_signed_jar_does_not_need_network(self):
        with tempfile.TemporaryDirectory() as directory:
            destination = Path(directory) / "server.jar"
            destination.write_bytes(b"signed-server")
            digest = room_server._sha1(destination)
            destination.with_suffix(".jar.sha1").write_text(
                digest + "\n", encoding="ascii"
            )
            with mock.patch.object(room_server.requests, "get") as request:
                room_server._ensure_server_jar("1.21.1", destination)
            request.assert_not_called()

    def test_untrusted_download_url_is_rejected(self):
        with self.assertRaises(room_server.RoomServerError):
            room_server._trusted_url("https://evil.example/server.jar")

    def test_start_uses_ram_limit_nogui_and_no_shell(self):
        server = room_server.DedicatedRoomServer(
            self.profile(), ram_mb=4096, port=25570,
            java_path="C:/Java/bin/java.exe",
        )
        with tempfile.TemporaryDirectory() as directory:
            server.directory = Path(directory)
            server.jar_path = server.directory / "server.jar"
            server.launch_jar = server.jar_path
            server.jar_path.write_bytes(b"JAR" * 600)
            process = types.SimpleNamespace()
            with mock.patch.object(
                room_server.subprocess, "Popen", return_value=process
            ) as popen:
                self.assertIs(server.start(), process)
            command, options = popen.call_args.args[0], popen.call_args.kwargs
            self.assertIn("-Xmx4096M", command)
            self.assertIn("nogui", command)
            self.assertIn("--universe", command)
            self.assertNotIn("shell", options)

    def test_existing_world_is_listed_and_copied_without_session_lock(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            game = root / "game"
            source = game / "saves" / "Mi Mundo"
            source.mkdir(parents=True)
            (source / "level.dat").write_bytes(b"level")
            (source / "session.lock").write_bytes(b"lock")
            profile = self.profile()
            with mock.patch.object(
                    Profile, "game_dir", new_callable=mock.PropertyMock,
                    return_value=str(game)), \
                    mock.patch.object(room_server, "ROOM_ROOT", root / "rooms"):
                worlds = room_server.list_profile_worlds(profile)
                self.assertEqual(worlds[0]["name"], "Mi Mundo")
                server = room_server.DedicatedRoomServer(
                    profile, world_id=worlds[0]["id"],
                    world_name=worlds[0]["name"], hardcore=False,
                )
                server.directory.mkdir(parents=True)
                server._prepare_world()
            copied = server.world_root / server.world_folder
            self.assertEqual((copied / "level.dat").read_bytes(), b"level")
            self.assertFalse((copied / "session.lock").exists())

    def test_invalid_port_is_rejected(self):
        with self.assertRaises(room_server.RoomServerError):
            room_server.DedicatedRoomServer(self.profile(), port=70000)

    def test_modded_profile_uses_loader_installer_and_syncs_mods(self):
        profile = self.profile()
        profile.loader = "fabric"
        with tempfile.TemporaryDirectory() as directory:
            with mock.patch.object(room_server, "ROOM_ROOT", Path(directory)), \
                    mock.patch.object(room_server, "port_available", return_value=True), \
                    mock.patch.object(
                        room_server.launcher_core,
                        "ensure_compatible_java",
                        return_value="C:/Java/bin/java.exe",
                    ), \
                    mock.patch.object(
                        room_server.DedicatedRoomServer,
                        "_prepare_modded_server",
                    ) as installer, \
                    mock.patch.object(
                        room_server.DedicatedRoomServer,
                        "_sync_profile_mods",
                    ) as sync:
                server = room_server.DedicatedRoomServer(profile)
                server.prepare()
            installer.assert_called_once_with("fabric")
            sync.assert_called_once_with()


if __name__ == "__main__":
    unittest.main()
