import hashlib
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from katlauncher.core import bundled_content


class BundledContentTests(unittest.TestCase):
    def test_mckat_is_copied_once_and_verified(self):
        payload = b"PK\x03\x04test-pack"
        digest = hashlib.sha256(payload).hexdigest()
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source = root / "bundled.zip"
            source.write_bytes(payload)
            with mock.patch.object(
                    bundled_content, "bundled_asset", return_value=source), \
                    mock.patch.object(bundled_content, "MCKAT_SHA256", digest):
                target, changed = bundled_content.install_mckat_resource_pack(
                    root / "instance"
                )
                self.assertTrue(changed)
                self.assertEqual(target.read_bytes(), payload)
                same_target, changed = bundled_content.install_mckat_resource_pack(
                    root / "instance"
                )
            self.assertFalse(changed)
            self.assertEqual(same_target, target)

    def test_a_different_user_pack_is_never_overwritten(self):
        payload = b"PK\x03\x04official"
        digest = hashlib.sha256(payload).hexdigest()
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source = root / "bundled.zip"
            source.write_bytes(payload)
            resourcepacks = root / "instance" / "resourcepacks"
            resourcepacks.mkdir(parents=True)
            user_pack = resourcepacks / "MCKAT.zip"
            user_pack.write_bytes(b"custom-user-version")
            with mock.patch.object(
                    bundled_content, "bundled_asset", return_value=source), \
                    mock.patch.object(bundled_content, "MCKAT_SHA256", digest):
                target, changed = bundled_content.install_mckat_resource_pack(
                    root / "instance"
                )
            self.assertTrue(changed)
            self.assertEqual(user_pack.read_bytes(), b"custom-user-version")
            self.assertEqual(target.name, "MCKAT-KatLauncher.zip")


if __name__ == "__main__":
    unittest.main()
