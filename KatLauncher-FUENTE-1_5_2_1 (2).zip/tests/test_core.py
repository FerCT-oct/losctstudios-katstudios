import hashlib
import ast
import base64
import json
import sys
import tempfile
import threading
import time
import types
import unittest
import zipfile
from pathlib import Path
from unittest import mock
from PySide6.QtGui import QColor, QImage


def _install_dependency_stubs():
    try:
        __import__("requests")
    except ImportError:
        requests = types.ModuleType("requests")
        requests.RequestException = Exception
        requests.get = lambda *_args, **_kwargs: None
        sys.modules["requests"] = requests
    try:
        __import__("minecraft_launcher_lib")
    except ImportError:
        mll = types.ModuleType("minecraft_launcher_lib")
        mll.types = types.SimpleNamespace(MinecraftOptions=dict)
        mll.mrpack = types.SimpleNamespace()
        mll.mod_loader = types.SimpleNamespace()
        mll.utils = types.SimpleNamespace(get_installed_versions=lambda *_args: [])
        mll.install = types.SimpleNamespace(
            install_minecraft_version=lambda *_args, **_kwargs: None
        )
        mll.fabric = types.SimpleNamespace()
        mll.forge = types.SimpleNamespace()
        mll.command = types.SimpleNamespace()
        sys.modules["minecraft_launcher_lib"] = mll


_install_dependency_stubs()

from katlauncher.core import (
    launcher_core, modpack_manager, modrinth_api, modrinth_media,
    profile_manager, skins_manager,
)
from katlauncher.core.discord_presence import DEFAULT_DISCORD_CLIENT_ID
from katlauncher.core.settings_manager import SettingsManager
try:
    from katlauncher.gui.i18n import ENGLISH, I18n
except ImportError:
    ENGLISH = {}
    I18n = None


class ProfileManagerTests(unittest.TestCase):
    def test_load_preserves_valid_profiles_when_one_record_is_invalid(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            profiles_file = root / "profiles.json"
            profiles_file.write_text(json.dumps({
                "good123": {
                    "id": "ignored",
                    "name": "Good",
                    "nickname": "Player_1",
                    "version": "1.21.1",
                    "future_field": "ignored safely",
                },
                "migrated": {
                    "name": "Migrated",
                    "nickname": "unsafe name",
                    "version": "1.20.1",
                },
                "GOOD123": {
                    "name": "Case collision",
                    "nickname": "Player2",
                    "version": "1.20.1",
                },
                "bad123": {"name": "Missing required values"},
            }), encoding="utf-8")
            with mock.patch.object(profile_manager, "APP_DIR", root), \
                    mock.patch.object(profile_manager, "GAME_ROOT", root / "instances"), \
                    mock.patch.object(profile_manager, "PROFILES_FILE", profiles_file):
                manager = profile_manager.ProfileManager()
                self.assertEqual(
                    [item.id for item in manager.list_profiles()], ["good123", "migrated"]
                )
                self.assertEqual(manager.get("good123").nickname, "Player_1")
                self.assertEqual(manager.get("migrated").nickname, "Jugador")

    def test_profile_save_is_valid_json_and_keeps_backup(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            profiles_file = root / "profiles.json"
            with mock.patch.object(profile_manager, "APP_DIR", root), \
                    mock.patch.object(profile_manager, "GAME_ROOT", root / "instances"), \
                    mock.patch.object(profile_manager, "PROFILES_FILE", profiles_file):
                manager = profile_manager.ProfileManager()
                manager.create_profile("Second", "Player2", "1.20.1")
                self.assertIsInstance(json.loads(profiles_file.read_text("utf-8")), dict)
                self.assertTrue(profiles_file.with_suffix(".json.bak").is_file())

    def test_nickname_validation_rejects_unsafe_names(self):
        for value in ("../Steve", "A B", "name/skin", "x" * 17, "", "CON", "LPT1"):
            with self.subTest(value=value), self.assertRaises(ValueError):
                profile_manager.validate_nickname(value)
        self.assertEqual(profile_manager.validate_nickname("Player_123"), "Player_123")

    def test_completed_modpack_is_recovered_but_detached_pack_stays_removed(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            game_root = root / "instances"
            profiles_file = root / "profiles.json"
            profile = profile_manager.Profile(
                id="pack123", name="Recovered Pack", nickname="Player1",
                version="1.20.1", loader="fabric", loader_version="0.16.10",
                source_type="modrinth",
            )
            private_dir = game_root / profile.id / ".katlauncher"
            private_dir.mkdir(parents=True)
            (private_dir / "instance.json").write_text(json.dumps({
                "schema_version": 1,
                "profile": profile_manager.asdict(profile),
            }), encoding="utf-8")

            with mock.patch.object(profile_manager, "APP_DIR", root), \
                    mock.patch.object(profile_manager, "GAME_ROOT", game_root), \
                    mock.patch.object(profile_manager, "PROFILES_FILE", profiles_file):
                manager = profile_manager.ProfileManager()
                self.assertIsNotNone(manager.get("pack123"))
                manager.delete_profile("pack123")
                self.assertTrue((private_dir / "detached").is_file())

                restarted = profile_manager.ProfileManager()
                self.assertIsNone(restarted.get("pack123"))
                self.assertEqual([item.name for item in restarted.list_profiles()], ["Vanilla"])

    def test_failed_modpack_delete_restores_profile_and_recovery_marker(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            game_root = root / "instances"
            profiles_file = root / "profiles.json"
            with mock.patch.object(profile_manager, "APP_DIR", root), \
                    mock.patch.object(profile_manager, "GAME_ROOT", game_root), \
                    mock.patch.object(profile_manager, "PROFILES_FILE", profiles_file):
                manager = profile_manager.ProfileManager()
                profile = profile_manager.Profile(
                    id="pack456", name="Pack", nickname="Player1",
                    version="1.20.1", source_type="modrinth",
                )
                manager.register_profile(profile)
                with mock.patch.object(manager, "save", side_effect=OSError("disk full")):
                    with self.assertRaises(OSError):
                        manager.delete_profile(profile.id)
                self.assertIs(manager.get(profile.id), profile)
                self.assertFalse(
                    (game_root / profile.id / ".katlauncher" / "detached").exists()
                )

    def test_malformed_recovery_manifests_do_not_abort_startup(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            game_root = root / "instances"
            profiles_file = root / "profiles.json"
            for profile_id, payload in (
                ("badlist", []),
                ("badprofile", {"profile": []}),
            ):
                private_dir = game_root / profile_id / ".katlauncher"
                private_dir.mkdir(parents=True)
                (private_dir / "instance.json").write_text(
                    json.dumps(payload), encoding="utf-8"
                )
            with mock.patch.object(profile_manager, "APP_DIR", root), \
                    mock.patch.object(profile_manager, "GAME_ROOT", game_root), \
                    mock.patch.object(profile_manager, "PROFILES_FILE", profiles_file):
                manager = profile_manager.ProfileManager()
                self.assertEqual([item.name for item in manager.list_profiles()], ["Vanilla"])


class SettingsManagerTests(unittest.TestCase):
    def test_discord_application_id_and_presence_are_preconfigured(self):
        with tempfile.TemporaryDirectory() as directory:
            manager = SettingsManager(Path(directory) / "settings.json")
            self.assertEqual(
                manager.settings.discord_client_id, DEFAULT_DISCORD_CLIENT_ID
            )
            self.assertEqual(
                manager.settings.discord_client_id, "1423530924783566920"
            )
            self.assertTrue(manager.settings.discord_rich_presence)
            self.assertTrue(manager.settings.auto_install_mckat_pack)

    def test_invalid_values_are_normalized(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "settings.json"
            path.write_text(json.dumps({
                "language": "xx",
                "default_nickname": "unsafe name",
                "default_min_ram": 8000,
                "default_max_ram": 1000,
                "log_max_lines": "not-a-number",
                "show_splash": "false",
                "discord_client_id": "not-an-id",
            }), encoding="utf-8")
            manager = SettingsManager(path)
            self.assertEqual(manager.settings.language, "es")
            self.assertEqual(manager.settings.default_nickname, "Jugador")
            self.assertEqual(manager.settings.default_max_ram, 8000)
            self.assertEqual(manager.settings.log_max_lines, 2000)
            self.assertTrue(manager.settings.show_splash)
            self.assertEqual(
                manager.settings.discord_client_id, DEFAULT_DISCORD_CLIENT_ID
            )

    def test_custom_discord_application_id_is_migrated_to_official(self):
        custom_id = "123456789012345678"
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "settings.json"
            path.write_text(json.dumps({
                "discord_rich_presence": True,
                "discord_client_id": custom_id,
            }), encoding="utf-8")
            manager = SettingsManager(path)
            self.assertTrue(manager.settings.discord_rich_presence)
            self.assertEqual(
                manager.settings.discord_client_id, DEFAULT_DISCORD_CLIENT_ID
            )

    def test_legacy_and_corrupt_settings_receive_the_new_presence_default(self):
        payloads = ({"language": "en"}, "{")
        for index, payload in enumerate(payloads):
            with self.subTest(payload=payload), tempfile.TemporaryDirectory() as directory:
                path = Path(directory) / f"settings-{index}.json"
                text = json.dumps(payload) if isinstance(payload, dict) else payload
                path.write_text(text, encoding="utf-8")
                manager = SettingsManager(path)
                self.assertTrue(manager.settings.discord_rich_presence)
                self.assertEqual(
                    manager.settings.discord_client_id, DEFAULT_DISCORD_CLIENT_ID
                )

    def test_failed_update_restores_in_memory_settings(self):
        with tempfile.TemporaryDirectory() as directory:
            manager = SettingsManager(Path(directory) / "settings.json")
            with mock.patch.object(manager, "save", side_effect=OSError("disk full")):
                with self.assertRaises(OSError):
                    manager.update(language="en", default_nickname="Player1")
            self.assertEqual(manager.settings.language, "es")
            self.assertEqual(manager.settings.default_nickname, "Jugador")

    def test_non_object_json_uses_defaults(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "settings.json"
            path.write_text("[]", encoding="utf-8")
            manager = SettingsManager(path)
            self.assertEqual(manager.settings.language, "es")
            self.assertEqual(manager.settings.default_nickname, "Jugador")


class LauncherHelpersTests(unittest.TestCase):
    def test_minecraft_process_is_started_without_a_windows_console(self):
        profile = profile_manager.Profile(
            id="launch-test",
            name="Launch test",
            nickname="Player1",
            version="1.21.1",
            server_host="play.example.net",
            server_port=25570,
        )
        process = object()
        with tempfile.TemporaryDirectory() as directory, mock.patch.object(
            profile_manager, "GAME_ROOT", Path(directory)
        ), mock.patch.object(
            launcher_core, "resolve_installed_version_id", return_value="1.21.1"
        ), mock.patch.object(
            launcher_core.mll.command,
            "get_minecraft_command",
            return_value=["java.exe", "-version"],
        ) as command_builder, mock.patch.object(
            launcher_core.subprocess, "Popen", return_value=process
        ) as popen:
            self.assertIs(launcher_core.launch(profile), process)

        launch_options = command_builder.call_args.args[2]
        self.assertEqual(launch_options["server"], "play.example.net")
        self.assertEqual(launch_options["port"], "25570")

        command, = popen.call_args.args
        options = popen.call_args.kwargs
        self.assertEqual(command, ["java.exe", "-version"])
        self.assertIs(options["stdout"], launcher_core.subprocess.PIPE)
        self.assertIs(options["stderr"], launcher_core.subprocess.STDOUT)
        self.assertNotIn("shell", options)
        if hasattr(launcher_core.subprocess, "CREATE_NO_WINDOW"):
            self.assertEqual(
                options["creationflags"], launcher_core.subprocess.CREATE_NO_WINDOW
            )
            self.assertTrue(
                options["startupinfo"].dwFlags
                & launcher_core.subprocess.STARTF_USESHOWWINDOW
            )
            self.assertEqual(
                options["startupinfo"].wShowWindow,
                launcher_core.subprocess.SW_HIDE,
            )

    def test_offline_uuid_matches_minecraft_and_legacy_is_available(self):
        self.assertEqual(
            profile_manager.offline_uuid("Notch"),
            "b50ad385-829d-3141-a216-7e7d7539ba7f",
        )
        self.assertNotEqual(
            profile_manager.offline_uuid("Notch", legacy=True),
            profile_manager.offline_uuid("Notch"),
        )

    def test_jvm_arguments_keep_windows_paths_with_spaces(self):
        parsed = launcher_core._split_jvm_arguments(
            '-Djava.library.path="C:\\Program Files\\Java\\lib" -XX:+UseG1GC'
        )
        self.assertEqual(parsed, [
            "-Djava.library.path=C:\\Program Files\\Java\\lib",
            "-XX:+UseG1GC",
        ])

    def test_loader_ids_match_exact_minecraft_version(self):
        self.assertTrue(launcher_core._matches_loader_id(
            "fabric-loader-0.16.10-1.20.1", "fabric", "1.20.1"
        ))
        self.assertFalse(launcher_core._matches_loader_id(
            "fabric-loader-0.16.10-1.20.1", "fabric", "1.20"
        ))

    def test_existing_installation_is_still_verified_and_repaired(self):
        with tempfile.TemporaryDirectory() as directory:
            game_root = Path(directory) / "instances"
            profile = profile_manager.Profile(
                id="repair123", name="Repair", nickname="Player1", version="1.20.1"
            )
            with mock.patch.object(profile_manager, "GAME_ROOT", game_root):
                version_dir = Path(profile.game_dir) / "versions" / profile.version
                version_dir.mkdir(parents=True)
                (version_dir / f"{profile.version}.json").write_text("{}", encoding="utf-8")
                (version_dir / f"{profile.version}.jar").write_bytes(b"jar")
                with mock.patch.object(launcher_core, "get_installed_versions",
                                       return_value=[profile.version]), \
                        mock.patch.object(launcher_core.mll.utils, "get_installed_versions",
                                          return_value=[{"id": profile.version}]), \
                        mock.patch.object(
                            launcher_core.mll.install, "install_minecraft_version"
                        ) as install:
                    result = launcher_core.install_version(profile)
            self.assertEqual(result, profile.version)
            install.assert_called_once()

    def test_existing_installation_can_launch_when_repair_has_no_network(self):
        with tempfile.TemporaryDirectory() as directory, \
                mock.patch.object(profile_manager, "GAME_ROOT", Path(directory)):
            profile = profile_manager.Profile(
                id="offline123", name="Offline", nickname="Player1", version="1.20.1"
            )
            statuses = []
            with mock.patch.object(launcher_core, "is_profile_installed", return_value=True), \
                    mock.patch.object(
                        launcher_core, "resolve_installed_version_id",
                        return_value="1.20.1",
                    ), mock.patch.object(
                        launcher_core.mll.install, "install_minecraft_version",
                        side_effect=launcher_core.requests.ConnectionError("offline"),
                    ):
                result = launcher_core.install_version(profile, status_cb=statuses.append)
        self.assertEqual(result, "1.20.1")
        self.assertIn("Sin conexión", statuses[-1])

    def test_modern_loader_selects_compatible_java_and_latest_loader(self):
        with tempfile.TemporaryDirectory() as directory, \
                mock.patch.object(profile_manager, "GAME_ROOT", Path(directory)):
            profile = profile_manager.Profile(
                id="loader123", name="Fabric", nickname="Player1",
                version="1.21.1", loader="fabric",
            )
            loader = mock.Mock()
            loader.is_minecraft_version_supported.return_value = True
            loader.get_latest_loader_version.return_value = "0.16.10"
            loader.install.return_value = "fabric-loader-0.16.10-1.21.1"
            java_info = [{
                "version": "21.0.4", "is_64bit": True,
                "java_path": "C:/Java21/bin/java.exe",
            }]
            with mock.patch.object(launcher_core, "is_profile_installed", return_value=False), \
                    mock.patch.object(
                        launcher_core.mll.mod_loader, "get_mod_loader", return_value=loader,
                    ), mock.patch.object(
                        launcher_core.mll.java_utils,
                        "find_system_java_versions_information", return_value=java_info,
                    ), mock.patch.object(
                        launcher_core.mll.install, "install_minecraft_version",
                    ):
                result = launcher_core.install_version(profile)
            self.assertEqual(result, "fabric-loader-0.16.10-1.21.1")
            self.assertEqual(loader.install.call_args.kwargs["loader_version"], "0.16.10")
            self.assertEqual(loader.install.call_args.kwargs["java"], "C:/Java21/bin/java.exe")

    def test_modern_loader_installs_managed_java_when_missing(self):
        with tempfile.TemporaryDirectory() as directory, \
                mock.patch.object(profile_manager, "GAME_ROOT", Path(directory)):
            profile = profile_manager.Profile(
                id="loader456", name="Forge", nickname="Player1",
                version="1.20.6", loader="forge",
            )
            loader = mock.Mock()
            loader.is_minecraft_version_supported.return_value = True
            loader.get_latest_loader_version.return_value = "50.1.0"
            with mock.patch.object(launcher_core, "is_profile_installed", return_value=False), \
                    mock.patch.object(
                        launcher_core.mll.mod_loader, "get_mod_loader", return_value=loader,
                    ), mock.patch.object(
                        launcher_core.mll.java_utils,
                        "find_system_java_versions_information", return_value=[{
                            "version": "1.8.0_401", "is_64bit": True,
                            "java_path": "C:/Java8/bin/java.exe",
                        }],
                    ), mock.patch.object(
                        launcher_core.mll.install, "install_minecraft_version",
                    ), mock.patch.object(
                        launcher_core.mll.runtime, "get_executable_path",
                        side_effect=[None, "C:/Kat/runtime/java-runtime-delta/bin/java.exe"],
                    ), mock.patch.object(
                        launcher_core.mll.runtime, "install_jvm_runtime",
                    ) as install_runtime:
                launcher_core.install_version(profile)
            install_runtime.assert_called_once()
            self.assertEqual(
                loader.install.call_args.kwargs["java"],
                "C:/Kat/runtime/java-runtime-delta/bin/java.exe",
            )

    def test_calendar_minecraft_uses_java_25(self):
        self.assertEqual(launcher_core.required_java_major("26.2"), 25)


@unittest.skipIf(I18n is None, "PySide6 is not installed")
class I18nTests(unittest.TestCase):
    def test_dynamic_errors_and_external_statuses_are_translated(self):
        translator = I18n("en")
        self.assertEqual(
            translator.t("No se descargó un archivo requerido: mods/a.jar."),
            "A required file was not downloaded: mods/a.jar.",
        )
        self.assertEqual(
            translator.t("Minecraft 1.20.1 no está instalado"),
            "Minecraft 1.20.1 is not installed",
        )
        self.assertEqual(
            translator.t(
                "El modpack usa dependencias que KatLauncher aún no admite: future-loader"
            ),
            "The modpack uses dependencies KatLauncher does not support yet: future-loader",
        )
        self.assertEqual(
            translator.t(
                "No se pudo descargar mods/a.jar: La descarga excedió el tamaño esperado."
            ),
            "Could not download mods/a.jar: The download exceeded the expected size.",
        )
        translator.set_language("es")
        self.assertEqual(translator.t("Download Libraries"), "Descargando librerías")

    def test_gui_literal_strings_have_english_catalog_entries(self):
        gui_root = Path(__file__).parents[1] / "katlauncher" / "gui"
        used = set()
        for path in gui_root.glob("*.py"):
            tree = ast.parse(path.read_text(encoding="utf-8"))
            for node in ast.walk(tree):
                is_translation_call = isinstance(node, ast.Call) and (
                    isinstance(node.func, ast.Attribute) and node.func.attr == "t"
                    or isinstance(node.func, ast.Name) and node.func.id == "t"
                )
                if is_translation_call and node.args \
                        and isinstance(node.args[0], ast.Constant) \
                        and isinstance(node.args[0].value, str):
                    used.add(node.args[0].value)
        self.assertEqual(used - set(ENGLISH), set())


class FilesystemSafetyTests(unittest.TestCase):
    def test_cancelled_modrinth_download_keeps_existing_target(self):
        with tempfile.TemporaryDirectory() as directory:
            destination = Path(directory) / "mod.jar"
            destination.write_bytes(b"existing")
            replacement = b"replacement"
            descriptor = {
                "url": "https://cdn.modrinth.com/data/test/mod.jar",
                "fileSize": len(replacement),
                "hashes": {"sha1": hashlib.sha1(replacement).hexdigest()},
            }
            cancelled = threading.Event()
            response = mock.Mock()
            response.iter_content.return_value = [replacement]
            with mock.patch.object(
                modrinth_api, "_open_download", return_value=response
            ):
                with self.assertRaises(modrinth_api.ModrinthError):
                    modrinth_api.download_file(
                        descriptor,
                        destination,
                        progress_cb=lambda _value: cancelled.set(),
                        cancel_cb=cancelled.is_set,
                    )
            self.assertEqual(destination.read_bytes(), b"existing")
            self.assertEqual(list(destination.parent.glob(".kat-*.part")), [])

    def test_modrinth_filenames_reject_windows_unsafe_names(self):
        for filename in ("CON.jar", "bad?.jar", "trail .", "x" * 241 + ".jar"):
            with self.subTest(filename=filename), self.assertRaises(
                modrinth_api.ModrinthError
            ):
                modrinth_api._validate_filename(filename, ".jar")

    def test_download_file_enforces_exact_file_size(self):
        cases = ((0, b"x"), (1, b"xx"))
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            for expected_size, chunk in cases:
                with self.subTest(expected_size=expected_size):
                    destination = root / f"file-{expected_size}.jar"
                    response = mock.Mock()
                    response.iter_content.return_value = [chunk]
                    descriptor = {
                        "url": "https://cdn.modrinth.com/data/test/file.jar",
                        "fileSize": expected_size,
                        "hashes": {
                            "sha1": hashlib.sha1(chunk).hexdigest(),
                            "sha512": hashlib.sha512(chunk).hexdigest(),
                        },
                    }
                    with mock.patch.object(
                        modrinth_api, "_open_download", return_value=response
                    ), self.assertRaisesRegex(
                        modrinth_api.ModrinthError, "excedió el tamaño esperado"
                    ):
                        modrinth_api.download_file(descriptor, destination)
                    self.assertFalse(destination.exists())
                    self.assertFalse(
                        destination.with_name(destination.name + ".part").exists()
                    )
                    self.assertEqual(list(root.glob(".kat-*.part")), [])
                    response.close.assert_called_once()

    def test_redirect_only_hosts_are_not_valid_initial_urls(self):
        url = "https://release-assets.githubusercontent.com/example/file.jar"
        with self.assertRaises(modrinth_api.ModrinthError):
            modrinth_api._validated_download_url(url)
        self.assertEqual(
            modrinth_api._validated_download_url(url, is_redirect=True), url
        )

    def test_clearing_active_skin_removes_both_cached_copies(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            skins_dir = root / "skins"
            game_dir = root / "game"
            skins_dir.mkdir()
            internal = skins_dir / "active_skin.png"
            external = game_dir / "CustomSkinLoader" / "LocalSkin" / "skins" / "Player1.png"
            internal.write_bytes(b"png")
            external.parent.mkdir(parents=True)
            external.write_bytes(b"png")
            skins_manager.clear_active_skin(
                str(skins_dir), str(game_dir), "Player1"
            )
            self.assertFalse(internal.exists())
            self.assertFalse(external.exists())

    def test_nickname_skin_migration_can_rollback_and_commit(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            game = root / "game"
            source = root / "chosen.png"
            source.write_bytes(b"new-skin")
            skins = game / "CustomSkinLoader" / "LocalSkin" / "skins"
            skins.mkdir(parents=True)
            old_path = skins / "OldNick.png"
            new_path = skins / "NewNick.png"
            old_path.write_bytes(b"old-active")
            new_path.write_bytes(b"preexisting")

            migration = skins_manager.stage_nickname_skin_migration(
                str(game), "OldNick", "NewNick", str(source)
            )
            self.assertEqual(new_path.read_bytes(), b"new-skin")
            migration.rollback()
            self.assertEqual(old_path.read_bytes(), b"old-active")
            self.assertEqual(new_path.read_bytes(), b"preexisting")

            migration = skins_manager.stage_nickname_skin_migration(
                str(game), "OldNick", "NewNick", str(source)
            )
            migration.commit()
            self.assertFalse(old_path.exists())
            self.assertEqual(new_path.read_bytes(), b"new-skin")

    def test_skin_can_be_copied_by_mojang_username(self):
        encoded = base64.b64encode(json.dumps({
            "textures": {
                "SKIN": {"url": "https://textures.minecraft.net/texture/abc123"}
            }
        }).encode()).decode()
        profile_response = mock.Mock(status_code=200)
        profile_response.json.return_value = {
            "id": "a" * 32, "name": "Notch",
        }
        textures_response = mock.Mock(status_code=200)
        textures_response.json.return_value = {
            "properties": [{"name": "textures", "value": encoded}]
        }
        skin_response = mock.Mock(
            status_code=200, content=b"\x89PNG\r\n\x1a\npublic-skin"
        )
        client = mock.Mock()
        client.get.side_effect = [
            profile_response, textures_response, skin_response,
        ]
        with tempfile.TemporaryDirectory() as directory:
            path = Path(skins_manager.download_skin_by_username(
                directory, "Notch", session=client,
            ))
            self.assertEqual(path.name, "Notch.png")
            self.assertTrue(path.read_bytes().startswith(b"\x89PNG"))
        self.assertEqual(client.get.call_count, 3)

    def test_local_cape_and_elytra_can_be_installed_and_removed(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source = root / "cape.png"
            image = QImage(64, 32, QImage.Format_ARGB32)
            image.fill(QColor("#7048ff"))
            self.assertTrue(image.save(str(source), "PNG"))
            game = root / "game"
            cape = Path(skins_manager.install_local_cosmetic_for_profile(
                str(game), "Player1", str(source), "cape"
            ))
            elytra = Path(skins_manager.install_local_cosmetic_for_profile(
                str(game), "Player1", str(source), "elytra"
            ))
            self.assertTrue(cape.read_bytes().startswith(b"\x89PNG"))
            self.assertTrue(elytra.read_bytes().startswith(b"\x89PNG"))
            config = json.loads((
                game / "CustomSkinLoader" / "CustomSkinLoader.json"
            ).read_text(encoding="utf-8"))
            self.assertEqual(config["loadlist"][0]["cape"],
                             "LocalSkin/capes/{USERNAME}.png")
            skins_manager.remove_local_cosmetic(
                str(game), "Player1", "cape"
            )
            self.assertFalse(cape.exists())
            self.assertTrue(elytra.exists())


def _valid_index(**overrides):
    index = {
        "formatVersion": 1,
        "game": "minecraft",
        "versionId": "test-1",
        "name": "Test Pack",
        "summary": "Fixture",
        "files": [],
        "dependencies": {"minecraft": "1.20.1", "fabric-loader": "0.16.10"},
    }
    index.update(overrides)
    return index


def _write_mrpack(path: Path, index: dict, extra=None):
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("modrinth.index.json", json.dumps(index))
        for name, content in extra or []:
            archive.writestr(name, content)


def _manifest_file(path: str, content: bytes, env=None):
    item = {
        "path": path,
        "hashes": {
            "sha1": hashlib.sha1(content).hexdigest(),
            "sha512": hashlib.sha512(content).hexdigest(),
        },
        "downloads": ["https://cdn.modrinth.com/data/test/file.jar"],
        "fileSize": len(content),
    }
    if env is not None:
        item["env"] = env
    return item


class MrpackValidationTests(unittest.TestCase):
    def test_folder_can_be_exported_as_a_portable_mrpack(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source = root / "source"
            (source / "config").mkdir(parents=True)
            (source / "config" / "kat.json").write_text("{}", encoding="utf-8")
            (source / "versions").mkdir()
            (source / "versions" / "do-not-bundle.jar").write_bytes(b"runtime")
            output = root / "Kat Pack.mrpack"
            modpack_manager.export_folder_to_mrpack(
                source, output, name="Kat Pack", minecraft_version="1.21.1",
                loader="fabric", loader_version="0.16.10",
            )
            index, derived = modpack_manager.inspect_mrpack(output)
            self.assertEqual(index["name"], "Kat Pack")
            self.assertEqual(derived["loader"], "fabric")
            with zipfile.ZipFile(output) as archive:
                self.assertIn("overrides/config/kat.json", archive.namelist())
                self.assertNotIn(
                    "overrides/versions/do-not-bundle.jar", archive.namelist()
                )

    def test_valid_pack_is_inspected(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "valid.mrpack"
            _write_mrpack(path, _valid_index())
            _index, derived = modpack_manager.inspect_mrpack(path)
            self.assertEqual(derived["minecraft_version"], "1.20.1")
            self.assertEqual(derived["loader"], "fabric")
            self.assertEqual(derived["loader_version"], "0.16.10")

    def test_oversized_index_is_rejected_before_it_is_read(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "large-index.mrpack"
            with zipfile.ZipFile(path, "w") as archive:
                archive.writestr("modrinth.index.json", b"x" * 11)
            with mock.patch.object(modpack_manager, "MAX_INDEX_SIZE", 10), \
                    mock.patch.object(
                        zipfile.ZipFile, "read",
                        side_effect=AssertionError("oversized index was read"),
                    ), self.assertRaisesRegex(
                        modpack_manager.ModpackError, "índice del modpack es demasiado grande"
                    ):
                modpack_manager.inspect_mrpack(path)

    def test_oversized_local_archive_is_rejected_before_zip_parsing(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "large.mrpack"
            path.write_bytes(b"x" * 11)
            with mock.patch.object(modpack_manager, "MAX_ARCHIVE_SIZE", 10), \
                    mock.patch.object(
                        zipfile, "ZipFile",
                        side_effect=AssertionError("oversized archive was parsed"),
                    ), self.assertRaisesRegex(
                        modpack_manager.ModpackError,
                        "archivo .mrpack es demasiado grande",
                    ):
                modpack_manager.inspect_mrpack(path)

    def test_manifest_path_traversal_is_rejected(self):
        content = b"jar"
        bad_file = {
            "path": "../outside.jar",
            "hashes": {
                "sha1": hashlib.sha1(content).hexdigest(),
                "sha512": hashlib.sha512(content).hexdigest(),
            },
            "downloads": ["https://cdn.modrinth.com/data/test/file.jar"],
            "fileSize": len(content),
        }
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "bad.mrpack"
            _write_mrpack(path, _valid_index(files=[bad_file]))
            with self.assertRaises(modpack_manager.ModpackError):
                modpack_manager.inspect_mrpack(path)

    def test_zip_path_traversal_and_symlinks_are_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            traversal = Path(directory) / "traversal.mrpack"
            _write_mrpack(traversal, _valid_index(), [("overrides/../../evil.txt", b"x")])
            with self.assertRaises(modpack_manager.ModpackError):
                modpack_manager.inspect_mrpack(traversal)

            symlink = Path(directory) / "symlink.mrpack"
            with zipfile.ZipFile(symlink, "w") as archive:
                archive.writestr("modrinth.index.json", json.dumps(_valid_index()))
                info = zipfile.ZipInfo("overrides/link")
                info.create_system = 3
                info.external_attr = 0o120777 << 16
                archive.writestr(info, "target")
            with self.assertRaises(modpack_manager.ModpackError):
                modpack_manager.inspect_mrpack(symlink)

    def test_client_overrides_are_applied_after_common_overrides(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            path = root / "layers.mrpack"
            with zipfile.ZipFile(path, "w") as archive:
                archive.writestr("modrinth.index.json", json.dumps(_valid_index()))
                # El orden del ZIP es intencionalmente el contrario al de las capas.
                archive.writestr("client-overrides/config/value.txt", "client")
                archive.writestr("overrides/config/value.txt", "common")
            destination = root / "instance"
            destination.mkdir()
            modpack_manager.inspect_mrpack(path)
            modpack_manager._apply_override_layers(path, destination)
            self.assertEqual(
                (destination / "config" / "value.txt").read_text("utf-8"), "client"
            )

    def test_multiple_or_unknown_loaders_are_rejected(self):
        cases = (
            {"minecraft": "1.20.1", "fabric-loader": "1", "forge": "2"},
            {"minecraft": "1.20.1", "future-loader": "1"},
        )
        with tempfile.TemporaryDirectory() as directory:
            for index, dependencies in enumerate(cases):
                path = Path(directory) / f"bad-{index}.mrpack"
                _write_mrpack(path, _valid_index(dependencies=dependencies))
                with self.subTest(dependencies=dependencies), \
                    self.assertRaises(modpack_manager.ModpackError):
                    modpack_manager.inspect_mrpack(path)

    def test_optional_client_files_are_verified_only_when_selected(self):
        content = b"optional"
        item = _manifest_file(
            "mods/optional.jar", content,
            env={"client": "optional", "server": "unsupported"},
        )
        index = _valid_index(files=[item])
        with tempfile.TemporaryDirectory() as directory:
            destination = Path(directory) / "instance"
            destination.mkdir()
            modpack_manager._verify_manifest_files(index, destination, [])
            with self.assertRaises(modpack_manager.ModpackError):
                modpack_manager._verify_manifest_files(
                    index, destination, ["mods/optional.jar"]
                )

    def test_incomplete_environment_declaration_is_rejected(self):
        content = b"x"
        item = _manifest_file(
            "mods/client.jar", content, env={"client": "required"}
        )
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "bad-env.mrpack"
            _write_mrpack(path, _valid_index(files=[item]))
            with self.assertRaises(modpack_manager.ModpackError):
                modpack_manager.inspect_mrpack(path)

    def test_manifest_download_count_and_total_size_are_limited(self):
        content = b"xx"
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            count_pack = root / "count.mrpack"
            _write_mrpack(count_pack, _valid_index(files=[
                _manifest_file("mods/a.jar", content),
                _manifest_file("mods/b.jar", content),
            ]))
            with mock.patch.object(modpack_manager, "MAX_MANIFEST_FILES", 1), \
                    self.assertRaises(modpack_manager.ModpackError):
                modpack_manager.inspect_mrpack(count_pack)

            size_pack = root / "size.mrpack"
            _write_mrpack(size_pack, _valid_index(files=[
                _manifest_file("mods/a.jar", content),
            ]))
            with mock.patch.object(modpack_manager, "MAX_MANIFEST_DOWNLOAD_SIZE", 1), \
                    self.assertRaises(modpack_manager.ModpackError):
                modpack_manager.inspect_mrpack(size_pack)

    def test_manifest_file_directory_conflicts_are_rejected_in_both_orders(self):
        content = b"x"
        cases = (
            [
                _manifest_file("config/value", content),
                _manifest_file("config/value/nested.txt", content),
            ],
            [
                _manifest_file("config/value/nested.txt", content),
                _manifest_file("config/value", content),
            ],
        )
        with tempfile.TemporaryDirectory() as directory:
            for index, files in enumerate(cases):
                path = Path(directory) / f"conflict-{index}.mrpack"
                _write_mrpack(path, _valid_index(files=files))
                with self.subTest(order=index), self.assertRaisesRegex(
                    modpack_manager.ModpackError, "conflicto entre archivo y carpeta"
                ):
                    modpack_manager.inspect_mrpack(path)

    def test_internal_metadata_and_invalid_windows_names_are_rejected(self):
        content = b"x"
        cases = (
            ".katlauncher/detached",
            "mods/bad?.jar",
            "mods/CON.jar",
        )
        with tempfile.TemporaryDirectory() as directory:
            for index, unsafe_path in enumerate(cases):
                pack = Path(directory) / f"unsafe-{index}.mrpack"
                _write_mrpack(pack, _valid_index(files=[
                    _manifest_file(unsafe_path, content),
                ]))
                with self.subTest(path=unsafe_path), \
                        self.assertRaises(modpack_manager.ModpackError):
                    modpack_manager.inspect_mrpack(pack)

    def test_local_install_downloads_manifest_without_mll_and_promotes(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            content = b"jar"
            archive_path = root / "pack.mrpack"
            _write_mrpack(archive_path, _valid_index(files=[
                _manifest_file("mods/fixture.jar", content),
            ]))
            game_root = root / "instances"

            def fake_download(_descriptor, destination, **_kwargs):
                destination = Path(destination)
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_bytes(content)
                return str(destination)

            with mock.patch.object(modpack_manager, "GAME_ROOT", game_root), \
                    mock.patch.object(modpack_manager, "APP_DIR", root), \
                    mock.patch.object(profile_manager, "GAME_ROOT", game_root), \
                    mock.patch.object(modpack_manager.mll.mrpack, "get_mrpack_information",
                                      return_value={"name": "Pack", "summary": "Fixture", "versionId": "v1"},
                                      create=True), \
                    mock.patch.object(modpack_manager.mll.mrpack, "get_mrpack_launch_version",
                                      return_value="fabric-loader-0.16.10-1.20.1", create=True), \
                    mock.patch.object(modpack_manager.mll.mrpack, "install_mrpack",
                                      create=True) as legacy_install, \
                    mock.patch.object(modpack_manager.modrinth_api, "download_file",
                                      side_effect=fake_download) as download, \
                    mock.patch.object(modpack_manager.launcher_core, "install_version",
                                      return_value="fabric-loader-0.16.10-1.20.1"):
                result = modpack_manager.install_modpack(
                    nickname="Player1", local_path=str(archive_path)
                )

            final_dir = game_root / result["id"]
            self.assertEqual((final_dir / "mods" / "fixture.jar").read_bytes(), content)
            self.assertTrue((final_dir / ".katlauncher" / "source.mrpack").is_file())
            self.assertFalse(any(path.name.startswith(".staging-") for path in game_root.iterdir()))
            download.assert_called_once()
            legacy_install.assert_not_called()

    def test_manifest_download_uses_next_url_after_failure(self):
        with tempfile.TemporaryDirectory() as directory:
            destination = Path(directory) / "instance"
            destination.mkdir()
            content = b"mirror-content"
            item = _manifest_file("mods/mirror.jar", content)
            first = "https://cdn.modrinth.com/data/test/first.jar"
            second = "https://cdn.modrinth.com/data/test/second.jar"
            item["downloads"] = [first, second]
            index = _valid_index(files=[item])
            attempts = []

            def fake_download(descriptor, target, **_kwargs):
                attempts.append(descriptor["url"])
                if descriptor["url"] == first:
                    raise modrinth_api.ModrinthError("mirror down")
                target = Path(target)
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(content)
                return str(target)

            with mock.patch.object(
                modpack_manager.modrinth_api, "download_file",
                side_effect=fake_download,
            ):
                modpack_manager._download_manifest_files(index, destination, [])
            self.assertEqual(attempts, [first, second])
            self.assertEqual(
                (destination / "mods" / "mirror.jar").read_bytes(), content
            )
            modpack_manager._verify_manifest_files(index, destination, [])

    def test_stream_failure_uses_next_manifest_mirror(self):
        with tempfile.TemporaryDirectory() as directory:
            destination = Path(directory) / "instance"
            destination.mkdir()
            content = b"second-mirror"
            item = _manifest_file("mods/mirror.jar", content)
            first = "https://cdn.modrinth.com/data/test/first.jar"
            second = "https://cdn.modrinth.com/data/test/second.jar"
            item["downloads"] = [first, second]
            index = _valid_index(files=[item])
            attempts = []

            first_response = mock.Mock()
            first_response.iter_content.side_effect = \
                modrinth_api.requests.ConnectionError("stream interrupted")
            second_response = mock.Mock()
            second_response.iter_content.return_value = [content]

            def fake_open(url):
                attempts.append(url)
                return first_response if url == first else second_response

            with mock.patch.object(
                modrinth_api, "_open_download", side_effect=fake_open
            ):
                modpack_manager._download_manifest_files(index, destination, [])

            self.assertEqual(attempts, [first, second])
            self.assertEqual(
                (destination / "mods" / "mirror.jar").read_bytes(), content
            )
            self.assertEqual(list((destination / "mods").glob(".kat-*.part")), [])
            first_response.close.assert_called_once()
            second_response.close.assert_called_once()

    def test_download_temporaries_do_not_collide_with_manifest_paths(self):
        with tempfile.TemporaryDirectory() as directory:
            destination = Path(directory) / "instance"
            destination.mkdir()
            contents = {
                "https://cdn.modrinth.com/data/test/value-part": b"part-file",
                "https://cdn.modrinth.com/data/test/value": b"plain-file",
            }
            first = _manifest_file("config/value.part", contents[
                "https://cdn.modrinth.com/data/test/value-part"
            ])
            first["downloads"] = ["https://cdn.modrinth.com/data/test/value-part"]
            second = _manifest_file("config/value", contents[
                "https://cdn.modrinth.com/data/test/value"
            ])
            second["downloads"] = ["https://cdn.modrinth.com/data/test/value"]
            index = _valid_index(files=[first, second])

            def fake_open(url):
                response = mock.Mock()
                response.iter_content.return_value = [contents[url]]
                return response

            with mock.patch.object(
                modrinth_api, "_open_download", side_effect=fake_open
            ):
                modpack_manager._download_manifest_files(index, destination, [])

            self.assertEqual(
                (destination / "config" / "value.part").read_bytes(), b"part-file"
            )
            self.assertEqual(
                (destination / "config" / "value").read_bytes(), b"plain-file"
            )
            modpack_manager._verify_manifest_files(index, destination, [])

    def test_manifest_files_download_in_bounded_parallel_with_monotonic_progress(self):
        with tempfile.TemporaryDirectory() as directory:
            destination = Path(directory) / "instance"
            destination.mkdir()
            files = []
            contents = {}
            for index in range(12):
                content = f"parallel-{index}".encode()
                url = f"https://cdn.modrinth.com/data/test/{index}.jar"
                item = _manifest_file(f"mods/{index}.jar", content)
                item["downloads"] = [url]
                files.append(item)
                contents[url] = content

            active = 0
            maximum_active = 0
            active_lock = threading.Lock()
            progress = []

            def fake_download(descriptor, target, progress_cb=None, **_kwargs):
                nonlocal active, maximum_active
                content = contents[descriptor["url"]]
                with active_lock:
                    active += 1
                    maximum_active = max(maximum_active, active)
                try:
                    if progress_cb:
                        progress_cb(max(1, len(content) // 2))
                    time.sleep(0.03)
                    target = Path(target)
                    target.parent.mkdir(parents=True, exist_ok=True)
                    target.write_bytes(content)
                    if progress_cb:
                        progress_cb(len(content))
                    return str(target)
                finally:
                    with active_lock:
                        active -= 1

            index = _valid_index(files=files)
            with mock.patch.object(
                modpack_manager.modrinth_api,
                "download_file",
                side_effect=fake_download,
            ):
                modpack_manager._download_manifest_files(
                    index, destination, [], progress_cb=progress.append
                )

            self.assertGreater(maximum_active, 1)
            self.assertLessEqual(maximum_active, modpack_manager.MAX_PARALLEL_DOWNLOADS)
            self.assertEqual(progress, sorted(progress))
            self.assertEqual(
                progress[-1], len(files) * modpack_manager.PROGRESS_STEPS_PER_FILE
            )
            modpack_manager._verify_manifest_files(index, destination, [])

    def test_parallel_manifest_failure_cancels_active_download_before_publish(self):
        with tempfile.TemporaryDirectory() as directory:
            destination = Path(directory) / "instance"
            destination.mkdir()
            failed = _manifest_file("mods/fail.jar", b"fail")
            failed["downloads"] = ["https://cdn.modrinth.com/data/test/fail.jar"]
            slow = _manifest_file("mods/slow.jar", b"slow")
            slow["downloads"] = ["https://cdn.modrinth.com/data/test/slow.jar"]
            slow_started = threading.Event()

            def fake_download(descriptor, target, cancel_cb=None, **_kwargs):
                if descriptor["url"].endswith("fail.jar"):
                    slow_started.wait(1)
                    raise modrinth_api.ModrinthError("failed")
                slow_started.set()
                for _ in range(100):
                    if cancel_cb and cancel_cb():
                        raise modrinth_api.ModrinthError("cancelled")
                    time.sleep(0.005)
                target = Path(target)
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(b"slow")
                return str(target)

            started_at = time.monotonic()
            with mock.patch.object(
                modpack_manager.modrinth_api,
                "download_file",
                side_effect=fake_download,
            ):
                with self.assertRaises(modpack_manager.ModpackError):
                    modpack_manager._download_manifest_files(
                        _valid_index(files=[failed, slow]), destination, []
                    )
            self.assertLess(time.monotonic() - started_at, 0.4)
            self.assertFalse((destination / "mods" / "slow.jar").exists())

    def test_failed_mirror_cannot_report_one_hundred_percent(self):
        with tempfile.TemporaryDirectory() as directory:
            destination = Path(directory) / "instance"
            destination.mkdir()
            content = b"verified"
            item = _manifest_file("mods/mirror.jar", content)
            first = "https://cdn.modrinth.com/data/test/first.jar"
            second = "https://cdn.modrinth.com/data/test/second.jar"
            item["downloads"] = [first, second]
            progress = []

            def fake_download(descriptor, target, progress_cb=None, **_kwargs):
                if progress_cb:
                    progress_cb(len(content))
                if descriptor["url"] == first:
                    raise modrinth_api.ModrinthError("bad mirror")
                target = Path(target)
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(content)
                return str(target)

            with mock.patch.object(
                modpack_manager.modrinth_api,
                "download_file",
                side_effect=fake_download,
            ):
                modpack_manager._download_manifest_files(
                    _valid_index(files=[item]),
                    destination,
                    [],
                    progress_cb=progress.append,
                )
            maximum = modpack_manager.PROGRESS_STEPS_PER_FILE
            self.assertEqual(progress[-1], maximum)
            self.assertNotIn(maximum, progress[:-1])

    def test_install_verifies_manifest_before_overlapping_override(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            downloaded = b"downloaded"
            archive_path = root / "pack.mrpack"
            _write_mrpack(
                archive_path,
                _valid_index(files=[
                    _manifest_file("config/value.txt", downloaded),
                ]),
                [("overrides/config/value.txt", b"override")],
            )
            game_root = root / "instances"

            def fake_download(_descriptor, destination, **_kwargs):
                destination = Path(destination)
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_bytes(downloaded)
                return str(destination)

            with mock.patch.object(modpack_manager, "GAME_ROOT", game_root), \
                    mock.patch.object(modpack_manager, "APP_DIR", root), \
                    mock.patch.object(profile_manager, "GAME_ROOT", game_root), \
                    mock.patch.object(modpack_manager.mll.mrpack, "get_mrpack_information",
                                      return_value={"name": "Pack", "versionId": "v1"},
                                      create=True), \
                    mock.patch.object(modpack_manager.mll.mrpack, "get_mrpack_launch_version",
                                      return_value="fabric-loader-0.16.10-1.20.1", create=True), \
                    mock.patch.object(modpack_manager.modrinth_api, "download_file",
                                      side_effect=fake_download), \
                    mock.patch.object(modpack_manager.launcher_core, "install_version",
                                      return_value="fabric-loader-0.16.10-1.20.1"):
                result = modpack_manager.install_modpack(
                    nickname="Player1", local_path=str(archive_path)
                )

            final_dir = game_root / result["id"]
            self.assertEqual(
                (final_dir / "config" / "value.txt").read_bytes(), b"override"
            )
            self.assertFalse(any(path.name.startswith(".staging-") for path in game_root.iterdir()))

    def test_failed_install_rolls_back_staging(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            archive_path = root / "pack.mrpack"
            _write_mrpack(archive_path, _valid_index())
            game_root = root / "instances"
            with mock.patch.object(modpack_manager, "GAME_ROOT", game_root), \
                    mock.patch.object(modpack_manager, "APP_DIR", root), \
                    mock.patch.object(profile_manager, "GAME_ROOT", game_root), \
                    mock.patch.object(modpack_manager.mll.mrpack, "get_mrpack_information",
                                      return_value={"name": "Pack", "summary": "Fixture", "versionId": "v1"},
                                      create=True), \
                    mock.patch.object(modpack_manager.mll.mrpack, "get_mrpack_launch_version",
                                      return_value="fabric-loader-0.16.10-1.20.1", create=True), \
                    mock.patch.object(modpack_manager.launcher_core, "install_version",
                                      side_effect=RuntimeError("simulated failure")):
                with self.assertRaises(RuntimeError):
                    modpack_manager.install_modpack(
                        nickname="Player1", local_path=str(archive_path)
                    )
            self.assertFalse(game_root.exists() and any(game_root.iterdir()))

    def test_missing_required_download_is_not_promoted(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            content = b"required"
            archive_path = root / "pack.mrpack"
            _write_mrpack(archive_path, _valid_index(files=[
                _manifest_file("mods/required.jar", content),
            ]))
            game_root = root / "instances"

            with mock.patch.object(modpack_manager, "GAME_ROOT", game_root), \
                    mock.patch.object(modpack_manager, "APP_DIR", root), \
                    mock.patch.object(profile_manager, "GAME_ROOT", game_root), \
                    mock.patch.object(modpack_manager.mll.mrpack, "get_mrpack_information",
                                      return_value={"name": "Pack", "versionId": "v1"},
                                      create=True), \
                    mock.patch.object(modpack_manager.mll.mrpack, "get_mrpack_launch_version",
                                      return_value="fabric-loader-0.16.10-1.20.1", create=True), \
                    mock.patch.object(modpack_manager.modrinth_api, "download_file",
                                      side_effect=lambda _descriptor, destination, **_kwargs:
                                      str(destination)), \
                    mock.patch.object(modpack_manager.launcher_core, "install_version",
                                      return_value="fabric-loader-0.16.10-1.20.1"):
                with self.assertRaises(modpack_manager.ModpackError):
                    modpack_manager.install_modpack(
                        nickname="Player1", local_path=str(archive_path)
                    )

            self.assertFalse(game_root.exists() and any(game_root.iterdir()))


class ModDependencyInstallerTests(unittest.TestCase):
    @staticmethod
    def _version(version_id, project_id, filename, dependencies=None,
                 games=None, loaders=None):
        payload = filename.encode("utf-8")
        return {
            "id": version_id,
            "project_id": project_id,
            "name": version_id,
            "game_versions": games or ["1.21.1"],
            "loaders": loaders or ["fabric"],
            "dependencies": dependencies or [],
            "files": [{
                "filename": filename,
                "primary": True,
                "url": f"https://cdn.modrinth.com/data/{project_id}/{filename}",
                "size": len(payload),
                "hashes": {"sha1": hashlib.sha1(payload).hexdigest()},
            }],
        }

    def test_required_dependencies_are_recursive_deduplicated_and_cycle_safe(self):
        root = self._version("root-v1", "root", "root.jar", [
            {"project_id": "dep", "dependency_type": "required"},
            {"project_id": "optional", "dependency_type": "optional"},
            {"file_name": "bad-old-mod.jar", "dependency_type": "incompatible"},
        ])
        dependency = self._version("dep-v1", "dep", "dep.jar", [
            {"version_id": "leaf-v1", "project_id": "leaf",
             "dependency_type": "required"},
        ])
        leaf = self._version("leaf-v1", "leaf", "leaf.jar", [
            {"version_id": "root-v1", "project_id": "root",
             "dependency_type": "required"},
        ])

        with mock.patch.object(
            modrinth_api, "get_versions", return_value=[dependency]
        ) as get_versions, mock.patch.object(
            modrinth_api, "get_version", side_effect=lambda value: {
                "leaf-v1": leaf, "root-v1": root,
            }[value]
        ):
            graph = modrinth_api.resolve_required_dependencies(
                root, "fabric", "1.21.1"
            )

        self.assertEqual(
            [item["id"] for item in graph["versions"]],
            ["leaf-v1", "dep-v1", "root-v1"],
        )
        self.assertEqual(get_versions.call_count, 1)
        self.assertEqual(graph["optional"][0]["project_id"], "optional")
        self.assertEqual(graph["incompatible"][0]["file_name"], "bad-old-mod.jar")

    def test_exact_dependency_version_is_not_replaced_when_incompatible(self):
        root = self._version("root-v1", "root", "root.jar", [{
            "version_id": "old-v1", "project_id": "dep",
            "dependency_type": "required",
        }])
        old = self._version(
            "old-v1", "dep", "old.jar", games=["1.19.4"]
        )
        with mock.patch.object(modrinth_api, "get_version", return_value=old), \
                mock.patch.object(modrinth_api, "get_versions") as fallback:
            with self.assertRaisesRegex(
                modrinth_api.ModrinthError, "no es compatible con Minecraft"
            ):
                modrinth_api.resolve_required_dependencies(
                    root, "fabric", "1.21.1"
                )
        fallback.assert_not_called()

    def test_failed_publish_restores_every_previous_file(self):
        dependency = self._version("dep-v1", "dep", "dep.jar")
        root = self._version("root-v1", "root", "root.jar", [{
            "version_id": "dep-v1", "project_id": "dep",
            "dependency_type": "required",
        }])
        with tempfile.TemporaryDirectory() as directory:
            destination = Path(directory)
            (destination / "dep.jar").write_bytes(b"old dependency")
            (destination / "root.jar").write_bytes(b"old root")

            def fake_download(descriptor, target, **_kwargs):
                Path(target).write_bytes(descriptor["filename"].encode("utf-8"))
                return str(target)

            real_replace = modrinth_api.os.replace

            def fail_on_second_backup(source, target):
                source = Path(source)
                target = Path(target)
                if source == destination / "root.jar" and target.name.startswith(".backup-"):
                    raise OSError("simulated publish failure")
                return real_replace(source, target)

            with mock.patch.object(modrinth_api, "get_version", return_value=dependency), \
                    mock.patch.object(modrinth_api, "download_file", side_effect=fake_download), \
                    mock.patch.object(modrinth_api.os, "replace", side_effect=fail_on_second_backup):
                with self.assertRaisesRegex(OSError, "simulated"):
                    modrinth_api.install_version_with_dependencies(
                        root, "fabric", "1.21.1", str(destination)
                    )

            self.assertEqual((destination / "dep.jar").read_bytes(), b"old dependency")
            self.assertEqual((destination / "root.jar").read_bytes(), b"old root")
            self.assertFalse(any(path.name.startswith(".kat-install-")
                                 for path in destination.iterdir()))

    def test_resourcepack_uses_minecraft_loader_and_zip_destination(self):
        pack = self._version(
            "pack-v1", "pack", "pretty.zip", loaders=["minecraft"]
        )
        with tempfile.TemporaryDirectory() as directory:
            def fake_download(_descriptor, target, **_kwargs):
                Path(target).write_bytes(b"pack")
                return str(target)

            with mock.patch.object(modrinth_api, "get_versions", return_value=[pack]) as versions, \
                    mock.patch.object(modrinth_api, "download_file", side_effect=fake_download):
                report = modrinth_api.install_content_latest(
                    "pack", "resourcepack", "fabric", "1.21.1", directory
                )

            versions.assert_called_once_with("pack", "minecraft", "1.21.1")
            self.assertEqual(Path(report["primary_path"]).name, "pretty.zip")
            self.assertTrue((Path(directory) / "pretty.zip").is_file())


class ModrinthMediaTests(unittest.TestCase):
    def test_icon_is_verified_cached_and_not_downloaded_twice(self):
        payload = b"\x89PNG\r\n\x1a\ncover"
        response = mock.Mock(
            headers={"Content-Length": str(len(payload))},
        )
        response.iter_content.return_value = [payload]
        client = mock.Mock()
        client.get.return_value = response
        with tempfile.TemporaryDirectory() as directory, mock.patch.object(
            modrinth_media, "ICON_CACHE", Path(directory)
        ):
            url = "https://cdn.modrinth.com/data/kat/icon.png"
            self.assertEqual(modrinth_media.fetch_icon(url, session=client), payload)
            self.assertEqual(modrinth_media.fetch_icon(url, session=client), payload)
        client.get.assert_called_once_with(
            url, timeout=15, stream=True, allow_redirects=False
        )
        response.close.assert_called_once()

    def test_icon_rejects_non_modrinth_hosts(self):
        with self.assertRaisesRegex(ValueError, "no permitida"):
            modrinth_media.fetch_icon("https://example.com/data/icon.png")


class ModUpdateTests(unittest.TestCase):
    def test_batch_update_preserves_disabled_state(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            old = root / "old.jar.disabled"
            old.write_bytes(b"old")
            digest = hashlib.sha1(b"old").hexdigest()
            new_bytes = b"new"
            descriptor = {
                "filename": "new.jar", "primary": True,
                "url": "https://cdn.modrinth.com/data/x/versions/y/new.jar",
                "size": len(new_bytes),
                "hashes": {"sha1": hashlib.sha1(new_bytes).hexdigest()},
            }
            response = {digest: {"files": [descriptor]}}

            def fake_download(_file, destination, **_kwargs):
                Path(destination).write_bytes(new_bytes)
                return str(destination)

            with mock.patch.object(modrinth_api, "_request_json", return_value=response), \
                    mock.patch.object(modrinth_api, "download_file", side_effect=fake_download):
                result = modrinth_api.update_mods(str(root), "fabric", "1.21.1")

            self.assertEqual(result["updated"], 1)
            self.assertFalse(old.exists())
            self.assertEqual((root / "new.jar.disabled").read_bytes(), new_bytes)


if __name__ == "__main__":
    unittest.main()
