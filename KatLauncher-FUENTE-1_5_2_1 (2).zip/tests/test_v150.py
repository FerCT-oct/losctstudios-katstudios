import os
import tempfile
import unittest
from pathlib import Path
from unittest import mock

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtCore import QByteArray, QBuffer, QIODevice, Qt
from PySide6.QtGui import QColor, QImage
from PySide6.QtWidgets import QApplication

from katlauncher.core import mcstat_api
from katlauncher.gui.skin_3d_widget import (
    SkinPreview2D, SkinPreview3D, TexturePreview2D,
)


class FakeResponse:
    def __init__(self, payload=None, content=b"", status_code=200):
        self._payload = payload
        self.content = content
        self.status_code = status_code

    def json(self):
        return self._payload

    def raise_for_status(self):
        if self.status_code >= 400:
            raise RuntimeError(self.status_code)


class Version150Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def test_mcstat_catalog_is_normalized_and_cached(self):
        response = FakeResponse({
            "success": True,
            "data": {
                "skins": [{
                    "id": "skin-1", "name": "Cosmic Cat", "model": "slim",
                    "tags": ["cat", "space"],
                    "pngPath": "https://mcstat.org/media/skins/cat.png",
                    "likeCount": 9, "downloadCount": 42,
                }],
                "pagination": {"page": 1, "totalPages": 1},
            },
        })
        session = mock.Mock()
        session.get.return_value = response
        with tempfile.TemporaryDirectory() as directory, \
                mock.patch.object(
                    mcstat_api, "CACHE_FILE",
                    Path(directory) / "cache.json",
                ):
            result = mcstat_api.list_skins("cat", session=session)
            self.assertEqual(result["skins"][0]["name"], "Cosmic Cat")
            self.assertEqual(result["skins"][0]["downloads"], 42)
            self.assertTrue(mcstat_api.CACHE_FILE.is_file())
            self.assertEqual(
                session.get.call_args.kwargs["headers"]["X-API-Key"],
                mcstat_api.BUNDLED_API_KEY,
            )

    def test_mcstat_cape_catalog_is_normalized_and_cached(self):
        response = FakeResponse({
            "success": True,
            "data": {
                "capes": [{
                    "id": "cape-1", "name": "Kat Cape",
                    "tags": ["cat"],
                    "pngPath": "https://mcstat.org/media/capes/kat.png",
                    "likeCount": 7, "downloadCount": 25,
                }],
                "pagination": {"page": 1, "totalPages": 1},
            },
        })
        session = mock.Mock()
        session.get.return_value = response
        with tempfile.TemporaryDirectory() as directory, \
                mock.patch.object(
                    mcstat_api, "CAPE_CACHE_FILE",
                    Path(directory) / "capes.json",
                ):
            result = mcstat_api.list_capes("kat", session=session)
            self.assertEqual(result["capes"][0]["name"], "Kat Cape")
            self.assertEqual(result["capes"][0]["model"], "cape")
            self.assertTrue(mcstat_api.CAPE_CACHE_FILE.is_file())

    def test_skin_preview_accepts_modern_skin_with_outer_layer(self):
        image = QImage(64, 64, QImage.Format_ARGB32)
        image.fill(Qt.transparent)
        image.fill(QColor("#202020"))
        # Casco exterior rojo para verificar que existe contenido en la capa 2.
        for y in range(8, 16):
            for x in range(40, 48):
                image.setPixelColor(x, y, QColor("#ff0000"))
        payload = QByteArray()
        buffer = QBuffer(payload)
        buffer.open(QIODevice.WriteOnly)
        self.assertTrue(image.save(buffer, "PNG"))
        preview = SkinPreview3D()
        self.addCleanup(preview.close)
        self.assertTrue(preview.load_skin_data(bytes(payload)))
        self.assertTrue(any(part.overlay_regions for part in preview._parts()))

    def test_skin_preview_2d_accepts_slim_skin_without_filtering_pixels(self):
        image = QImage(64, 64, QImage.Format_ARGB32)
        image.fill(QColor("#24a0ed"))
        payload = QByteArray()
        buffer = QBuffer(payload)
        buffer.open(QIODevice.WriteOnly)
        self.assertTrue(image.save(buffer, "PNG"))
        preview = SkinPreview2D()
        self.addCleanup(preview.close)
        self.assertTrue(preview.load_skin_data(bytes(payload), slim=True))
        self.assertTrue(preview._slim)
        self.assertFalse(preview._image.isNull())

    def test_texture_preview_accepts_mcstat_cape(self):
        image = QImage(64, 32, QImage.Format_ARGB32)
        image.fill(QColor("#7048ff"))
        payload = QByteArray()
        buffer = QBuffer(payload)
        buffer.open(QIODevice.WriteOnly)
        self.assertTrue(image.save(buffer, "PNG"))
        preview = TexturePreview2D()
        self.addCleanup(preview.close)
        self.assertTrue(preview.load_texture_data(bytes(payload)))
        self.assertFalse(preview._image.isNull())


if __name__ == "__main__":
    unittest.main()
