import unittest
from unittest import mock

from katlauncher.core.katglobal import KatGlobalError, KatGlobalTunnel


class _Process:
    def __init__(self, lines):
        self.stdout = iter(lines)
        self.returncode = None
        self.terminated = False

    def poll(self):
        return self.returncode

    def terminate(self):
        self.terminated = True
        self.returncode = 0

    def wait(self, timeout=None):
        return self.returncode

    def kill(self):
        self.returncode = -9


class KatGlobalTests(unittest.TestCase):
    def test_rejects_invalid_port(self):
        with self.assertRaises(KatGlobalError):
            KatGlobalTunnel("java", 70000).start(timeout=0)

    def test_reads_assigned_domain_and_stops_process(self):
        process = _Process([
            "KATGLOBAL_STATUS=connecting:na\n",
            "KATGLOBAL_DOMAIN=happy-cat.na.e4mc.link\n",
        ])
        logs = []
        with mock.patch(
            "katlauncher.core.katglobal.subprocess.Popen",
            return_value=process,
        ) as popen:
            tunnel = KatGlobalTunnel("java", 25565)
            domain = tunnel.start(timeout=1, log_cb=logs.append)
            self.assertEqual(domain, "happy-cat.na.e4mc.link")
            self.assertIn("[Kat Global] connecting:na", logs)
            command = popen.call_args.args[0]
            self.assertIn("--target-port", command)
            self.assertIn("25565", command)
            tunnel.stop()
        self.assertTrue(process.terminated)

    def test_surfaces_relay_error(self):
        process = _Process(["KATGLOBAL_ERROR=relay unavailable\n"])
        with mock.patch(
            "katlauncher.core.katglobal.subprocess.Popen",
            return_value=process,
        ):
            with self.assertRaisesRegex(KatGlobalError, "relay unavailable"):
                KatGlobalTunnel("java", 25565).start(timeout=1)


if __name__ == "__main__":
    unittest.main()
