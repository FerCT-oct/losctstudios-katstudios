import os
import time
import unittest
from unittest import mock

from katlauncher.core.discord_presence import (
    CLIENT_ID_ENV,
    DiscordRichPresence,
    MAX_PRESENCE_TEXT_LENGTH,
)


CLIENT_ID = "123456789012345678"


class FakePresence:
    def __init__(self, client_id, *, connect_error=None, update_error=None):
        self.client_id = client_id
        self.connect_error = connect_error
        self.update_error = update_error
        self.connect_calls = 0
        self.updates = []
        self.clear_calls = 0
        self.close_calls = 0

    def connect(self):
        self.connect_calls += 1
        if self.connect_error:
            raise self.connect_error

    def update(self, **payload):
        if self.update_error:
            raise self.update_error
        self.updates.append(payload)

    def clear(self):
        self.clear_calls += 1

    def close(self):
        self.close_calls += 1


class DiscordRichPresenceTests(unittest.TestCase):
    def test_missing_or_invalid_client_id_is_a_clean_noop(self):
        factory = mock.Mock(side_effect=AssertionError("factory must not run"))
        with mock.patch.dict(os.environ, {}, clear=True):
            missing = DiscordRichPresence(presence_factory=factory)
            invalid = DiscordRichPresence("not-a-client-id", presence_factory=factory)
        self.addCleanup(missing.close)
        self.addCleanup(invalid.close)

        self.assertFalse(missing.configured)
        self.assertFalse(missing.start())
        self.assertFalse(missing.show_launcher())
        self.assertFalse(invalid.configured)
        self.assertFalse(invalid.show_playing("1.21"))
        factory.assert_not_called()

    def test_client_id_can_come_from_environment(self):
        with mock.patch.dict(os.environ, {CLIENT_ID_ENV: CLIENT_ID}, clear=True):
            presence = DiscordRichPresence(enabled=False)
        self.addCleanup(presence.close)
        self.assertTrue(presence.configured)
        self.assertEqual(presence.client_id, CLIENT_ID)
        self.assertFalse(presence.active)

    def test_show_playing_is_nonblocking_and_does_not_expose_nickname(self):
        instances = []

        def factory(client_id):
            instance = FakePresence(client_id)
            instances.append(instance)
            return instance

        presence = DiscordRichPresence(
            CLIENT_ID,
            presence_factory=factory,
            wall_clock=lambda: 1234.9,
        )
        self.addCleanup(presence.close)

        self.assertTrue(presence.show_playing("1.21.4", loader="fabric"))
        self.assertTrue(presence.flush())
        self.assertTrue(presence.connected)
        self.assertEqual(len(instances), 1)
        self.assertEqual(instances[0].client_id, CLIENT_ID)
        self.assertEqual(instances[0].connect_calls, 1)
        self.assertEqual(instances[0].updates, [{
            "details": "Jugando Minecraft",
            "state": "Minecraft 1.21.4 · Fabric",
            "start": 1234,
        }])
        self.assertNotIn("nickname", str(instances[0].updates).lower())

    def test_payload_is_sanitized_and_duplicate_updates_are_coalesced(self):
        instance = FakePresence(CLIENT_ID)
        presence = DiscordRichPresence(
            CLIENT_ID, presence_factory=lambda _client_id: instance
        )
        self.addCleanup(presence.close)
        details = "  line one\n" + ("x" * 200)

        self.assertTrue(presence.update_activity(
            details=details,
            state=" ready ",
            start="invalid",
            large_text="ignored without an image",
        ))
        self.assertTrue(presence.update_activity(
            details=details,
            state=" ready ",
            start="invalid",
            large_text="ignored without an image",
        ))
        self.assertTrue(presence.flush())

        self.assertEqual(len(instance.updates), 1)
        payload = instance.updates[0]
        self.assertLessEqual(len(payload["details"]), MAX_PRESENCE_TEXT_LENGTH)
        self.assertNotIn("\n", payload["details"])
        self.assertEqual(payload["state"], "ready")
        self.assertNotIn("start", payload)
        self.assertNotIn("large_text", payload)

    def test_connection_failure_is_swallowed_and_respects_cooldown(self):
        now = [10.0]
        instances = []

        def factory(client_id):
            if not instances:
                instance = FakePresence(client_id, connect_error=OSError("Discord closed"))
            else:
                instance = FakePresence(client_id)
            instances.append(instance)
            return instance

        presence = DiscordRichPresence(
            CLIENT_ID,
            presence_factory=factory,
            monotonic=lambda: now[0],
            reconnect_cooldown=30,
        )
        self.addCleanup(presence.close)

        self.assertTrue(presence.show_launcher())
        self.assertTrue(presence.flush())
        self.assertFalse(presence.connected)
        self.assertEqual(presence.last_error, "Discord closed")

        self.assertTrue(presence.show_launcher())
        self.assertTrue(presence.flush())
        self.assertEqual(len(instances), 1)

        now[0] += 31
        self.assertTrue(presence.show_launcher())
        self.assertTrue(presence.flush())
        self.assertEqual(len(instances), 2)
        self.assertTrue(presence.connected)
        self.assertIsNone(presence.last_error)

    def test_update_failure_disconnects_without_raising(self):
        instance = FakePresence(CLIENT_ID, update_error=RuntimeError("RPC failed"))
        presence = DiscordRichPresence(
            CLIENT_ID,
            presence_factory=lambda _client_id: instance,
            reconnect_cooldown=60,
        )
        self.addCleanup(presence.close)

        self.assertTrue(presence.show_launcher())
        self.assertTrue(presence.flush())
        self.assertFalse(presence.connected)
        self.assertEqual(presence.last_error, "RPC failed")
        self.assertEqual(instance.close_calls, 1)

    def test_connection_failure_retries_latest_activity_automatically(self):
        instances = []

        def factory(client_id):
            instance = FakePresence(
                client_id,
                connect_error=OSError("Discord closed") if not instances else None,
            )
            instances.append(instance)
            return instance

        presence = DiscordRichPresence(
            CLIENT_ID,
            presence_factory=factory,
            reconnect_cooldown=0.05,
        )
        self.addCleanup(presence.close)
        self.assertTrue(presence.show_playing("1.21.4", loader="fabric"))

        deadline = time.monotonic() + 1
        while not presence.connected and time.monotonic() < deadline:
            time.sleep(0.02)
            presence.flush()

        self.assertTrue(presence.connected)
        self.assertEqual(len(instances), 2)
        self.assertEqual(instances[1].updates[-1]["state"], "Minecraft 1.21.4 · Fabric")

    def test_disable_and_close_clear_the_presence(self):
        instances = []

        def factory(client_id):
            instance = FakePresence(client_id)
            instances.append(instance)
            return instance

        presence = DiscordRichPresence(CLIENT_ID, presence_factory=factory)
        self.addCleanup(presence.close)
        self.assertTrue(presence.show_launcher(language="en"))
        self.assertTrue(presence.flush())

        presence.set_enabled(False)
        self.assertTrue(presence.flush())
        self.assertFalse(presence.active)
        self.assertFalse(presence.connected)
        self.assertEqual(instances[0].clear_calls, 1)
        self.assertEqual(instances[0].close_calls, 1)
        self.assertFalse(presence.show_launcher())

        presence.set_enabled(True)
        self.assertTrue(presence.show_launcher())
        self.assertTrue(presence.flush())
        self.assertEqual(len(instances), 2)
        presence.close()
        self.assertGreaterEqual(instances[1].clear_calls, 1)
        self.assertEqual(instances[1].close_calls, 1)


if __name__ == "__main__":
    unittest.main()
