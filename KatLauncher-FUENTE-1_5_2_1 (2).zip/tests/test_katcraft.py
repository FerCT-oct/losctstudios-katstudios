import json
import tempfile
import types
import unittest
from pathlib import Path
from unittest import mock

from katlauncher.core import katcraft_manager, modrinth_api
from katlauncher.core.katcraft_bridge import KatCraftBridge


class KatCraftArtifactTests(unittest.TestCase):
    def test_universal_selector_chooses_exact_loader_and_version(self):
        matrix = {
            ("fabric", "26.2"): "KatCraft-fabric-26.2-1.5.2.jar",
            ("fabric", "1.21.1"): "KatCraft-fabric-1.21.1-1.5.2.jar",
            ("quilt", "1.21.1"): "KatCraft-fabric-1.21.1-1.5.2.jar",
            ("forge", "1.20.1"): "KatCraft-forge-1.20.1-1.5.2.jar",
            ("neoforge", "1.21.1"): "KatCraft-neoforge-1.21.1-1.5.2.jar",
        }
        for key, filename in matrix.items():
            with self.subTest(loader=key[0], version=key[1]):
                self.assertEqual(
                    katcraft_manager.select_artifact(*key).filename, filename)
        self.assertIsNone(katcraft_manager.select_artifact("vanilla", "1.21.1"))
        self.assertIsNone(katcraft_manager.select_artifact("forge", "26.2"))

    def test_install_is_atomic_and_removes_stale_katcraft(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            assets = root / "assets"
            mods = root / "mods"
            assets.mkdir()
            artifact = katcraft_manager.select_artifact("fabric", "1.21.1")
            (assets / artifact.filename).write_bytes(b"JAR" * 600)
            mods.mkdir()
            stale = mods / "KatCraft-old.jar"
            stale.write_bytes(b"old")
            profile = types.SimpleNamespace(
                loader="fabric", version="1.21.1", mods_dir=str(mods))
            with mock.patch.object(katcraft_manager, "ASSET_ROOT", assets):
                installed = Path(katcraft_manager.ensure_katcraft(profile))
            self.assertEqual(installed.name, artifact.filename)
            self.assertTrue(installed.is_file())
            self.assertFalse(stale.exists())

    def test_fabric_api_uses_fabric_channel_for_quilt(self):
        with tempfile.TemporaryDirectory() as directory:
            profile = types.SimpleNamespace(
                loader="quilt", version="1.21.1", mods_dir=directory)
            expected = str(Path(directory) / "fabric-api.jar")
            with mock.patch.object(
                modrinth_api, "install_project_latest", return_value=expected
            ) as install:
                self.assertEqual(modrinth_api.ensure_fabric_api(profile), expected)
            install.assert_called_once_with(
                "fabric-api", "fabric", "1.21.1", directory)


class KatCraftBridgeTests(unittest.TestCase):
    def test_bridge_config_is_per_launch_and_contains_no_remote_secret(self):
        with tempfile.TemporaryDirectory() as directory:
            profile = types.SimpleNamespace(
                nickname="KatPlayer",
                version="1.21.1",
                loader="fabric",
                game_dir=directory,
            )
            social = types.SimpleNamespace(
                session=None, configured=False, me={}, shared_skin_root="")
            trophies = types.SimpleNamespace(snapshot=lambda: [{"id": "guide"}])
            bridge = KatCraftBridge(social, trophies)
            try:
                path = bridge.prepare(profile)
                config = json.loads(path.read_text(encoding="utf-8"))
                self.assertEqual(config["nickname"], "KatPlayer")
                self.assertEqual(config["loader"], "fabric")
                self.assertGreater(config["port"], 0)
                self.assertGreaterEqual(len(config["token"]), 32)
                self.assertNotIn("supabase", json.dumps(config).lower())
                state = bridge._state()
                self.assertFalse(state["signed_in"])
                self.assertEqual(state["trophies"], [{"id": "guide"}])
            finally:
                bridge.stop()

    def test_pending_game_invites_are_forwarded_to_the_launcher(self):
        invitations = [{
            "id": 7,
            "display_name": "KatFriend",
            "server_host": "play.example.test",
            "server_port": 25565,
        }]
        social = types.SimpleNamespace(
            session={"access_token": "local-test"},
            configured=True,
            me={},
            shared_skin_root="",
            rpc=lambda name: (
                invitations if name == "kat_list_game_invites" else []
            ),
        )
        bridge = KatCraftBridge(social, None)
        received = []
        bridge.game_invites.connect(received.append)

        state = bridge._state()

        self.assertEqual(received, [invitations])
        self.assertEqual(state["invites"][0]["id"], 7)

    def test_local_room_invite_uses_the_lan_address(self):
        calls = []
        social = types.SimpleNamespace(
            session={"access_token": "local-test"},
            rpc=lambda name, body=None: calls.append((name, body)) or {"ok": True},
        )
        bridge = KatCraftBridge(social, None)
        bridge.set_room("192.168.1.55", 25570)

        bridge._invite({
            "friend_id": "friend-id",
            "host": "127.0.0.1",
            "port": 25570,
            "version": "1.21.1",
            "loader": "fabric",
        })

        self.assertEqual(calls[0][0], "kat_send_game_invite")
        self.assertEqual(calls[0][1]["p_host"], "192.168.1.55")
        self.assertEqual(calls[0][1]["p_port"], 25570)

    def test_room_can_be_requested_from_the_mod(self):
        bridge = KatCraftBridge(None, None)
        requests = []
        bridge.room_start_requested.connect(
            lambda options: requests.append(options)
        )
        result = bridge._start_room({
            "accept_eula": True,
            "ram_mb": 3072,
            "port": 25571,
            "global": True,
        })
        self.assertEqual(result["status"], "starting")
        self.assertEqual(requests[0]["ram_mb"], 3072)
        self.assertEqual(requests[0]["port"], 25571)
        self.assertTrue(requests[0]["global"])
        self.assertTrue(requests[0]["create_world"])
        self.assertEqual(bridge._state()["room"]["status"], "starting")

    def test_room_request_requires_eula(self):
        bridge = KatCraftBridge(None, None)
        with self.assertRaises(ValueError):
            bridge._start_room({"accept_eula": False})


if __name__ == "__main__":
    unittest.main()
