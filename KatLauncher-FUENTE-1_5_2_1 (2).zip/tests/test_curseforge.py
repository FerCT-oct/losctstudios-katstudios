import hashlib
import tempfile
import unittest
from pathlib import Path
from unittest.mock import Mock, patch

from katlauncher.core import curseforge_api


class CurseForgeTests(unittest.TestCase):
    def test_search_normalises_official_response(self):
        payload = [{
            "id": 12, "name": "Kat Mod", "slug": "kat-mod",
            "summary": "Rápido", "downloadCount": 900,
            "authors": [{"name": "Oliver"}],
            "categories": [{"name": "Optimization"}],
            "logo": {"thumbnailUrl": "https://media.forgecdn.net/a.png"},
            "links": {"websiteUrl": "https://www.curseforge.com/minecraft/mc-mods/kat-mod"},
        }]
        with patch.object(curseforge_api, "_request", return_value=payload) as request:
            result = curseforge_api.search_projects("kat", "mod", "fabric", "1.21.1")
        self.assertEqual(result[0]["provider"], "curseforge")
        self.assertEqual(result[0]["title"], "Kat Mod")
        self.assertEqual(result[0]["author"], "Oliver")
        self.assertEqual(request.call_args.kwargs["params"]["modLoaderType"], 4)

    def test_download_rejects_non_forgecdn_host(self):
        with self.assertRaises(curseforge_api.CurseForgeError):
            curseforge_api._validate_download_url("https://evil.example/mod.jar")

    def test_install_downloads_required_dependency(self):
        root_bytes = b"root"
        dependency_bytes = b"dependency"
        files = {
            1: [{
                "id": 10, "fileName": "root.jar", "fileDate": "2026-01-02",
                "fileLength": len(root_bytes), "downloadUrl": "https://edge.forgecdn.net/root.jar",
                "hashes": [{"algo": 1, "value": hashlib.sha1(root_bytes).hexdigest()}],
                "dependencies": [{"modId": 2, "relationType": 3}],
            }],
            2: [{
                "id": 20, "fileName": "dependency.jar", "fileDate": "2026-01-01",
                "fileLength": len(dependency_bytes), "downloadUrl": "https://edge.forgecdn.net/dep.jar",
                "hashes": [{"algo": 1, "value": hashlib.sha1(dependency_bytes).hexdigest()}],
                "dependencies": [],
            }],
        }

        def fake_request(path, params=None):
            mod_id = int(path.split("/")[2])
            return files[mod_id]

        def fake_get(url, **_kwargs):
            response = Mock()
            response.raise_for_status.return_value = None
            data = dependency_bytes if url.endswith("dep.jar") else root_bytes
            response.iter_content.return_value = [data]
            return response

        with tempfile.TemporaryDirectory() as temp, \
                patch.object(curseforge_api, "_request", side_effect=fake_request), \
                patch.object(curseforge_api.requests, "get", side_effect=fake_get):
            report = curseforge_api.install_content_latest(
                1, "mod", "fabric", "1.21.1", temp
            )
            self.assertEqual(Path(report["primary_path"]).read_bytes(), root_bytes)
            self.assertEqual((Path(temp) / "dependency.jar").read_bytes(), dependency_bytes)
            self.assertEqual(len(report["dependencies"]), 1)


if __name__ == "__main__":
    unittest.main()
