import unittest

from PySide6.QtWidgets import QApplication, QLabel

from katlauncher.gui.onboarding import OnboardingWizard
from katlauncher.gui.i18n import I18n
from katlauncher import __version__
from katlauncher.gui.theme_manager import ThemeName



class OnboardingTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def test_onboarding_wizard_can_be_created(self):
        wizard = OnboardingWizard()

        self.assertEqual(wizard.pageIds(), [0, 1, 2, 3, 4, 5])
        self.assertEqual(
            wizard.windowTitle(), f"Bienvenido a KatLauncher {__version__}"
        )
        self.assertEqual(len(wizard.interface_page.buttons), 4)
        self.assertIn(ThemeName.EPIC, wizard.interface_page.buttons)

    def test_onboarding_is_really_rendered_in_english(self):
        wizard = OnboardingWizard(I18n("en"))
        self.addCleanup(wizard.close)
        self.assertEqual(
            wizard.windowTitle(), f"Welcome to KatLauncher {__version__}"
        )
        self.assertEqual(wizard.page(0).title(), "Welcome to KatLauncher")
        labels = wizard.page(0).findChildren(QLabel)
        self.assertTrue(any("You do not need to sign in" in label.text()
                            for label in labels))
