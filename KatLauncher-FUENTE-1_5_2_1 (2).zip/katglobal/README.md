# Kat Global

Ayudante interno de KatLauncher para publicar una sala temporal en Internet.
Reenvía únicamente hacia `127.0.0.1` y termina junto con la sala.

El protocolo de túnel es interoperable con quiclime/e4mc y se basa en código
MIT de e4mc. Kat Global no es un producto oficial de e4mc.

