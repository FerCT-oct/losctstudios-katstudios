package net.katlauncher.katglobal;

import com.google.gson.Gson;
import io.netty.bootstrap.Bootstrap;
import io.netty.buffer.ByteBuf;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.DatagramChannel;
import io.netty.channel.socket.nio.NioDatagramChannel;
import io.netty.channel.socket.nio.NioSocketChannel;
import io.netty.handler.codec.ByteToMessageCodec;
import io.netty.incubator.codec.quic.QuicChannel;
import io.netty.incubator.codec.quic.QuicClientCodecBuilder;
import io.netty.incubator.codec.quic.QuicSslContext;
import io.netty.incubator.codec.quic.QuicSslContextBuilder;
import io.netty.incubator.codec.quic.QuicStreamChannel;
import io.netty.incubator.codec.quic.QuicStreamType;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * Reverse TCP tunnel for short-lived KatLauncher rooms.
 *
 * Protocol interoperability is based on e4mc/quiclime (MIT, Copyright
 * 2024 Skye). Kat Global is a separate launcher helper and is not presented
 * as an official e4mc product.
 */
public final class KatGlobal {
    private static final Gson GSON = new Gson();
    private final String targetHost;
    private final int targetPort;
    private final String brokerUrl;
    private final EventLoopGroup group = new NioEventLoopGroup(2);
    private final CountDownLatch closed = new CountDownLatch(1);
    private volatile Channel datagram;
    private volatile QuicChannel quic;

    private KatGlobal(String targetHost, int targetPort, String brokerUrl) {
        this.targetHost = targetHost;
        this.targetPort = targetPort;
        this.brokerUrl = brokerUrl;
    }

    public static void main(String[] args) {
        try {
            Map<String, String> options = Arguments.parse(args);
            String host = options.getOrDefault("target-host", "127.0.0.1");
            int port = Integer.parseInt(options.getOrDefault("target-port", "25565"));
            if (!host.equals("127.0.0.1") && !host.equals("localhost") && !host.equals("::1")) {
                throw new IllegalArgumentException("Kat Global only proxies to loopback.");
            }
            if (port < 1 || port > 65535) {
                throw new IllegalArgumentException("Invalid target port.");
            }
            KatGlobal app = new KatGlobal(
                    host,
                    port,
                    options.getOrDefault(
                            "broker-url", "https://broker.e4mc.link/getBestRelay"
                    )
            );
            Runtime.getRuntime().addShutdownHook(new Thread(app::close, "katglobal-stop"));
            app.start();
            app.closed.await();
        } catch (Throwable error) {
            System.out.println("KATGLOBAL_ERROR=" + oneLine(error));
            System.out.flush();
            System.exit(2);
        }
    }

    private void start() throws Exception {
        Relay relay = getRelay();
        System.out.println("KATGLOBAL_STATUS=connecting:" + relay.id);
        System.out.flush();

        QuicSslContext ssl = QuicSslContextBuilder.forClient()
                .applicationProtocols("quiclime")
                .build();
        var codec = new QuicClientCodecBuilder()
                .sslContext(ssl)
                .sslEngineProvider(channel ->
                        ssl.newEngine(channel.alloc(), relay.host, relay.port)
                )
                .initialMaxStreamsBidirectional(512)
                .maxIdleTimeout(10, TimeUnit.SECONDS)
                .initialMaxData(Long.MAX_VALUE / 2)
                .initialMaxStreamDataBidirectionalRemote(1_250_000)
                .initialMaxStreamDataBidirectionalLocal(1_250_000)
                .initialMaxStreamDataUnidirectional(1_250_000)
                .build();

        datagram = new Bootstrap()
                .group(group)
                .channel(NioDatagramChannel.class)
                .handler(codec)
                .bind(0)
                .sync()
                .channel();

        quic = QuicChannel.newBootstrap((DatagramChannel) datagram)
                .streamHandler(new ProxyInitializer(targetHost, targetPort))
                .handler(new ChannelInboundHandlerAdapter() {
                    @Override
                    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {
                        fail(cause);
                    }
                })
                .remoteAddress(new InetSocketAddress(
                        InetAddress.getByName(relay.host), relay.port
                ))
                .connect()
                .sync()
                .getNow();

        quic.closeFuture().addListener(ignored -> close());
        quic.createStream(
                QuicStreamType.BIDIRECTIONAL,
                new ChannelInitializer<QuicStreamChannel>() {
                    @Override
                    protected void initChannel(QuicStreamChannel channel) {
                        channel.pipeline().addLast(
                                new ControlCodec(),
                                new SimpleChannelInboundHandler<ControlMessage>() {
                                    @Override
                                    protected void channelRead0(
                                            ChannelHandlerContext ctx,
                                            ControlMessage message
                                    ) {
                                        if ("domain_assignment_complete".equals(message.kind)
                                                && message.domain != null
                                                && !message.domain.isBlank()) {
                                            System.out.println(
                                                    "KATGLOBAL_DOMAIN=" + message.domain.trim()
                                            );
                                            System.out.flush();
                                        }
                                    }
                                }
                        );
                    }
                }
        ).sync().getNow()
                .writeAndFlush(new ControlMessage("probe_capabilities"))
                .addListener((ChannelFutureListener) ignored ->
                        ignored.channel().writeAndFlush(
                                new ControlMessage("request_domain_assignment")
                        )
                );
    }

    private Relay getRelay() throws Exception {
        HttpClient client = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(15))
                .build();
        HttpRequest request = HttpRequest.newBuilder(URI.create(brokerUrl))
                .timeout(Duration.ofSeconds(20))
                .header("Accept", "application/json")
                .build();
        HttpResponse<String> response = client.send(
                request, HttpResponse.BodyHandlers.ofString()
        );
        if (response.statusCode() != 200) {
            throw new IllegalStateException("Relay broker HTTP " + response.statusCode());
        }
        Relay relay = GSON.fromJson(response.body(), Relay.class);
        if (relay == null || relay.host == null || relay.host.isBlank()
                || relay.port < 1 || relay.port > 65535) {
            throw new IllegalStateException("Relay broker returned invalid data.");
        }
        return relay;
    }

    private void fail(Throwable cause) {
        System.out.println("KATGLOBAL_ERROR=" + oneLine(cause));
        System.out.flush();
        close();
    }

    private synchronized void close() {
        if (quic != null) {
            quic.close();
            quic = null;
        }
        if (datagram != null) {
            datagram.close();
            datagram = null;
        }
        group.shutdownGracefully(0, 2, TimeUnit.SECONDS);
        closed.countDown();
    }

    private static String oneLine(Throwable error) {
        String message = error.getMessage();
        if (message == null || message.isBlank()) {
            message = error.getClass().getSimpleName();
        }
        return message.replace('\r', ' ').replace('\n', ' ').trim();
    }

    private static final class Relay {
        String id = "relay";
        String host;
        int port;
    }

    private static final class ControlMessage {
        String kind;
        String domain;

        ControlMessage(String kind) {
            this.kind = kind;
        }
    }

    private static final class ControlCodec extends ByteToMessageCodec<ControlMessage> {
        @Override
        protected void encode(ChannelHandlerContext ctx, ControlMessage message, ByteBuf out) {
            byte[] json = GSON.toJson(message).getBytes(StandardCharsets.UTF_8);
            writeVarInt(out, json.length);
            out.writeBytes(json);
        }

        @Override
        protected void decode(
                ChannelHandlerContext ctx, ByteBuf in, List<Object> out
        ) {
            int index = in.readerIndex();
            int length = 0;
            int shift = 0;
            int prefix = 0;
            while (prefix < 5) {
                if (in.readableBytes() <= prefix) {
                    return;
                }
                int value = in.getUnsignedByte(index + prefix);
                length |= (value & 0x7f) << shift;
                prefix++;
                if ((value & 0x80) == 0) {
                    if (length < 0 || length > 65_536) {
                        throw new IllegalArgumentException("Invalid control frame.");
                    }
                    if (in.readableBytes() < prefix + length) {
                        return;
                    }
                    in.skipBytes(prefix);
                    byte[] json = new byte[length];
                    in.readBytes(json);
                    out.add(GSON.fromJson(
                            new String(json, StandardCharsets.UTF_8),
                            ControlMessage.class
                    ));
                    return;
                }
                shift += 7;
            }
            throw new IllegalArgumentException("Invalid control VarInt.");
        }

        private static void writeVarInt(ByteBuf out, int value) {
            while ((value & 0xffffff80) != 0) {
                out.writeByte((value & 0x7f) | 0x80);
                value >>>= 7;
            }
            out.writeByte(value);
        }
    }

    private static final class ProxyInitializer
            extends ChannelInitializer<QuicStreamChannel> {
        private final String host;
        private final int port;

        ProxyInitializer(String host, int port) {
            this.host = host;
            this.port = port;
        }

        @Override
        protected void initChannel(QuicStreamChannel remote) {
            System.out.println("KATGLOBAL_STATUS=incoming_stream");
            System.out.flush();
            remote.config().setAutoRead(false);
            Bootstrap bootstrap = new Bootstrap()
                    .group(remote.eventLoop())
                    .channel(NioSocketChannel.class)
                    .handler(new ChannelInitializer<NioSocketChannel>() {
                        @Override
                        protected void initChannel(NioSocketChannel local) {
                            local.pipeline().addLast(
                                    new RelayHandler(remote)
                            );
                        }
                    });
            bootstrap.connect(host, port).addListener(future -> {
                if (!future.isSuccess()) {
                    System.out.println(
                            "KATGLOBAL_ERROR=local_connect:" + oneLine(future.cause())
                    );
                    System.out.flush();
                    remote.close();
                    return;
                }
                Channel local = ((io.netty.channel.ChannelFuture) future).channel();
                System.out.println("KATGLOBAL_STATUS=local_connected");
                System.out.flush();
                remote.pipeline().addLast(new RelayHandler(local));
                remote.config().setAutoRead(true);
                remote.read();
            });
        }
    }

    private static final class RelayHandler
            extends SimpleChannelInboundHandler<ByteBuf> {
        private final Channel peer;

        RelayHandler(Channel peer) {
            this.peer = peer;
        }

        @Override
        protected void channelRead0(ChannelHandlerContext ctx, ByteBuf message) {
            if (peer.isActive()) {
                peer.writeAndFlush(message.retainedDuplicate());
            }
        }

        @Override
        public void channelInactive(ChannelHandlerContext ctx) {
            if (peer.isOpen()) {
                peer.close();
            }
        }

        @Override
        public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {
            ctx.close();
            if (peer.isOpen()) {
                peer.close();
            }
        }
    }

    private static final class Arguments {
        static Map<String, String> parse(String[] args) {
            java.util.HashMap<String, String> values = new java.util.HashMap<>();
            for (int index = 0; index < args.length; index++) {
                String arg = args[index];
                if (!arg.startsWith("--") || index + 1 >= args.length) {
                    throw new IllegalArgumentException("Invalid arguments.");
                }
                values.put(arg.substring(2), args[++index]);
            }
            return values;
        }
    }
}
