# KatLauncher 1.5.2.1

## Kat Interfaces, skins y personalización

KatLauncher 1.5.0 incorpora XMBKat, Kat Normal, Kat Epic y Kat Classic como
interfaces completas sobre las mismas funciones reales. Añade vistas previas
en la guía, color de acento personalizado, acceso directo al auto-update,
biblioteca MCStat integrada para skins y capas, galería de screenshots por
perfil y render correcto de las capas exteriores de skins.
Para instalar o actualizar el esquema social completo, ejecuta:

```text
supabase/00_KAT_SOCIAL_TODO_EN_UNO.sql
```

El script fusionado es idempotente y conserva perfiles, mensajes, amistades,
publicaciones, skins y trofeos.

## Novedades de 1.4.0

- **Inicio guiado y modo sin conexión resistente**: Google y una cuenta Premium
  no son obligatorios para perfiles Java offline.
- **Minecraft Bedrock**: acceso a la instalación y compra oficiales de Windows.
- **Personalización**: cinco acentos, navegación legible y Rich Presence por defecto.
- **Skins y cosméticos**: copia por usuario Mojang, NameMC, capas y élitros locales.
- **MCKAT incluido**: instalación automática y no destructiva por perfil.
- **Kat Social 1.4**: solicitudes corregidas, búsqueda, posts y rangos de juego.
- **Creador de modpacks**: convierte carpetas seleccionadas en `.mrpack` seguros.
- Mejoras de reparación offline, loaders, botones, traducciones y empaquetado.
- **Modrinth + CurseForge**: carátulas, información al doble clic e instalación
  compatible con dependencias obligatorias.
- **Java administrado**: descarga automáticamente el runtime oficial que necesita
  cada versión, incluido Java 25 para Minecraft 26.x.
- **Linux x86_64**: paquete portable y acceso seguro a Kat Social mediante el
  llavero del escritorio.

## Novedades de 1.3.0

- **Kat Modern**: dashboard cósmico, navegación lateral y selector en vivo para
  volver a **Kat Classic** sin reiniciar.
- **Biblioteca Kat**: mods, paquetes de recursos y shaders de Modrinth por perfil,
  búsqueda con Enter e instalación transaccional de dependencias obligatorias.
- **Kat Social renovado**: nick y PFP propios, presencia, timestamps, mensajes
  privados sin leer y renovación automática de sesiones caducadas.
- **Noticias oficiales de Minecraft** con imágenes y caché para uso sin conexión.
- **Servidores favoritos** con ping, MOTD seguro, jugadores y conexión directa.
- **Cuentas offline múltiples**, aplicables a cada perfil sin perder la skin activa.
- **Visor de skins 3D** pixelado, rotable, con zoom y modelos Classic/Slim.
- Más seguridad, cancelación, rollback y pruebas automáticas antes de crear cada EXE.

## Novedades de 1.2.2

- El envío de mensajes ya no puede quedar bloqueado por el refresco automático de Kat Social.
- Mejora de fiabilidad para conexiones lentas o con mayor latencia.

## Novedades de 1.2.1

- Nueva pestaña **Amigos** con Google OAuth, solicitudes y chat global Realtime.
- Mensajes privados entre amigos, bloqueos, reportes, límites anti-spam y moderación.
- Sesión social cifrada con Windows DPAPI; el ejecutable nunca contiene secretos.
- Actualización en lote de mods compatibles mediante hashes de Modrinth.
- Reparación segura de perfiles y modpacks sin modificar mundos ni configuraciones.
- Acceso directo a la carpeta de datos y perfiles de KatLauncher.

## Activar Kat Social

1. Crea un proyecto en Supabase y ejecuta `supabase/kat_social.sql` en SQL Editor.
   Si ya tenías Kat Social 1.2, ejecuta además `supabase/03_kat_social_profiles.sql`.
2. Activa Google en **Authentication > Providers** de Supabase.
3. Crea un cliente OAuth de tipo **Web application** en Google Auth Platform y registra
   `https://TU-PROJECT-REF.supabase.co/auth/v1/callback` como redirect URI autorizado.
4. En Redirect URLs de Supabase agrega `http://127.0.0.1:8765/katlauncher-auth`.
5. Compila con `-SocialProjectUrl` y `-SocialPublishableKey`. La key debe empezar por
   `sb_publishable_`; nunca uses una secret key o `service_role`.

Los mensajes privados tienen permisos de servidor, pero no cifrado de extremo a extremo.

Launcher no oficial de **Minecraft: Java Edition**, hecho en Python con PySide6 (Qt).
Funciona en **modo offline/nickname** (sin cuenta Microsoft) — ideal para pruebas, LAN
o servidores que aceptan modo offline.

## ✨ Funciones

- **Perfiles**: crea varios perfiles con su propia versión de Minecraft, RAM, resolución
  y argumentos JVM. Cada perfil tiene su propia carpeta `.minecraft` independiente.
- **Descarga y reparación automática**: instala la versión elegida y, antes de cada
  inicio, verifica assets, librerías y archivos de versión para reparar solo lo que
  falte o esté dañado.
- **Mod loaders**: soporte para **Fabric** y **Forge**, instalados automáticamente.
- **Loaders modernos**: también admite **NeoForge** y **Quilt** mediante la API
  unificada de `minecraft-launcher-lib`.
- **Modpacks de Modrinth**: busca un pack, elige una versión exacta e instálala
  como un perfil aislado. También puedes importar archivos `.mrpack` locales.
  La instalación limita cantidad y tamaño total, valida rutas y hashes SHA-1/SHA-512,
  se prepara en una carpeta temporal y solo aparece como perfil cuando termina
  correctamente. Sus archivos se descargan en paralelo, con un máximo acotado de
  ocho conexiones y sin omitir ninguna verificación.
- **Gestión de mods**: añade, elimina y activa/desactiva mods `.jar` por perfil.
- **Dependencias automáticas**: resuelve el grafo obligatorio de Modrinth, detecta
  ciclos e incompatibilidades y revierte toda la operación si un archivo falla.
- **Biblioteca de contenido**: instala mods, resource packs y shaders en la carpeta
  correcta del perfil. Los datapacks se gestionan por mundo y por eso no se instalan
  globalmente de forma automática.
- **Integración con Modrinth y CurseForge**: busca mods directamente desde la pestaña Mods
  (filtrados automáticamente por el loader y la versión de Minecraft del perfil
  activo), muestra carátula y detalles con doble clic y los descarga con un clic.
  CurseForge requiere la API key oficial del proyecto, configurable desde ese panel.
- **CustomSkinLoader automático**: KatLauncher puede buscar e instalar por ti el
  mod *CustomSkinLoader* desde Modrinth, tanto con un botón dedicado en **Mods**
  como automáticamente cada vez que marcas una skin como "activa" en **Skins**.
- **Skins locales 3D**: guarda, gira y previsualiza skins PNG por perfil. En modo offline,
  Minecraft solo puede mostrarlas si el perfil tiene CustomSkinLoader instalado
  (por eso se auto-instala al fijar una skin activa).
- **Pantalla de carga**: al abrir la app se muestra una mini splash screen con el
  logo mientras se cargan los perfiles y se comprueba Java, antes de abrir la
  ventana principal.
- **Login offline**: solo pide un nickname, genera un UUID determinista igual que
  hace el launcher oficial en modo sin conexión.
- **Configuración**: selector de idioma español/inglés, Java personalizado,
  comportamiento de la ventana, límite del registro y valores predeterminados
  para perfiles nuevos.
- **Inicio limpio de Minecraft**: Java se ejecuta sin abrir una ventana de consola;
  la salida sigue disponible en el registro plegable de la pestaña **Jugar**.
- **Sonidos de interfaz**: reproduce el sonido de éxito al completar operaciones.
  Al pulsar el logotipo de KatLauncher se activa un ringtone de gato como easter egg.
- **Discord Rich Presence**: integración opcional y no bloqueante para mostrar que
  estás jugando Minecraft, su versión y loader, sin publicar tu nickname. El ID
  público del proyecto ya viene configurado; la integración se activa voluntariamente
  desde **Configuración**.
- **Actualizaciones integradas**: comprueba el canal estable al iniciar, avisa sin
  bloquear la interfaz, descarga en segundo plano y verifica tamaño y SHA-256 antes
  de ofrecer **Instalar y reiniciar**. Al terminar, reproduce el sonido configurado
  y muestra una notificación de Windows. Nunca interrumpe Minecraft ni otra descarga.
- **Noticias y servidores**: consulta novedades oficiales de Java Edition, conserva
  una copia local y administra servidores favoritos con conexión directa.
- **Cuentas**: conserva varias identidades offline. Google autentica Kat Social;
  no reemplaza una licencia. El inicio oficial de Microsoft se habilitará únicamente
  cuando Microsoft/Xbox apruebe la aplicación, sin incrustar Client Secrets.

## 📦 Instalación en Windows

La opción recomendada es ejecutar **`KatLauncher-Setup-1.5.2.1.exe`**. El instalador:

- instala KatLauncher solo para tu usuario, sin pedir permisos de administrador;
- crea un acceso en el menú Inicio y, opcionalmente, en el escritorio;
- incluye Python, PySide6 y las demás dependencias de la aplicación;
- añade un desinstalador y actualiza futuras versiones sobre la misma instalación,
  conservando perfiles, mundos, mods, skins y ajustes.

No necesitas instalar Java manualmente: KatLauncher obtiene y reutiliza el runtime
oficial de Mojang adecuado para cada perfil.

Windows 8.1 se conserva en la compilación x64. No existe una ruta fiable de 32 bits
para Minecraft moderno: Mojang no publica Java 21/25 para Windows x86 y PySide6 no
ofrece una distribución Windows x86 compatible. Las versiones modernas requieren
un sistema operativo de 64 bits.

El desinstalador conserva deliberadamente `~/.katlauncher`, donde están los
perfiles, ajustes, mundos, mods, skins e instancias. Para borrar también esos datos,
haz una copia de tus mundos si la necesitas y elimina esa carpeta manualmente.

## 🧰 Ejecución desde el código fuente

Requiere **Python 3.10+** y tener **Java** instalado (Java 17+ recomendado para
versiones recientes de Minecraft; Java 8 para versiones muy antiguas).

```bash
cd KatLauncher
pip install -r requirements.txt -c constraints-release.txt
```

## 🐧 Compilar e instalar en Linux

En una distribución Linux x86_64 con `python3`, `venv` y herramientas básicas:

```bash
chmod +x packaging/build_linux.sh
./packaging/build_linux.sh
```

El resultado queda en `outputs/KatLauncher-1.4.0-linux-x86_64.tar.gz`. Extráelo y
ejecuta `./install.sh`; se instala para el usuario actual, sin `sudo`. Bedrock no
tiene cliente oficial para Linux, por lo que allí KatLauncher usa Java Edition.

## ▶️ Uso

```bash
python main.py
```

## 🏗️ Compilar la versión de Windows

Instala las dependencias de compilación y ejecuta el script de release desde
PowerShell:

```powershell
python -m pip install -r requirements-build.txt -c constraints-release.txt
.\packaging\build_release.ps1 -Python python
```

El script usa PyInstaller en modo `onedir` e Inno Setup 6 para producir el
instalador. Inno Setup debe estar instalado en su ruta habitual o indicarse con
`-Iscc "C:\ruta\a\ISCC.exe"`.

Para una release conectada al actualizador, proporciona la URL pública del
manifiesto, los hosts permitidos y la URL final del instalador:

```powershell
.\packaging\build_release.ps1 -Python python `
  -UpdateManifestUrl "https://katlauncher.netlify.app/downloads/KatLauncher-latest.json" `
  -UpdateAllowedHosts "katlauncher.netlify.app" `
  -InstallerUrl "https://katlauncher.netlify.app/downloads/KatLauncher-Setup-1.3.0.exe" `
  -SocialProjectUrl "https://TU-PROYECTO.supabase.co" `
  -SocialPublishableKey "sb_publishable_TU_CLAVE_PUBLICA" `
  -CurseForgeApiKey "TU_API_KEY_OFICIAL_DE_CURSEFORGE"
```

La clave de CurseForge se solicita como servicio de terceros desde la consola
oficial de CurseForge for Studios. No uses una clave de Supabase, Google o Discord.

El script toma la versión de `katlauncher/__init__.py`, compila el EXE y el
instalador, calcula su SHA-256 y genera `KatLauncher-latest.json`. Si no se indican
URLs, genera un manifiesto `.template.json` y el programa muestra que el canal aún
no está configurado. La primera versión que incorpora el actualizador debe
instalarse manualmente una vez; las siguientes ya se ofrecen desde la aplicación.

El canal queda fijado dentro del EXE y solo acepta HTTPS y los hosts indicados.
Para distribución pública, firma el instalador con Authenticode o firma el
manifiesto con una clave independiente: SHA-256 evita archivos corruptos, pero un
hash alojado junto al instalador no sustituye la identidad criptográfica del editor.

1. Ve a la pestaña **Perfiles**, elige nombre, nickname, versión de Minecraft y
   (opcional) un mod loader (Fabric/Forge/NeoForge/Quilt).
2. Guarda el perfil.
3. Ve a **Jugar**, selecciona el perfil y pulsa **▶ Jugar**. La primera vez
   descargará los archivos necesarios; después arrancará directo.
4. En **Mods**: añade archivos `.jar` manualmente, o búscalos por nombre en el
   panel remoto e instálalos con un clic (requiere loader
   Fabric/Forge/NeoForge/Quilt). El botón "Auto-instalar CustomSkinLoader" lo instala directo.
5. En **Skins**: añade PNGs, previsualízalos y pulsa "Marcar como activa" — si
   el checkbox de auto-instalación está marcado, KatLauncher instalará
   CustomSkinLoader automáticamente para ese perfil.
6. En **Modpacks**: busca un proyecto de Modrinth, elige la versión, configura el
   nickname y pulsa "Instalar como perfil". Cuando termine aparecerá en **Jugar**,
   **Perfiles**, **Mods** y **Skins**. La versión de Minecraft y el loader de esos
   perfiles quedan bloqueados para no romper el pack.
7. En **Configuración** puedes cambiar idioma y tema. Ambos cambios se aplican
   inmediatamente; **Kat Classic** conserva el aspecto de la serie 1.2.
8. En **Configuración > Actualizaciones** puedes activar la comprobación automática,
   buscar una versión manualmente y cancelar una descarga. Cuando una actualización
   esté verificada, KatLauncher pedirá confirmación, se cerrará limpiamente,
   actualizará la misma instalación y volverá a abrirse con un sonido y una
   notificación de confirmación.
9. En **Configuración > Sonido y Discord** puedes desactivar los sonidos o activar
   Rich Presence. El ID público de KatLauncher ya está incluido, así que no necesitas
   crear una aplicación ni pegar credenciales.

## 📣 Enviar una alerta a los usuarios (banner o diálogo, vía Supabase)

KatLauncher lee la alerta activa directo desde Supabase — el mismo proyecto
que ya usa Kat Social — así que **no hace falta ningún hosting aparte**.
Puede mostrarse como banner en el Dashboard o como cuadro de diálogo, con
sonido de advertencia opcional, según la severidad (info, advertencia o
crítico).

**Configuración (una sola vez):** en el SQL Editor de tu proyecto de
Supabase, ejecuta `supabase/11_kat_alerts_1521.sql` (después de los scripts
`09`/`10` que ya usa Kat Social, o después del paquete
`00_KAT_SOCIAL_TODO_EN_UNO.sql` si usaste ese). Crea la tabla `kat_alerts`
(lectura pública, sin necesidad de iniciar sesión) y la función
`kat_get_active_alert()` que el launcher consulta. También habilita
Realtime en esa tabla, así que un aviso nuevo llega casi al instante en vez
de esperar al siguiente sondeo (el launcher igual reintenta cada 15 min por
si acaso).

**Para publicar un aviso**, usa la herramienta incluida:

```
python tools/kat_alert_sender.py
```

Completa título/mensaje (ES/EN), severidad, si se muestra como banner o
diálogo, y si suena la advertencia; tiene vista previa y botón para probar
el sonido. Pide la **service_role key** de tu proyecto de Supabase (Settings
→ API → service_role) solo la primera vez — se guarda únicamente en tu
equipo, en `tools/kat_alert_sender_secrets.json` (ya está en `.gitignore`),
y nunca dentro de la app ni de `social_config.json`. El botón "🚀 Publicar
en Supabase" sube la fila; "🧹 Retirar alerta activa" la desactiva.

## 📁 Dónde se guarda todo

- Configuración y perfiles: `~/.katlauncher/profiles.json`
- Ajustes del launcher: `~/.katlauncher/settings.json`
- Instancias del juego (una carpeta `.minecraft` por perfil):
  `~/.katlauncher/instances/<id-del-perfil>/`

Los perfiles creados con versiones anteriores conservan automáticamente su UUID
offline antiguo para no perder inventarios ni identidad en mundos existentes. Los
perfiles nuevos usan el algoritmo exacto de Minecraft.

## 🐛 Sobre las skins "random" (ej. Jack Black)

Por defecto, **CustomSkinLoader busca tu skin por nickname en Mojang y en
varios servidores de terceros ANTES de mirar tu carpeta local**. Si tu
nickname coincide con el de una cuenta real que tiene una skin puesta (por
ejemplo, la skin de Jack Black/Steve por la película de Minecraft), verás
esa skin ajena en vez de la tuya.

KatLauncher lo soluciona: al pulsar "Marcar como activa" en la pestaña
Skins, reescribe `CustomSkinLoader.json` para que el **único** origen de
skins sea tu carpeta local (`CustomSkinLoader/LocalSkin/skins/<nickname>.png`),
sin consultar ningún servidor externo. Si cambias el nickname, KatLauncher migra
la copia activa de forma transaccional para que no desaparezca.

## ⚠️ Notas legales

Este launcher **no distribuye ni modifica** los archivos oficiales de Minecraft;
solo automatiza la descarga desde los servidores oficiales de Mojang usando la
librería [`minecraft-launcher-lib`](https://pypi.org/project/minecraft-launcher-lib/).
El modo offline no requiere ni verifica una licencia de Minecraft: úsalo bajo tu
propia responsabilidad y respetando los [términos de uso de Mojang](https://www.minecraft.net/en-us/eula).

Los avisos y licencias de los componentes incluidos en la compilación para Windows
se encuentran en `THIRD_PARTY_NOTICES.txt` y en la carpeta `licenses` instalada
junto a la aplicación.

KatLauncher se distribuye bajo [su licencia propia](LICENSE.txt). Los componentes
de terceros conservan íntegramente sus licencias originales.

## 🗂️ Estructura del proyecto

```
KatLauncher/
├── main.py                     # Punto de entrada
├── requirements.txt
├── requirements-build.txt
├── README.md
├── THIRD_PARTY_NOTICES.txt
├── packaging/                  # PyInstaller, icono e instalador de Windows
└── katlauncher/
    ├── update_channel.json     # Endpoint y hosts fijos de la compilación
    ├── core/
    │   ├── profile_manager.py  # Perfiles (JSON persistente)
    │   ├── launcher_core.py    # Instalación y lanzamiento (vanilla/fabric/forge)
    │   ├── mods_manager.py     # Añadir/quitar/activar mods
    │   ├── modrinth_api.py     # Búsqueda/descarga desde Modrinth + CustomSkinLoader
    │   ├── modpack_manager.py  # Validación e instalación transaccional de .mrpack
    │   ├── settings_manager.py # Ajustes globales persistentes
    │   ├── discord_presence.py # Discord RPC opcional y no bloqueante
    │   ├── update_manager.py   # Canal HTTPS, versión, descarga y SHA-256
    │   └── skins_manager.py    # Gestión de skins locales
    └── gui/
        ├── main_window.py      # Ventana principal + tema oscuro
        ├── splash_screen.py    # Pantalla de carga inicial (logo del gato cósmico)
        ├── play_tab.py         # Pestaña Jugar
        ├── profiles_tab.py     # Pestaña Perfiles
        ├── mods_tab.py         # Pestaña Mods
        ├── modpacks_tab.py     # Buscador/instalador de modpacks de Modrinth
        ├── skins_tab.py        # Pestaña Skins
        ├── settings_tab.py     # Configuración e idioma
        ├── update_controller.py# Hilos y estado del actualizador
        ├── update_banner.py    # Aviso no intrusivo de nueva versión
        ├── sound_manager.py    # Reproducción de sonidos integrada en Windows
        ├── i18n.py             # Catálogo español/inglés
        └── workers.py          # Hilos en segundo plano (QThread)
    └── assets/
        ├── logo.png            # Logo de KatLauncher (gato cósmico)
        ├── success.mp3         # Confirmación de operaciones
        ├── cat_ringtone.mp3    # Easter egg del logotipo
        └── update_success.wav  # Confirmación de actualización
```
