"""
Núcleo de KatLauncher: instala y lanza Minecraft Java Edition usando
minecraft-launcher-lib, en modo offline/nickname (sin cuenta Microsoft).
"""
from __future__ import annotations

import subprocess
import re
from pathlib import Path
from typing import Callable, Optional

import minecraft_launcher_lib as mll
import requests

from .. import __version__
from .profile_manager import Profile, offline_uuid


class LoaderInstallError(RuntimeError):
    """Error de loader con contexto suficiente para soporte, sin traceback crudo."""


def required_java_major(minecraft_version: str) -> int:
    """Java mínimo usado por las versiones release modernas de Minecraft."""
    calendar = re.fullmatch(r"(\d{2})\.(\d+)(?:\.(\d+))?", str(minecraft_version or ""))
    if calendar:
        return 25 if int(calendar.group(1)) >= 26 else 21
    match = re.fullmatch(r"1\.(\d+)(?:\.(\d+))?", str(minecraft_version or ""))
    if not match:
        return 21  # snapshots/nombres desconocidos: opción moderna y segura
    minor, patch = int(match.group(1)), int(match.group(2) or 0)
    if minor > 20 or (minor == 20 and patch >= 5):
        return 21
    if minor >= 18:
        return 17
    if minor == 17:
        return 16
    return 8


RUNTIME_BY_JAVA_MAJOR = {
    8: "jre-legacy",
    16: "java-runtime-alpha",
    17: "java-runtime-gamma",
    21: "java-runtime-delta",
    25: "java-runtime-epsilon",
}


def _java_major(value: str) -> int:
    value = str(value or "")
    match = re.match(r"1\.(\d+)", value)
    if match:
        return int(match.group(1))
    match = re.match(r"(\d+)", value)
    return int(match.group(1)) if match else 0


def compatible_java(profile: Profile, configured_path: str = "") -> str:
    """Escoge Java suficiente y devuelve su ejecutable, o explica qué falta."""
    required = required_java_major(profile.version)
    if configured_path:
        configured = Path(configured_path)
        java_home = configured.parent.parent \
            if configured.name.lower() in ("java.exe", "javaw.exe", "java", "javaw") \
            else configured
        try:
            info = mll.java_utils.get_java_information(java_home)
        except Exception as error:
            raise LoaderInstallError(
                f"El Java configurado no se pudo ejecutar: {configured_path}"
            ) from error
        major = _java_major(info.get("version", ""))
        if major < required:
            raise LoaderInstallError(
                f"Minecraft {profile.version} necesita Java {required} o superior; "
                f"el Java configurado es {info.get('version', '?')}."
            )
        return str(info.get("java_path") or configured_path)

    try:
        candidates = mll.java_utils.find_system_java_versions_information()
    except Exception:
        candidates = []
    compatible = [item for item in candidates if _java_major(item.get("version", "")) >= required]
    if not compatible:
        raise LoaderInstallError(
            f"Minecraft {profile.version} necesita Java {required} o superior y no se encontró "
            "uno compatible. Instala ese Java o selecciónalo en Configuración > Java."
        )
    compatible.sort(key=lambda item: (
        _java_major(item.get("version", "")) != required,
        not bool(item.get("is_64bit", False)),
        _java_major(item.get("version", "")),
    ))
    return str(compatible[0].get("java_path") or "")


def ensure_compatible_java(profile: Profile, configured_path: str = "",
                           callback: dict | None = None, status_cb=None) -> str:
    """Usa Java del sistema o instala el runtime oficial administrado por Mojang."""
    try:
        return compatible_java(profile, configured_path)
    except LoaderInstallError:
        if configured_path:
            raise
    required = required_java_major(profile.version)
    component = RUNTIME_BY_JAVA_MAJOR.get(required)
    if not component:
        raise LoaderInstallError(f"No existe un runtime administrado para Java {required}.")
    if status_cb:
        status_cb(f"Instalando automáticamente Java {required} oficial de Minecraft...")
    try:
        executable = mll.runtime.get_executable_path(component, profile.game_dir)
        if not executable:
            mll.runtime.install_jvm_runtime(component, profile.game_dir, callback=callback or {})
            executable = mll.runtime.get_executable_path(component, profile.game_dir)
    except Exception as error:
        raise LoaderInstallError(
            f"No se pudo instalar automáticamente Java {required}: {error}"
        ) from error
    if not executable:
        raise LoaderInstallError(
            f"Java {required} terminó de descargarse pero no se encontró su ejecutable."
        )
    return str(executable)


def _loader_error(profile: Profile, loader_version: str, error: Exception) -> LoaderInstallError:
    detail = " ".join(str(error or "").split())[:500]
    lowered = detail.lower()
    if any(marker in lowered for marker in ("ssl", "connection", "timeout", "network")):
        reason = "falló la conexión o la verificación HTTPS"
    elif any(marker in lowered for marker in ("java", "jvm", "exit code", "return code")):
        reason = "el instalador del loader no pudo ejecutarse con Java"
    elif any(marker in lowered for marker in ("404", "not found", "unsupported", "compatible")):
        reason = "esa combinación de Minecraft y loader no está disponible"
    else:
        reason = "el instalador del loader devolvió un error"
    version = loader_version or "automática"
    return LoaderInstallError(
        f"No se pudo instalar {profile.loader} {version} para Minecraft {profile.version}: "
        f"{reason}. Detalle: {detail or type(error).__name__}"
    )


def get_version_list(include_snapshots: bool = False, include_old: bool = False) -> list[dict]:
    """Devuelve la lista de versiones vanilla disponibles para descargar."""
    versions = mll.utils.get_version_list()
    result = []
    for v in versions:
        if v["type"] == "release":
            result.append(v)
        elif v["type"] == "snapshot" and include_snapshots:
            result.append(v)
        elif v["type"] in ("old_beta", "old_alpha") and include_old:
            result.append(v)
    return result


def get_installed_versions(minecraft_directory: str) -> list[str]:
    try:
        return [v["id"] for v in mll.utils.get_installed_versions(minecraft_directory)]
    except Exception:
        return []


def get_fabric_loader_versions() -> list[str]:
    return [v["version"] for v in mll.fabric.get_all_loader_versions()]


def get_forge_version(minecraft_version: str) -> Optional[str]:
    """Encuentra la última versión de Forge recomendada/soportada para una versión de Minecraft."""
    try:
        return mll.forge.find_forge_version(minecraft_version)
    except Exception:
        return None


def _callback(status_cb, progress_cb, max_cb) -> dict:
    cb = {}
    if status_cb:
        cb["setStatus"] = status_cb
    if progress_cb:
        cb["setProgress"] = progress_cb
    if max_cb:
        cb["setMax"] = max_cb
    return cb


def install_version(profile: Profile,
                    status_cb: Callable[[str], None] = None,
                    progress_cb: Callable[[int], None] = None,
                    max_cb: Callable[[int], None] = None,
                    java_path: str = "") -> str:
    """Instala (si hace falta) la versión vanilla + el mod loader elegido para un perfil."""
    game_dir = profile.game_dir
    cb = _callback(status_cb, progress_cb, max_cb)

    if is_profile_installed(profile):
        if status_cb:
            status_cb("Verificando y reparando la instalación...")
        launch_version_id = resolve_installed_version_id(profile)
        # minecraft-launcher-lib también verifica assets, librerías y natives;
        # no basta con que existan los JSON/JAR de la versión.
        try:
            mll.install.install_minecraft_version(profile.version, game_dir, callback=cb)
            if launch_version_id != profile.version:
                mll.install.install_minecraft_version(
                    launch_version_id, game_dir, callback=cb
                )
        except requests.RequestException:
            # Una instancia que ya arrancó correctamente conserva todos sus
            # archivos locales. Sin red se omite únicamente la reparación.
            if status_cb:
                status_cb("Sin conexión: usando la instalación local verificada.")
        return launch_version_id

    if profile.loader == "vanilla":
        mll.install.install_minecraft_version(profile.version, game_dir, callback=cb)
        return profile.version

    if profile.loader not in ("fabric", "forge", "quilt", "neoforge"):
        raise ValueError(f"Loader desconocido: {profile.loader}")

    loader = mll.mod_loader.get_mod_loader(profile.loader)
    chosen_loader_version = profile.loader_version or ""
    try:
        if status_cb:
            status_cb(f"Comprobando compatibilidad de {profile.loader}...")
        if not loader.is_minecraft_version_supported(profile.version):
            raise LoaderInstallError(
                f"{profile.loader.title()} no ofrece una versión compatible con "
                f"Minecraft {profile.version}."
            )
        if chosen_loader_version:
            available = loader.get_loader_versions(profile.version, stable_only=False)
            if chosen_loader_version not in available:
                raise LoaderInstallError(
                    f"{profile.loader.title()} {chosen_loader_version} no es compatible "
                    f"con Minecraft {profile.version}."
                )
        else:
            chosen_loader_version = loader.get_latest_loader_version(profile.version)
        if status_cb:
            status_cb(f"Preparando Minecraft {profile.version}...")
        mll.install.install_minecraft_version(profile.version, game_dir, callback=cb)
        selected_java = ensure_compatible_java(
            profile, java_path, callback=cb, status_cb=status_cb
        )
        if status_cb:
            status_cb(
                f"Instalando {profile.loader} {chosen_loader_version} con Java "
                f"{required_java_major(profile.version)}+..."
            )
        return loader.install(
            profile.version,
            game_dir,
            loader_version=chosen_loader_version,
            callback=cb,
            java=selected_java,
        )
    except LoaderInstallError:
        raise
    except Exception as error:
        raise _loader_error(profile, chosen_loader_version, error) from error


def is_profile_installed(profile: Profile) -> bool:
    if not profile.version:
        return False
    installed = set(get_installed_versions(profile.game_dir))
    if profile.launch_version_id:
        return profile.launch_version_id in installed \
            and _has_required_version_files(profile, profile.launch_version_id)
    if profile.loader == "vanilla":
        return profile.version in installed \
            and _has_required_version_files(profile, profile.version)
    if profile.loader_version:
        try:
            expected = mll.mod_loader.get_mod_loader(profile.loader).get_installed_version(
                profile.version, profile.loader_version
            )
            return expected in installed and _has_required_version_files(profile, expected)
        except Exception:
            return False
    candidates = [item for item in installed
                  if _matches_loader_id(item, profile.loader, profile.version)]
    return len(candidates) == 1 and _has_required_version_files(profile, candidates[0])


def _has_required_version_files(profile: Profile, launch_version_id: str) -> bool:
    versions_dir = Path(profile.game_dir) / "versions"
    base_dir = versions_dir / profile.version
    launch_dir = versions_dir / launch_version_id
    return (
        (base_dir / f"{profile.version}.json").is_file()
        and (base_dir / f"{profile.version}.jar").is_file()
        and (launch_dir / f"{launch_version_id}.json").is_file()
    )


def resolve_installed_version_id(profile: Profile) -> str:
    """Tras instalar, Fabric/Forge crean un id de versión compuesto
    (p.ej. 'fabric-loader-0.15.0-1.21' o '1.21-forge-51.0.0').
    Buscamos ese id instalado en la carpeta del perfil."""
    installed = mll.utils.get_installed_versions(profile.game_dir)
    ids = [v["id"] for v in installed]

    if profile.launch_version_id:
        if profile.launch_version_id in ids:
            return profile.launch_version_id
        raise RuntimeError(
            f"No se encontró la versión instalada requerida: {profile.launch_version_id}"
        )

    if profile.loader == "vanilla":
        if profile.version in ids:
            return profile.version
        raise RuntimeError(f"Minecraft {profile.version} no está instalado")

    if profile.loader_version:
        expected = mll.mod_loader.get_mod_loader(profile.loader).get_installed_version(
            profile.version, profile.loader_version
        )
        if expected in ids:
            return expected

    candidates = [vid for vid in ids if _matches_loader_id(vid, profile.loader, profile.version)]
    if len(candidates) == 1:
        return candidates[0]
    if len(candidates) > 1:
        # No se adivina entre varias instalaciones: guardar launch_version_id lo evita.
        raise RuntimeError(
            f"Hay varias versiones instaladas de {profile.loader} para Minecraft {profile.version}"
        )
    raise RuntimeError(
        f"No se encontró {profile.loader} instalado para Minecraft {profile.version}"
    )


def _matches_loader_id(version_id: str, loader: str, minecraft_version: str) -> bool:
    escaped = re.escape(minecraft_version)
    patterns = {
        "fabric": rf"^fabric-loader-.+-{escaped}$",
        "quilt": rf"^quilt-loader-.+-{escaped}$",
        "forge": rf"^{escaped}-forge-.+$",
        "neoforge": rf"^(?:{escaped}-)?neoforge-.+$",
    }
    pattern = patterns.get(loader)
    return bool(pattern and re.fullmatch(pattern, version_id, flags=re.IGNORECASE))


def launch(profile: Profile, java_path: str = "") -> subprocess.Popen:
    """Lanza Minecraft en modo offline con el nickname del perfil."""
    version_id = resolve_installed_version_id(profile)

    options: mll.types.MinecraftOptions = {
        "username": profile.nickname,
        "uuid": offline_uuid(
            profile.nickname, legacy=profile.offline_uuid_mode == "legacy"
        ),
        "token": "",  # vacío = sin autenticación online
        "gameDirectory": profile.game_dir,
        "launcherName": "KatLauncher",
        "launcherVersion": __version__,
        "customResolution": True,
        "resolutionWidth": str(profile.resolution_w),
        "resolutionHeight": str(profile.resolution_h),
        "jvmArguments": (
            [f"-Xms{profile.min_ram}M", f"-Xmx{profile.max_ram}M"]
            + (_split_jvm_arguments(profile.jvm_args) if profile.jvm_args.strip() else [])
        ),
    }
    if profile.min_ram > profile.max_ram:
        raise ValueError("La RAM máxima no puede ser menor que la mínima")
    selected_java = java_path
    if not selected_java:
        component = RUNTIME_BY_JAVA_MAJOR.get(required_java_major(profile.version))
        if component:
            selected_java = mll.runtime.get_executable_path(component, profile.game_dir) or ""
    if selected_java:
        options["executablePath"] = selected_java
    if profile.server_host:
        options["server"] = profile.server_host
        options["port"] = str(max(1, min(int(profile.server_port), 65535)))

    command = mll.command.get_minecraft_command(version_id, profile.game_dir, options)
    popen_options = {
        "cwd": profile.game_dir,
        "stdout": subprocess.PIPE,
        "stderr": subprocess.STDOUT,
        "text": True,
        "encoding": "utf-8",
        "errors": "replace",
        "bufsize": 1,
    }
    if hasattr(subprocess, "CREATE_NO_WINDOW"):
        # KatLauncher es una aplicación gráfica. Este flag evita que java.exe
        # cree una consola independiente sin perder stdout, que sigue llegando
        # mediante el pipe a la pestaña Registro del juego.
        popen_options["creationflags"] = subprocess.CREATE_NO_WINDOW
        startupinfo = subprocess.STARTUPINFO()
        startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        startupinfo.wShowWindow = subprocess.SW_HIDE
        popen_options["startupinfo"] = startupinfo
    process = subprocess.Popen(command, **popen_options)
    return process


def _split_jvm_arguments(value: str) -> list[str]:
    """Separa argumentos respetando comillas, incluidas rutas de Windows con espacios."""
    result: list[str] = []
    current: list[str] = []
    quoted = False
    text = value.strip()
    index = 0
    while index < len(text):
        char = text[index]
        if char == "\\" and quoted and index + 1 < len(text) \
                and text[index + 1] in ('"', "\\"):
            current.append(text[index + 1])
            index += 2
            continue
        if char == '"':
            quoted = not quoted
        elif char.isspace() and not quoted:
            if current:
                result.append("".join(current))
                current = []
        else:
            current.append(char)
        index += 1
    if quoted:
        raise ValueError("Las comillas de los argumentos JVM no están cerradas")
    if current:
        result.append("".join(current))
    return result
