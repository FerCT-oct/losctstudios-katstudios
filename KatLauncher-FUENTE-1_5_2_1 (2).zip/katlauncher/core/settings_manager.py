"""Persistencia y validación de la configuración global de KatLauncher."""
from __future__ import annotations

import json
from dataclasses import asdict, dataclass, fields
from pathlib import Path

from .discord_presence import DEFAULT_DISCORD_CLIENT_ID
from .profile_manager import APP_DIR, validate_nickname


SETTINGS_FILE = APP_DIR / "settings.json"


@dataclass
class LauncherSettings:
    language: str = "es"
    java_path: str = ""
    show_splash: bool = True
    minimize_on_launch: bool = True
    log_max_lines: int = 2000
    sound_effects_enabled: bool = True
    discord_rich_presence: bool = True
    discord_client_id: str = DEFAULT_DISCORD_CLIENT_ID
    include_snapshots: bool = False
    auto_install_custom_skin_loader: bool = True
    auto_install_katcraft: bool = True
    warn_vanilla_katcraft: bool = True
    auto_install_controlify: bool = True
    auto_install_mckat_pack: bool = True
    social_keep_local_history: bool = False
    kat_presence_enabled: bool = True
    auto_check_updates: bool = True
    onboarding_completed: bool = False
    default_nickname: str = "Jugador"
    default_min_ram: int = 1024
    default_max_ram: int = 2048
    default_resolution_w: int = 854
    default_resolution_h: int = 480
    roadmap_1_6_0_banner_dismissed: bool = False

    def normalize(self):
        if self.language not in ("es", "en"):
            self.language = "es"
        self.java_path = str(self.java_path or "").strip()
        for name, default in (
            ("show_splash", True),
            ("minimize_on_launch", True),
            ("sound_effects_enabled", True),
            ("discord_rich_presence", True),
            ("include_snapshots", False),
            ("auto_install_custom_skin_loader", True),
            ("auto_install_katcraft", True),
            ("warn_vanilla_katcraft", True),
            ("auto_install_controlify", True),
            ("auto_install_mckat_pack", True),
            ("social_keep_local_history", False),
            ("kat_presence_enabled", True),
            ("auto_check_updates", True),
            ("onboarding_completed", False),
            ("roadmap_1_6_0_banner_dismissed", False),
        ):
            if not isinstance(getattr(self, name), bool):
                setattr(self, name, default)
        self.log_max_lines = max(200, min(_safe_int(self.log_max_lines, 2000), 20000))
        # El Application ID es configuración pública del producto. Se fuerza el
        # oficial para que instalaciones antiguas o ajustes editados a mano no
        # terminen publicando bajo otra aplicación de Discord.
        self.discord_client_id = DEFAULT_DISCORD_CLIENT_ID
        self.default_nickname = str(self.default_nickname or "Jugador").strip() or "Jugador"
        try:
            validate_nickname(self.default_nickname)
        except ValueError:
            self.default_nickname = "Jugador"
        self.default_min_ram = max(512, min(_safe_int(self.default_min_ram, 1024), 32768))
        self.default_max_ram = max(
            self.default_min_ram, min(_safe_int(self.default_max_ram, 2048), 32768)
        )
        self.default_resolution_w = max(
            320, min(_safe_int(self.default_resolution_w, 854), 7680)
        )
        self.default_resolution_h = max(
            240, min(_safe_int(self.default_resolution_h, 480), 4320)
        )


class SettingsManager:
    def __init__(self, settings_file: str | Path | None = None):
        self.settings_file = Path(settings_file) if settings_file else SETTINGS_FILE
        self.settings_file.parent.mkdir(parents=True, exist_ok=True)
        self.settings = LauncherSettings()
        self.load()

    def load(self):
        self.settings = LauncherSettings()
        if self.settings_file.exists():
            try:
                raw = json.loads(self.settings_file.read_text(encoding="utf-8"))
                if not isinstance(raw, dict):
                    raise TypeError("La configuración debe ser un objeto JSON")
                allowed = {item.name for item in fields(LauncherSettings)}
                values = {key: value for key, value in raw.items() if key in allowed}
                self.settings = LauncherSettings(**values)
            except (OSError, ValueError, TypeError, json.JSONDecodeError):
                self.settings = LauncherSettings()
        self.settings.normalize()

    def save(self):
        self.settings.normalize()
        payload = json.dumps(asdict(self.settings), indent=2, ensure_ascii=False)
        temp_file = self.settings_file.with_suffix(self.settings_file.suffix + ".tmp")
        temp_file.write_text(payload, encoding="utf-8")
        temp_file.replace(self.settings_file)

    def update(self, **kwargs) -> LauncherSettings:
        previous = asdict(self.settings)
        try:
            for key, value in kwargs.items():
                if hasattr(self.settings, key):
                    setattr(self.settings, key, value)
            self.save()
        except Exception:
            self.settings = LauncherSettings(**previous)
            raise
        return self.settings


def _safe_int(value, default: int) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default
