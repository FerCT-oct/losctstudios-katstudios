"""Descarga y caché seguro de carátulas públicas de Modrinth."""
from __future__ import annotations

import hashlib
import os
from pathlib import Path
from urllib.parse import urlsplit

import requests

from .profile_manager import APP_DIR


MAX_ICON_BYTES = 2 * 1024 * 1024
ICON_CACHE = APP_DIR / "cache" / "modrinth-icons"
_SIGNATURES = (
    b"\x89PNG\r\n\x1a\n",
    b"\xff\xd8\xff",
    b"RIFF",  # WebP también se valida por WEBP en bytes 8..12.
)


def _validated_icon_url(value: str) -> str:
    value = str(value or "")
    if not value or len(value) > 2048:
        raise ValueError("La carátula de Modrinth no tiene una URL válida.")
    parsed = urlsplit(value)
    if parsed.scheme != "https" or parsed.hostname != "cdn.modrinth.com" \
            or parsed.username or parsed.password or not parsed.path.startswith("/data/"):
        raise ValueError("La carátula de Modrinth usa una URL no permitida.")
    return value


def _valid_image(payload: bytes) -> bool:
    return (
        payload.startswith(_SIGNATURES[:2])
        or (payload.startswith(b"RIFF") and payload[8:12] == b"WEBP")
    ) and 1 <= len(payload) <= MAX_ICON_BYTES


def fetch_icon(icon_url: str, *, session: requests.Session | None = None) -> bytes:
    """Devuelve una carátula verificada y la conserva en caché por URL."""
    icon_url = _validated_icon_url(icon_url)
    cache = ICON_CACHE / (hashlib.sha256(icon_url.encode("utf-8")).hexdigest() + ".img")
    try:
        cached = cache.read_bytes()
        if _valid_image(cached):
            return cached
    except OSError:
        pass

    client = session or requests.Session()
    response = client.get(icon_url, timeout=15, stream=True, allow_redirects=False)
    try:
        response.raise_for_status()
        announced = int(response.headers.get("Content-Length", "0") or 0)
        if announced > MAX_ICON_BYTES:
            raise ValueError("La carátula de Modrinth supera 2 MB.")
        chunks = []
        total = 0
        for chunk in response.iter_content(64 * 1024):
            if not chunk:
                continue
            total += len(chunk)
            if total > MAX_ICON_BYTES:
                raise ValueError("La carátula de Modrinth supera 2 MB.")
            chunks.append(chunk)
        payload = b"".join(chunks)
    finally:
        response.close()
    if not _valid_image(payload):
        raise ValueError("Modrinth devolvió una carátula no válida.")

    cache.parent.mkdir(parents=True, exist_ok=True)
    temporary = cache.with_suffix(".tmp")
    try:
        temporary.write_bytes(payload)
        os.replace(temporary, cache)
    finally:
        temporary.unlink(missing_ok=True)
    return payload
