"""Detección ligera de mandos sin mantenerlos abiertos ni capturar su entrada."""
from __future__ import annotations

import ctypes
import os
from pathlib import Path


def connected_gamepads() -> list[str]:
    """Devuelve mandos detectados con dependencias opcionales y fallbacks nativos."""
    names: list[str] = []
    try:
        from inputs import devices

        names.extend(
            str(getattr(device, "name", "") or "Mando").strip()
            for device in devices.gamepads
        )
    except Exception:
        pass
    if names:
        return _unique(names)
    if os.name == "nt":
        return _windows_gamepads()
    return _linux_gamepads()


def has_gamepad() -> bool:
    return bool(connected_gamepads())


def primary_gamepad_state() -> dict | None:
    """Estado normalizado del primer mando para navegar la XMB sin capturarlo."""
    if os.name != "nt":
        return None
    try:
        winmm = ctypes.windll.winmm
    except (AttributeError, OSError):
        return None
    state_type = _joy_info_type()
    count = min(int(winmm.joyGetNumDevs()), 16)
    for index in range(count):
        state = state_type()
        state.dwSize = ctypes.sizeof(state_type)
        state.dwFlags = 0xFF
        if winmm.joyGetPosEx(index, ctypes.byref(state)) != 0:
            continue
        # WinMM normalmente informa los ejes en 0..65535.
        normalize = lambda value: max(-1.0, min(1.0, (int(value) - 32767.5) / 32767.5))
        return {
            "name": f"Mando {index + 1}",
            "x": normalize(state.dwXpos),
            "y": normalize(state.dwYpos),
            "buttons": int(state.dwButtons),
            "pov": int(state.dwPOV) if int(state.dwPOV) != 0xFFFF else -1,
        }
    return None


def _joy_info_type():
    class JOYINFOEX(ctypes.Structure):
        _fields_ = [
            ("dwSize", ctypes.c_uint32),
            ("dwFlags", ctypes.c_uint32),
            ("dwXpos", ctypes.c_uint32),
            ("dwYpos", ctypes.c_uint32),
            ("dwZpos", ctypes.c_uint32),
            ("dwRpos", ctypes.c_uint32),
            ("dwUpos", ctypes.c_uint32),
            ("dwVpos", ctypes.c_uint32),
            ("dwButtons", ctypes.c_uint32),
            ("dwButtonNumber", ctypes.c_uint32),
            ("dwPOV", ctypes.c_uint32),
            ("dwReserved1", ctypes.c_uint32),
            ("dwReserved2", ctypes.c_uint32),
        ]
    return JOYINFOEX


def _windows_gamepads() -> list[str]:
    """WinMM cubre mandos DirectInput y una gran parte de los XInput."""
    try:
        winmm = ctypes.windll.winmm
    except (AttributeError, OSError):
        return []

    result = []
    JOYINFOEX = _joy_info_type()
    count = min(int(winmm.joyGetNumDevs()), 16)
    for index in range(count):
        state = JOYINFOEX()
        state.dwSize = ctypes.sizeof(JOYINFOEX)
        state.dwFlags = 0xFF
        if winmm.joyGetPosEx(index, ctypes.byref(state)) == 0:
            result.append(f"Mando {index + 1}")
    return result


def _linux_gamepads() -> list[str]:
    paths = list(Path("/dev/input").glob("js*")) if Path("/dev/input").exists() else []
    return [f"Mando {path.name}" for path in paths]


def _unique(values: list[str]) -> list[str]:
    result = []
    seen = set()
    for value in values:
        value = value or "Mando"
        key = value.casefold()
        if key not in seen:
            seen.add(key)
            result.append(value)
    return result
