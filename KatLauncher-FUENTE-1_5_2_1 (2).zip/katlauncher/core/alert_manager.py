"""Alertas (banner o diálogo) leídas desde Supabase.

No requiere hosting aparte: reutiliza el mismo proyecto y la misma
"publishable key" pública de ``social_config.json`` (Kat Social), llamando a
la función ``kat_get_active_alert()`` (ver
``supabase/11_kat_alerts_1521.sql``), que cualquiera puede leer sin iniciar
sesión. Escribir en la tabla está bloqueado para el cliente: solo
``tools/kat_alert_sender.py``, con la service_role key guardada localmente
por el desarrollador, puede publicar una alerta.
"""
from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path

from supabase import create_client

from .profile_manager import APP_DIR
from .social_service import SocialError, load_config

ALERT_STATE_FILE = APP_DIR / "alert_state.json"
MAX_STATE_FILE_SIZE = 16 * 1024
SEVERITIES = ("info", "warning", "critical")
DISPLAYS = ("banner", "dialog")


class AlertError(RuntimeError):
    """Error consultando o validando la alerta activa."""


@dataclass(frozen=True)
class AlertInfo:
    id: str
    severity: str = "info"
    display: str = "banner"
    sound: bool = True
    title_es: str = ""
    title_en: str = ""
    message_es: str = ""
    message_en: str = ""
    published_at: str = ""

    def title_for(self, language: str) -> str:
        if language == "en":
            return self.title_en or self.title_es
        return self.title_es or self.title_en

    def message_for(self, language: str) -> str:
        if language == "en":
            return self.message_en or self.message_es
        return self.message_es or self.message_en


def is_configured() -> bool:
    try:
        config = load_config()
    except SocialError:
        return False
    url = str(config.get("project_url", "")).rstrip("/")
    key = str(config.get("publishable_key", ""))
    return url.startswith("https://") and bool(key)


def make_anon_client():
    """Cliente de solo lectura con la publishable key pública.

    Es exactamente el mismo proyecto que usa Kat Social; nunca lleva la
    service_role key, así que solo puede leer lo que la política de RLS
    ("kat_alerts_public_read") deja ver.
    """
    try:
        config = load_config()
    except SocialError as error:
        raise AlertError("Kat Social no está configurado; no hay alertas.") from error
    url = str(config.get("project_url", "")).rstrip("/")
    key = str(config.get("publishable_key", ""))
    if not url.startswith("https://") or not key:
        raise AlertError("Kat Social no está configurado; no hay alertas.")
    return create_client(url, key)


def fetch_alert(*, client=None) -> AlertInfo | None:
    """Llama a ``kat_get_active_alert()`` y devuelve la alerta vigente."""
    active_client = client or make_anon_client()
    try:
        response = active_client.rpc("kat_get_active_alert", {}).execute()
    except Exception as error:
        raise AlertError(f"No se pudo consultar la alerta: {error}") from error
    return parse_alert_payload(response.data)


def parse_alert_payload(payload) -> AlertInfo | None:
    if payload is None:
        return None
    if isinstance(payload, list):
        payload = payload[0] if payload else None
    if payload is None:
        return None
    if not isinstance(payload, dict):
        raise AlertError("La respuesta de alertas no tiene el formato esperado.")

    alert_id = str(payload.get("id") or "").strip()
    if not alert_id or len(alert_id) > 128:
        raise AlertError("La alerta no tiene un identificador válido.")

    severity = str(payload.get("severity") or "info").strip().lower()
    if severity not in SEVERITIES:
        severity = "info"

    display = str(payload.get("display") or "banner").strip().lower()
    if display not in DISPLAYS:
        display = "banner"

    sound = bool(payload.get("sound", True))
    title_es = str(payload.get("title_es", ""))[:140].strip()
    title_en = str(payload.get("title_en", ""))[:140].strip()
    message_es = str(payload.get("message_es", ""))[:600].strip()
    message_en = str(payload.get("message_en", ""))[:600].strip()

    if not (title_es or title_en) or not (message_es or message_en):
        raise AlertError("La alerta debe incluir al menos un título y un mensaje.")

    published_at = str(payload.get("published_at", ""))[:64]

    return AlertInfo(
        id=alert_id,
        severity=severity,
        display=display,
        sound=sound,
        title_es=title_es,
        title_en=title_en,
        message_es=message_es,
        message_en=message_en,
        published_at=published_at,
    )


def get_last_seen_alert_id(state_file: str | Path | None = None) -> str:
    path = Path(state_file) if state_file else ALERT_STATE_FILE
    try:
        if path.stat().st_size > MAX_STATE_FILE_SIZE:
            return ""
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, ValueError, json.JSONDecodeError):
        return ""
    if not isinstance(payload, dict):
        return ""
    return str(payload.get("last_seen_alert_id", ""))[:128]


def record_seen_alert(alert_id: str, state_file: str | Path | None = None) -> None:
    path = Path(state_file) if state_file else ALERT_STATE_FILE
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps({"last_seen_alert_id": str(alert_id)[:128]}, ensure_ascii=False)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(payload, encoding="utf-8")
    os.replace(temporary, path)


def check_for_new_alert(
    *, client=None, state_file: str | Path | None = None,
) -> AlertInfo | None:
    """Devuelve la alerta activa solo si es distinta de la última ya mostrada."""
    info = fetch_alert(client=client)
    if info is None:
        return None
    if info.id == get_last_seen_alert_id(state_file):
        return None
    return info
