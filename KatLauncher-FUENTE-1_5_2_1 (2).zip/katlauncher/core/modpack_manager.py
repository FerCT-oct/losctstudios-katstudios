"""Instalación transaccional y validación de modpacks Modrinth (.mrpack)."""
from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import stat
import time
import uuid
import zipfile
from concurrent.futures import CancelledError, ThreadPoolExecutor, as_completed
from dataclasses import asdict
from pathlib import Path, PurePosixPath
from threading import Event, Lock
from typing import Callable, Optional

import minecraft_launcher_lib as mll

from . import launcher_core, modrinth_api
from .profile_manager import APP_DIR, GAME_ROOT, Profile, validate_nickname


MAX_ARCHIVE_ENTRIES = 20_000
MAX_ARCHIVE_SIZE = (2 * 1024 * 1024 * 1024) - 1
MAX_UNCOMPRESSED_SIZE = 2 * 1024 * 1024 * 1024
MAX_SINGLE_FILE_SIZE = 1024 * 1024 * 1024
MAX_COMPRESSION_RATIO = 1000
MAX_INDEX_SIZE = 10 * 1024 * 1024
MAX_MANIFEST_FILES = 20_000
MAX_MANIFEST_DOWNLOAD_SIZE = 20 * 1024 * 1024 * 1024
PROGRESS_STEPS_PER_FILE = 1000
MAX_PARALLEL_DOWNLOADS = 8
STALE_STAGING_SECONDS = 24 * 60 * 60
WINDOWS_INVALID_CHARS = set('<>:"|?*')
WINDOWS_RESERVED = {
    "CON", "PRN", "AUX", "NUL",
    *(f"COM{i}" for i in range(1, 10)),
    *(f"LPT{i}" for i in range(1, 10)),
}
LOADER_DEPENDENCIES = {
    "fabric-loader": "fabric",
    "quilt-loader": "quilt",
    "forge": "forge",
    "neoforge": "neoforge",
}


class ModpackError(RuntimeError):
    pass


def export_folder_to_mrpack(
    source_dir: str | Path,
    output_path: str | Path,
    *,
    name: str,
    minecraft_version: str,
    loader: str = "vanilla",
    loader_version: str = "",
    status_cb=None,
) -> str:
    """Convierte una carpeta en un .mrpack portátil mediante ``overrides``.

    Es útil para copias privadas y packs propios. Quien lo publique debe tener
    permiso para redistribuir los mods, resource packs y shaders incluidos.
    """

    source = Path(source_dir).resolve()
    output = Path(output_path)
    if not source.is_dir():
        raise ModpackError("La carpeta de origen no existe.")
    clean_name = " ".join(str(name or "").strip().split())
    if not 1 <= len(clean_name) <= 64:
        raise ModpackError("El nombre del modpack debe tener entre 1 y 64 caracteres.")
    minecraft_version = _validate_dependency_version(minecraft_version, "Minecraft")
    loader = str(loader or "vanilla").lower()
    if loader not in ("vanilla", "fabric", "quilt", "forge", "neoforge"):
        raise ModpackError("El loader seleccionado no es compatible.")
    if loader != "vanilla":
        loader_version = _validate_dependency_version(loader_version, loader)
    if output.suffix.lower() != ".mrpack":
        output = output.with_suffix(".mrpack")

    excluded_roots = {
        ".katlauncher", "versions", "libraries", "assets", "runtime",
        "logs", "crash-reports",
    }
    entries: list[tuple[Path, Path]] = []
    total_size = 0
    for path in source.rglob("*"):
        relative = path.relative_to(source)
        if not relative.parts or relative.parts[0].lower() in excluded_roots:
            continue
        if path.is_symlink():
            raise ModpackError(f"No se permiten enlaces simbólicos: {relative.as_posix()}")
        if not path.is_file():
            continue
        if path.resolve() == output.resolve() or path.name.endswith((".part", ".tmp")):
            continue
        _safe_relative_path(relative.as_posix())
        size = path.stat().st_size
        if size > 512 * 1024 * 1024:
            raise ModpackError(f"El archivo es demasiado grande: {relative.as_posix()}")
        total_size += size
        if total_size > 2 * 1024 * 1024 * 1024 or len(entries) >= 20000:
            raise ModpackError("La carpeta supera el límite seguro del exportador.")
        entries.append((path, relative))

    dependencies = {"minecraft": minecraft_version}
    if loader != "vanilla":
        dependencies[f"{loader}-loader" if loader in ("fabric", "quilt") else loader] = loader_version
    index = {
        "formatVersion": 1,
        "game": "minecraft",
        "versionId": "1.0.0",
        "name": clean_name,
        "summary": f"Creado con KatLauncher {__import__('katlauncher').__version__}",
        "files": [],
        "dependencies": dependencies,
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.with_suffix(output.suffix + ".tmp")
    try:
        if status_cb:
            status_cb("Empaquetando archivos del modpack...")
        with zipfile.ZipFile(temporary, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
            archive.writestr(
                "modrinth.index.json",
                json.dumps(index, ensure_ascii=False, indent=2).encode("utf-8"),
            )
            for path, relative in entries:
                archive.write(path, f"overrides/{relative.as_posix()}")
        os.replace(temporary, output)
    except Exception:
        temporary.unlink(missing_ok=True)
        raise
    return str(output)


def _safe_relative_path(value: str, *, allow_directory: bool = False) -> PurePosixPath:
    if not isinstance(value, str) or not value or "\0" in value or "\\" in value:
        raise ModpackError(f"Ruta no segura dentro del modpack: {value!r}")
    raw = value[:-1] if allow_directory and value.endswith("/") else value
    if not raw or raw.startswith(("/", "\\")) or re.match(r"^[A-Za-z]:", raw):
        raise ModpackError(f"Ruta absoluta no permitida en el modpack: {value!r}")
    segments = raw.split("/")
    if any(part in ("", ".", "..") for part in segments):
        raise ModpackError(f"Ruta no segura dentro del modpack: {value!r}")
    path = PurePosixPath(raw)
    if path.is_absolute():
        raise ModpackError(f"Ruta no segura dentro del modpack: {value!r}")
    for part in path.parts:
        if any(ord(char) < 32 or char in WINDOWS_INVALID_CHARS for char in part) \
                or part.endswith((".", " ")):
            raise ModpackError(f"Nombre no válido para Windows en el modpack: {part!r}")
        if part.casefold() == ".katlauncher":
            raise ModpackError("El modpack intenta ocupar una carpeta interna de KatLauncher.")
        stem = part.split(".", 1)[0].rstrip(" ").upper()
        if stem in WINDOWS_RESERVED:
            raise ModpackError(f"Nombre reservado de Windows en el modpack: {part!r}")
    return path


def _validate_dependency_version(value, label: str) -> str:
    if not isinstance(value, str) or not value or value != value.strip() or len(value) > 128:
        raise ModpackError(f"La versión de {label} no es válida.")
    path = _safe_relative_path(value)
    if len(path.parts) != 1:
        raise ModpackError(f"La versión de {label} no es válida.")
    return value


def inspect_mrpack(archive_path: str | Path) -> tuple[dict, dict]:
    """Valida el ZIP y devuelve (índice, datos derivados del perfil)."""
    archive_path = Path(archive_path)
    if archive_path.suffix.lower() != ".mrpack":
        raise ModpackError("El archivo debe tener extensión .mrpack.")
    try:
        if archive_path.stat().st_size > MAX_ARCHIVE_SIZE:
            raise ModpackError("El archivo .mrpack es demasiado grande.")
        with zipfile.ZipFile(archive_path) as archive:
            entries = archive.infolist()
            if len(entries) > MAX_ARCHIVE_ENTRIES:
                raise ModpackError("El modpack contiene demasiados archivos.")
            seen: set[str] = set()
            file_paths: set[str] = set()
            total_size = 0
            for entry in entries:
                path = _safe_relative_path(entry.filename, allow_directory=entry.is_dir())
                key = path.as_posix().casefold()
                if key in seen:
                    raise ModpackError(f"El modpack contiene rutas duplicadas: {entry.filename}")
                seen.add(key)
                if not entry.is_dir():
                    file_paths.add(key)
                mode = entry.external_attr >> 16
                if stat.S_ISLNK(mode):
                    raise ModpackError(f"No se permiten enlaces simbólicos: {entry.filename}")
                if entry.is_dir() and entry.file_size:
                    raise ModpackError("Una entrada de carpeta del modpack contiene datos.")
                if entry.file_size > MAX_SINGLE_FILE_SIZE:
                    raise ModpackError(f"Un archivo del modpack es demasiado grande: {entry.filename}")
                total_size += entry.file_size
                if total_size > MAX_UNCOMPRESSED_SIZE:
                    raise ModpackError("El contenido descomprimido del modpack es demasiado grande.")
                if entry.compress_size and entry.file_size / entry.compress_size > MAX_COMPRESSION_RATIO:
                    raise ModpackError(f"Relación de compresión sospechosa: {entry.filename}")

            for key in file_paths:
                parts = key.split("/")
                for length in range(1, len(parts)):
                    if "/".join(parts[:length]) in file_paths:
                        raise ModpackError("El modpack contiene un conflicto entre archivo y carpeta.")

            try:
                index_entry = archive.getinfo("modrinth.index.json")
            except KeyError as error:
                raise ModpackError("El modpack no contiene modrinth.index.json.") from error
            if index_entry.file_size > MAX_INDEX_SIZE:
                raise ModpackError("El índice del modpack es demasiado grande.")
            raw_index = archive.read(index_entry)
    except (zipfile.BadZipFile, OSError) as error:
        raise ModpackError(f"El archivo .mrpack no es un ZIP válido: {error}") from error

    try:
        index = json.loads(raw_index.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError, TypeError) as error:
        raise ModpackError("modrinth.index.json no es un JSON UTF-8 válido.") from error
    if not isinstance(index, dict) or type(index.get("formatVersion")) is not int \
            or index.get("formatVersion") != 1:
        raise ModpackError("La versión del formato .mrpack no es compatible.")
    if index.get("game") != "minecraft":
        raise ModpackError("Este modpack no es para Minecraft.")
    for field_name in ("name", "versionId"):
        value = index.get(field_name)
        if not isinstance(value, str) or not value.strip() or len(value) > 512:
            raise ModpackError(f"El campo {field_name} del modpack no es válido.")
    if "summary" in index and not isinstance(index["summary"], str):
        raise ModpackError("El resumen del modpack no es válido.")

    dependencies = index.get("dependencies")
    if not isinstance(dependencies, dict) or any(
        not isinstance(key, str) for key in dependencies
    ) or "minecraft" not in dependencies:
        raise ModpackError("El modpack no indica una versión válida de Minecraft.")
    minecraft_version = _validate_dependency_version(
        dependencies.get("minecraft"), "Minecraft"
    )
    unknown = set(dependencies) - {"minecraft", *LOADER_DEPENDENCIES}
    if unknown:
        raise ModpackError(
            "El modpack usa dependencias que KatLauncher aún no admite: "
            + ", ".join(sorted(unknown))
        )
    selected_loaders = [key for key in LOADER_DEPENDENCIES if key in dependencies]
    if len(selected_loaders) > 1:
        raise ModpackError("El modpack declara más de un mod loader.")
    loader_dependency = selected_loaders[0] if selected_loaders else ""
    loader = LOADER_DEPENDENCIES.get(loader_dependency, "vanilla")
    loader_version = dependencies.get(loader_dependency) if loader_dependency else None
    if loader_version is not None:
        loader_version = _validate_dependency_version(loader_version, "mod loader")

    files = index.get("files")
    if not isinstance(files, list):
        raise ModpackError("La lista de archivos del modpack no es válida.")
    if len(files) > MAX_MANIFEST_FILES:
        raise ModpackError("El índice del modpack contiene demasiadas descargas.")
    optional_files = []
    manifest_paths: set[str] = set()
    manifest_directory_prefixes: set[str] = set()
    total_download_size = 0
    for item in files:
        if not isinstance(item, dict):
            raise ModpackError("El índice contiene una entrada de archivo no válida.")
        path = _safe_relative_path(item.get("path", ""))
        path_key = path.as_posix().casefold()
        if path_key in manifest_paths:
            raise ModpackError(f"El índice contiene una ruta duplicada: {path.as_posix()}.")
        parts = path_key.split("/")
        parent_paths = {
            "/".join(parts[:length]) for length in range(1, len(parts))
        }
        if any(parent in manifest_paths for parent in parent_paths) \
                or path_key in manifest_directory_prefixes:
            raise ModpackError("El índice contiene un conflicto entre archivo y carpeta.")
        manifest_paths.add(path_key)
        manifest_directory_prefixes.update(parent_paths)
        hashes = item.get("hashes", {})
        if not isinstance(hashes, dict) \
                or not re.fullmatch(r"[0-9a-fA-F]{40}", str(hashes.get("sha1", ""))) \
                or not re.fullmatch(r"[0-9a-fA-F]{128}", str(hashes.get("sha512", ""))):
            raise ModpackError(f"Faltan hashes válidos para {path.as_posix()}.")
        file_size = item.get("fileSize")
        if type(file_size) is not int or file_size < 0 or file_size > MAX_SINGLE_FILE_SIZE:
            raise ModpackError(f"El tamaño de {path.as_posix()} no es válido.")
        total_download_size += file_size
        if total_download_size > MAX_MANIFEST_DOWNLOAD_SIZE:
            raise ModpackError("Las descargas del modpack exceden el límite de tamaño.")
        downloads = item.get("downloads")
        if not isinstance(downloads, list) or not downloads or len(downloads) > 16:
            raise ModpackError(f"No hay descargas para {path.as_posix()}.")
        for url in downloads:
            modrinth_api._validated_download_url(str(url))
        env = item.get("env", {})
        if not isinstance(env, dict):
            raise ModpackError(f"El entorno de {path.as_posix()} no es válido.")
        if env and (
            set(env) != {"client", "server"}
            or any(value not in ("required", "optional", "unsupported")
                   for value in env.values())
        ):
            raise ModpackError(f"El entorno de {path.as_posix()} no es válido.")
        if env.get("client") == "optional":
            optional_files.append(path.as_posix())

    derived = {
        "minecraft_version": minecraft_version,
        "loader": loader,
        "loader_version": loader_version,
        "optional_files": optional_files,
    }
    return index, derived


def install_modpack(*, nickname: str, version: Optional[dict] = None,
                    local_path: str = "", project: Optional[dict] = None,
                    include_optional: bool = True, java_path: str = "",
                    profile_defaults: Optional[dict] = None,
                    status_cb: Optional[Callable[[str], None]] = None,
                    progress_cb: Optional[Callable[[int], None]] = None,
                    max_cb: Optional[Callable[[int], None]] = None) -> dict:
    """Instala a staging y devuelve un Profile serializado solo tras publicarlo."""
    validate_nickname(nickname)
    profile_defaults = profile_defaults or {}
    project = project or {}
    instance_id = uuid.uuid4().hex[:12]
    staging = GAME_ROOT / f".staging-{instance_id}"
    final_dir = GAME_ROOT / instance_id
    download_dir = APP_DIR / "downloads" / instance_id
    archive_path: Path
    owns_download = False

    GAME_ROOT.mkdir(parents=True, exist_ok=True)
    _cleanup_stale_staging()
    if staging.exists() or final_dir.exists():
        raise ModpackError("No se pudo reservar una carpeta para el modpack.")

    try:
        if local_path:
            archive_path = Path(local_path)
            if not archive_path.is_file():
                raise ModpackError("No se encontró el archivo .mrpack seleccionado.")
        else:
            if not version:
                raise ModpackError("No se seleccionó una versión del modpack.")
            owns_download = True
            download_dir.mkdir(parents=True, exist_ok=False)
            if status_cb:
                status_cb("Descargando archivo .mrpack...")
            archive_path = Path(modrinth_api.download_modpack_archive(
                version, download_dir, progress_cb=progress_cb, max_cb=max_cb
            ))

        if status_cb:
            status_cb("Validando el modpack...")
        index, derived = inspect_mrpack(archive_path)
        information = mll.mrpack.get_mrpack_information(str(archive_path))
        launch_version = mll.mrpack.get_mrpack_launch_version(str(archive_path))
        staging.mkdir(parents=False, exist_ok=False)

        temp_profile = Profile(
            id=staging.name,
            name=str(information.get("name") or index.get("name") or "Modpack"),
            nickname=nickname,
            version=derived["minecraft_version"],
            loader=derived["loader"],
            loader_version=derived["loader_version"],
        )
        if status_cb:
            status_cb("Instalando Minecraft y el mod loader...")
        installed_version = launcher_core.install_version(
            temp_profile,
            status_cb=status_cb,
            progress_cb=progress_cb,
            max_cb=max_cb,
            java_path=java_path,
        )
        if launch_version != installed_version:
            installed_ids = set(launcher_core.get_installed_versions(str(staging)))
            if launch_version not in installed_ids:
                raise ModpackError(
                    f"El modpack requiere {launch_version}, pero se instaló {installed_version}."
                )

        optional = derived["optional_files"] if include_optional else []
        if status_cb:
            status_cb("Descargando los archivos del modpack...")
        _download_manifest_files(
            index, staging, optional,
            progress_cb=progress_cb, max_cb=max_cb,
        )
        if status_cb:
            status_cb("Verificando los archivos del modpack...")
        _verify_manifest_files(index, staging, optional)
        # El formato exige que las capas ganen sobre los archivos descargados:
        # primero overrides y después client-overrides.
        _apply_override_layers(archive_path, staging)

        private_dir = staging / ".katlauncher"
        private_dir.mkdir(parents=True, exist_ok=True)
        stored_archive = private_dir / "source.mrpack"
        if archive_path.resolve() != stored_archive.resolve():
            shutil.copy2(archive_path, stored_archive)
        archive_hash = _sha512_file(stored_archive)

        remote_version_id = str((version or {}).get("id") or information.get("versionId") or "")
        version_number = str((version or {}).get("version_number") or information.get("versionId") or "")
        profile = Profile(
            id=instance_id,
            name=str(information.get("name") or index.get("name") or project.get("title") or "Modpack"),
            nickname=nickname,
            version=derived["minecraft_version"],
            loader=derived["loader"],
            loader_version=derived["loader_version"],
            min_ram=int(profile_defaults.get("min_ram", 1024)),
            max_ram=int(profile_defaults.get("max_ram", 2048)),
            resolution_w=int(profile_defaults.get("resolution_w", 854)),
            resolution_h=int(profile_defaults.get("resolution_h", 480)),
            source_type="modrinth",
            modpack_project_id=str(project.get("project_id") or project.get("slug") or ""),
            modpack_version_id=remote_version_id,
            modpack_version_number=version_number,
            modpack_summary=str(information.get("summary") or project.get("description") or ""),
            modpack_icon_url=str(project.get("icon_url") or ""),
            launch_version_id=launch_version,
        )
        manifest = {
            "schema_version": 1,
            "profile": asdict(profile),
            "archive_sha512": archive_hash,
            "dependencies": index.get("dependencies", {}),
            "optional_files": optional,
        }
        manifest_path = private_dir / "instance.json"
        manifest_path.write_text(
            json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8"
        )

        os.replace(staging, final_dir)
        return asdict(profile)
    except Exception:
        _remove_staging(staging)
        raise
    finally:
        if owns_download and download_dir.exists():
            _remove_tree(download_dir)


def repair_modpack(profile: Profile, *, java_path: str = "", status_cb=None,
                   progress_cb=None, max_cb=None) -> str:
    """Restaura archivos administrados sin tocar mundos ni configuración."""
    root = Path(profile.game_dir)
    archive = root / ".katlauncher" / "source.mrpack"
    manifest_path = root / ".katlauncher" / "instance.json"
    if not archive.is_file() or not manifest_path.is_file():
        raise ModpackError("Este modpack no conserva la fuente necesaria para repararlo.")
    try:
        metadata = json.loads(manifest_path.read_text(encoding="utf-8"))
        optional = metadata.get("optional_files", [])
    except (OSError, ValueError, json.JSONDecodeError) as error:
        raise ModpackError("Los metadatos del modpack están dañados.") from error
    if status_cb:
        status_cb("Reparando Minecraft y el mod loader...")
    launcher_core.install_version(
        profile, status_cb=status_cb, progress_cb=progress_cb,
        max_cb=max_cb, java_path=java_path,
    )
    if status_cb:
        status_cb("Comprobando archivos del modpack...")
    index, _derived = inspect_mrpack(archive)
    _download_manifest_files(
        index, root, optional, progress_cb=progress_cb, max_cb=max_cb
    )
    _verify_manifest_files(index, root, optional)
    return str(root)


def _remove_staging(path: Path):
    try:
        resolved = path.resolve()
        root = GAME_ROOT.resolve()
        if resolved.parent == root and resolved.name.startswith(".staging-") and resolved.exists():
            _remove_tree(resolved)
    except OSError:
        pass


def _cleanup_stale_staging():
    try:
        candidates = list(GAME_ROOT.iterdir())
    except OSError:
        return
    cutoff = time.time() - STALE_STAGING_SECONDS
    for path in candidates:
        if not re.fullmatch(r"\.staging-[0-9a-f]{12}", path.name):
            continue
        try:
            if path.is_dir() and path.stat().st_mtime < cutoff:
                _remove_staging(path)
        except OSError:
            continue


def _remove_tree(path: Path) -> bool:
    def make_writable_and_retry(function, filename, _exc_info):
        os.chmod(filename, stat.S_IWRITE | stat.S_IREAD)
        function(filename)

    for attempt in range(3):
        try:
            shutil.rmtree(path, onerror=make_writable_and_retry)
            return True
        except OSError:
            if attempt < 2:
                time.sleep(0.15 * (attempt + 1))
    return not path.exists()


def _apply_override_layers(archive_path: Path, destination: Path):
    root = destination.resolve()
    with zipfile.ZipFile(archive_path) as archive:
        entries = archive.infolist()
        for prefix in ("overrides/", "client-overrides/"):
            for entry in entries:
                if not entry.filename.startswith(prefix):
                    continue
                relative_name = entry.filename[len(prefix):]
                if not relative_name:
                    continue
                relative = _safe_relative_path(relative_name, allow_directory=entry.is_dir())
                target = destination.joinpath(*relative.parts)
                resolved_target = target.resolve()
                if root not in resolved_target.parents and resolved_target != root:
                    raise ModpackError("Un override intentó salir de la carpeta de la instancia.")
                if entry.is_dir():
                    if target.exists() and not target.is_dir():
                        raise ModpackError("Un override tiene un conflicto entre archivo y carpeta.")
                    target.mkdir(parents=True, exist_ok=True)
                    continue
                if target.exists() and target.is_dir():
                    raise ModpackError("Un override tiene un conflicto entre archivo y carpeta.")
                target.parent.mkdir(parents=True, exist_ok=True)
                with archive.open(entry) as source, target.open("wb") as output:
                    shutil.copyfileobj(source, output, length=1024 * 1024)


def _selected_manifest_files(index: dict, optional_files: list[str]):
    selected_optional = set(optional_files)
    for item in index["files"]:
        client = item.get("env", {}).get("client", "required")
        if client == "unsupported" \
                or (client == "optional" and item["path"] not in selected_optional):
            continue
        yield item


def _download_manifest_files(index: dict, destination: Path,
                             optional_files: list[str], progress_cb=None,
                             max_cb=None):
    """Descarga en paralelo con límites, hashes, mirrors y progreso seguro."""
    selected = list(_selected_manifest_files(index, optional_files))
    maximum = len(selected) * PROGRESS_STEPS_PER_FILE
    if max_cb:
        max_cb(maximum)
    if progress_cb:
        progress_cb(0)
    if not selected:
        return

    root = destination.resolve()
    prepared = []
    # Todas las rutas se validan antes de abrir la primera conexión. Así un pack
    # inválido nunca queda parcialmente descargado por otros workers.
    for file_index, item in enumerate(selected):
        relative = _safe_relative_path(item["path"])
        target = destination.joinpath(*relative.parts)
        resolved_target = target.resolve()
        if root not in resolved_target.parents or target.is_symlink():
            raise ModpackError(f"Ruta descargada no segura: {relative.as_posix()}.")
        parent = target.parent
        while parent != destination:
            if parent.is_symlink():
                raise ModpackError(f"Ruta descargada no segura: {relative.as_posix()}.")
            parent = parent.parent
        prepared.append((file_index, item, relative, target))

    progress_lock = Lock()
    per_file_progress = [0] * len(prepared)
    total_progress = 0
    stop_event = Event()

    def report_file_progress(file_index: int, file_size: int, value: int,
                             *, complete: bool = False):
        nonlocal total_progress
        if complete:
            fraction = PROGRESS_STEPS_PER_FILE
        else:
            transfer_steps = PROGRESS_STEPS_PER_FILE - 1
            fraction = transfer_steps if file_size == 0 else min(
                transfer_steps,
                int(value * transfer_steps / file_size),
            )
        with progress_lock:
            previous = per_file_progress[file_index]
            if fraction > previous:
                per_file_progress[file_index] = fraction
                total_progress += fraction - previous
                # Emitir mientras se conserva el lock mantiene el orden incluso
                # si dos descargas completan el mismo bloque a la vez.
                if progress_cb:
                    progress_cb(total_progress)

    def download_one(file_index: int, item: dict, relative: PurePosixPath,
                     target: Path):
        if stop_event.is_set():
            return
        file_size = item["fileSize"]

        def report(value: int):
            if not stop_event.is_set():
                report_file_progress(file_index, file_size, value)

        try:
            last_error = None
            for url in item["downloads"]:
                if stop_event.is_set():
                    return
                descriptor = {
                    "url": url,
                    "fileSize": file_size,
                    "hashes": item["hashes"],
                }
                try:
                    modrinth_api.download_file(
                        descriptor,
                        target,
                        progress_cb=report,
                        cancel_cb=stop_event.is_set,
                    )
                    last_error = None
                    break
                except modrinth_api.ModrinthError as error:
                    if stop_event.is_set():
                        return
                    last_error = error
            if last_error is not None:
                raise ModpackError(
                    f"No se pudo descargar {relative.as_posix()}: {last_error}"
                ) from last_error
            if not stop_event.is_set():
                report_file_progress(file_index, file_size, file_size, complete=True)
        except Exception:
            # Avisar desde el propio worker reduce la ventana durante la que los
            # demás hilos podrían continuar consumiendo ancho de banda.
            stop_event.set()
            raise

    first_error = None
    workers = min(MAX_PARALLEL_DOWNLOADS, len(prepared))
    with ThreadPoolExecutor(max_workers=workers, thread_name_prefix="kat-download") as pool:
        futures = [pool.submit(download_one, *entry) for entry in prepared]
        for future in as_completed(futures):
            try:
                future.result()
            except CancelledError:
                continue
            except Exception as error:
                if first_error is None:
                    first_error = error
                    stop_event.set()
                    for pending in futures:
                        pending.cancel()
    if first_error is not None:
        if isinstance(first_error, ModpackError):
            raise first_error
        raise ModpackError(f"No se pudieron descargar los archivos: {first_error}") \
            from first_error


def _verify_manifest_files(index: dict, destination: Path, optional_files: list[str]):
    """Revalida cada archivo antes de aplicar las capas de overrides."""
    root = destination.resolve()
    for item in _selected_manifest_files(index, optional_files):
        relative = _safe_relative_path(item["path"])
        target = destination.joinpath(*relative.parts)
        resolved_target = target.resolve()
        if root not in resolved_target.parents or target.is_symlink():
            raise ModpackError(f"Ruta descargada no segura: {relative.as_posix()}.")
        if not target.is_file():
            raise ModpackError(f"No se descargó un archivo requerido: {relative.as_posix()}.")
        if target.stat().st_size != item["fileSize"]:
            raise ModpackError(f"El tamaño descargado no coincide: {relative.as_posix()}.")
        actual_sha1, actual_sha512 = _file_hashes(target)
        hashes = item["hashes"]
        if actual_sha1 != str(hashes["sha1"]).lower() \
                or actual_sha512 != str(hashes["sha512"]).lower():
            raise ModpackError(f"Los hashes descargados no coinciden: {relative.as_posix()}.")


def _file_hashes(path: Path) -> tuple[str, str]:
    sha1 = hashlib.sha1()
    sha512 = hashlib.sha512()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            sha1.update(chunk)
            sha512.update(chunk)
    return sha1.hexdigest(), sha512.hexdigest()


def _sha512_file(path: Path) -> str:
    digest = hashlib.sha512()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()
