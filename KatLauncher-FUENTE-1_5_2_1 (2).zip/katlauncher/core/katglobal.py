"""Túnel global temporal para salas de KatLauncher."""
from __future__ import annotations

import os
import re
import subprocess
import threading
from pathlib import Path


class KatGlobalError(RuntimeError):
    pass


class KatGlobalTunnel:
    """Ejecuta el proxy QUIC aislado y devuelve el dominio asignado."""

    def __init__(self, java_path: str, target_port: int):
        self.java_path = str(java_path or "")
        self.target_port = int(target_port)
        self.process: subprocess.Popen | None = None
        self.domain = ""
        self.error = ""
        self._ready = threading.Event()
        self._reader: threading.Thread | None = None

    def start(self, *, timeout: float = 35, log_cb=None) -> str:
        if not 1 <= self.target_port <= 65535:
            raise KatGlobalError("Puerto local inválido para Kat Global.")
        classpath = str(_distribution_lib_dir() / "*")
        command = [
            _console_java(self.java_path),
            "-cp",
            classpath,
            "net.katlauncher.katglobal.KatGlobal",
            "--target-host",
            "127.0.0.1",
            "--target-port",
            str(self.target_port),
        ]
        options = {
            "stdin": subprocess.DEVNULL,
            "stdout": subprocess.PIPE,
            "stderr": subprocess.STDOUT,
            "text": True,
            "encoding": "utf-8",
            "errors": "replace",
            "bufsize": 1,
        }
        if hasattr(subprocess, "CREATE_NO_WINDOW"):
            options["creationflags"] = subprocess.CREATE_NO_WINDOW
            startupinfo = subprocess.STARTUPINFO()
            startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            startupinfo.wShowWindow = subprocess.SW_HIDE
            options["startupinfo"] = startupinfo
        try:
            self.process = subprocess.Popen(command, **options)
        except OSError as error:
            raise KatGlobalError(
                f"No se pudo iniciar el túnel global: {error}"
            ) from error
        self._reader = threading.Thread(
            target=self._read_output,
            args=(log_cb,),
            name="KatGlobalOutput",
            daemon=True,
        )
        self._reader.start()
        if not self._ready.wait(timeout):
            self.stop()
            raise KatGlobalError(
                "Kat Global no recibió un dominio dentro del tiempo esperado."
            )
        if not self.domain:
            message = self.error or "El relay global rechazó la conexión."
            self.stop()
            raise KatGlobalError(message)
        return self.domain

    def _read_output(self, log_cb):
        process = self.process
        try:
            for raw in process.stdout if process and process.stdout else ():
                line = raw.rstrip()
                if line.startswith("KATGLOBAL_DOMAIN="):
                    candidate = line.partition("=")[2].strip().lower()
                    if re.fullmatch(
                        r"[a-z0-9](?:[a-z0-9.-]{0,251}[a-z0-9])?",
                        candidate,
                    ):
                        self.domain = candidate
                        self._ready.set()
                elif line.startswith("KATGLOBAL_ERROR="):
                    self.error = line.partition("=")[2].strip()[:300]
                    self._ready.set()
                elif log_cb and line.startswith("KATGLOBAL_STATUS="):
                    log_cb("[Kat Global] " + line.partition("=")[2])
        finally:
            if not self.domain:
                self._ready.set()

    def stop(self):
        self._ready.set()
        process = self.process
        self.process = None
        if process is not None and process.poll() is None:
            try:
                process.terminate()
                process.wait(timeout=4)
            except (OSError, subprocess.TimeoutExpired):
                try:
                    process.kill()
                except OSError:
                    pass
        reader = self._reader
        self._reader = None
        if reader and reader is not threading.current_thread():
            reader.join(timeout=2)


def _distribution_lib_dir() -> Path:
    packaged = (
        Path(__file__).resolve().parent.parent
        / "assets"
        / "katglobal"
        / "lib"
    )
    if packaged.is_dir() and any(packaged.glob("katglobal-*.jar")):
        return packaged
    development = (
        Path(__file__).resolve().parents[2]
        / "katglobal"
        / "build"
        / "install"
        / "katglobal"
        / "lib"
    )
    if development.is_dir() and any(development.glob("katglobal-*.jar")):
        return development
    raise KatGlobalError(
        "Faltan los archivos internos de Kat Global. Reinstala KatLauncher."
    )


def _console_java(value: str) -> str:
    path = Path(str(value or "java"))
    if os.name == "nt" and path.name.casefold() == "javaw.exe":
        candidate = path.with_name("java.exe")
        if candidate.is_file():
            return str(candidate)
    return str(path)
