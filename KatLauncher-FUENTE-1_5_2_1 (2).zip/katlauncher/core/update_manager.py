"""Comprobación y descarga segura de actualizaciones de KatLauncher."""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import re
import subprocess
import sys
import tempfile
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from urllib.parse import urljoin, urlparse

import requests

from .. import __version__
from .profile_manager import APP_DIR


CHANNEL_CONFIG_PATH = Path(__file__).resolve().parent.parent / "update_channel.json"
UPDATE_STATE_FILE = APP_DIR / "update_state.json"
UPDATES_DIR = APP_DIR / "updates"
MANIFEST_SCHEMA = 1
CHANNEL_SCHEMA = 1
MAX_MANIFEST_SIZE = 64 * 1024
MAX_INSTALLER_SIZE = 256 * 1024 * 1024
CHECK_INTERVAL = timedelta(hours=24)
HEADERS = {"User-Agent": f"KatLauncher/{__version__} (Windows updater)"}
VERSION_RE = re.compile(r"^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$")
SHA256_RE = re.compile(r"^[0-9a-fA-F]{64}$")
HOST_RE = re.compile(
    r"^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)*"
    r"[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$"
)
GITHUB_HOSTS = {
    "api.github.com",
    "github.com",
    "raw.githubusercontent.com",
    "objects.githubusercontent.com",
    "release-assets.githubusercontent.com",
}


class UpdateError(RuntimeError):
    """Error validando, consultando o preparando una actualización."""


class UpdateCancelled(UpdateError):
    """La descarga fue cancelada por el usuario."""


@dataclass(frozen=True)
class UpdateChannel:
    manifest_url: str
    allowed_hosts: frozenset[str]


@dataclass(frozen=True)
class UpdateInfo:
    version: str
    installer_url: str
    installer_size: int
    installer_sha256: str
    notes_es: str = ""
    notes_en: str = ""
    published_at: str = ""

    def notes_for(self, language: str) -> str:
        if language == "en":
            return self.notes_en or self.notes_es
        return self.notes_es or self.notes_en


def version_tuple(value: str) -> tuple[int, int, int]:
    if not isinstance(value, str):
        raise UpdateError("La versión de la actualización no es válida.")
    match = VERSION_RE.fullmatch(value.strip())
    if not match:
        raise UpdateError("La versión de la actualización no es válida.")
    parts = tuple(int(item) for item in match.groups())
    if any(item > 65535 for item in parts):
        raise UpdateError("La versión de la actualización no es válida.")
    return parts


def is_newer_version(candidate: str, current: str = __version__) -> bool:
    return version_tuple(candidate) > version_tuple(current)


def load_update_channel(path: str | Path | None = None) -> UpdateChannel | None:
    """Carga el endpoint fijo incluido en la compilación.

    Las variables de entorno existen únicamente para compilaciones/pruebas internas;
    la interfaz no permite sustituir el canal por una URL recibida de Internet.
    """
    environment_url = os.environ.get("KATLAUNCHER_UPDATE_MANIFEST_URL", "").strip()
    environment_hosts = os.environ.get("KATLAUNCHER_UPDATE_ALLOWED_HOSTS", "")
    if environment_url and not getattr(sys, "frozen", False):
        hosts = [item.strip() for item in environment_hosts.split(",") if item.strip()]
        return _make_channel(environment_url, hosts)

    config_path = Path(path) if path else CHANNEL_CONFIG_PATH
    if not config_path.is_file():
        return None
    try:
        if config_path.stat().st_size > MAX_MANIFEST_SIZE:
            raise UpdateError("La configuración del canal de actualizaciones es demasiado grande.")
        payload = json.loads(config_path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, ValueError, json.JSONDecodeError) as error:
        raise UpdateError("La configuración del canal de actualizaciones no es válida.") from error
    if not isinstance(payload, dict) or payload.get("schema") != CHANNEL_SCHEMA:
        raise UpdateError("La configuración del canal de actualizaciones no es válida.")
    manifest_url = payload.get("manifest_url", "")
    if manifest_url == "":
        return None
    allowed_hosts = payload.get("allowed_hosts", [])
    if not isinstance(allowed_hosts, list) or any(
        not isinstance(item, str) for item in allowed_hosts
    ):
        raise UpdateError("La configuración del canal de actualizaciones no es válida.")
    return _make_channel(manifest_url, allowed_hosts)


def _make_channel(manifest_url: str, allowed_hosts) -> UpdateChannel:
    manifest_url = _validate_https_url(manifest_url)
    manifest_host = (urlparse(manifest_url).hostname or "").lower()
    hosts = {manifest_host}
    for raw_host in allowed_hosts:
        host = str(raw_host).strip().lower().rstrip(".")
        if not HOST_RE.fullmatch(host):
            raise UpdateError("La lista de servidores de actualización no es válida.")
        hosts.add(host)
    if manifest_host in GITHUB_HOSTS or hosts.intersection(GITHUB_HOSTS):
        hosts.update(GITHUB_HOSTS)
    return UpdateChannel(manifest_url=manifest_url, allowed_hosts=frozenset(hosts))


def _validate_https_url(url: str, allowed_hosts=None) -> str:
    if not isinstance(url, str) or not url or len(url) > 8192 or any(
        character.isspace() or ord(character) < 32 for character in url
    ):
        raise UpdateError("La URL de actualización no es segura.")
    try:
        parsed = urlparse(url)
        host = (parsed.hostname or "").lower().rstrip(".")
        port = parsed.port
    except ValueError as error:
        raise UpdateError("La URL de actualización no es segura.") from error
    if parsed.scheme != "https" or not host or port not in (None, 443):
        raise UpdateError("La URL de actualización no es segura.")
    if parsed.username or parsed.password or parsed.fragment:
        raise UpdateError("La URL de actualización no es segura.")
    if allowed_hosts is not None and host not in allowed_hosts:
        raise UpdateError("La actualización redirigió a un servidor no permitido.")
    return url


def _open_https(url: str, channel: UpdateChannel, *, session=requests):
    current = url
    for redirect_count in range(6):
        _validate_https_url(current, channel.allowed_hosts)
        try:
            response = session.get(
                current,
                headers=HEADERS,
                timeout=(15, 60),
                stream=True,
                allow_redirects=False,
            )
        except requests.RequestException as error:
            raise UpdateError(f"No se pudo conectar con el servicio de actualizaciones: {error}") from error
        if response.status_code in (301, 302, 303, 307, 308):
            location = response.headers.get("Location")
            response.close()
            if not location:
                raise UpdateError("La actualización redirigió sin indicar un destino.")
            current = urljoin(current, location)
            continue
        try:
            response.raise_for_status()
        except requests.RequestException as error:
            response.close()
            raise UpdateError(f"El servicio de actualizaciones devolvió un error: {error}") from error
        return response
    raise UpdateError("La actualización superó el límite de redirecciones.")


def check_for_update(
    channel: UpdateChannel,
    *,
    current_version: str = __version__,
    session=requests,
) -> UpdateInfo | None:
    response = _open_https(channel.manifest_url, channel, session=session)
    payload = bytearray()
    try:
        raw_length = response.headers.get("Content-Length")
        if raw_length:
            try:
                announced_length = int(raw_length)
            except (TypeError, ValueError) as error:
                raise UpdateError("El tamaño del manifiesto no es válido.") from error
            if announced_length < 0 or announced_length > MAX_MANIFEST_SIZE:
                raise UpdateError("El manifiesto de actualización es demasiado grande.")
        for chunk in response.iter_content(chunk_size=16 * 1024):
            if not chunk:
                continue
            payload.extend(chunk)
            if len(payload) > MAX_MANIFEST_SIZE:
                raise UpdateError("El manifiesto de actualización es demasiado grande.")
    except requests.RequestException as error:
        raise UpdateError(f"No se pudo descargar el manifiesto de actualización: {error}") from error
    finally:
        response.close()
    info = parse_manifest(bytes(payload), channel)
    return info if is_newer_version(info.version, current_version) else None


def parse_manifest(payload: bytes | str | dict, channel: UpdateChannel) -> UpdateInfo:
    if isinstance(payload, bytes):
        try:
            payload = json.loads(payload.decode("utf-8"))
        except (UnicodeError, ValueError, json.JSONDecodeError) as error:
            raise UpdateError("El manifiesto de actualización no es JSON válido.") from error
    elif isinstance(payload, str):
        try:
            payload = json.loads(payload)
        except (ValueError, json.JSONDecodeError) as error:
            raise UpdateError("El manifiesto de actualización no es JSON válido.") from error
    if not isinstance(payload, dict) or payload.get("schema") != MANIFEST_SCHEMA:
        raise UpdateError("El manifiesto de actualización no es compatible.")
    if payload.get("channel", "stable") != "stable":
        raise UpdateError("El canal de la actualización no es compatible.")

    version = payload.get("version")
    version_tuple(version)
    installer = payload.get("installer")
    if not isinstance(installer, dict):
        raise UpdateError("El manifiesto no contiene un instalador válido.")
    url = _validate_https_url(installer.get("url"), channel.allowed_hosts)
    if not urlparse(url).path.lower().endswith(".exe"):
        raise UpdateError("El manifiesto no contiene un instalador de Windows.")
    size = installer.get("size")
    if type(size) is not int or size <= 0 or size > MAX_INSTALLER_SIZE:
        raise UpdateError("El tamaño del instalador no es válido.")
    sha256 = installer.get("sha256")
    if not isinstance(sha256, str) or not SHA256_RE.fullmatch(sha256):
        raise UpdateError("El hash SHA-256 del instalador no es válido.")

    notes = payload.get("notes", {})
    if notes is None:
        notes = {}
    if not isinstance(notes, dict):
        raise UpdateError("Las notas de la actualización no son válidas.")
    notes_es = notes.get("es", "")
    notes_en = notes.get("en", "")
    if not isinstance(notes_es, str) or not isinstance(notes_en, str) or any(
        len(value) > 8000 for value in (notes_es, notes_en)
    ):
        raise UpdateError("Las notas de la actualización no son válidas.")
    published_at = payload.get("published_at", "")
    if not isinstance(published_at, str) or len(published_at) > 64:
        raise UpdateError("La fecha de la actualización no es válida.")
    return UpdateInfo(
        version=version,
        installer_url=url,
        installer_size=size,
        installer_sha256=sha256.lower(),
        notes_es=notes_es.strip(),
        notes_en=notes_en.strip(),
        published_at=published_at,
    )


def installer_path(info: UpdateInfo, updates_dir: str | Path | None = None) -> Path:
    root = Path(updates_dir) if updates_dir else UPDATES_DIR
    version_tuple(info.version)
    return root / info.version / f"KatLauncher-Setup-{info.version}.exe"


def download_update(
    info: UpdateInfo,
    channel: UpdateChannel,
    *,
    updates_dir: str | Path | None = None,
    session=requests,
    progress_cb=None,
    max_cb=None,
    cancel_cb=None,
) -> Path:
    destination = installer_path(info, updates_dir)
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists():
        try:
            verify_installer(destination, info)
            return destination
        except UpdateError:
            destination.unlink(missing_ok=True)

    file_descriptor = None
    partial = None
    downloaded = 0
    digest = hashlib.sha256()
    try:
        file_descriptor, partial_name = tempfile.mkstemp(
            prefix=".KatLauncher-", suffix=".part", dir=destination.parent
        )
        partial = Path(partial_name)
        if max_cb:
            max_cb(info.installer_size)
        response = _open_https(info.installer_url, channel, session=session)
        try:
            raw_length = response.headers.get("Content-Length")
            if raw_length:
                try:
                    announced_length = int(raw_length)
                except (TypeError, ValueError) as error:
                    raise UpdateError("El tamaño anunciado del instalador no es válido.") from error
                if announced_length != info.installer_size:
                    raise UpdateError("El tamaño anunciado del instalador no coincide.")
            with os.fdopen(file_descriptor, "wb") as output:
                file_descriptor = None
                for chunk in response.iter_content(chunk_size=256 * 1024):
                    if cancel_cb and cancel_cb():
                        raise UpdateCancelled("La descarga de la actualización fue cancelada.")
                    if not chunk:
                        continue
                    downloaded += len(chunk)
                    if downloaded > info.installer_size:
                        raise UpdateError("La descarga excedió el tamaño esperado.")
                    output.write(chunk)
                    digest.update(chunk)
                    if progress_cb:
                        progress_cb(downloaded)
                output.flush()
                os.fsync(output.fileno())
        except requests.RequestException as error:
            raise UpdateError(f"No se pudo descargar el instalador: {error}") from error
        finally:
            response.close()

        if downloaded != info.installer_size:
            raise UpdateError("El instalador descargado está incompleto.")
        if not hmac.compare_digest(digest.hexdigest(), info.installer_sha256):
            raise UpdateError("El hash SHA-256 del instalador no coincide.")
        os.replace(partial, destination)
        partial = None
        return destination
    finally:
        if file_descriptor is not None:
            os.close(file_descriptor)
        if partial is not None:
            partial.unlink(missing_ok=True)


def verify_installer(path: str | Path, info: UpdateInfo) -> Path:
    path = Path(path)
    expected_path = installer_path(info, path.parent.parent)
    if path.resolve() != expected_path.resolve() or path.suffix.lower() != ".exe":
        raise UpdateError("La ruta del instalador descargado no es válida.")
    try:
        if not path.is_file() or path.stat().st_size != info.installer_size:
            raise UpdateError("El tamaño del instalador descargado no coincide.")
        digest = hashlib.sha256()
        with path.open("rb") as source:
            for chunk in iter(lambda: source.read(1024 * 1024), b""):
                digest.update(chunk)
    except OSError as error:
        raise UpdateError(f"No se pudo verificar el instalador descargado: {error}") from error
    if not hmac.compare_digest(digest.hexdigest(), info.installer_sha256):
        raise UpdateError("El hash SHA-256 del instalador no coincide.")
    return path


def launch_update_installer(
    path: str | Path,
    info: UpdateInfo,
    *,
    language: str = "es",
    parent_pid: int | None = None,
    popen=subprocess.Popen,
    require_frozen: bool = True,
):
    path = verify_installer(path, info)
    if os.name != "nt":
        raise UpdateError("La instalación automática solo está disponible en Windows.")
    if require_frozen and not getattr(sys, "frozen", False):
        raise UpdateError("La instalación automática solo está disponible en la aplicación instalada.")
    language = "english" if language == "en" else "spanish"
    parent_pid = int(parent_pid or os.getpid())
    logs_dir = APP_DIR / "logs"
    try:
        logs_dir.mkdir(parents=True, exist_ok=True)
    except OSError as error:
        raise UpdateError(
            f"No se pudo preparar el registro de la actualización: {error}"
        ) from error
    log_path = logs_dir / f"update-{info.version}.log"
    command = [
        str(path),
        "/SP-",
        "/SILENT",
        "/CLOSEAPPLICATIONS",
        "/NOFORCECLOSEAPPLICATIONS",
        "/NORESTARTAPPLICATIONS",
        "/NORESTART",
        f"/LANG={language}",
        f"/WAITFORPID={parent_pid}",
        "/AUTOUPDATE=1",
        f"/LOG={log_path}",
    ]
    creationflags = getattr(subprocess, "DETACHED_PROCESS", 0) | getattr(
        subprocess, "CREATE_NEW_PROCESS_GROUP", 0
    )
    try:
        return popen(
            command,
            shell=False,
            close_fds=True,
            creationflags=creationflags,
        )
    except OSError as error:
        raise UpdateError(f"No se pudo iniciar el instalador de la actualización: {error}") from error


def should_check_automatically(
    *,
    state_file: str | Path | None = None,
    now: datetime | None = None,
) -> bool:
    state = _read_state(state_file)
    raw_value = state.get("last_check_utc", "")
    if not isinstance(raw_value, str) or not raw_value:
        return True
    try:
        previous = datetime.fromisoformat(raw_value.replace("Z", "+00:00"))
    except ValueError:
        return True
    if previous.tzinfo is None:
        previous = previous.replace(tzinfo=timezone.utc)
    current = now or datetime.now(timezone.utc)
    return current - previous.astimezone(timezone.utc) >= CHECK_INTERVAL


def record_successful_check(
    *,
    state_file: str | Path | None = None,
    now: datetime | None = None,
):
    path = Path(state_file) if state_file else UPDATE_STATE_FILE
    state = _read_state(path)
    current = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    state["schema"] = 1
    state["last_check_utc"] = current.isoformat().replace("+00:00", "Z")
    _write_state(path, state)


def _read_state(path: str | Path | None = None) -> dict:
    state_path = Path(path) if path else UPDATE_STATE_FILE
    if not state_path.is_file():
        return {}
    try:
        if state_path.stat().st_size > MAX_MANIFEST_SIZE:
            return {}
        payload = json.loads(state_path.read_text(encoding="utf-8"))
        return payload if isinstance(payload, dict) else {}
    except (OSError, UnicodeError, ValueError, json.JSONDecodeError):
        return {}


def _write_state(path: Path, payload: dict):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    os.replace(temporary, path)
