"""
Gestión de mods por perfil. Los mods son archivos .jar dentro de la carpeta
'mods' de cada instancia. Desactivar un mod simplemente le añade la
extensión '.disabled' (convención usada por Forge/Fabric/Quilt).
"""
from __future__ import annotations

import shutil
import os
import tempfile
from dataclasses import dataclass
from pathlib import Path


CONTENT_DIRECTORIES = {
    "mod": "mods",
    "resourcepack": "resourcepacks",
    "shader": "shaderpacks",
}
CONTENT_SUFFIXES = {
    "mod": ".jar",
    "resourcepack": ".zip",
    "shader": ".zip",
}


@dataclass
class ModInfo:
    filename: str
    path: str
    enabled: bool
    size_kb: float


def content_directory(game_dir: str, project_type: str) -> str:
    if project_type not in CONTENT_DIRECTORIES:
        raise ValueError(f"Tipo de contenido no compatible: {project_type}")
    directory = Path(game_dir) / CONTENT_DIRECTORIES[project_type]
    directory.mkdir(parents=True, exist_ok=True)
    return str(directory)


def list_content(content_dir: str, project_type: str = "mod") -> list[ModInfo]:
    if project_type not in CONTENT_SUFFIXES:
        raise ValueError(f"Tipo de contenido no compatible: {project_type}")
    suffix = CONTENT_SUFFIXES[project_type]
    directory = Path(content_dir)
    directory.mkdir(parents=True, exist_ok=True)
    mods = []
    for f in sorted(directory.iterdir()):
        lower_name = f.name.lower()
        if f.is_file() and (
            lower_name.endswith(suffix) or lower_name.endswith(suffix + ".disabled")
        ):
            enabled = lower_name.endswith(suffix)
            mods.append(ModInfo(
                filename=f.name,
                path=str(f),
                enabled=enabled,
                size_kb=round(f.stat().st_size / 1024, 1),
            ))
    return mods


def list_mods(mods_dir: str) -> list[ModInfo]:
    return list_content(mods_dir, "mod")


def add_content(content_dir: str, source_path: str,
                project_type: str = "mod") -> str:
    if project_type not in CONTENT_SUFFIXES:
        raise ValueError(f"Tipo de contenido no compatible: {project_type}")
    expected_suffix = CONTENT_SUFFIXES[project_type]
    src = Path(source_path)
    if not src.is_file() or src.suffix.lower() != expected_suffix:
        raise ValueError(f"Solo se permiten archivos {expected_suffix}")
    directory = Path(content_dir)
    directory.mkdir(parents=True, exist_ok=True)
    dest = directory / src.name
    if src.resolve() == dest.resolve():
        return str(dest)

    # Copia primero dentro del mismo volumen y publica al final. Un corte no
    # deja un ZIP/JAR parcial con apariencia de instalación válida.
    descriptor, partial_name = tempfile.mkstemp(
        prefix=".kat-local-", suffix=".part", dir=directory
    )
    os.close(descriptor)
    partial = Path(partial_name)
    try:
        shutil.copy2(src, partial)
        os.replace(partial, dest)
    finally:
        partial.unlink(missing_ok=True)
    return str(dest)


def add_mod(mods_dir: str, source_path: str) -> str:
    return add_content(mods_dir, source_path, "mod")


def remove_mod(mod_path: str):
    p = Path(mod_path)
    if p.exists():
        p.unlink()


def toggle_content(mod_path: str) -> str:
    """Activa/desactiva contenido renombrando su extensión."""
    p = Path(mod_path)
    lower_name = p.name.lower()
    if lower_name.endswith((".jar.disabled", ".zip.disabled")):
        new_path = p.with_name(p.name[:-len(".disabled")])
    elif lower_name.endswith((".jar", ".zip")):
        new_path = p.with_name(p.name + ".disabled")
    else:
        return str(p)
    p.rename(new_path)
    return str(new_path)


def toggle_mod(mod_path: str) -> str:
    """Compatibilidad para el administrador clásico de mods."""
    return toggle_content(mod_path)
