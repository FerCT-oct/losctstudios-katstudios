"""Cliente seguro y opcional para CurseForge usado por la biblioteca de contenido."""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import tempfile
import time
import sys
from pathlib import Path
from urllib.parse import urlparse

import requests

from .. import __version__
from .profile_manager import APP_DIR

API_BASE = "https://api.curseforge.com/v1"
MINECRAFT_GAME_ID = 432
CLASS_IDS = {"mod": 6, "resourcepack": 12, "shader": 6552}
LOADER_TYPES = {"forge": 1, "fabric": 4, "quilt": 5, "neoforge": 6}
SUFFIXES = {"mod": ".jar", "resourcepack": ".zip", "shader": ".zip"}
KEY_FILE = APP_DIR / "curseforge_api_key.txt"
MAX_DOWNLOAD_SIZE = (2 * 1024 * 1024 * 1024) - 1
MAX_DEPENDENCIES = 100


class CurseForgeError(RuntimeError):
    pass


def api_key() -> str:
    value = os.environ.get("KATLAUNCHER_CURSEFORGE_API_KEY", "").strip()
    if not value and KEY_FILE.is_file():
        try:
            value = KEY_FILE.read_text(encoding="utf-8").strip()
        except OSError:
            value = ""
    if not value:
        base = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parents[2]))
        config_path = base / "katlauncher" / "curseforge_config.json"
        if not config_path.is_file():
            config_path = Path(__file__).resolve().parents[1] / "curseforge_config.json"
        try:
            payload = json.loads(config_path.read_text(encoding="utf-8"))
            value = str(payload.get("api_key") or "").strip() if isinstance(payload, dict) else ""
        except (OSError, ValueError, TypeError):
            value = ""
    if not value:
        raise CurseForgeError(
            "CurseForge necesita una API key oficial del proyecto. Pulsa 'Configurar API key' para añadirla."
        )
    if len(value) > 512 or any(ord(char) < 33 or ord(char) > 126 for char in value):
        raise CurseForgeError("La API key de CurseForge no tiene un formato válido.")
    return value


def save_api_key(value: str) -> None:
    value = str(value or "").strip()
    if value:
        if len(value) > 512 or any(ord(char) < 33 or ord(char) > 126 for char in value):
            raise CurseForgeError("La API key de CurseForge no tiene un formato válido.")
        KEY_FILE.parent.mkdir(parents=True, exist_ok=True)
        temp = KEY_FILE.with_suffix(".tmp")
        temp.write_text(value, encoding="utf-8")
        temp.replace(KEY_FILE)
        try:
            KEY_FILE.chmod(0o600)
        except OSError:
            pass
    else:
        KEY_FILE.unlink(missing_ok=True)


def _request(path: str, *, params: dict | None = None) -> object:
    key = api_key()
    last_error = None
    for attempt in range(3):
        try:
            response = requests.get(
                f"{API_BASE}{path}", params=params,
                headers={
                    "Accept": "application/json", "x-api-key": key,
                    "User-Agent": f"KatLauncher/{__version__}",
                }, timeout=25,
            )
            if response.status_code in (401, 403):
                raise CurseForgeError("CurseForge rechazó la API key configurada.")
            if response.status_code == 429 or response.status_code >= 500:
                last_error = CurseForgeError(f"CurseForge respondió {response.status_code}.")
                response.close()
                if attempt < 2:
                    time.sleep(0.5 * (attempt + 1))
                    continue
            response.raise_for_status()
            payload = response.json()
            if not isinstance(payload, dict) or "data" not in payload:
                raise CurseForgeError("CurseForge devolvió una respuesta no válida.")
            return payload["data"]
        except CurseForgeError:
            raise
        except (requests.RequestException, ValueError) as error:
            last_error = error
            if attempt < 2:
                time.sleep(0.5 * (attempt + 1))
    raise CurseForgeError(f"No se pudo consultar CurseForge: {last_error}") from last_error


def search_projects(query: str, project_type: str, loader: str,
                    game_version: str, limit: int = 20) -> list[dict]:
    if project_type not in CLASS_IDS:
        raise CurseForgeError("Este tipo de contenido no es compatible con CurseForge.")
    params = {
        "gameId": MINECRAFT_GAME_ID, "classId": CLASS_IDS[project_type],
        "searchFilter": str(query).strip(), "gameVersion": game_version,
        "pageSize": max(1, min(int(limit), 50)), "sortField": 2,
        "sortOrder": "desc",
    }
    if project_type == "mod" and loader in LOADER_TYPES:
        params["modLoaderType"] = LOADER_TYPES[loader]
    data = _request("/mods/search", params=params)
    if not isinstance(data, list) or any(not isinstance(item, dict) for item in data):
        raise CurseForgeError("CurseForge devolvió resultados no válidos.")
    return [_normalise_project(item, project_type) for item in data]


def _normalise_project(item: dict, project_type: str) -> dict:
    authors = item.get("authors") if isinstance(item.get("authors"), list) else []
    categories = item.get("categories") if isinstance(item.get("categories"), list) else []
    logo = item.get("logo") if isinstance(item.get("logo"), dict) else {}
    links = item.get("links") if isinstance(item.get("links"), dict) else {}
    return {
        "provider": "curseforge", "project_id": item.get("id"),
        "slug": str(item.get("slug") or ""), "title": str(item.get("name") or "?"),
        "author": ", ".join(str(x.get("name")) for x in authors if x.get("name")),
        "description": str(item.get("summary") or ""),
        "downloads": int(item.get("downloadCount") or 0), "follows": 0,
        "categories": [str(x.get("name")) for x in categories if x.get("name")],
        "versions": [], "date_modified": str(item.get("dateModified") or ""),
        "icon_url": str(logo.get("thumbnailUrl") or logo.get("url") or ""),
        "website_url": str(links.get("websiteUrl") or ""),
        "project_type": project_type,
    }


def fetch_icon(url: str) -> bytes:
    _validate_download_url(url)
    try:
        response = requests.get(url, timeout=20, allow_redirects=False)
        response.raise_for_status()
    except requests.RequestException as error:
        raise CurseForgeError(f"No se pudo cargar la carátula: {error}") from error
    content = response.content
    if len(content) > 2 * 1024 * 1024 or not (
        content.startswith(b"\x89PNG\r\n\x1a\n") or content.startswith(b"\xff\xd8\xff")
        or content.startswith(b"RIFF") and content[8:12] == b"WEBP"
    ):
        raise CurseForgeError("CurseForge devolvió una carátula no válida.")
    return content


def _get_files(mod_id: int, loader: str, game_version: str) -> list[dict]:
    params = {"gameVersion": game_version, "pageSize": 50}
    if loader in LOADER_TYPES:
        params["modLoaderType"] = LOADER_TYPES[loader]
    data = _request(f"/mods/{int(mod_id)}/files", params=params)
    if not isinstance(data, list) or any(not isinstance(item, dict) for item in data):
        raise CurseForgeError("CurseForge devolvió archivos no válidos.")
    return sorted(data, key=lambda item: str(item.get("fileDate") or ""), reverse=True)


def _select_file(mod_id: int, project_type: str, loader: str, game_version: str) -> dict:
    suffix = SUFFIXES[project_type]
    for item in _get_files(mod_id, loader, game_version):
        if item.get("isAvailable", True) and str(item.get("fileName") or "").lower().endswith(suffix):
            return item
    raise CurseForgeError("No existe un archivo compatible con este loader y versión.")


def _safe_filename(value: str, suffix: str) -> str:
    value = str(value or "")
    if not value or Path(value).name != value or len(value) > 240 \
            or not value.lower().endswith(suffix) or value.endswith((".", " ")) \
            or any(char in '<>:"/\\|?*' or ord(char) < 32 for char in value):
        raise CurseForgeError("CurseForge devolvió un nombre de archivo no seguro.")
    return value


def _validate_download_url(url: str) -> str:
    try:
        parsed = urlparse(str(url))
        host = (parsed.hostname or "").lower()
    except ValueError as error:
        raise CurseForgeError("CurseForge devolvió una URL no segura.") from error
    if parsed.scheme != "https" or not host.endswith(".forgecdn.net") \
            or parsed.port not in (None, 443) or parsed.username or parsed.password:
        raise CurseForgeError("CurseForge devolvió una URL no segura.")
    return str(url)


def _download_url(mod_id: int, file: dict) -> str:
    url = str(file.get("downloadUrl") or "")
    if not url:
        value = _request(f"/mods/{int(mod_id)}/files/{int(file['id'])}/download-url")
        url = str(value or "")
    if not url:
        raise CurseForgeError(
            "El autor no permite descargar este archivo desde clientes de terceros."
        )
    return _validate_download_url(url)


def _download(mod_id: int, file: dict, destination: Path, suffix: str,
              cancel_cb=None) -> None:
    url = _download_url(mod_id, file)
    expected = int(file.get("fileLength") or 0)
    if expected < 0 or expected > MAX_DOWNLOAD_SIZE:
        raise CurseForgeError("El archivo excede el tamaño permitido.")
    hashes = file.get("hashes") if isinstance(file.get("hashes"), list) else []
    sha1_expected = next((str(x.get("value", "")).lower() for x in hashes
                          if isinstance(x, dict) and x.get("algo") == 1), "")
    digest = hashlib.sha1()
    try:
        response = requests.get(url, stream=True, timeout=(15, 90), allow_redirects=False)
        response.raise_for_status()
        total = 0
        with destination.open("wb") as handle:
            for chunk in response.iter_content(1024 * 1024):
                if cancel_cb and cancel_cb():
                    raise CurseForgeError("La descarga fue cancelada.")
                if not chunk:
                    continue
                total += len(chunk)
                if total > MAX_DOWNLOAD_SIZE:
                    raise CurseForgeError("El archivo excede el tamaño permitido.")
                handle.write(chunk)
                digest.update(chunk)
    except requests.RequestException as error:
        raise CurseForgeError(f"No se pudo descargar el archivo: {error}") from error
    if expected and total != expected:
        raise CurseForgeError("La descarga quedó incompleta.")
    if sha1_expected and digest.hexdigest().lower() != sha1_expected:
        raise CurseForgeError("La descarga no coincide con el hash publicado.")


def install_content_latest(mod_id: int, project_type: str, loader: str,
                           game_version: str, destination_dir: str,
                           status_cb=None, cancel_cb=None) -> dict:
    if project_type not in SUFFIXES:
        raise CurseForgeError("Tipo de contenido no compatible.")
    root = (int(mod_id), _select_file(int(mod_id), project_type, loader, game_version), project_type)
    queue = [root]
    selected: dict[int, tuple[dict, str]] = {}
    while queue:
        current_id, file, kind = queue.pop(0)
        if current_id in selected:
            continue
        selected[current_id] = (file, kind)
        if len(selected) > MAX_DEPENDENCIES:
            raise CurseForgeError("El árbol de dependencias es demasiado grande.")
        if kind != "mod":
            continue
        dependencies = file.get("dependencies") if isinstance(file.get("dependencies"), list) else []
        for dependency in dependencies:
            if isinstance(dependency, dict) and dependency.get("relationType") == 3:
                dep_id = int(dependency.get("modId") or 0)
                if dep_id and dep_id not in selected:
                    queue.append((dep_id, _select_file(dep_id, "mod", loader, game_version), "mod"))

    destination = Path(destination_dir)
    destination.mkdir(parents=True, exist_ok=True)
    staging = Path(tempfile.mkdtemp(prefix=".kat-cf-", dir=destination))
    published = []
    backups = []
    try:
        staged = []
        for current_id, (file, kind) in selected.items():
            filename = _safe_filename(file.get("fileName"), SUFFIXES[kind])
            if status_cb:
                status_cb(f"Descargando {filename} desde CurseForge...")
            temporary = staging / filename
            _download(current_id, file, temporary, SUFFIXES[kind], cancel_cb)
            staged.append((current_id, temporary, destination / filename))
        if len({str(target).casefold() for _, _, target in staged}) != len(staged):
            raise CurseForgeError("Dos archivos intentaron usar el mismo nombre.")
        for index, (_, temporary, target) in enumerate(staged):
            if target.exists():
                backup = staging / f"backup-{index}-{target.name}"
                os.replace(target, backup)
                backups.append((backup, target))
            os.replace(temporary, target)
            published.append(target)
        primary_target = next(target for item_id, _, target in staged if item_id == int(mod_id))
        return {
            "primary_path": str(primary_target),
            "dependencies": [str(target) for item_id, _, target in staged if item_id != int(mod_id)],
            "optional": [], "incompatible": [], "provider": "curseforge",
        }
    except Exception:
        for target in published:
            target.unlink(missing_ok=True)
        for backup, original in reversed(backups):
            if backup.exists():
                os.replace(backup, original)
        raise
    finally:
        shutil.rmtree(staging, ignore_errors=True)
