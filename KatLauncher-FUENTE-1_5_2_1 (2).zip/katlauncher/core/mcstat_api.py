"""Cliente integrado para la biblioteca pública de skins de MCStat."""
from __future__ import annotations

import json
import os
import re
import time
from pathlib import Path
from urllib.parse import urlparse

import requests

from .. import __version__
from .profile_manager import APP_DIR

API_BASE = "https://mcstat.org/api/v1"
BUNDLED_API_KEY = "mcs_O8WSTHvkUfhZ1YerdXjkXlKUUF3LlNIif3bu"
CACHE_FILE = APP_DIR / "cache" / "mcstat_skins.json"
CAPE_CACHE_FILE = APP_DIR / "cache" / "mcstat_capes.json"
MAX_SKIN_BYTES = 2 * 1024 * 1024
PNG_SIGNATURE = b"\x89PNG\r\n\x1a\n"


class McStatError(RuntimeError):
    pass


def api_key() -> str:
    return BUNDLED_API_KEY


def list_skins(
    search: str = "", *, page: int = 1, model: str = "",
    session: requests.Session | None = None,
) -> dict:
    search = str(search or "").strip()[:80]
    model = str(model or "").strip().lower()
    if model not in ("", "classic", "slim"):
        raise McStatError("El modelo debe ser classic o slim.")
    params = {"page": max(1, int(page)), "limit": 24, "sort": "popular"}
    if search:
        params["search"] = search
    if model:
        params["model"] = model
    client = session or requests.Session()
    try:
        response = client.get(
            f"{API_BASE}/skins",
            params=params,
            headers={
                "Accept": "application/json",
                "X-API-Key": api_key(),
                "User-Agent": f"KatLauncher/{__version__}",
            },
            timeout=20,
        )
        if response.status_code in (401, 403):
            raise McStatError("MCStat rechazó la API key configurada.")
        if response.status_code == 429:
            raise McStatError("MCStat alcanzó su límite temporal de solicitudes.")
        response.raise_for_status()
        payload = response.json()
        data = payload.get("data") if isinstance(payload, dict) else None
        if not isinstance(data, dict) or not isinstance(data.get("skins"), list):
            raise McStatError("MCStat devolvió una respuesta no válida.")
        result = {
            "skins": [_normalize_skin(item) for item in data["skins"]
                      if isinstance(item, dict)],
            "pagination": data.get("pagination") or {},
            "cached": False,
            "query": {"search": search, "page": params["page"], "model": model},
        }
        _write_cache(result)
        return result
    except McStatError:
        cached = _read_cache(search, model)
        if cached is not None:
            cached["cached"] = True
            return cached
        raise
    except (requests.RequestException, ValueError, TypeError) as error:
        cached = _read_cache(search, model)
        if cached is not None:
            cached["cached"] = True
            return cached
        raise McStatError(f"No se pudo consultar MCStat: {error}") from error


def list_capes(
    search: str = "", *, page: int = 1,
    session: requests.Session | None = None,
) -> dict:
    search = str(search or "").strip()[:80]
    params = {"page": max(1, int(page)), "limit": 24, "sort": "popular"}
    if search:
        params["search"] = search
    client = session or requests.Session()
    try:
        response = client.get(
            f"{API_BASE}/capes",
            params=params,
            headers={
                "Accept": "application/json",
                "X-API-Key": api_key(),
                "User-Agent": f"KatLauncher/{__version__}",
            },
            timeout=20,
        )
        if response.status_code in (401, 403):
            raise McStatError("MCStat rechazó la API key configurada.")
        if response.status_code == 429:
            raise McStatError("MCStat alcanzó su límite temporal de solicitudes.")
        response.raise_for_status()
        payload = response.json()
        data = payload.get("data") if isinstance(payload, dict) else None
        if not isinstance(data, dict) or not isinstance(data.get("capes"), list):
            raise McStatError("MCStat devolvió una respuesta no válida.")
        result = {
            "capes": [_normalize_cape(item) for item in data["capes"]
                      if isinstance(item, dict)],
            "pagination": data.get("pagination") or {},
            "cached": False,
            "query": {"search": search, "page": params["page"], "model": ""},
        }
        _write_cache(result, CAPE_CACHE_FILE)
        return result
    except McStatError:
        cached = _read_cache(
            search, "", cache_file=CAPE_CACHE_FILE, collection="capes"
        )
        if cached is not None:
            cached["cached"] = True
            return cached
        raise
    except (requests.RequestException, ValueError, TypeError) as error:
        cached = _read_cache(
            search, "", cache_file=CAPE_CACHE_FILE, collection="capes"
        )
        if cached is not None:
            cached["cached"] = True
            return cached
        raise McStatError(f"No se pudo consultar MCStat: {error}") from error


def download_skin(
    item: dict, skins_dir: str, *, session: requests.Session | None = None,
) -> str:
    payload = fetch_skin_data(item, session=session)
    name = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(item.get("name") or "mcstat_skin"))
    name = name.strip("._")[:80] or "mcstat_skin"
    directory = Path(skins_dir)
    directory.mkdir(parents=True, exist_ok=True)
    destination = directory / f"{name}.png"
    counter = 2
    while destination.exists():
        destination = directory / f"{name}_{counter}.png"
        counter += 1
    temporary = destination.with_suffix(".png.tmp")
    try:
        temporary.write_bytes(payload)
        os.replace(temporary, destination)
    finally:
        temporary.unlink(missing_ok=True)
    return str(destination)


def fetch_skin_data(
    item: dict, *, session: requests.Session | None = None,
) -> bytes:
    """Descarga y valida una skin para mostrarla sin instalarla."""
    url = str(item.get("png_url") or "")
    parsed = urlparse(url)
    host = (parsed.hostname or "").lower()
    if parsed.scheme != "https" or not (
        host == "mcstat.org" or host.endswith(".mcstat.org")
    ):
        raise McStatError("MCStat devolvió una dirección de descarga no segura.")
    client = session or requests.Session()
    try:
        response = client.get(
            url, headers={"User-Agent": f"KatLauncher/{__version__}"}, timeout=20,
        )
        response.raise_for_status()
        payload = response.content
    except requests.RequestException as error:
        raise McStatError(f"No se pudo descargar la skin: {error}") from error
    if not payload.startswith(PNG_SIGNATURE) or not 1 <= len(payload) <= MAX_SKIN_BYTES:
        raise McStatError("La descarga de MCStat no es una skin PNG válida.")
    return payload


def _normalize_skin(item: dict) -> dict:
    return {
        "id": str(item.get("id") or "")[:120],
        "name": str(item.get("name") or item.get("slug") or "Skin")[:120],
        "model": str(item.get("model") or "classic").lower(),
        "tags": [str(tag)[:40] for tag in (item.get("tags") or [])[:12]],
        "png_url": str(item.get("pngPath") or item.get("png_url") or "")[:1000],
        "downloads": int(item.get("downloadCount") or 0),
        "likes": int(item.get("likeCount") or 0),
    }


def _normalize_cape(item: dict) -> dict:
    return {
        "id": str(item.get("id") or "")[:120],
        "name": str(item.get("name") or item.get("slug") or "Capa")[:120],
        "model": "cape",
        "tags": [str(tag)[:40] for tag in (item.get("tags") or [])[:12]],
        "png_url": str(item.get("pngPath") or item.get("png_url") or "")[:1000],
        "downloads": int(item.get("downloadCount") or 0),
        "likes": int(item.get("likeCount") or 0),
    }


def _write_cache(payload: dict, cache_file: Path | None = None) -> None:
    cache_file = CACHE_FILE if cache_file is None else cache_file
    cache_file.parent.mkdir(parents=True, exist_ok=True)
    stored = dict(payload)
    stored["saved_at"] = int(time.time())
    temporary = cache_file.with_suffix(".tmp")
    try:
        temporary.write_text(
            json.dumps(stored, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        os.replace(temporary, cache_file)
    finally:
        temporary.unlink(missing_ok=True)


def _read_cache(
    search: str, model: str, *, cache_file: Path | None = None,
    collection: str = "skins",
) -> dict | None:
    cache_file = CACHE_FILE if cache_file is None else cache_file
    try:
        payload = json.loads(cache_file.read_text(encoding="utf-8"))
        query = payload.get("query") or {}
        if str(query.get("search") or "") != search \
                or str(query.get("model") or "") != model:
            return None
        if not isinstance(payload.get(collection), list):
            return None
        return payload
    except (OSError, ValueError, TypeError, json.JSONDecodeError):
        return None
