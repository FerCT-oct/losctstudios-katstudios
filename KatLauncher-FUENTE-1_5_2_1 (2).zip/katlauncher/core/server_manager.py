"""Favoritos y ping del protocolo de estado de servidores Minecraft Java."""
from __future__ import annotations

import json
import os
import re
import socket
import struct
import time
import uuid
from dataclasses import asdict, dataclass
from pathlib import Path

from .profile_manager import APP_DIR


SERVERS_FILE = APP_DIR / "servers.json"
MAX_STATUS_PACKET = 1024 * 1024
HOST_RE = re.compile(r"^[A-Za-z0-9._:-]+$")


@dataclass(frozen=True)
class FavoriteServer:
    id: str
    name: str
    host: str
    port: int = 25565


@dataclass(frozen=True)
class ServerStatus:
    online: bool
    latency_ms: int = 0
    version: str = ""
    protocol: int = 0
    players_online: int = 0
    players_max: int = 0
    description: str = ""
    error: str = ""


def parse_server_address(value: str, default_port: int = 25565) -> tuple[str, int]:
    value = str(value or "").strip()
    if value.startswith("["):
        close = value.find("]")
        if close < 0:
            raise ValueError("Dirección IPv6 no válida")
        host = value[1:close]
        suffix = value[close + 1:]
        port = int(suffix[1:]) if suffix.startswith(":") and suffix[1:] else default_port
    elif value.count(":") == 1:
        host, raw_port = value.rsplit(":", 1)
        port = int(raw_port) if raw_port else default_port
    else:
        host, port = value, default_port
    host = host.strip().rstrip(".")
    if not host or len(host) > 253 or not HOST_RE.fullmatch(host):
        raise ValueError("Host de servidor no válido")
    if not 1 <= int(port) <= 65535:
        raise ValueError("Puerto de servidor no válido")
    return host, int(port)


class ServerManager:
    def __init__(self, servers_file: str | Path | None = None):
        self.servers_file = Path(servers_file) if servers_file else SERVERS_FILE
        self._servers: dict[str, FavoriteServer] = {}
        self.load()

    def load(self):
        self._servers = {}
        try:
            raw = json.loads(self.servers_file.read_text(encoding="utf-8"))
            records = raw.get("servers", []) if isinstance(raw, dict) else []
            for value in records[:500]:
                try:
                    if not isinstance(value, dict):
                        continue
                    host, port = parse_server_address(
                        str(value.get("host", "")), int(value.get("port", 25565))
                    )
                    server_id = str(value.get("id") or "")
                    name = str(value.get("name") or host).strip()[:80]
                    if server_id and name and server_id not in self._servers:
                        self._servers[server_id] = FavoriteServer(server_id, name, host, port)
                except (ValueError, TypeError):
                    continue
        except (OSError, ValueError, TypeError, json.JSONDecodeError):
            self._servers = {}

    def save(self):
        self.servers_file.parent.mkdir(parents=True, exist_ok=True)
        temp = self.servers_file.with_suffix(self.servers_file.suffix + ".tmp")
        temp.write_text(json.dumps(
            {"schema_version": 1, "servers": [asdict(item) for item in self.list()]},
            ensure_ascii=False, indent=2,
        ), encoding="utf-8")
        os.replace(temp, self.servers_file)

    def list(self) -> list[FavoriteServer]:
        return list(self._servers.values())

    def add(self, name: str, address: str, port: int | None = None) -> FavoriteServer:
        host, parsed_port = parse_server_address(address, port or 25565)
        if port is not None and ":" not in address:
            parsed_port = int(port)
            if not 1 <= parsed_port <= 65535:
                raise ValueError("Puerto de servidor no válido")
        label = str(name or host).strip()
        if not label or len(label) > 80:
            raise ValueError("Nombre de servidor no válido")
        duplicate = next(
            (item for item in self._servers.values()
             if item.host.casefold() == host.casefold() and item.port == parsed_port), None
        )
        if duplicate:
            return duplicate
        item = FavoriteServer(uuid.uuid4().hex[:12], label, host, parsed_port)
        self._servers[item.id] = item
        try:
            self.save()
        except Exception:
            self._servers.pop(item.id, None)
            raise
        return item

    def remove(self, server_id: str):
        removed = self._servers.pop(server_id, None)
        if removed is None:
            return
        try:
            self.save()
        except Exception:
            self._servers[removed.id] = removed
            raise


def ping_server(host: str, port: int = 25565, timeout: float = 4.0) -> ServerStatus:
    host, port = parse_server_address(host, port)
    started = time.perf_counter()
    try:
        with socket.create_connection((host, port), timeout=timeout) as connection:
            connection.settimeout(timeout)
            host_bytes = host.encode("utf-8")
            handshake = (
                _pack_varint(0) + _pack_varint(47) + _pack_varint(len(host_bytes))
                + host_bytes + struct.pack(">H", port) + _pack_varint(1)
            )
            connection.sendall(_pack_varint(len(handshake)) + handshake)
            request = _pack_varint(0)
            connection.sendall(_pack_varint(len(request)) + request)
            packet_length = _read_varint(connection)
            if packet_length <= 0 or packet_length > MAX_STATUS_PACKET:
                raise ValueError("Respuesta de servidor demasiado grande")
            packet = _recv_exact(connection, packet_length)
            packet_id, offset = _decode_varint(packet, 0)
            if packet_id != 0:
                raise ValueError("Respuesta de estado no compatible")
            json_length, offset = _decode_varint(packet, offset)
            if json_length < 2 or json_length > MAX_STATUS_PACKET or offset + json_length > len(packet):
                raise ValueError("Respuesta de estado incompleta")
            payload = json.loads(packet[offset:offset + json_length].decode("utf-8"))
            version = payload.get("version") if isinstance(payload.get("version"), dict) else {}
            players = payload.get("players") if isinstance(payload.get("players"), dict) else {}
            return ServerStatus(
                online=True,
                latency_ms=max(0, round((time.perf_counter() - started) * 1000)),
                version=str(version.get("name") or "")[:100],
                protocol=int(version.get("protocol") or 0),
                players_online=max(0, int(players.get("online") or 0)),
                players_max=max(0, int(players.get("max") or 0)),
                description=_description_text(payload.get("description"))[:400],
            )
    except (
        OSError, ValueError, TypeError, UnicodeError, json.JSONDecodeError,
        RecursionError,
    ) as error:
        return ServerStatus(False, error=str(error)[:240] or "Sin respuesta")


def _pack_varint(value: int) -> bytes:
    value &= 0xFFFFFFFF
    result = bytearray()
    while True:
        byte = value & 0x7F
        value >>= 7
        result.append(byte | (0x80 if value else 0))
        if not value:
            return bytes(result)


def _read_varint(connection) -> int:
    result = 0
    for position in range(5):
        current = _recv_exact(connection, 1)[0]
        result |= (current & 0x7F) << (7 * position)
        if not current & 0x80:
            return result
    raise ValueError("VarInt demasiado grande")


def _decode_varint(data: bytes, offset: int) -> tuple[int, int]:
    result = 0
    for position in range(5):
        if offset >= len(data):
            raise ValueError("VarInt incompleto")
        current = data[offset]
        offset += 1
        result |= (current & 0x7F) << (7 * position)
        if not current & 0x80:
            return result, offset
    raise ValueError("VarInt demasiado grande")


def _recv_exact(connection, length: int) -> bytes:
    chunks = bytearray()
    while len(chunks) < length:
        chunk = connection.recv(length - len(chunks))
        if not chunk:
            raise OSError("El servidor cerró la conexión")
        chunks.extend(chunk)
    return bytes(chunks)


def _description_text(value) -> str:
    """Aplana componentes de texto con límites frente a MOTD hostiles."""
    stack = [value]
    parts: list[str] = []
    visited = 0
    while stack and visited < 256 and sum(map(len, parts)) < 800:
        current = stack.pop()
        visited += 1
        if isinstance(current, str):
            parts.append(current[:400])
            continue
        if not isinstance(current, dict):
            continue
        text = current.get("text")
        if isinstance(text, (str, int, float)):
            parts.append(str(text)[:400])
        extra = current.get("extra")
        if isinstance(extra, list):
            stack.extend(reversed(extra[:128]))
    return "".join(parts).strip()[:800]
