"""
Cliente ligero para la API pública de Modrinth (https://modrinth.com).
Se usa para:
  - Buscar mods compatibles con el loader/versión de un perfil.
  - Descargar e instalar el archivo .jar de un mod en la carpeta 'mods' del perfil.
  - Auto-instalar 'CustomSkinLoader', el mod que permite aplicar skins
    personalizadas en modo offline.
"""
from __future__ import annotations

import json
import hashlib
import os
import shutil
import tempfile
import time
from pathlib import Path
from typing import Optional
from urllib.parse import urljoin, urlparse

import requests

from .. import __version__

API_BASE = "https://api.modrinth.com/v2"
HEADERS = {"User-Agent": f"KatLauncher/{__version__} (desktop offline launcher)"}

CUSTOMSKINLOADER_SLUG = "customskinloader"
SUPPORTED_PROJECT_TYPES = {"mod", "resourcepack", "shader"}
PROJECT_FILE_SUFFIXES = {
    "mod": ".jar",
    "resourcepack": ".zip",
    "shader": ".zip",
}
MAX_DEPENDENCY_GRAPH_SIZE = 200
ALLOWED_DOWNLOAD_HOSTS = {
    "cdn.modrinth.com",
    "github.com",
    "raw.githubusercontent.com",
    "gitlab.com",
}
ALLOWED_REDIRECT_HOSTS = ALLOWED_DOWNLOAD_HOSTS | {
    "objects.githubusercontent.com",
    "release-assets.githubusercontent.com",
}
# Los callbacks de progreso terminan en Signal(int) / QProgressBar (entero
# firmado de 32 bits), por lo que este límite también protege esa interfaz.
MAX_DOWNLOAD_SIZE = (2 * 1024 * 1024 * 1024) - 1
WINDOWS_INVALID_CHARS = set('<>:"|?*')
WINDOWS_RESERVED = {
    "CON", "PRN", "AUX", "NUL",
    *(f"COM{i}" for i in range(1, 10)),
    *(f"LPT{i}" for i in range(1, 10)),
}


class ModrinthError(RuntimeError):
    pass


def _request_json(url: str, *, params: Optional[dict] = None,
                  method: str = "get", body: Optional[dict] = None):
    last_error = None
    for attempt in range(3):
        try:
            response = requests.request(
                method, url, params=params, json=body, headers=HEADERS, timeout=20
            )
            if response.status_code == 429 or 500 <= response.status_code < 600:
                wait = min(float(response.headers.get("Retry-After", 1)), 5.0)
                response.close()
                if attempt < 2:
                    time.sleep(max(wait, 0.1))
                    continue
            response.raise_for_status()
            return response.json()
        except (requests.RequestException, ValueError) as error:
            last_error = error
            if attempt < 2:
                time.sleep(0.4 * (attempt + 1))
    raise ModrinthError(f"No se pudo consultar Modrinth: {last_error}") from last_error


def update_mods(mods_dir: str, loader: str, game_version: str,
                status_cb=None) -> dict:
    """Actualiza en lote mods reconocidos por Modrinth y publica todo atómicamente."""
    directory = Path(mods_dir)
    directory.mkdir(parents=True, exist_ok=True)
    candidates = [p for p in directory.iterdir() if p.is_file() and (
        p.name.lower().endswith(".jar") or p.name.lower().endswith(".jar.disabled")
    )]
    if not candidates:
        return {"updated": 0, "current": 0, "unknown": 0, "files": []}

    hashes = {}
    for index, path in enumerate(candidates, 1):
        if status_cb:
            status_cb(f"Identificando mods ({index}/{len(candidates)})...")
        digest = hashlib.sha1()
        with path.open("rb") as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(chunk)
        hashes[digest.hexdigest()] = path

    result = _request_json(
        f"{API_BASE}/version_files/update", method="post",
        body={
            "hashes": list(hashes), "algorithm": "sha1",
            "loaders": [loader], "game_versions": [game_version],
        },
    )
    if not isinstance(result, dict):
        raise ModrinthError("Modrinth devolvió una respuesta de actualización no válida.")

    staging = Path(tempfile.mkdtemp(prefix=".kat-update-", dir=directory))
    replacements = []
    current = 0
    try:
        for digest, source in hashes.items():
            version = result.get(digest)
            if not version:
                continue
            file = _pick_primary_file(version)
            if not file:
                continue
            new_hash = str(file.get("hashes", {}).get("sha1", "")).lower()
            if new_hash == digest:
                current += 1
                continue
            filename = _validate_filename(str(file.get("filename", "")), ".jar")
            disabled = source.name.lower().endswith(".disabled")
            target_name = filename + (".disabled" if disabled else "")
            if status_cb:
                status_cb(f"Descargando {filename}...")
            staged = staging / target_name
            download_file(file, staged)
            replacements.append((source, staged, directory / target_name))

        targets = [destination for _, _, destination in replacements]
        if len({str(path).casefold() for path in targets}) != len(targets):
            raise ModrinthError("Dos actualizaciones intentaron usar el mismo nombre de archivo.")
        backups = []
        published = []
        try:
            for index, (source, staged, destination) in enumerate(replacements):
                backup = staging / f"backup-{index}-{source.name}"
                os.replace(source, backup)
                backups.append((backup, source))
                if destination.exists() and destination != source:
                    displaced = staging / f"displaced-{index}-{destination.name}"
                    os.replace(destination, displaced)
                    backups.append((displaced, destination))
                os.replace(staged, destination)
                published.append(destination)
        except Exception:
            for destination in reversed(published):
                destination.unlink(missing_ok=True)
            for backup, original in reversed(backups):
                if backup.exists():
                    os.replace(backup, original)
            raise
        return {
            "updated": len(replacements), "current": current,
            "unknown": len(hashes) - len(result),
            "files": [destination.name for _, _, destination in replacements],
        }
    finally:
        shutil.rmtree(staging, ignore_errors=True)


def search_projects(query: str, project_type: str = "mod",
                    loader: Optional[str] = None,
                    game_version: Optional[str] = None, limit: int = 20,
                    offset: int = 0, index: str = "relevance") -> list[dict]:
    """Busca contenido instalable en Modrinth con filtros seguros.

    Los tipos admitidos corresponden a los tipos públicos de la API que
    KatLauncher puede colocar en una carpeta global de la instancia. Los
    datapacks no se incluyen porque deben instalarse dentro de un mundo
    concreto, nunca en una carpeta global inventada por el launcher.
    """
    project_type = str(project_type or "").lower()
    if project_type not in SUPPORTED_PROJECT_TYPES:
        raise ModrinthError(f"Tipo de contenido no compatible: {project_type}.")
    if type(limit) is not int or not 1 <= limit <= 100:
        raise ModrinthError("El límite de resultados de Modrinth no es válido.")
    if type(offset) is not int or offset < 0:
        raise ModrinthError("El desplazamiento de resultados no es válido.")
    if index not in {"relevance", "downloads", "follows", "newest", "updated"}:
        raise ModrinthError("El orden de resultados de Modrinth no es válido.")

    facets = [[f"project_type:{project_type}"]]
    if project_type == "mod" and loader and loader != "vanilla":
        facets.append([f"categories:{loader}"])
    if game_version:
        facets.append([f"versions:{game_version}"])

    params = {
        "query": query, "limit": limit, "offset": offset, "index": index,
        "facets": json.dumps(facets),
    }
    return _search_hits(_request_json(f"{API_BASE}/search", params=params))


def search_mods(query: str, loader: Optional[str] = None,
                 game_version: Optional[str] = None, limit: int = 20) -> list[dict]:
    """Compatibilidad: busca exclusivamente mods."""
    return search_projects(query, "mod", loader, game_version, limit)


def search_modpacks(query: str, limit: int = 20) -> list[dict]:
    facets = [["project_type:modpack"]]
    params = {"query": query, "limit": limit, "facets": json.dumps(facets)}
    return _search_hits(_request_json(f"{API_BASE}/search", params=params))


def get_versions(project_id_or_slug: str, loader: Optional[str] = None,
                  game_version: Optional[str] = None) -> list[dict]:
    """Devuelve las versiones (archivos descargables) de un proyecto de Modrinth,
    filtradas por loader/versión de Minecraft cuando se indican. La API ya las
    devuelve ordenadas de más reciente a más antigua."""
    params = {}
    if loader and loader != "vanilla":
        params["loaders"] = json.dumps([loader])
    if game_version:
        params["game_versions"] = json.dumps([game_version])

    params["include_changelog"] = "false"
    result = _request_json(
        f"{API_BASE}/project/{project_id_or_slug}/version", params=params
    )
    if not isinstance(result, list) or any(not isinstance(item, dict) for item in result):
        raise ModrinthError("Modrinth devolvió una lista de versiones no válida.")
    for item in result:
        files = item.get("files", [])
        if not isinstance(files, list) or any(not isinstance(file, dict) for file in files):
            raise ModrinthError("Modrinth devolvió una lista de versiones no válida.")
    return result


def get_version(version_id: str) -> dict:
    result = _request_json(f"{API_BASE}/version/{version_id}")
    if not isinstance(result, dict):
        raise ModrinthError("Modrinth devolvió una versión no válida.")
    return result


def _search_hits(result) -> list[dict]:
    if not isinstance(result, dict):
        raise ModrinthError("Modrinth devolvió una respuesta de búsqueda no válida.")
    hits = result.get("hits", [])
    if not isinstance(hits, list) or any(not isinstance(item, dict) for item in hits):
        raise ModrinthError("Modrinth devolvió una respuesta de búsqueda no válida.")
    return hits


def _pick_primary_file(version: dict) -> Optional[dict]:
    for f in version.get("files", []):
        if f.get("primary"):
            return f
    files = version.get("files", [])
    return files[0] if files else None


def _pick_mrpack_file(version: dict) -> Optional[dict]:
    files = [item for item in version.get("files", [])
             if str(item.get("filename", "")).lower().endswith(".mrpack")]
    for item in files:
        if item.get("primary"):
            return item
    return files[0] if files else None


def _validate_filename(filename: str, suffix: str = "") -> str:
    if not filename or filename in (".", "..") or len(filename) > 240:
        raise ModrinthError("Modrinth devolvió un nombre de archivo no válido.")
    if Path(filename).name != filename or "/" in filename or "\\" in filename \
            or filename.endswith((".", " ")) \
            or any(ord(char) < 32 or char in WINDOWS_INVALID_CHARS for char in filename):
        raise ModrinthError("Modrinth devolvió una ruta de archivo no segura.")
    stem = filename.split(".", 1)[0].rstrip(" ").upper()
    if stem in WINDOWS_RESERVED:
        raise ModrinthError("Modrinth devolvió un nombre reservado de Windows.")
    if suffix and not filename.lower().endswith(suffix.lower()):
        raise ModrinthError(f"El archivo descargable no termina en {suffix}.")
    return filename


def _validated_download_url(url: str, *, is_redirect: bool = False) -> str:
    if not isinstance(url, str) or not url or len(url) > 8192 \
            or any(char.isspace() or ord(char) < 32 for char in url):
        raise ModrinthError("El archivo usa una URL de descarga no permitida.")
    try:
        parsed = urlparse(url)
        host = (parsed.hostname or "").lower()
        port = parsed.port
    except ValueError as error:
        raise ModrinthError("El archivo usa una URL de descarga no permitida.") from error
    allowed_hosts = ALLOWED_REDIRECT_HOSTS if is_redirect else ALLOWED_DOWNLOAD_HOSTS
    if parsed.scheme != "https" or host not in allowed_hosts:
        raise ModrinthError("El archivo usa una URL de descarga no permitida.")
    if port not in (None, 443):
        raise ModrinthError("El archivo usa una URL de descarga no permitida.")
    if parsed.username or parsed.password:
        raise ModrinthError("La URL de descarga contiene credenciales no permitidas.")
    return url


def _open_download(url: str):
    current = url
    for redirect_count in range(6):
        _validated_download_url(current, is_redirect=redirect_count > 0)
        try:
            response = requests.get(
                current, headers=HEADERS, timeout=(15, 60), stream=True,
                allow_redirects=False,
            )
        except requests.RequestException as error:
            raise ModrinthError(f"No se pudo descargar el archivo: {error}") from error
        if response.status_code in (301, 302, 303, 307, 308):
            location = response.headers.get("Location")
            response.close()
            if not location:
                raise ModrinthError("La descarga redirigió sin indicar un destino.")
            current = urljoin(current, location)
            continue
        try:
            response.raise_for_status()
        except requests.RequestException as error:
            response.close()
            raise ModrinthError(f"No se pudo descargar el archivo: {error}") from error
        return response
    raise ModrinthError("La descarga superó el límite de redirecciones.")


def download_file(file: dict, destination: str | Path,
                  progress_cb=None, max_cb=None, cancel_cb=None) -> str:
    """Descarga en streaming, valida tamaño/hashes y publica de forma atómica."""
    def ensure_not_cancelled():
        if cancel_cb and cancel_cb():
            raise ModrinthError("La descarga fue cancelada.")

    url = str(file.get("url", ""))
    raw_size = file.get("size")
    if raw_size is None:
        raw_size = file.get("fileSize")
    has_expected_size = raw_size is not None
    if has_expected_size and (type(raw_size) is not int):
        raise ModrinthError("El tamaño anunciado del archivo no es válido.")
    expected_size = raw_size if has_expected_size else 0
    if expected_size < 0 or expected_size > MAX_DOWNLOAD_SIZE:
        raise ModrinthError("El tamaño anunciado del archivo no es válido.")
    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    file_descriptor = None
    partial = None
    sha1 = hashlib.sha1()
    sha512 = hashlib.sha512()
    downloaded = 0
    try:
        file_descriptor, partial_name = tempfile.mkstemp(
            prefix=".kat-", suffix=".part", dir=destination.parent
        )
        partial = Path(partial_name)
        if max_cb:
            max_cb(expected_size or 0)
        ensure_not_cancelled()
        response = _open_download(url)
        try:
            with os.fdopen(file_descriptor, "wb") as output:
                file_descriptor = None
                try:
                    for chunk in response.iter_content(chunk_size=1024 * 256):
                        ensure_not_cancelled()
                        if not chunk:
                            continue
                        downloaded += len(chunk)
                        limit = expected_size if has_expected_size else MAX_DOWNLOAD_SIZE
                        if downloaded > limit:
                            raise ModrinthError("La descarga excedió el tamaño esperado.")
                        output.write(chunk)
                        sha1.update(chunk)
                        sha512.update(chunk)
                        if progress_cb:
                            progress_cb(downloaded)
                except requests.RequestException as error:
                    raise ModrinthError(
                        f"No se pudo descargar el archivo: {error}"
                    ) from error
        finally:
            response.close()

        if has_expected_size and downloaded != expected_size:
            raise ModrinthError("El tamaño descargado no coincide con el anunciado.")
        hashes = file.get("hashes", {})
        expected_sha1 = str(hashes.get("sha1", "")).lower()
        expected_sha512 = str(hashes.get("sha512", "")).lower()
        if expected_sha1 and sha1.hexdigest() != expected_sha1:
            raise ModrinthError("El hash SHA-1 del archivo descargado no coincide.")
        if expected_sha512 and sha512.hexdigest() != expected_sha512:
            raise ModrinthError("El hash SHA-512 del archivo descargado no coincide.")
        if not expected_sha1 and not expected_sha512:
            raise ModrinthError("Modrinth no proporcionó un hash para verificar la descarga.")
        ensure_not_cancelled()
        os.replace(partial, destination)
        return str(destination)
    except Exception:
        if file_descriptor is not None:
            try:
                os.close(file_descriptor)
            except OSError:
                pass
        try:
            if partial is not None:
                partial.unlink(missing_ok=True)
        except OSError:
            pass
        raise


def download_version(version: dict, mods_dir: str) -> str:
    file = _pick_primary_file(version)
    if not file:
        raise ModrinthError("Esta versión del mod no tiene archivos descargables.")
    filename = _validate_filename(str(file.get("filename", "")), ".jar")
    dest = Path(mods_dir) / filename
    return download_file(file, dest)


def _ensure_version_compatible(version: dict, loader: Optional[str],
                               game_version: str) -> None:
    """Comprueba una versión exacta antes de instalarla como dependencia.

    Las consultas por proyecto ya se filtran en el servidor. Esta validación
    adicional es imprescindible para dependencias con ``version_id``: la API
    debe respetar esa versión exacta y no debemos sustituirla silenciosamente
    por otra incompatible.
    """
    supported_games = version.get("game_versions")
    if isinstance(supported_games, list) and supported_games \
            and game_version not in supported_games:
        name = version.get("name") or version.get("version_number") \
            or version.get("id") or "desconocida"
        raise ModrinthError(
            f"La dependencia exacta '{name}' no es compatible con Minecraft "
            f"{game_version}."
        )
    supported_loaders = version.get("loaders")
    if loader and isinstance(supported_loaders, list) and supported_loaders \
            and loader not in supported_loaders:
        name = version.get("name") or version.get("version_number") \
            or version.get("id") or "desconocida"
        raise ModrinthError(
            f"La dependencia exacta '{name}' no es compatible con {loader}."
        )


def _dependency_description(dependency: dict) -> dict:
    return {
        "project_id": str(dependency.get("project_id") or ""),
        "version_id": str(dependency.get("version_id") or ""),
        "file_name": str(dependency.get("file_name") or ""),
    }


def resolve_required_dependencies(root_version: dict, loader: str,
                                  game_version: str) -> dict:
    """Resuelve recursivamente el grafo de dependencias de una versión.

    Devuelve las versiones en orden dependencias-primero. Los ciclos se
    detienen por ID de versión y dos versiones distintas del mismo proyecto
    se consideran un conflicto, en vez de instalar ambas al azar.
    """
    ordered: list[dict] = []
    resolved: set[str] = set()
    visiting: set[str] = set()
    selected_projects: dict[str, str] = {}
    versions_by_id: dict[str, dict] = {}
    optional: list[dict] = []
    incompatible: list[dict] = []
    seen_notices: set[tuple] = set()

    def add_notice(bucket: list[dict], dependency: dict, kind: str) -> None:
        description = _dependency_description(dependency)
        key = (kind, *description.values())
        if key not in seen_notices:
            seen_notices.add(key)
            bucket.append(description)

    def validate_record(version: dict) -> tuple[str, str]:
        if not isinstance(version, dict):
            raise ModrinthError("Modrinth devolvió una dependencia no válida.")
        version_id = str(version.get("id") or "")
        project_id = str(version.get("project_id") or "")
        if not version_id:
            raise ModrinthError("Una dependencia de Modrinth no tiene ID de versión.")
        files = version.get("files", [])
        dependencies = version.get("dependencies", [])
        if not isinstance(files, list) or any(not isinstance(item, dict) for item in files):
            raise ModrinthError("Modrinth devolvió archivos de dependencia no válidos.")
        if not isinstance(dependencies, list) \
                or any(not isinstance(item, dict) for item in dependencies):
            raise ModrinthError("Modrinth devolvió un grafo de dependencias no válido.")
        return version_id, project_id

    def choose_required(dependency: dict) -> Optional[dict]:
        version_id = str(dependency.get("version_id") or "")
        project_id = str(dependency.get("project_id") or "")
        file_name = str(dependency.get("file_name") or "")
        if version_id:
            selected = versions_by_id.get(version_id) or get_version(version_id)
            selected_id, selected_project = validate_record(selected)
            if selected_id != version_id:
                raise ModrinthError("Modrinth devolvió una versión distinta a la solicitada.")
            if project_id and selected_project and selected_project != project_id:
                raise ModrinthError(
                    "Una dependencia exacta pertenece a un proyecto distinto."
                )
            _ensure_version_compatible(selected, loader, game_version)
            return selected
        if project_id:
            already_selected = selected_projects.get(project_id)
            if already_selected:
                return versions_by_id[already_selected]
            compatible = get_versions(project_id, loader, game_version)
            if not compatible:
                raise ModrinthError(
                    f"No existe una versión compatible de la dependencia '{project_id}' "
                    f"para {loader} {game_version}."
                )
            selected = compatible[0]
            _selected_id, selected_project = validate_record(selected)
            if selected_project and selected_project != project_id:
                raise ModrinthError(
                    "Modrinth devolvió una dependencia de un proyecto distinto."
                )
            _ensure_version_compatible(selected, loader, game_version)
            return selected
        if file_name:
            raise ModrinthError(
                f"La dependencia obligatoria externa '{file_name}' no se puede "
                "descargar automáticamente desde Modrinth."
            )
        raise ModrinthError("Una dependencia obligatoria no tiene proyecto ni versión.")

    def visit(version: dict) -> None:
        version_id, project_id = validate_record(version)
        existing = selected_projects.get(project_id) if project_id else None
        if existing and existing != version_id:
            raise ModrinthError(
                f"Conflicto de dependencias: el proyecto '{project_id}' requiere "
                "dos versiones distintas."
            )
        if project_id:
            selected_projects[project_id] = version_id
        versions_by_id[version_id] = version
        if version_id in resolved or version_id in visiting:
            return
        if len(versions_by_id) > MAX_DEPENDENCY_GRAPH_SIZE:
            raise ModrinthError("El grafo de dependencias es demasiado grande.")
        visiting.add(version_id)
        try:
            for dependency in version.get("dependencies", []):
                kind = str(dependency.get("dependency_type") or "")
                if kind == "required":
                    required = choose_required(dependency)
                    if required is not None:
                        visit(required)
                elif kind == "optional":
                    add_notice(optional, dependency, kind)
                elif kind == "incompatible":
                    add_notice(incompatible, dependency, kind)
                elif kind == "embedded":
                    continue
                else:
                    raise ModrinthError(
                        f"Modrinth devolvió un tipo de dependencia no válido: {kind}."
                    )
        finally:
            visiting.discard(version_id)
        resolved.add(version_id)
        ordered.append(version)

    _ensure_version_compatible(root_version, loader, game_version)
    visit(root_version)
    return {
        "versions": ordered,
        "optional": optional,
        "incompatible": incompatible,
    }


def _install_versions_transactionally(versions: list[dict], destination_dir: str,
                                      suffix: str, status_cb=None,
                                      cancel_cb=None) -> list[str]:
    """Descarga un plan completo y lo publica atómicamente en una carpeta."""
    destination = Path(destination_dir)
    if destination.exists() and (destination.is_symlink() or not destination.is_dir()):
        raise ModrinthError("La carpeta de destino del contenido no es segura.")
    destination.mkdir(parents=True, exist_ok=True)
    staging = Path(tempfile.mkdtemp(prefix=".kat-install-", dir=destination))
    planned: list[tuple[dict, str, Path]] = []
    target_names: set[str] = set()
    try:
        for version in versions:
            file = _pick_primary_file(version)
            if not file:
                raise ModrinthError("Una dependencia no tiene archivos descargables.")
            filename = _validate_filename(str(file.get("filename", "")), suffix)
            folded = filename.casefold()
            if folded in target_names:
                raise ModrinthError(
                    "Dos dependencias intentaron instalar el mismo nombre de archivo."
                )
            target_names.add(folded)
            target = destination / filename
            if target.exists() and not target.is_file():
                raise ModrinthError(
                    f"No se puede reemplazar '{filename}' porque no es un archivo."
                )
            planned.append((file, filename, target))

        for index, (file, filename, _target) in enumerate(planned, 1):
            if status_cb:
                status_cb(f"Descargando {filename} ({index}/{len(planned)})...")
            download_file(
                file, staging / filename,
                cancel_cb=cancel_cb,
            )

        if cancel_cb and cancel_cb():
            raise ModrinthError("La instalación fue cancelada.")

        backups: list[tuple[Path, Path]] = []
        published: list[Path] = []
        try:
            for index, (_file, filename, target) in enumerate(planned):
                if target.exists():
                    backup = staging / f".backup-{index}-{filename}"
                    os.replace(target, backup)
                    backups.append((backup, target))
                os.replace(staging / filename, target)
                published.append(target)
        except Exception:
            for target in reversed(published):
                target.unlink(missing_ok=True)
            for backup, target in reversed(backups):
                if backup.exists():
                    os.replace(backup, target)
            raise
        return [str(target) for _file, _filename, target in planned]
    finally:
        shutil.rmtree(staging, ignore_errors=True)


def install_version_with_dependencies(version: dict, loader: str,
                                      game_version: str, mods_dir: str,
                                      status_cb=None, cancel_cb=None) -> dict:
    """Instala un mod y todas sus dependencias obligatorias como una operación."""
    if not loader or loader == "vanilla":
        raise ModrinthError("Los mods requieren un perfil con mod loader.")
    graph = resolve_required_dependencies(version, loader, game_version)
    installed = _install_versions_transactionally(
        graph["versions"], mods_dir, ".jar", status_cb, cancel_cb
    )
    return {
        "primary_path": installed[-1],
        "installed": installed,
        "dependencies": installed[:-1],
        "optional": graph["optional"],
        "incompatible": graph["incompatible"],
        "root_version_id": str(version.get("id") or ""),
    }


def download_modpack_archive(version: dict, destination_dir: str | Path,
                             progress_cb=None, max_cb=None) -> str:
    file = _pick_mrpack_file(version)
    if not file:
        raise ModrinthError("Esta versión no tiene un archivo .mrpack instalable.")
    filename = _validate_filename(str(file.get("filename", "")), ".mrpack")
    return download_file(
        file,
        Path(destination_dir) / filename,
        progress_cb=progress_cb,
        max_cb=max_cb,
    )


def install_content_latest(project_id_or_slug: str, project_type: str,
                           loader: str, game_version: str,
                           destination_dir: str, status_cb=None,
                           cancel_cb=None) -> dict:
    """Instala la versión compatible más reciente de contenido de Modrinth.

    Los mods incluyen resolución recursiva de dependencias. Los resource packs
    usan el loader especial ``minecraft`` documentado por Modrinth; los shaders
    se filtran por versión porque sus plataformas son Iris/OptiFine. Ambos se
    publican con la misma protección transaccional.
    """
    project_type = str(project_type or "").lower()
    if project_type not in SUPPORTED_PROJECT_TYPES:
        raise ModrinthError(f"Tipo de contenido no compatible: {project_type}.")
    if project_type == "mod":
        effective_loader = loader
    elif project_type == "resourcepack":
        effective_loader = "minecraft"
    else:
        # Shaders declaran plataformas como Iris u OptiFine, que no equivalen
        # al loader del perfil. La versión de Minecraft sigue filtrándose.
        effective_loader = None
    versions = get_versions(project_id_or_slug, effective_loader, game_version)
    if not versions:
        raise ModrinthError(
            f"No se encontró una versión de '{project_id_or_slug}' compatible con "
            f"{effective_loader or 'Minecraft'} {game_version}."
        )
    selected = versions[0]
    if project_type == "mod":
        return install_version_with_dependencies(
            selected, effective_loader, game_version, destination_dir,
            status_cb=status_cb, cancel_cb=cancel_cb,
        )

    _ensure_version_compatible(selected, effective_loader, game_version)
    dependencies = selected.get("dependencies", [])
    if not isinstance(dependencies, list) \
            or any(not isinstance(item, dict) for item in dependencies):
        raise ModrinthError("Modrinth devolvió dependencias no válidas.")
    required = [item for item in dependencies
                if item.get("dependency_type") == "required"]
    if required:
        # Una dependencia podría ser un mod y requerir otra carpeta. Hasta
        # conocer el tipo de cada proyecto es más seguro detenerse que colocar
        # un JAR dentro de resourcepacks o shaderpacks.
        raise ModrinthError(
            "Este contenido tiene dependencias obligatorias de otro tipo y no "
            "puede instalarse automáticamente de forma segura."
        )
    installed = _install_versions_transactionally(
        [selected], destination_dir, PROJECT_FILE_SUFFIXES[project_type],
        status_cb, cancel_cb,
    )
    optional = [_dependency_description(item) for item in dependencies
                if item.get("dependency_type") == "optional"]
    incompatible = [_dependency_description(item) for item in dependencies
                    if item.get("dependency_type") == "incompatible"]
    return {
        "primary_path": installed[0],
        "installed": installed,
        "dependencies": [],
        "optional": optional,
        "incompatible": incompatible,
        "root_version_id": str(selected.get("id") or ""),
    }


def install_project_latest(project_id_or_slug: str, loader: str,
                            game_version: str, mods_dir: str) -> str:
    """Compatibilidad: instala un mod y devuelve la ruta de su archivo principal."""
    report = install_content_latest(
        project_id_or_slug, "mod", loader, game_version, mods_dir
    )
    return report["primary_path"]


def _mod_already_installed(mods_dir: str, name_hint: str) -> Optional[str]:
    hint = name_hint.lower()
    for f in Path(mods_dir).glob("*.jar"):
        if hint in f.name.lower():
            return str(f)
    return None


def _enable_disabled_mod(mods_dir: str, name_hint: str) -> Optional[str]:
    hint = name_hint.lower()
    for file in Path(mods_dir).iterdir():
        if file.is_file() and file.name.lower().endswith(".jar.disabled") \
                and hint in file.name.lower():
            destination = file.with_name(file.name[:-len(".disabled")])
            file.replace(destination)
            return str(destination)
    return None


def ensure_customskinloader(profile) -> str:
    """Se asegura de que el perfil tenga instalado CustomSkinLoader, el mod
    que permite mostrar skins personalizadas jugando en modo offline.
    Si ya está instalado, no vuelve a descargarlo."""
    if profile.loader not in ("fabric", "forge", "quilt", "neoforge"):
        raise ModrinthError(
            "CustomSkinLoader requiere un perfil con mod loader compatible "
            "(cámbialo en la pestaña Perfiles)."
        )
    if not profile.version:
        raise ModrinthError("Este perfil no tiene una versión de Minecraft asignada.")

    existing = _mod_already_installed(profile.mods_dir, "customskinloader")
    if existing:
        return existing
    enabled = _enable_disabled_mod(profile.mods_dir, "customskinloader")
    if enabled:
        return enabled

    try:
        return install_project_latest(CUSTOMSKINLOADER_SLUG, profile.loader,
                                       profile.version, profile.mods_dir)
    except ModrinthError:
        # Fallback: buscar por nombre si el slug directo no devolvió versiones
        # compatibles (p. ej. versión de Minecraft muy nueva o muy antigua).
        hits = search_mods("CustomSkinLoader", profile.loader, profile.version, limit=5)
        if not hits:
            raise
        project_id = hits[0]["project_id"]
        return install_project_latest(
            project_id, profile.loader, profile.version, profile.mods_dir
        )


def ensure_fabric_api(profile) -> str:
    """Instala Fabric API, dependencia de KatCraft en Fabric y Quilt."""
    if profile.loader not in ("fabric", "quilt"):
        raise ModrinthError("Fabric API solo corresponde a perfiles Fabric o Quilt.")
    if not profile.version:
        raise ModrinthError("Este perfil no tiene una versión de Minecraft asignada.")
    existing = _mod_already_installed(profile.mods_dir, "fabric-api")
    if existing:
        return existing
    enabled = _enable_disabled_mod(profile.mods_dir, "fabric-api")
    if enabled:
        return enabled
    # Quilt ejecuta mods Fabric; Modrinth etiqueta Fabric API como loader fabric.
    return install_project_latest(
        "fabric-api", "fabric", profile.version, profile.mods_dir
    )


def ensure_controlify(profile) -> str:
    """Instala Controlify cuando existe una versión para el perfil seleccionado."""
    if profile.loader not in ("fabric", "quilt", "neoforge", "forge"):
        raise ModrinthError(
            "Controlify requiere un perfil con Fabric, Quilt, NeoForge o Forge."
        )
    if not profile.version:
        raise ModrinthError("Este perfil no tiene una versión de Minecraft asignada.")
    existing = _mod_already_installed(profile.mods_dir, "controlify")
    if existing:
        return existing
    enabled = _enable_disabled_mod(profile.mods_dir, "controlify")
    if enabled:
        return enabled
    return install_project_latest(
        "controlify", profile.loader, profile.version, profile.mods_dir
    )


def controlify_installed(profile) -> bool:
    """Indica si Controlify ya está activo en el perfil."""
    return bool(_mod_already_installed(profile.mods_dir, "controlify"))
