from __future__ import annotations

import base64
import ctypes
import json
import os
import re
import sqlite3
import sys
import threading
from ctypes import wintypes
from pathlib import Path
from urllib.parse import quote, urlsplit

from supabase import ClientOptions, create_client

from .. import __version__
from .profile_manager import APP_DIR


AVATAR_BUCKET = "kat-avatars"
SKIN_BUCKET = "kat-skins"
SOCIAL_HISTORY_FILE = APP_DIR / "kat_social_history.sqlite3"
MAX_AVATAR_BYTES = 2 * 1024 * 1024
MAX_SKIN_BYTES = 2 * 1024 * 1024
_PNG_SIGNATURE = b"\x89PNG\r\n\x1a\n"
_AVATAR_PATH = re.compile(
    r"^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}/avatar\.png$",
    re.IGNORECASE,
)


class SocialError(RuntimeError):
    pass


class SocialHistoryArchive:
    """Archivo local deduplicado. Nunca se sincroniza ni se expone por red."""

    def __init__(self, path: str | Path | None = None):
        self.path = Path(path) if path else SOCIAL_HISTORY_FILE
        self._lock = threading.RLock()

    def save(self, rows: list[dict], scope: str, friend_id: str = "") -> int:
        if scope not in ("global", "private"):
            raise ValueError("Ámbito de historial no válido.")
        prepared = []
        for row in rows or []:
            try:
                message_id = int(row.get("id"))
            except (TypeError, ValueError):
                continue
            prepared.append((
                message_id,
                scope,
                str(friend_id or ""),
                str(row.get("sender_id") or ""),
                str(row.get("display_name") or ""),
                str(row.get("body") or ""),
                str(row.get("created_at") or ""),
            ))
        if not prepared:
            return 0
        with self._lock:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            database = sqlite3.connect(self.path, timeout=5)
            try:
                database.execute("""
                    create table if not exists messages (
                      id integer primary key,
                      scope text not null,
                      friend_id text not null default '',
                      sender_id text not null default '',
                      display_name text not null default '',
                      body text not null,
                      created_at text not null default '',
                      saved_at text not null default current_timestamp
                    )
                """)
                before = database.total_changes
                database.executemany("""
                    insert or ignore into messages(
                      id,scope,friend_id,sender_id,display_name,body,created_at
                    ) values(?,?,?,?,?,?,?)
                """, prepared)
                database.commit()
                return database.total_changes - before
            finally:
                database.close()


def _resource_path(name: str) -> Path:
    base = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parents[2]))
    bundled = base / "katlauncher" / name
    return bundled if bundled.exists() else Path(__file__).resolve().parents[1] / name


def load_config() -> dict:
    try:
        data = json.loads(_resource_path("social_config.json").read_text(encoding="utf-8"))
    except (OSError, ValueError, json.JSONDecodeError) as error:
        raise SocialError("La configuración de Kat Social no es válida.") from error
    return data


def validate_display_name(value: str) -> str:
    """Valida un nick público sin limitar alfabetos internacionales."""
    clean = " ".join(str(value or "").strip().split())
    if not 2 <= len(clean) <= 32:
        raise SocialError("El nick debe tener entre 2 y 32 caracteres.")
    if any(ord(character) < 32 or ord(character) == 127 for character in clean):
        raise SocialError("El nick contiene caracteres no permitidos.")
    return clean


def is_expired_jwt_error(error: BaseException) -> bool:
    """Reconoce la respuesta de PostgREST incluso entre versiones del SDK."""
    code = str(getattr(error, "code", "") or "").upper()
    message = str(getattr(error, "message", "") or "").lower()
    raw = getattr(error, "_raw_error", None)
    if isinstance(raw, dict):
        code = str(raw.get("code", code) or code).upper()
        message = f"{message} {raw.get('message', '')}".lower()
    rendered = str(error).lower()
    return code == "PGRST303" or "jwt expired" in message or "jwt expired" in rendered


class _Blob(ctypes.Structure):
    _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_byte))]


def _crypt(data: bytes, decrypt: bool = False) -> bytes:
    if os.name != "nt":
        raise SocialError("El almacenamiento seguro requiere Windows.")
    source_buffer = ctypes.create_string_buffer(data)
    source = _Blob(len(data), ctypes.cast(source_buffer, ctypes.POINTER(ctypes.c_byte)))
    output = _Blob()
    crypt32 = ctypes.windll.crypt32
    function = crypt32.CryptUnprotectData if decrypt else crypt32.CryptProtectData
    if decrypt:
        ok = function(ctypes.byref(source), None, None, None, None, 0, ctypes.byref(output))
    else:
        ok = function(ctypes.byref(source), None, None, None, None, 1, ctypes.byref(output))
    if not ok:
        raise SocialError("Windows no pudo abrir la sesión cifrada.")
    try:
        return ctypes.string_at(output.pbData, output.cbData)
    finally:
        ctypes.windll.kernel32.LocalFree(output.pbData)


class SecureStorage:
    """Storage de Supabase: DPAPI en Windows y keyring del escritorio en Linux."""

    def __init__(self):
        self.path = APP_DIR / "social_session.bin"
        self.lock = threading.RLock()
        self._memory = {}

    def _linux_keyring(self):
        try:
            import keyring
            return keyring
        except (ImportError, RuntimeError):
            return None

    def _read(self) -> dict:
        if os.name != "nt":
            keyring = self._linux_keyring()
            if keyring is None:
                return dict(self._memory)
            try:
                raw = keyring.get_password("KatLauncher", "kat-social-session")
                value = json.loads(raw) if raw else {}
                return value if isinstance(value, dict) else {}
            except Exception:
                return dict(self._memory)
        if not self.path.exists():
            return {}
        try:
            raw = base64.b64decode(self.path.read_bytes(), validate=True)
            value = json.loads(_crypt(raw, decrypt=True).decode("utf-8"))
            return value if isinstance(value, dict) else {}
        except Exception:
            return {}

    def _write(self, value: dict):
        if os.name != "nt":
            self._memory = dict(value)
            keyring = self._linux_keyring()
            if keyring is not None:
                try:
                    keyring.set_password(
                        "KatLauncher", "kat-social-session",
                        json.dumps(value, separators=(",", ":")),
                    )
                except Exception:
                    # Escritorios sin Secret Service conservan la sesión solo
                    # durante esta ejecución; nunca cae a texto plano.
                    pass
            return
        APP_DIR.mkdir(parents=True, exist_ok=True)
        payload = json.dumps(value, separators=(",", ":")).encode("utf-8")
        temporary = self.path.with_suffix(".tmp")
        temporary.write_bytes(base64.b64encode(_crypt(payload)))
        os.replace(temporary, self.path)

    def get_item(self, key):
        with self.lock:
            return self._read().get(key)

    def set_item(self, key, value):
        with self.lock:
            data = self._read()
            data[key] = value
            self._write(data)

    def remove_item(self, key):
        with self.lock:
            data = self._read()
            data.pop(key, None)
            self._write(data)


class SocialService:
    def __init__(self):
        config = load_config()
        self.url = str(config.get("project_url", "")).rstrip("/")
        self.key = str(config.get("publishable_key", ""))
        self.redirect_url = str(config.get("redirect_url", ""))
        self.provider = str(config.get("provider", "google")).lower()
        self._refresh_lock = threading.RLock()
        self._read_lock = threading.RLock()
        self._read_markers: dict[str, int] = {}
        self.posts_supported = False
        if self.provider not in ("google", "discord"):
            raise SocialError("El proveedor de acceso de Kat Social no es válido.")
        self.client = None
        self.me = None
        # El smoke test del instalador debe ser completamente local: nunca usa
        # la sesión real del usuario ni hace peticiones a Supabase.
        if self.configured and os.environ.get("KATLAUNCHER_SMOKE_TEST") != "1":
            self.client = create_client(
                self.url,
                self.key,
                ClientOptions(flow_type="pkce", storage=SecureStorage()),
            )
            try:
                session = self.client.auth.get_session()
            except Exception:
                # Kat Social es opcional: una caída de red nunca debe impedir
                # abrir perfiles ni jugar Minecraft sin conexión.
                session = None
            if session:
                try:
                    self.me = self.rpc("kat_upsert_profile")
                except Exception:
                    self.me = None

    @property
    def configured(self):
        return self.url.startswith("https://") and bool(self.key) and bool(self.redirect_url)

    @property
    def session(self):
        if not self.client:
            return None
        # get_session() también puede renovar un JWT vencido. El bloqueo evita
        # que dos hilos intenten consumir el mismo refresh token de un solo uso.
        with self._refresh_lock:
            return self.client.auth.get_session()

    def oauth_url(self) -> str:
        if not self.client:
            raise SocialError("Kat Social todavía no está configurado.")
        result = self.client.auth.sign_in_with_oauth({
            "provider": self.provider,
            "options": {"redirect_to": self.redirect_url},
        })
        return result.url

    def exchange_code(self, code: str):
        result = self.client.auth.exchange_code_for_session({"auth_code": code})
        self.me = self.rpc("kat_upsert_profile")
        return result.session

    def sign_out(self):
        if self.client:
            self.client.auth.sign_out()
        self.me = None

    def _require_session(self):
        if not self.client:
            raise SocialError("Kat Social todavía no está configurado.")
        session = self.session
        if not session:
            raise SocialError(f"Inicia sesión con {self.provider.title()} primero.")
        return session

    def _refresh_expired_session(self, expired_access_token: str):
        # Los refresh tokens son de un solo uso. Este bloqueo también cubre el
        # refresco periódico y el envío manual ejecutados en hilos distintos.
        with self._refresh_lock:
            current = self.client.auth.get_session()
            if current and current.access_token != expired_access_token:
                return current
            if not current or not current.refresh_token:
                raise SocialError("Tu sesión de Kat Social caducó. Inicia sesión nuevamente.")
            try:
                response = self.client.auth.refresh_session(current.refresh_token)
            except Exception as error:
                raise SocialError(
                    "No se pudo renovar tu sesión de Kat Social. Inicia sesión nuevamente."
                ) from error
            if not response or not response.session:
                raise SocialError("Tu sesión de Kat Social caducó. Inicia sesión nuevamente.")
            return response.session

    def _authenticated(self, function):
        session = self._require_session()
        try:
            return function()
        except Exception as error:
            if not is_expired_jwt_error(error):
                raise
            self._refresh_expired_session(session.access_token)
            # Se repite una sola vez: una operación con otro error sigue siendo
            # visible y nunca se duplica indefinidamente.
            return function()

    def rpc(self, name: str, params: dict | None = None):
        return self._authenticated(
            lambda: self.client.rpc(name, params or {}).execute().data
        )

    def update_display_name(self, display_name: str):
        profile = self.rpc(
            "kat_set_display_name",
            {"p_display_name": validate_display_name(display_name)},
        )
        if isinstance(profile, dict):
            self.me = profile
        return profile

    def upload_avatar(self, png: bytes):
        if not isinstance(png, bytes) or not png.startswith(_PNG_SIGNATURE):
            raise SocialError("La foto de perfil debe ser una imagen PNG válida.")
        if not 1 <= len(png) <= MAX_AVATAR_BYTES:
            raise SocialError("La foto de perfil no puede superar 2 MB.")
        session = self._require_session()
        user_id = str(session.user.id)
        path = f"{user_id}/avatar.png"
        if not _AVATAR_PATH.fullmatch(path):
            raise SocialError("No se pudo determinar la carpeta segura del avatar.")

        bucket = self.client.storage.from_(AVATAR_BUCKET)
        self._authenticated(lambda: bucket.upload(
            path,
            png,
            {"content-type": "image/png", "cache-control": "3600", "upsert": "true"},
        ))
        profile = self.rpc("kat_set_avatar", {"p_object_path": path})
        if isinstance(profile, dict):
            self.me = profile
        return profile

    def upload_shared_skin(self, nickname: str, png: bytes, model: str = "auto"):
        """Publica una sola skin persistente para que otros KatLauncher la vean."""
        from .profile_manager import validate_nickname

        nickname = validate_nickname(str(nickname or "").strip())
        model = str(model or "auto").lower()
        if model not in ("auto", "classic", "slim"):
            raise SocialError("El modelo de skin no es válido.")
        if not isinstance(png, bytes) or not png.startswith(_PNG_SIGNATURE):
            raise SocialError("La skin compartida debe ser un PNG válido.")
        if not 1 <= len(png) <= MAX_SKIN_BYTES:
            raise SocialError("La skin compartida no puede superar 2 MB.")
        claim = self.rpc(
            "kat_claim_skin_name", {"p_nickname": nickname, "p_model": model},
        )
        if not isinstance(claim, dict):
            raise SocialError("KatSkin no devolvió una ruta válida.")
        object_path = str(claim.get("object_path") or "")
        expected = f"skins/{nickname}.png"
        if object_path != expected:
            raise SocialError("KatSkin rechazó la ruta de publicación.")
        bucket = self.client.storage.from_(SKIN_BUCKET)
        self._authenticated(lambda: bucket.upload(
            object_path,
            png,
            {"content-type": "image/png", "cache-control": "300", "upsert": "true"},
        ))
        digest = __import__("hashlib").sha256(png).hexdigest()
        result = self.rpc(
            "kat_commit_skin", {"p_sha256": digest, "p_model": model},
        )
        return result if isinstance(result, dict) else claim

    @property
    def shared_skin_root(self) -> str:
        return f"{self.url}/storage/v1/object/public/{SKIN_BUCKET}/skins"

    def reset_profile(self, reset_name: bool = True, reset_avatar: bool = True):
        profile = self.rpc("kat_reset_profile", {
            "p_reset_name": bool(reset_name),
            "p_reset_avatar": bool(reset_avatar),
        })
        if isinstance(profile, dict):
            self.me = profile
        return profile

    def touch_presence(self):
        profile = self.rpc("kat_touch_presence")
        if isinstance(profile, dict):
            self.me = profile
        return profile

    def mark_private_read(self, friend_id, message_id):
        if not friend_id or not message_id:
            return
        friend_key = str(friend_id)
        message_number = int(message_id)
        with self._read_lock:
            if self._read_markers.get(friend_key, 0) >= message_number:
                return
        self.rpc("kat_mark_private_read", {
            "p_friend": friend_id,
            "p_message": message_number,
        })
        with self._read_lock:
            self._read_markers[friend_key] = message_number

    def avatar_url(self, profile: dict | None) -> str:
        if not isinstance(profile, dict):
            return ""
        avatar_path = str(profile.get("avatar_path") or "")
        if avatar_path and _AVATAR_PATH.fullmatch(avatar_path):
            url = (
                f"{self.url}/storage/v1/object/public/{AVATAR_BUCKET}/"
                f"{quote(avatar_path, safe='/')}"
            )
            version = str(profile.get("avatar_updated_at") or "")
            return f"{url}?v={quote(version)}" if version else url

        url = str(profile.get("avatar_url") or "")
        if not url or len(url) > 2048:
            return ""
        parsed = urlsplit(url)
        project_host = urlsplit(self.url).hostname or ""
        host = (parsed.hostname or "").lower()
        allowed = (
            host == project_host
            or host.endswith(".googleusercontent.com")
            or host == "googleusercontent.com"
            or host.endswith(".ggpht.com")
            or host == "ggpht.com"
        )
        return url if parsed.scheme == "https" and allowed else ""

    def global_messages(self):
        return self.rpc("kat_list_global_messages") or []

    def friends(self):
        return self.rpc("kat_list_friends") or []

    def requests(self):
        return self.rpc("kat_list_friend_requests") or []

    def private_messages(self, friend_id):
        if not friend_id:
            return []
        return self.rpc("kat_list_private_messages", {"p_friend": friend_id}) or []

    def posts(self):
        try:
            rows = self.rpc("kat_list_posts") or []
        except Exception as error:
            rendered = str(error).lower()
            if "kat_list_posts" in rendered and any(marker in rendered for marker in (
                "pgrst202", "could not find", "does not exist", "schema cache",
            )):
                return []
            raise
        self.posts_supported = True
        return rows

    def groups(self):
        try:
            return self.rpc("kat_list_groups") or []
        except Exception as error:
            rendered = str(error).lower()
            if any(marker in rendered for marker in (
                "kat_list_groups", "pgrst202", "could not find", "does not exist",
            )):
                return []
            raise

    def group_messages(self, group_id):
        if not group_id:
            return []
        rows = self.rpc("kat_list_group_messages", {"p_group": group_id}) or []
        return list(reversed(rows))

    def create_group(self, name: str, members: list[str] | None = None):
        return self.rpc("kat_create_group", {
            "p_name": validate_display_name(name),
            "p_members": list(members or []),
        })

    def send_group_message(self, group_id, body: str):
        return self.rpc("kat_send_group_message", {
            "p_group": group_id, "p_body": str(body or "").strip()[:500],
        })

    def add_group_member(self, group_id, user_id):
        return self.rpc("kat_add_group_member", {
            "p_group": group_id, "p_user": user_id,
        })

    def add_playtime(self, seconds: int):
        profile = self.rpc("kat_add_playtime", {"p_seconds": int(seconds)})
        if isinstance(profile, dict):
            self.me = profile
        return profile

    def sync_trophies(self, trophy_ids: list[str]):
        profile = self.rpc(
            "kat_sync_trophies",
            {"p_trophies": [str(item) for item in trophy_ids]},
        )
        if isinstance(profile, dict):
            self.me = profile
        return profile

    def public_profile(self, user_id: str):
        profile = self.rpc("kat_get_public_profile", {"p_user": str(user_id)})
        # PostgREST/Supabase puede entregar jsonb como objeto, texto JSON o,
        # con ciertas versiones del cliente, una lista de una sola fila.
        if isinstance(profile, str):
            try:
                profile = json.loads(profile)
            except json.JSONDecodeError:
                return {}
        if isinstance(profile, list):
            profile = profile[0] if profile else {}
        return profile if isinstance(profile, dict) else {}

    def sync_launcher_version(self):
        profile = self.rpc(
            "kat_set_launcher_version",
            {"p_version": str(__version__)[:24]},
        )
        if isinstance(profile, dict):
            self.me = profile
        return profile

    def set_presence(
        self, active: bool, loader: str = "", version: str = "", skin: str = "",
        enabled: bool = True,
    ):
        profile = self.rpc("kat_set_presence", {
            "p_active": bool(active),
            "p_loader": str(loader or "")[:24],
            "p_version": str(version or "")[:40],
            "p_skin": str(skin or "")[:16],
            "p_enabled": bool(enabled),
        })
        if isinstance(profile, dict):
            self.me = profile
        return profile
