"""Contenido oficial pequeño que KatLauncher puede copiar a sus instancias."""
from __future__ import annotations

import hashlib
import os
import shutil
import sys
from pathlib import Path


MCKAT_FILENAME = "MCKAT.zip"
MCKAT_SHA256 = "199d972b5ddc3213febb18a781f5fcdbb4e12b1942d2e6e0093748e94eb8bd0a"


def bundled_asset(name: str) -> Path:
    """Resuelve un asset tanto desde el código como desde PyInstaller."""

    roots = (
        Path(getattr(sys, "_MEIPASS", "")),
        Path(__file__).resolve().parents[1],
    )
    for root in roots:
        if not str(root):
            continue
        candidate = root / "katlauncher" / "assets" / name
        if candidate.is_file():
            return candidate
        candidate = root / "assets" / name
        if candidate.is_file():
            return candidate
    raise FileNotFoundError(f"No se encontró el recurso incluido: {name}")


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def install_mckat_resource_pack(game_dir: str | Path) -> tuple[Path, bool]:
    """Instala MCKAT sin sobrescribir una edición diferente del usuario.

    Devuelve ``(ruta, cambiado)``. Si ya existe un ``MCKAT.zip`` distinto se
    conserva intacto y la copia oficial usa el nombre ``MCKAT-KatLauncher.zip``.
    """

    source = bundled_asset(MCKAT_FILENAME)
    if _sha256(source) != MCKAT_SHA256:
        raise OSError("El texture pack MCKAT incluido no superó su verificación.")
    destination_dir = Path(game_dir) / "resourcepacks"
    destination_dir.mkdir(parents=True, exist_ok=True)
    destination = destination_dir / MCKAT_FILENAME
    if destination.is_file():
        if _sha256(destination) == MCKAT_SHA256:
            return destination, False
        destination = destination_dir / "MCKAT-KatLauncher.zip"
        if destination.is_file() and _sha256(destination) == MCKAT_SHA256:
            return destination, False

    temporary = destination.with_suffix(destination.suffix + ".tmp")
    try:
        shutil.copyfile(source, temporary)
        if _sha256(temporary) != MCKAT_SHA256:
            raise OSError("La copia de MCKAT quedó incompleta.")
        os.replace(temporary, destination)
    finally:
        try:
            temporary.unlink(missing_ok=True)
        except OSError:
            pass
    return destination, True
