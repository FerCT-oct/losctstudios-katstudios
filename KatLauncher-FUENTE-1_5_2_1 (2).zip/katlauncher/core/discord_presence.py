"""Discord Rich Presence opcional y tolerante a fallos.

La comunicacion con Discord se ejecuta en un hilo daemon para no bloquear Qt.
Si no hay Client ID, Discord no esta abierto o ``pypresence`` no esta
disponible, la aplicacion sigue funcionando con normalidad.
"""
from __future__ import annotations

import os
import queue
import threading
import time
from collections.abc import Callable
from typing import Any


CLIENT_ID_ENV = "KATLAUNCHER_DISCORD_CLIENT_ID"
DEFAULT_DISCORD_CLIENT_ID = "1423530924783566920"
MIN_CLIENT_ID_LENGTH = 15
MAX_CLIENT_ID_LENGTH = 24
MAX_PRESENCE_TEXT_LENGTH = 128


def _default_presence_factory(client_id: str):
    # Importacion intencionalmente diferida: Rich Presence es opcional y la
    # ausencia de esta dependencia nunca debe impedir que abra KatLauncher.
    from pypresence import Presence

    return Presence(client_id)


class DiscordRichPresence:
    """Publica el estado de KatLauncher en Discord sin bloquear al llamador.

    ``client_id`` debe ser el identificador numerico de una aplicacion creada
    en Discord Developer Portal. Si se omite, se consulta la variable de
    entorno :data:`CLIENT_ID_ENV`. Todos los metodos son seguros aunque Discord
    no este instalado o no se encuentre abierto.

    Los metodos que publican devuelven ``True`` cuando la operacion se puso en
    cola, no cuando Discord la confirmo. ``last_error`` permite diagnosticar un
    fallo sin mostrarlo al usuario ni interrumpir otras operaciones.
    """

    def __init__(
        self,
        client_id: str | int | None = None,
        *,
        enabled: bool = True,
        reconnect_cooldown: float = 30.0,
        presence_factory: Callable[[str], Any] | None = None,
        monotonic: Callable[[], float] = time.monotonic,
        wall_clock: Callable[[], float] = time.time,
    ):
        raw_client_id = os.environ.get(CLIENT_ID_ENV, "") \
            if client_id is None else client_id
        self.client_id = _normalize_client_id(raw_client_id)
        self._enabled = bool(enabled)
        self._reconnect_cooldown = max(0.0, float(reconnect_cooldown))
        self._presence_factory = presence_factory or _default_presence_factory
        self._monotonic = monotonic
        self._wall_clock = wall_clock

        self._commands: queue.Queue[tuple[str, Any]] = queue.Queue()
        self._guard = threading.RLock()
        self._thread: threading.Thread | None = None
        self._closed = False
        self._connected = False
        self._last_error: str | None = None
        self._retry_timer: threading.Timer | None = None
        self._retry_payload: dict[str, Any] | None = None

    @property
    def configured(self) -> bool:
        """Indica si hay un Client ID valido."""
        return bool(self.client_id)

    @property
    def enabled(self) -> bool:
        with self._guard:
            return self._enabled

    @property
    def active(self) -> bool:
        """Indica si el servicio puede aceptar publicaciones."""
        with self._guard:
            return bool(self.client_id and self._enabled and not self._closed)

    @property
    def connected(self) -> bool:
        with self._guard:
            return self._connected

    @property
    def last_error(self) -> str | None:
        with self._guard:
            return self._last_error

    def start(self) -> bool:
        """Inicia el hilo de fondo; la conexion se abre al publicar."""
        return self._ensure_worker()

    def set_enabled(self, enabled: bool) -> None:
        """Activa o desactiva el servicio durante la ejecucion.

        Al desactivarlo se limpia la actividad y se cierra la conexion en el
        hilo de fondo. Volver a activarlo no publica nada hasta la siguiente
        llamada a ``show_launcher``, ``show_playing`` o ``update_activity``.
        """
        with self._guard:
            if self._closed or self._enabled == bool(enabled):
                return
            self._enabled = bool(enabled)
            thread = self._thread
        if not enabled:
            self._cancel_retry()
        if not enabled and thread is not None and thread.is_alive():
            self._commands.put(("disconnect", None))

    def show_launcher(self, *, language: str = "es") -> bool:
        """Muestra que el usuario esta explorando KatLauncher."""
        if language == "en":
            details = "Browsing KatLauncher"
            state = "Preparing the next adventure"
        else:
            details = "Explorando KatLauncher"
            state = "Preparando la próxima aventura"
        return self.update_activity(details=details, state=state)

    def show_playing(
        self,
        version: str,
        *,
        loader: str = "vanilla",
        started_at: int | float | None = None,
        language: str = "es",
    ) -> bool:
        """Muestra Minecraft, su version y loader, sin revelar el nickname."""
        details = "Playing Minecraft" if language == "en" else "Jugando Minecraft"
        version_text = _clean_text(version, 64) or "Minecraft"
        loader_text = _format_loader(loader)
        state = f"Minecraft {version_text}"
        if loader_text and loader_text != "Vanilla":
            state = f"{state} · {loader_text}"
        timestamp = self._wall_clock() if started_at is None else started_at
        return self.update_activity(
            details=details,
            state=state,
            start=timestamp,
        )

    def update_activity(
        self,
        *,
        details: str = "",
        state: str = "",
        start: int | float | None = None,
        large_image: str = "",
        large_text: str = "",
        small_image: str = "",
        small_text: str = "",
    ) -> bool:
        """Pone una actividad en cola y vuelve inmediatamente.

        Los nombres de imagen son opcionales porque Discord rechaza assets que
        no hayan sido registrados previamente para el Client ID.
        """
        if not self.active or not self._ensure_worker():
            return False

        payload: dict[str, Any] = {}
        for key, value in (("details", details), ("state", state)):
            cleaned = _clean_text(value)
            if cleaned:
                payload[key] = cleaned
        if not payload:
            return False

        for key, value in (
            ("large_image", large_image),
            ("large_text", large_text),
            ("small_image", small_image),
            ("small_text", small_text),
        ):
            cleaned = _clean_text(value)
            if cleaned:
                payload[key] = cleaned

        # Los tooltips solo son validos cuando tambien existe su imagen.
        if "large_image" not in payload:
            payload.pop("large_text", None)
        if "small_image" not in payload:
            payload.pop("small_text", None)

        if start is not None:
            try:
                timestamp = int(start)
            except (TypeError, ValueError, OverflowError):
                timestamp = 0
            if timestamp > 0:
                payload["start"] = timestamp

        self._commands.put(("update", payload))
        return True

    def clear(self) -> bool:
        """Limpia la actividad actual, si existe una conexion abierta."""
        self._cancel_retry()
        with self._guard:
            thread = self._thread
            closed = self._closed
        if closed or thread is None or not thread.is_alive():
            return False
        self._commands.put(("clear", None))
        return True

    def flush(self, timeout: float = 1.0) -> bool:
        """Espera a que se procesen las operaciones previas.

        No es necesario usarlo desde la GUI; resulta util para pruebas y para
        un cierre controlado. El tiempo de espera evita que Discord pueda
        bloquear la salida de KatLauncher.
        """
        with self._guard:
            thread = self._thread
        if thread is None or not thread.is_alive():
            return True
        completed = threading.Event()
        self._commands.put(("barrier", completed))
        return completed.wait(max(0.0, float(timeout)))

    def close(self, timeout: float = 1.0) -> None:
        """Detiene el servicio sin dejar que un fallo de Discord se propague."""
        with self._guard:
            if self._closed:
                return
            self._closed = True
            thread = self._thread
        self._cancel_retry()
        if thread is None or not thread.is_alive():
            return
        self._commands.put(("stop", None))
        if thread is not threading.current_thread():
            thread.join(max(0.0, float(timeout)))

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, _exc_type, _exc_value, _traceback):
        self.close()

    def _ensure_worker(self) -> bool:
        with self._guard:
            if not self.client_id or not self._enabled or self._closed:
                return False
            if self._thread is None or not self._thread.is_alive():
                self._thread = threading.Thread(
                    target=self._run,
                    name="KatLauncher-DiscordPresence",
                    daemon=True,
                )
                self._thread.start()
            return True

    def _run(self) -> None:
        rpc = None
        last_payload: dict[str, Any] | None = None
        last_failure: float | None = None

        while True:
            action, value = self._commands.get()
            try:
                if action == "stop":
                    self._disconnect(rpc, clear=True)
                    return
                if action == "barrier":
                    value.set()
                    continue
                if action == "disconnect":
                    self._disconnect(rpc, clear=True)
                    rpc = None
                    last_payload = None
                    continue
                if action == "clear":
                    if rpc is not None:
                        try:
                            rpc.clear()
                            self._set_error(None)
                        except Exception as error:
                            self._set_error(error)
                            self._disconnect(rpc, clear=False)
                            rpc = None
                            last_failure = self._monotonic()
                    last_payload = None
                    continue
                if action != "update" or not self.active:
                    continue

                if rpc is None:
                    now = self._monotonic()
                    if last_failure is not None \
                            and now - last_failure < self._reconnect_cooldown:
                        self._schedule_retry(
                            value,
                            self._reconnect_cooldown - (now - last_failure),
                        )
                        continue
                    candidate = None
                    try:
                        candidate = self._presence_factory(self.client_id)
                        candidate.connect()
                        rpc = candidate
                        self._set_connected(True)
                        self._set_error(None)
                    except Exception as error:
                        self._set_error(error)
                        self._set_connected(False)
                        last_failure = self._monotonic()
                        self._schedule_retry(value, self._reconnect_cooldown)
                        if candidate is not None:
                            self._disconnect(candidate, clear=False)
                        continue

                if value == last_payload:
                    continue
                try:
                    rpc.update(**value)
                    last_payload = value
                    self._cancel_retry()
                    self._set_error(None)
                except Exception as error:
                    self._set_error(error)
                    self._disconnect(rpc, clear=False)
                    rpc = None
                    last_payload = None
                    last_failure = self._monotonic()
                    self._schedule_retry(value, self._reconnect_cooldown)
            finally:
                self._commands.task_done()

    def _disconnect(self, rpc, *, clear: bool) -> None:
        if rpc is not None:
            if clear:
                try:
                    rpc.clear()
                except Exception:
                    pass
            try:
                rpc.close()
            except Exception:
                pass
        self._set_connected(False)

    def _set_connected(self, value: bool) -> None:
        with self._guard:
            self._connected = value

    def _set_error(self, error: Exception | str | None) -> None:
        if error is None:
            message = None
        else:
            message = str(error).strip() or type(error).__name__
            message = message[:300]
        with self._guard:
            self._last_error = message

    def _schedule_retry(self, payload: dict[str, Any], delay: float) -> None:
        """Conserva el estado más reciente y reintenta sin bloquear el hilo RPC."""
        with self._guard:
            if self._closed or not self._enabled or not self.client_id:
                return
            self._retry_payload = dict(payload)
            if self._retry_timer is not None and self._retry_timer.is_alive():
                return
            timer = threading.Timer(max(0.05, float(delay)), self._enqueue_retry)
            timer.daemon = True
            self._retry_timer = timer
        timer.start()

    def _enqueue_retry(self) -> None:
        with self._guard:
            payload = self._retry_payload
            self._retry_payload = None
            self._retry_timer = None
            active = bool(self.client_id and self._enabled and not self._closed)
        if active and payload:
            self._commands.put(("update", payload))

    def _cancel_retry(self) -> None:
        with self._guard:
            timer = self._retry_timer
            self._retry_timer = None
            self._retry_payload = None
        if timer is not None:
            timer.cancel()


def _normalize_client_id(value: str | int | None) -> str:
    text = str(value or "").strip()
    if not text.isascii() or not text.isdigit():
        return ""
    if not MIN_CLIENT_ID_LENGTH <= len(text) <= MAX_CLIENT_ID_LENGTH:
        return ""
    return text


def _clean_text(value: str | None, limit: int = MAX_PRESENCE_TEXT_LENGTH) -> str:
    # Discord no acepta saltos de linea en estos campos. Colapsar espacios evita
    # ademas estados visualmente rotos al recibir datos editados por el usuario.
    return " ".join(str(value or "").split())[:limit]


def _format_loader(value: str) -> str:
    loader = _clean_text(value, 32).lower()
    known = {
        "vanilla": "Vanilla",
        "fabric": "Fabric",
        "forge": "Forge",
        "quilt": "Quilt",
        "neoforge": "NeoForge",
    }
    return known.get(loader, _clean_text(value, 32))
