"""Identidades offline locales de KatLauncher.

Las cuentas Microsoft requieren una aplicación aprobada para Xbox Live; este
módulo no guarda contraseñas ni finge tokens oficiales.
"""
from __future__ import annotations

import json
import os
import uuid
from dataclasses import asdict, dataclass
from pathlib import Path

from .profile_manager import APP_DIR, offline_uuid, validate_nickname


ACCOUNTS_FILE = APP_DIR / "accounts.json"


@dataclass(frozen=True)
class LauncherAccount:
    id: str
    nickname: str
    account_type: str = "offline"

    @property
    def player_uuid(self) -> str:
        return offline_uuid(self.nickname)


class AccountManager:
    def __init__(self, accounts_file: str | Path | None = None, default_nickname="Jugador"):
        self.accounts_file = Path(accounts_file) if accounts_file else ACCOUNTS_FILE
        self.default_nickname = default_nickname
        self.accounts: dict[str, LauncherAccount] = {}
        self.selected_id = ""
        self.load()

    def load(self):
        self.accounts = {}
        self.selected_id = ""
        try:
            payload = json.loads(self.accounts_file.read_text(encoding="utf-8"))
            records = payload.get("accounts", []) if isinstance(payload, dict) else []
            for value in records[:100]:
                try:
                    if not isinstance(value, dict) \
                            or value.get("account_type", "offline") != "offline":
                        continue
                    nickname = validate_nickname(str(value.get("nickname", "")))
                    account_id = str(value.get("id") or "")
                    if account_id and account_id not in self.accounts:
                        self.accounts[account_id] = LauncherAccount(account_id, nickname)
                except (ValueError, TypeError):
                    continue
            selected = str(payload.get("selected_id") or "") if isinstance(payload, dict) else ""
            if selected in self.accounts:
                self.selected_id = selected
        except (OSError, ValueError, TypeError, json.JSONDecodeError):
            self.accounts = {}
        if not self.accounts:
            nickname = validate_nickname(self.default_nickname)
            account = LauncherAccount(uuid.uuid4().hex[:12], nickname)
            self.accounts[account.id] = account
            self.selected_id = account.id
            try:
                self.save()
            except OSError:
                pass
        elif not self.selected_id:
            self.selected_id = next(iter(self.accounts))

    def save(self):
        self.accounts_file.parent.mkdir(parents=True, exist_ok=True)
        temp = self.accounts_file.with_suffix(self.accounts_file.suffix + ".tmp")
        temp.write_text(json.dumps({
            "schema_version": 1,
            "selected_id": self.selected_id,
            "accounts": [asdict(account) for account in self.list()],
        }, ensure_ascii=False, indent=2), encoding="utf-8")
        os.replace(temp, self.accounts_file)

    def list(self) -> list[LauncherAccount]:
        return list(self.accounts.values())

    def selected(self) -> LauncherAccount:
        return self.accounts[self.selected_id]

    def add_offline(self, nickname: str) -> LauncherAccount:
        nickname = validate_nickname(nickname)
        existing = next(
            (item for item in self.accounts.values()
             if item.nickname.casefold() == nickname.casefold()), None
        )
        if existing:
            self.select(existing.id)
            return existing
        account = LauncherAccount(uuid.uuid4().hex[:12], nickname)
        self.accounts[account.id] = account
        previous = self.selected_id
        self.selected_id = account.id
        try:
            self.save()
        except Exception:
            self.accounts.pop(account.id, None)
            self.selected_id = previous
            raise
        return account

    def select(self, account_id: str) -> LauncherAccount:
        if account_id not in self.accounts:
            raise ValueError("La cuenta seleccionada ya no existe")
        previous = self.selected_id
        self.selected_id = account_id
        try:
            self.save()
        except Exception:
            self.selected_id = previous
            raise
        return self.accounts[account_id]

    def remove(self, account_id: str):
        if account_id not in self.accounts:
            return
        if len(self.accounts) <= 1:
            raise ValueError("Debe quedar al menos una cuenta offline")
        removed = self.accounts.pop(account_id)
        previous = self.selected_id
        if self.selected_id == account_id:
            self.selected_id = next(iter(self.accounts))
        try:
            self.save()
        except Exception:
            self.accounts[removed.id] = removed
            self.selected_id = previous
            raise
