"""Noticias oficiales de Minecraft con caché resistente a desconexiones."""
from __future__ import annotations

import json
import os
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable

import requests

from .profile_manager import APP_DIR


NEWS_URL = "https://launchercontent.mojang.com/v2/javaPatchNotes.json"
NEWS_BASE_URL = "https://launchercontent.mojang.com"
NEWS_CACHE_FILE = APP_DIR / "cache" / "minecraft_news.json"
MAX_NEWS_BYTES = 4 * 1024 * 1024


@dataclass(frozen=True)
class NewsItem:
    id: str
    title: str
    summary: str
    date: str
    version: str = ""
    category: str = "release"
    image_url: str = ""
    source_url: str = "https://www.minecraft.net/en-us/articles"

    @classmethod
    def from_dict(cls, value: dict) -> "NewsItem":
        if not isinstance(value, dict):
            raise ValueError("Entrada de noticias no válida")
        image = value.get("image") if isinstance(value.get("image"), dict) else {}
        image_url = str(image.get("url") or value.get("image_url") or "").strip()
        if image_url.startswith("/"):
            image_url = NEWS_BASE_URL + image_url
        if image_url and not image_url.startswith(NEWS_BASE_URL + "/"):
            image_url = ""
        identifier = str(value.get("id") or value.get("version") or "").strip()
        title = str(value.get("title") or "").strip()
        if not identifier or not title:
            raise ValueError("Entrada de noticias incompleta")
        return cls(
            id=identifier[:128],
            title=title[:240],
            summary=str(value.get("shortText") or value.get("summary") or "").strip()[:1200],
            date=str(value.get("date") or "").strip()[:64],
            version=str(value.get("version") or "").strip()[:80],
            category=str(value.get("type") or value.get("category") or "release").strip()[:40],
            image_url=image_url,
            source_url="https://www.minecraft.net/en-us/articles",
        )


class NewsService:
    def __init__(self, cache_file: str | Path | None = None, session=None):
        self.cache_file = Path(cache_file) if cache_file else NEWS_CACHE_FILE
        self.session = session or requests.Session()

    def fetch(self, limit: int = 30) -> list[NewsItem]:
        """Obtiene novedades y recurre a la última copia válida si no hay red."""
        limit = max(1, min(int(limit), 100))
        try:
            response = self.session.get(
                NEWS_URL,
                timeout=(5, 20),
                headers={"Accept": "application/json", "User-Agent": "KatLauncher/1.3"},
            )
            response.raise_for_status()
            raw = response.content
            if len(raw) > MAX_NEWS_BYTES:
                raise ValueError("La respuesta de noticias es demasiado grande")
            payload = json.loads(raw.decode("utf-8"))
            items = self._parse_payload(payload, limit)
            if not items:
                raise ValueError("El canal oficial no devolvió noticias válidas")
            try:
                self._save_cache(items)
            except OSError:
                # La red puede funcionar aunque el disco esté en solo lectura.
                # Las noticias siguen siendo válidas sin una caché nueva.
                pass
            return items
        except (OSError, ValueError, TypeError, json.JSONDecodeError, requests.RequestException):
            cached = self.load_cache(limit)
            if cached:
                return cached
            raise RuntimeError("No se pudieron cargar las noticias y aún no existe una copia local.")

    @staticmethod
    def _parse_payload(payload: dict, limit: int) -> list[NewsItem]:
        if not isinstance(payload, dict) or not isinstance(payload.get("entries"), list):
            raise ValueError("Formato de noticias no compatible")
        result: list[NewsItem] = []
        seen: set[str] = set()
        for raw_item in payload["entries"]:
            try:
                item = NewsItem.from_dict(raw_item)
            except ValueError:
                continue
            if item.id in seen:
                continue
            seen.add(item.id)
            result.append(item)
        result.sort(key=lambda item: (item.date, item.id), reverse=True)
        return result[:limit]

    def _save_cache(self, items: Iterable[NewsItem]):
        self.cache_file.parent.mkdir(parents=True, exist_ok=True)
        payload = json.dumps(
            {"schema_version": 1, "items": [asdict(item) for item in items]},
            ensure_ascii=False,
            indent=2,
        )
        temp = self.cache_file.with_suffix(self.cache_file.suffix + ".tmp")
        temp.write_text(payload, encoding="utf-8")
        os.replace(temp, self.cache_file)

    def load_cache(self, limit: int = 30) -> list[NewsItem]:
        try:
            if not self.cache_file.is_file() or self.cache_file.stat().st_size > MAX_NEWS_BYTES:
                return []
            payload = json.loads(self.cache_file.read_text(encoding="utf-8"))
            raw_items = payload.get("items", []) if isinstance(payload, dict) else []
            result = []
            for raw_item in raw_items:
                try:
                    result.append(NewsItem.from_dict(raw_item))
                except ValueError:
                    continue
                if len(result) >= max(1, min(int(limit), 100)):
                    break
            return result
        except (OSError, ValueError, TypeError, json.JSONDecodeError):
            return []
