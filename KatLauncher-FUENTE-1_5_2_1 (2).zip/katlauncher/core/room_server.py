"""Servidor dedicado Vanilla temporal para salas LAN de KatLauncher."""
from __future__ import annotations

import hashlib
import ipaddress
import json
import os
import re
import socket
import subprocess
import threading
import shutil
import zipfile
import xml.etree.ElementTree as ET
from pathlib import Path
from urllib.parse import urlparse

import requests

from . import launcher_core
from .profile_manager import APP_DIR, Profile


MANIFEST_URL = "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json"
ROOM_ROOT = APP_DIR / "rooms"
MAX_SERVER_JAR_BYTES = 128 * 1024 * 1024
ALLOWED_DOWNLOAD_HOSTS = {
    "piston-meta.mojang.com",
    "piston-data.mojang.com",
    "launcher.mojang.com",
    "maven.fabricmc.net",
    "maven.quiltmc.org",
    "maven.minecraftforge.net",
    "maven.neoforged.net",
}
FABRIC_INSTALLER_METADATA = (
    "https://maven.fabricmc.net/net/fabricmc/fabric-installer/maven-metadata.xml"
)
QUILT_INSTALLER_METADATA = (
    "https://maven.quiltmc.org/repository/release/org/quiltmc/"
    "quilt-installer/maven-metadata.xml"
)


class RoomServerError(RuntimeError):
    pass


def lan_address() -> str:
    """Devuelve una IPv4 enrutable en la LAN sin enviar tráfico externo."""
    candidates: list[str] = []
    try:
        probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            probe.connect(("192.0.2.1", 9))
            candidates.append(str(probe.getsockname()[0]))
        finally:
            probe.close()
    except OSError:
        pass
    try:
        candidates.extend(socket.gethostbyname_ex(socket.gethostname())[2])
    except OSError:
        pass
    for value in candidates:
        try:
            address = ipaddress.ip_address(value)
        except ValueError:
            continue
        if address.version == 4 and address.is_private and not address.is_loopback:
            return str(address)
    return "127.0.0.1"


def port_available(port: int) -> bool:
    port = int(port)
    if not 1 <= port <= 65535:
        return False
    probe = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        probe.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        probe.bind(("", port))
        return True
    except OSError:
        return False
    finally:
        probe.close()


def available_room_port(preferred: int = 25565) -> int:
    """Conserva el puerto solicitado o elige uno libre automáticamente."""
    if port_available(preferred):
        return int(preferred)
    probe = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        probe.bind(("", 0))
        return int(probe.getsockname()[1])
    except OSError as error:
        raise RoomServerError(
            "No se encontró un puerto libre para crear la sala."
        ) from error
    finally:
        probe.close()


def list_profile_worlds(profile: Profile) -> list[dict]:
    """Lista mundos locales y copias persistentes creadas para servidores."""
    result: list[dict] = []
    saves = Path(profile.game_dir) / "saves"
    if saves.is_dir():
        try:
            children = list(saves.iterdir())
        except OSError:
            children = []
        for child in children:
            try:
                if child.is_dir() and (child / "level.dat").is_file():
                    result.append({
                        "id": "save:" + child.name,
                        "name": child.name,
                        "source": "save",
                        "modified": int(child.stat().st_mtime),
                    })
            except OSError:
                continue
    profile_id = str(getattr(profile, "id", "")).strip()
    version = str(getattr(profile, "version", "")).strip()
    root = (ROOM_ROOT / profile_id / _safe_version(version) / "worlds"
            if profile_id and version else None)
    if root is not None and root.is_dir():
        try:
            children = list(root.iterdir())
        except OSError:
            children = []
        for child in children:
            marker = child / ".katlauncher-world.json"
            if not child.is_dir() or not marker.is_file():
                continue
            try:
                data = json.loads(marker.read_text(encoding="utf-8"))
                name = str(data.get("name") or child.name)[:64]
                result.append({
                    "id": "room:" + child.name,
                    "name": name,
                    "source": "server",
                    "modified": int(child.stat().st_mtime),
                })
            except (OSError, ValueError, json.JSONDecodeError):
                continue
    result.sort(key=lambda item: (-int(item["modified"]), item["name"].casefold()))
    return result[:100]


def list_profile_server_mods(profile: Profile) -> list[dict]:
    """Lista los JAR elegibles para una sala y marca los exclusivos de cliente."""
    directory = Path(getattr(profile, "mods_dir", ""))
    if not directory.is_dir():
        return []
    result = []
    try:
        children = sorted(directory.iterdir(), key=lambda item: item.name.casefold())
    except OSError:
        return []
    for item in children:
        if not item.is_file() or item.suffix.lower() != ".jar":
            continue
        try:
            size = item.stat().st_size
        except OSError:
            continue
        client_only = _client_only_mod(item)
        result.append({
            "id": item.name,
            "name": item.stem[:120],
            "file": item.name[:180],
            "size": int(size),
            "client_only": client_only,
            "selected": not client_only,
        })
        if len(result) >= 500:
            break
    return result


def _validate_world_child(value: str) -> str:
    clean = str(value or "").strip()
    if not clean or len(clean) > 128 or clean in (".", "..") \
            or "/" in clean or "\\" in clean or "\x00" in clean:
        raise RoomServerError("El identificador del mundo no es válido.")
    return clean


def _safe_world_folder(value: str) -> str:
    clean = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "-", str(value or ""))
    clean = re.sub(r"\s+", " ", clean).strip(" .")[:64]
    return clean or "Nuevo mundo Kat"


def _write_world_marker(directory: Path, name: str, imported: bool):
    _write_text_atomic(
        directory / ".katlauncher-world.json",
        json.dumps({
            "schema": 1,
            "name": str(name or directory.name)[:64],
            "imported": bool(imported),
        }, ensure_ascii=False, indent=2),
    )


class DedicatedRoomServer:
    def __init__(
        self,
        profile: Profile,
        *,
        ram_mb: int = 2048,
        port: int = 25565,
        java_path: str = "",
        world_id: str = "",
        world_name: str = "",
        create_world: bool = False,
        hardcore: bool = False,
        selected_mods: list[str] | None = None,
    ):
        if not re.fullmatch(r"[A-Za-z0-9_-]{1,64}", str(profile.id)):
            raise RoomServerError("El perfil no tiene un identificador seguro.")
        if not str(profile.version).strip():
            raise RoomServerError("El perfil no tiene una versión de Minecraft.")
        self.profile = profile
        self.ram_mb = max(1024, min(int(ram_mb), 32768))
        self.port = int(port)
        if not 1 <= self.port <= 65535:
            raise RoomServerError("El puerto debe estar entre 1 y 65535.")
        self.java_path = str(java_path or "")
        self.directory = ROOM_ROOT / profile.id / _safe_version(profile.version)
        self.world_id = str(world_id or "").strip()
        self.world_name = str(world_name or "Nuevo mundo Kat").strip()[:64]
        self.create_world = bool(create_world)
        self.hardcore = bool(hardcore)
        self.selected_mods = (
            {_validate_mod_filename(value) for value in selected_mods}
            if selected_mods is not None else None
        )
        self.world_root = self.directory / "worlds"
        self.world_folder = ""
        self.jar_path = self.directory / "server.jar"
        self.launch_jar = self.jar_path
        self.run_script: Path | None = None
        self.process: subprocess.Popen | None = None
        self._stop_lock = threading.Lock()

    @property
    def advertised_host(self) -> str:
        return lan_address()

    def prepare(self, *, status_cb=None) -> Path:
        requested_port = self.port
        self.port = available_room_port(requested_port)
        if self.port != requested_port and status_cb:
            status_cb(
                f"El puerto {requested_port} estaba ocupado; "
                f"se usará automáticamente el {self.port}."
            )
        self.directory.mkdir(parents=True, exist_ok=True)
        self._prepare_world(status_cb=status_cb)
        if status_cb:
            status_cb("Preparando Java para la sala…")
        self.java_path = launcher_core.ensure_compatible_java(
            self.profile,
            self.java_path,
            status_cb=status_cb,
        )
        if status_cb:
            status_cb("Preparando servidor dedicado de Minecraft…")
        loader = str(self.profile.loader or "vanilla").lower()
        if loader == "vanilla":
            _ensure_server_jar(self.profile.version, self.jar_path)
            self.launch_jar = self.jar_path
        else:
            if status_cb:
                status_cb(
                    f"Instalando servidor {loader.title()} "
                    f"{self.profile.loader_version or 'automático'}…"
                )
            self._prepare_modded_server(loader)
            self._sync_profile_mods()
        _write_text_atomic(self.directory / "eula.txt", "eula=true\n")
        properties = "\n".join((
            "# Generado por KatLauncher",
            "allow-flight=true",
            "difficulty=normal",
            "enable-command-block=false",
            "enable-query=false",
            "enable-rcon=false",
            "enforce-secure-profile=false",
            "force-gamemode=false",
            "gamemode=survival",
            f"hardcore={'true' if self.hardcore else 'false'}",
            f"level-name={self.world_folder}",
            "max-players=8",
            "motd=Sala LAN de KatLauncher",
            "online-mode=false",
            "player-idle-timeout=0",
            f"server-port={self.port}",
            "server-ip=",
            "simulation-distance=6",
            "spawn-protection=0",
            "view-distance=8",
            "white-list=false",
            "",
        ))
        _write_text_atomic(self.directory / "server.properties", properties)
        return self.jar_path

    def _prepare_world(self, *, status_cb=None):
        """Prepara una copia segura de un mundo sin tocar el guardado original."""
        self.world_root.mkdir(parents=True, exist_ok=True)
        if self.create_world or not self.world_id:
            base = _safe_world_folder(self.world_name or "Nuevo mundo Kat")
            candidate = base
            suffix = 2
            while (self.world_root / candidate).exists():
                candidate = f"{base}-{suffix}"
                suffix += 1
            self.world_folder = candidate
            target = self.world_root / candidate
            target.mkdir(parents=True, exist_ok=False)
            _write_world_marker(target, self.world_name or candidate, False)
            return

        kind, separator, raw_name = self.world_id.partition(":")
        if not separator or kind not in ("save", "room"):
            raise RoomServerError("El mundo seleccionado no es válido.")
        safe_name = _validate_world_child(raw_name)
        if kind == "room":
            target = self.world_root / safe_name
            if not target.is_dir():
                raise RoomServerError("El mundo de servidor seleccionado ya no existe.")
            self.world_folder = safe_name
            return

        source_root = Path(self.profile.game_dir) / "saves"
        source = source_root / safe_name
        try:
            if source.resolve().parent != source_root.resolve():
                raise RoomServerError("La ruta del mundo no es segura.")
        except OSError as error:
            raise RoomServerError("No se pudo abrir el mundo seleccionado.") from error
        if not source.is_dir() or not (source / "level.dat").is_file():
            raise RoomServerError("El mundo seleccionado ya no existe.")
        imported = "save-" + hashlib.sha1(
            safe_name.encode("utf-8", errors="replace")
        ).hexdigest()[:12]
        target = self.world_root / imported
        if not target.exists():
            if status_cb:
                status_cb(f"Creando copia segura del mundo {self.world_name or safe_name}…")
            try:
                shutil.copytree(
                    source, target,
                    ignore=shutil.ignore_patterns("session.lock"),
                )
            except OSError as error:
                shutil.rmtree(target, ignore_errors=True)
                raise RoomServerError(
                    f"No se pudo copiar el mundo seleccionado: {error}"
                ) from error
            _write_world_marker(target, self.world_name or safe_name, True)
        self.world_folder = imported

    def start(self) -> subprocess.Popen:
        if self.run_script is None and not self.launch_jar.is_file():
            raise RoomServerError("El servidor todavía no está preparado.")
        java = _console_java(self.java_path)
        if self.run_script is not None:
            _write_text_atomic(
                self.directory / "user_jvm_args.txt",
                f"-Xms{min(1024, self.ram_mb)}M\n-Xmx{self.ram_mb}M\n",
            )
            if os.name == "nt":
                command = [
                    os.environ.get("COMSPEC", "cmd.exe"), "/d", "/s", "/c",
                    str(self.run_script), "nogui", "--universe", str(self.world_root),
                ]
            else:
                command = [
                    "/bin/sh", str(self.run_script), "nogui",
                    "--universe", str(self.world_root),
                ]
        else:
            command = [
                java,
                f"-Xms{min(1024, self.ram_mb)}M",
                f"-Xmx{self.ram_mb}M",
                "-jar",
                str(self.launch_jar),
                "nogui", "--universe", str(self.world_root),
            ]
        options = {
            "cwd": str(self.directory),
            "stdin": subprocess.PIPE,
            "stdout": subprocess.PIPE,
            "stderr": subprocess.STDOUT,
            "text": True,
            "encoding": "utf-8",
            "errors": "replace",
            "bufsize": 1,
        }
        if hasattr(subprocess, "CREATE_NO_WINDOW"):
            options["creationflags"] = subprocess.CREATE_NO_WINDOW
            startupinfo = subprocess.STARTUPINFO()
            startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            startupinfo.wShowWindow = subprocess.SW_HIDE
            options["startupinfo"] = startupinfo
        try:
            self.process = subprocess.Popen(command, **options)
        except OSError as error:
            raise RoomServerError(f"No se pudo iniciar el servidor: {error}") from error
        return self.process

    def _prepare_modded_server(self, loader: str):
        loader_version = str(self.profile.loader_version or "").strip()
        if loader == "fabric":
            installer_version = _latest_maven_version(FABRIC_INSTALLER_METADATA)
            installer = self.directory / f"fabric-installer-{installer_version}.jar"
            _download_installer(
                "https://maven.fabricmc.net/net/fabricmc/fabric-installer/"
                f"{installer_version}/fabric-installer-{installer_version}.jar",
                installer,
            )
            command = [
                _console_java(self.java_path), "-jar", str(installer), "server",
                "-dir", str(self.directory), "-mcversion", self.profile.version,
                "-downloadMinecraft",
            ]
            if loader_version:
                command.extend(("-loader", loader_version))
            _run_installer(command, self.directory)
            self.launch_jar = self.directory / "fabric-server-launch.jar"
        elif loader == "quilt":
            installer_version = _latest_maven_version(QUILT_INSTALLER_METADATA)
            installer = self.directory / f"quilt-installer-{installer_version}.jar"
            _download_installer(
                "https://maven.quiltmc.org/repository/release/org/quiltmc/"
                f"quilt-installer/{installer_version}/"
                f"quilt-installer-{installer_version}.jar",
                installer,
            )
            command = [
                _console_java(self.java_path), "-jar", str(installer),
                "install", "server", self.profile.version,
                "--install-dir=" + str(self.directory), "--download-server",
            ]
            if loader_version:
                command.append("--loader-version=" + loader_version)
            _run_installer(command, self.directory)
            nested = self.directory / "server" / "quilt-server-launch.jar"
            self.launch_jar = (
                nested if nested.is_file()
                else self.directory / "quilt-server-launch.jar"
            )
        elif loader in ("forge", "neoforge"):
            if not loader_version:
                raise RoomServerError(
                    f"El servidor {loader.title()} necesita una versión del loader."
                )
            if loader == "forge":
                artifact = f"{self.profile.version}-{loader_version}"
                url = (
                    "https://maven.minecraftforge.net/net/minecraftforge/forge/"
                    f"{artifact}/forge-{artifact}-installer.jar"
                )
            else:
                artifact = loader_version
                url = (
                    "https://maven.neoforged.net/releases/net/neoforged/neoforge/"
                    f"{artifact}/neoforge-{artifact}-installer.jar"
                )
            installer = self.directory / f"{loader}-{artifact}-installer.jar"
            _download_installer(url, installer)
            _run_installer([
                _console_java(self.java_path), "-jar", str(installer),
                "--installServer",
            ], self.directory)
            script = self.directory / ("run.bat" if os.name == "nt" else "run.sh")
            if not script.is_file():
                raise RoomServerError(
                    f"El instalador de {loader.title()} no generó el arranque."
                )
            self.run_script = script
        else:
            raise RoomServerError(f"Loader de servidor no compatible: {loader}")
        if self.run_script is None and not self.launch_jar.is_file():
            raise RoomServerError(
                f"El instalador de {loader.title()} no generó el servidor."
            )

    def _sync_profile_mods(self):
        source = Path(self.profile.mods_dir)
        destination = self.directory / "mods"
        destination.mkdir(parents=True, exist_ok=True)
        manifest_path = self.directory / ".katlauncher-managed-mods.json"
        try:
            old = json.loads(manifest_path.read_text(encoding="utf-8"))
        except (OSError, ValueError, json.JSONDecodeError):
            old = []
        for name in old if isinstance(old, list) else []:
            if re.fullmatch(r"[^/\\]{1,180}\.jar", str(name), re.IGNORECASE):
                (destination / str(name)).unlink(missing_ok=True)
        managed = []
        if source.is_dir():
            for item in source.iterdir():
                if not item.is_file() or item.suffix.lower() != ".jar":
                    continue
                if _client_only_mod(item):
                    continue
                if self.selected_mods is not None and item.name not in self.selected_mods:
                    continue
                shutil.copy2(item, destination / item.name)
                managed.append(item.name)
        _write_text_atomic(
            manifest_path,
            json.dumps(sorted(managed), ensure_ascii=False, indent=2),
        )

    def stop(self):
        with self._stop_lock:
            process = self.process
            if process is None or process.poll() is not None:
                return
            try:
                process.stdin.write("stop\n")
                process.stdin.flush()
            except (OSError, AttributeError):
                try:
                    process.terminate()
                except OSError:
                    pass

    def send_command(self, command: str):
        command = str(command or "").strip()
        if not command or len(command) > 200 or any(
            value in command for value in ("\r", "\n", "\x00")
        ):
            raise RoomServerError("Comando de consola no válido.")
        with self._stop_lock:
            process = self.process
            if process is None or process.poll() is not None or process.stdin is None:
                raise RoomServerError("La sala no está en ejecución.")
            try:
                process.stdin.write(command + "\n")
                process.stdin.flush()
            except OSError as error:
                raise RoomServerError(
                    "No se pudo enviar el comando a la sala."
                ) from error


def _latest_maven_version(metadata_url: str) -> str:
    try:
        response = requests.get(_trusted_url(metadata_url), timeout=(10, 30))
        response.raise_for_status()
        root = ET.fromstring(response.content)
        value = root.findtext("./versioning/release") \
            or root.findtext("./versioning/latest")
    except (requests.RequestException, ET.ParseError) as error:
        raise RoomServerError(
            f"No se pudo consultar la versión del instalador: {error}"
        ) from error
    if not value or not re.fullmatch(r"[0-9A-Za-z._+-]{1,64}", value):
        raise RoomServerError("El repositorio devolvió una versión no válida.")
    return value


def _download_installer(url: str, destination: Path):
    if destination.is_file():
        try:
            with zipfile.ZipFile(destination) as archive:
                if "META-INF/MANIFEST.MF" in archive.namelist():
                    return
        except (OSError, zipfile.BadZipFile):
            destination.unlink(missing_ok=True)
    temporary = destination.with_suffix(destination.suffix + ".part")
    temporary.unlink(missing_ok=True)
    downloaded = 0
    try:
        with requests.get(_trusted_url(url), stream=True, timeout=(10, 90)) as response:
            response.raise_for_status()
            with temporary.open("wb") as stream:
                for chunk in response.iter_content(256 * 1024):
                    if not chunk:
                        continue
                    downloaded += len(chunk)
                    if downloaded > MAX_SERVER_JAR_BYTES:
                        raise RoomServerError("El instalador excedió el límite permitido.")
                    stream.write(chunk)
        if downloaded < 1024:
            raise RoomServerError("El instalador descargado está incompleto.")
        with zipfile.ZipFile(temporary) as archive:
            if "META-INF/MANIFEST.MF" not in archive.namelist():
                raise RoomServerError("El archivo descargado no es un instalador Java.")
        os.replace(temporary, destination)
    except (requests.RequestException, OSError, zipfile.BadZipFile) as error:
        raise RoomServerError(f"No se pudo descargar el instalador: {error}") from error
    finally:
        temporary.unlink(missing_ok=True)


def _run_installer(command: list[str], directory: Path):
    options = {
        "cwd": str(directory),
        "capture_output": True,
        "text": True,
        "encoding": "utf-8",
        "errors": "replace",
        "timeout": 600,
    }
    if hasattr(subprocess, "CREATE_NO_WINDOW"):
        options["creationflags"] = subprocess.CREATE_NO_WINDOW
    try:
        result = subprocess.run(command, **options)
    except (OSError, subprocess.TimeoutExpired) as error:
        raise RoomServerError(f"Falló el instalador del servidor: {error}") from error
    if result.returncode:
        detail = (result.stderr or result.stdout or "").strip()[-1200:]
        raise RoomServerError(
            "El instalador del loader terminó con error"
            + (": " + detail if detail else ".")
        )


def _client_only_mod(path: Path) -> bool:
    """Evita copiar al servidor jars declarados explícitamente como cliente."""
    filename = path.name.casefold()
    known_client = (
        "iris", "sodium", "modmenu", "mod-menu", "controlify",
        "entityculling", "entity-culling", "dynamic-fps", "betterf3",
        "notenoughanimations", "lambdynamiclights", "continuity",
        "reeses-sodium-options", "sodium-extra", "zoomify",
    )
    if any(marker in filename for marker in known_client):
        return True
    try:
        with zipfile.ZipFile(path) as archive:
            for metadata in ("fabric.mod.json", "quilt.mod.json"):
                try:
                    value = json.loads(archive.read(metadata).decode("utf-8"))
                except KeyError:
                    continue
                environment = str(
                    value.get("environment")
                    or value.get("quilt_loader", {}).get("metadata", {})
                    .get("environment")
                    or ""
                ).lower()
                if environment == "client":
                    return True
    except (OSError, ValueError, zipfile.BadZipFile, UnicodeDecodeError):
        return False
    return False


def _validate_mod_filename(value: str) -> str:
    clean = str(value or "").strip()
    if not re.fullmatch(r"[^/\\\x00]{1,180}\.jar", clean, re.IGNORECASE):
        raise RoomServerError("La selección de mods contiene un archivo no válido.")
    return clean


def _ensure_server_jar(version: str, destination: Path):
    sha_path = destination.with_suffix(".jar.sha1")
    if destination.is_file() and sha_path.is_file():
        expected = sha_path.read_text(encoding="ascii").strip().lower()
        if re.fullmatch(r"[0-9a-f]{40}", expected) \
                and _sha1(destination) == expected:
            return

    manifest = _get_json(MANIFEST_URL)
    versions = manifest.get("versions") if isinstance(manifest, dict) else None
    item = next((
        value for value in (versions if isinstance(versions, list) else [])
        if isinstance(value, dict) and value.get("id") == version
    ), None)
    if not item:
        raise RoomServerError(
            f"Mojang no ofrece un servidor dedicado para Minecraft {version}."
        )
    metadata_url = _trusted_url(item.get("url"))
    metadata = _get_json(metadata_url)
    downloads = metadata.get("downloads") if isinstance(metadata, dict) else None
    server = downloads.get("server") if isinstance(downloads, dict) else None
    if not isinstance(server, dict):
        raise RoomServerError(
            f"Minecraft {version} no incluye un servidor dedicado descargable."
        )
    url = _trusted_url(server.get("url"))
    expected = str(server.get("sha1") or "").lower()
    size = int(server.get("size") or 0)
    if not re.fullmatch(r"[0-9a-f]{40}", expected):
        raise RoomServerError("Mojang devolvió una firma de servidor inválida.")
    if not 1 <= size <= MAX_SERVER_JAR_BYTES:
        raise RoomServerError("El tamaño del servidor está fuera del límite permitido.")

    temporary = destination.with_suffix(".jar.part")
    temporary.unlink(missing_ok=True)
    digest = hashlib.sha1()
    downloaded = 0
    try:
        with requests.get(url, stream=True, timeout=(10, 60)) as response:
            response.raise_for_status()
            with temporary.open("wb") as stream:
                for chunk in response.iter_content(256 * 1024):
                    if not chunk:
                        continue
                    downloaded += len(chunk)
                    if downloaded > MAX_SERVER_JAR_BYTES:
                        raise RoomServerError("La descarga del servidor excedió el límite.")
                    digest.update(chunk)
                    stream.write(chunk)
        if downloaded != size or digest.hexdigest() != expected:
            raise RoomServerError("La firma del servidor descargado no coincide.")
        os.replace(temporary, destination)
        _write_text_atomic(sha_path, expected + "\n", encoding="ascii")
    finally:
        temporary.unlink(missing_ok=True)


def _get_json(url: str) -> dict:
    try:
        response = requests.get(_trusted_url(url), timeout=(10, 30))
        response.raise_for_status()
        value = response.json()
    except (requests.RequestException, ValueError) as error:
        raise RoomServerError(f"No se pudo consultar a Mojang: {error}") from error
    if not isinstance(value, dict):
        raise RoomServerError("Mojang devolvió una respuesta inválida.")
    return value


def _trusted_url(value) -> str:
    url = str(value or "")
    parsed = urlparse(url)
    if parsed.scheme != "https" or parsed.hostname not in ALLOWED_DOWNLOAD_HOSTS:
        raise RoomServerError("Mojang devolvió una URL de descarga no confiable.")
    return url


def _sha1(path: Path) -> str:
    digest = hashlib.sha1()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(256 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _write_text_atomic(path: Path, value: str, *, encoding: str = "utf-8"):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(value, encoding=encoding)
    os.replace(temporary, path)


def _safe_version(value: str) -> str:
    safe = re.sub(r"[^A-Za-z0-9._-]", "_", str(value))[:80]
    if not safe or safe in (".", ".."):
        raise RoomServerError("La versión de Minecraft no es válida.")
    return safe


def _console_java(value: str) -> str:
    path = Path(value)
    if path.name.lower() == "javaw.exe":
        console = path.with_name("java.exe")
        if console.is_file():
            return str(console)
    return str(path)
