"""Selección e instalación transaccional de la variante correcta de KatCraft."""
from __future__ import annotations

import os
import shutil
import uuid
from dataclasses import dataclass
from pathlib import Path


ASSET_ROOT = Path(__file__).resolve().parent.parent / "assets" / "katcraft"


@dataclass(frozen=True)
class KatCraftArtifact:
    filename: str
    loaders: tuple[str, ...]
    minecraft_versions: tuple[str, ...]


ARTIFACTS = (
    KatCraftArtifact(
        "KatCraft-fabric-1.21.1-1.5.2.jar",
        ("fabric", "quilt"),
        ("1.21.1",),
    ),
    KatCraftArtifact(
        "KatCraft-fabric-26.2-1.5.2.jar",
        ("fabric", "quilt"),
        ("26.2",),
    ),
    KatCraftArtifact(
        "KatCraft-forge-1.20.1-1.5.2.jar",
        ("forge",),
        ("1.20.1",),
    ),
    KatCraftArtifact(
        "KatCraft-neoforge-1.21.1-1.5.2.jar",
        ("neoforge",),
        ("1.21.1",),
    ),
)


def select_artifact(loader: str, minecraft_version: str) -> KatCraftArtifact | None:
    loader = str(loader or "").lower()
    minecraft_version = str(minecraft_version or "")
    return next(
        (
            item for item in ARTIFACTS
            if loader in item.loaders and minecraft_version in item.minecraft_versions
        ),
        None,
    )


def ensure_katcraft(profile) -> str | None:
    artifact = select_artifact(profile.loader, profile.version)
    if artifact is None:
        return None
    source = ASSET_ROOT / artifact.filename
    if not source.is_file() or source.stat().st_size < 1024:
        raise OSError(f"Falta el artefacto incluido {artifact.filename}.")
    mods = Path(profile.mods_dir)
    mods.mkdir(parents=True, exist_ok=True)
    destination = mods / artifact.filename
    if destination.is_file() and destination.stat().st_size == source.stat().st_size:
        return str(destination)

    temporary = mods / f".{artifact.filename}.{uuid.uuid4().hex}.tmp"
    try:
        shutil.copy2(source, temporary)
        os.replace(temporary, destination)
    finally:
        temporary.unlink(missing_ok=True)

    for path in mods.glob("KatCraft-*.jar"):
        if path.name != destination.name:
            path.unlink(missing_ok=True)
    return str(destination)


def katcraft_installed(profile) -> bool:
    artifact = select_artifact(profile.loader, profile.version)
    return bool(artifact and (Path(profile.mods_dir) / artifact.filename).is_file())
