"""
Gestión de skins locales por perfil.

Importante: en modo offline (sin cuenta Microsoft) el cliente vanilla de
Minecraft NO puede descargar ni mostrar skins personalizadas por sí solo.
Para eso usamos el mod CustomSkinLoader — pero OJO: por defecto ese mod
busca tu skin **por nickname** en Mojang y en varios servidores de
terceros (littleservice.cn, prinzeugen.net, skinme.cc) ANTES de mirar tu
carpeta local. Si tu nickname coincide con el de una cuenta real que
tiene una skin puesta (por ejemplo, una skin de Jack Black/Steve por la
película de Minecraft), CustomSkinLoader te mostrará ESA skin ajena en
vez de la tuya.

Para evitarlo, cuando activamos una skin reescribimos
CustomSkinLoader.json para que el único origen de skins sea la carpeta
local del propio perfil, eliminando cualquier búsqueda online.
"""
from __future__ import annotations

import json
import base64
import os
import re
import shutil
import uuid
from dataclasses import dataclass
from pathlib import Path

import requests
from PySide6.QtGui import QImage

from .profile_manager import validate_nickname


_MOJANG_USERNAME = re.compile(r"^[A-Za-z0-9_]{1,16}$")
_PNG_SIGNATURE = b"\x89PNG\r\n\x1a\n"
MAX_REMOTE_SKIN_BYTES = 2 * 1024 * 1024


@dataclass
class SkinInfo:
    filename: str
    path: str


@dataclass
class NicknameSkinMigration:
    old_path: Path
    new_path: Path
    backup_path: Path | None = None
    same_path: bool = False

    def rollback(self):
        if self.same_path:
            return
        self.new_path.unlink(missing_ok=True)
        if self.backup_path and self.backup_path.exists():
            os.replace(self.backup_path, self.new_path)

    def commit(self):
        if not self.same_path:
            self.old_path.unlink(missing_ok=True)
        if self.backup_path:
            self.backup_path.unlink(missing_ok=True)


def list_skins(skins_dir: str) -> list[SkinInfo]:
    skins = []
    for f in sorted(Path(skins_dir).iterdir()):
        if f.is_file() and f.suffix.lower() == ".png" and f.name != "active_skin.png":
            skins.append(SkinInfo(filename=f.name, path=str(f)))
    return skins


def add_skin(skins_dir: str, source_path: str) -> str:
    src = Path(source_path)
    if src.suffix.lower() != ".png":
        raise ValueError("La skin debe ser un archivo .png")
    dest = Path(skins_dir) / src.name
    if src.resolve() == dest.resolve():
        return str(dest)
    shutil.copy2(src, dest)
    return str(dest)


def download_skin_by_username(
    skins_dir: str, username: str, *, session: requests.Session | None = None,
) -> str:
    """Copia la skin pública de un usuario usando las APIs oficiales Mojang.

    NameMC se abre como catálogo desde la interfaz, pero no se raspa ni se usa
    como API privada. La textura final siempre procede de textures.minecraft.net.
    """

    username = str(username or "").strip()
    if not _MOJANG_USERNAME.fullmatch(username):
        raise ValueError("El usuario debe tener entre 1 y 16 letras, números o guion bajo.")
    client = session or requests.Session()
    profile_response = client.get(
        f"https://api.mojang.com/users/profiles/minecraft/{username}", timeout=10,
    )
    if profile_response.status_code in (204, 404):
        raise ValueError("No se encontró ese usuario de Minecraft.")
    profile_response.raise_for_status()
    profile = profile_response.json()
    profile_id = str(profile.get("id") or "")
    canonical_name = str(profile.get("name") or username)
    if not re.fullmatch(r"[0-9a-fA-F]{32}", profile_id):
        raise ValueError("Mojang devolvió un perfil no válido.")

    textures_response = client.get(
        f"https://sessionserver.mojang.com/session/minecraft/profile/{profile_id}",
        timeout=10,
    )
    textures_response.raise_for_status()
    properties = textures_response.json().get("properties") or []
    encoded = next(
        (item.get("value") for item in properties if item.get("name") == "textures"),
        "",
    )
    try:
        textures = json.loads(base64.b64decode(encoded, validate=True).decode("utf-8"))
        skin_url = str(textures["textures"]["SKIN"]["url"])
    except (KeyError, TypeError, ValueError, UnicodeDecodeError, json.JSONDecodeError) as error:
        raise ValueError("Ese usuario no tiene una skin pública disponible.") from error
    if not skin_url.startswith("https://textures.minecraft.net/texture/"):
        raise ValueError("Mojang devolvió una URL de skin no segura.")

    skin_response = client.get(skin_url, timeout=15)
    skin_response.raise_for_status()
    payload = skin_response.content
    if not payload.startswith(_PNG_SIGNATURE) or not 1 <= len(payload) <= MAX_REMOTE_SKIN_BYTES:
        raise ValueError("La skin descargada no es un PNG válido.")
    directory = Path(skins_dir)
    directory.mkdir(parents=True, exist_ok=True)
    destination = directory / f"{canonical_name}.png"
    temporary = destination.with_suffix(".png.tmp")
    try:
        temporary.write_bytes(payload)
        os.replace(temporary, destination)
    finally:
        temporary.unlink(missing_ok=True)
    return str(destination)


def remove_skin(skin_path: str):
    p = Path(skin_path)
    if p.exists():
        p.unlink()


def set_active_skin(skins_dir: str, skin_path: str) -> str:
    """Copia la skin elegida como 'active_skin.png' dentro de la carpeta de
    skins de la instancia (solo para vista previa/gestión interna)."""
    dest = Path(skins_dir) / "active_skin.png"
    src = Path(skin_path)
    if src.resolve() == dest.resolve():
        return str(dest)
    shutil.copy2(src, dest)
    return str(dest)


def clear_active_skin(skins_dir: str, game_dir: str, nickname: str):
    """Retira tanto la copia interna como la que consume CustomSkinLoader."""
    validate_nickname(nickname)
    paths = (
        Path(skins_dir) / "active_skin.png",
        _csl_dir(game_dir) / "LocalSkin" / "skins" / f"{nickname}.png",
    )
    first_error = None
    for path in paths:
        try:
            path.unlink(missing_ok=True)
        except OSError as error:
            first_error = first_error or error
    if first_error is not None:
        raise first_error


# --------------------------------------------------------------------
# Integración real con CustomSkinLoader
# --------------------------------------------------------------------

def _csl_dir(game_dir: str) -> Path:
    return Path(game_dir) / "CustomSkinLoader"


def _kat_loadlist(shared_skin_root: str = "") -> list[dict]:
    """KatSkin compartido primero y copia local como respaldo sin conexión."""
    loadlist = []
    shared_skin_root = str(shared_skin_root or "").rstrip("/")
    if shared_skin_root:
        if not shared_skin_root.startswith("https://"):
            raise ValueError("La dirección de KatSkin debe usar HTTPS.")
        loadlist.append({
            "name": "KatSkin",
            "type": "Legacy",
            "checkPNG": True,
            "skin": f"{shared_skin_root}/{{USERNAME}}.png",
            "model": "auto",
        })
    loadlist.append({
            "name": "KatLauncherLocal",
            "type": "Legacy",
            "checkPNG": False,
            "skin": "LocalSkin/skins/{USERNAME}.png",
            "model": "auto",
            "cape": "LocalSkin/capes/{USERNAME}.png",
            "elytra": "LocalSkin/elytras/{USERNAME}.png",
    })
    return loadlist


def _local_only_loadlist() -> list[dict]:
    """Compatibilidad con extensiones y pruebas anteriores."""
    return _kat_loadlist()


def install_local_skin_for_profile(
    game_dir: str, nickname: str, skin_source_path: str,
    shared_skin_root: str = "",
) -> str:
    """Instala una skin para que CustomSkinLoader la use de forma 100% local:
      1. La copia a CustomSkinLoader/LocalSkin/skins/<nickname>.png
      2. Reescribe CustomSkinLoader.json para que SOLO use esa carpeta local,
         evitando que el mod consulte Mojang u otros servidores por nickname.
    Devuelve la ruta final del archivo de skin instalado.
    """
    validate_nickname(nickname)
    csl_dir = _csl_dir(game_dir)
    skins_subdir = csl_dir / "LocalSkin" / "skins"
    skins_subdir.mkdir(parents=True, exist_ok=True)
    (csl_dir / "LocalSkin" / "capes").mkdir(parents=True, exist_ok=True)
    (csl_dir / "LocalSkin" / "elytras").mkdir(parents=True, exist_ok=True)

    dest = skins_subdir / f"{nickname}.png"
    src = Path(skin_source_path)
    if src.resolve() != dest.resolve():
        temporary = dest.with_name(f".{dest.name}.{uuid.uuid4().hex}.tmp")
        try:
            shutil.copy2(src, temporary)
            os.replace(temporary, dest)
        finally:
            temporary.unlink(missing_ok=True)

    configure_shared_skin_source(game_dir, shared_skin_root)
    return str(dest)


def configure_shared_skin_source(game_dir: str, shared_skin_root: str = "") -> str:
    """Mantiene KatSkin compartido primero y la copia local como respaldo."""
    csl_dir = _csl_dir(game_dir)
    csl_dir.mkdir(parents=True, exist_ok=True)
    (csl_dir / "LocalSkin" / "skins").mkdir(parents=True, exist_ok=True)
    (csl_dir / "LocalSkin" / "capes").mkdir(parents=True, exist_ok=True)
    (csl_dir / "LocalSkin" / "elytras").mkdir(parents=True, exist_ok=True)
    config_path = csl_dir / "CustomSkinLoader.json"
    config = {}
    if config_path.exists():
        try:
            config = json.loads(config_path.read_text(encoding="utf-8"))
        except Exception:
            config = {}

    config["enable"] = True
    config["loadlist"] = _kat_loadlist(shared_skin_root)
    config.setdefault("enableDynamicSkull", True)
    config.setdefault("enableTransparentSkin", True)
    config.setdefault("enableCape", True)

    temp_path = config_path.with_suffix(".json.tmp")
    temp_path.write_text(json.dumps(config, indent=2, ensure_ascii=False), encoding="utf-8")
    os.replace(temp_path, config_path)
    return str(config_path)


def install_local_cosmetic_for_profile(
    game_dir: str, nickname: str, source_path: str, cosmetic: str,
) -> str:
    """Instala una capa o élitros locales consumidos por CustomSkinLoader."""
    validate_nickname(nickname)
    cosmetic = str(cosmetic or "").lower()
    folders = {"cape": "capes", "elytra": "elytras"}
    if cosmetic not in folders:
        raise ValueError("El cosmético debe ser una capa o unos élitros.")
    source = Path(source_path)
    if not source.is_file() or source.stat().st_size > 8 * 1024 * 1024:
        raise ValueError("El cosmético no existe o supera 8 MB.")
    image = QImage(str(source))
    return _install_local_cosmetic_image(game_dir, nickname, image, cosmetic)


def install_local_cosmetic_data_for_profile(
    game_dir: str, nickname: str, payload: bytes, cosmetic: str,
) -> str:
    """Instala directamente una textura descargada, sin archivo temporal externo."""
    return _install_local_cosmetic_image(
        game_dir, nickname, QImage.fromData(payload), cosmetic
    )


def _install_local_cosmetic_image(
    game_dir: str, nickname: str, image: QImage, cosmetic: str,
) -> str:
    validate_nickname(nickname)
    cosmetic = str(cosmetic or "").lower()
    folders = {"cape": "capes", "elytra": "elytras"}
    if cosmetic not in folders:
        raise ValueError("El cosmético debe ser una capa o unos élitros.")
    if image.isNull() or image.width() < 8 or image.height() < 8 \
            or image.width() > 1024 or image.height() > 1024:
        raise ValueError(
            "El cosmético no es una imagen compatible o sus dimensiones no son válidas."
        )

    csl_dir = _csl_dir(game_dir)
    destination_dir = csl_dir / "LocalSkin" / folders[cosmetic]
    destination_dir.mkdir(parents=True, exist_ok=True)
    destination = destination_dir / f"{nickname}.png"
    temporary = destination.with_name(f".{destination.name}.{uuid.uuid4().hex}.tmp")
    try:
        if not image.save(str(temporary), "PNG"):
            raise ValueError("No se pudo convertir el cosmético a PNG.")
        os.replace(temporary, destination)
    finally:
        temporary.unlink(missing_ok=True)

    config_path = csl_dir / "CustomSkinLoader.json"
    try:
        config = json.loads(config_path.read_text(encoding="utf-8")) \
            if config_path.exists() else {}
    except (OSError, ValueError, TypeError):
        config = {}
    config["enable"] = True
    config["enableCape"] = True
    existing_loadlist = config.get("loadlist")
    if not isinstance(existing_loadlist, list) or not any(
        isinstance(item, dict) and item.get("name") == "KatSkin"
        for item in existing_loadlist
    ):
        config["loadlist"] = _local_only_loadlist()
    config.setdefault("enableDynamicSkull", True)
    config.setdefault("enableTransparentSkin", True)
    config_path.parent.mkdir(parents=True, exist_ok=True)
    temporary_config = config_path.with_suffix(".json.tmp")
    try:
        temporary_config.write_text(
            json.dumps(config, indent=2, ensure_ascii=False), encoding="utf-8"
        )
        os.replace(temporary_config, config_path)
    finally:
        temporary_config.unlink(missing_ok=True)
    return str(destination)


def remove_local_cosmetic(game_dir: str, nickname: str, cosmetic: str) -> None:
    validate_nickname(nickname)
    folders = {"cape": "capes", "elytra": "elytras"}
    try:
        folder = folders[str(cosmetic or "").lower()]
    except KeyError as error:
        raise ValueError("El cosmético debe ser una capa o unos élitros.") from error
    (_csl_dir(game_dir) / "LocalSkin" / folder / f"{nickname}.png").unlink(
        missing_ok=True
    )


def stage_nickname_skin_migration(
    game_dir: str,
    old_nickname: str,
    new_nickname: str,
    skin_source_path: str,
) -> NicknameSkinMigration | None:
    """Prepara la skin del nick nuevo y conserva rollback hasta guardar perfil."""
    validate_nickname(old_nickname)
    validate_nickname(new_nickname)
    if old_nickname == new_nickname or not skin_source_path:
        return None
    skins_dir = _csl_dir(game_dir) / "LocalSkin" / "skins"
    old_path = skins_dir / f"{old_nickname}.png"
    new_path = skins_dir / f"{new_nickname}.png"
    old_key = os.path.normcase(os.path.abspath(old_path))
    new_key = os.path.normcase(os.path.abspath(new_path))
    if os.name == "nt" and old_key.casefold() == new_key.casefold():
        return NicknameSkinMigration(old_path, new_path, same_path=True)

    backup = None
    if new_path.exists():
        backup = new_path.with_name(f".{new_path.name}.{uuid.uuid4().hex}.bak")
        os.replace(new_path, backup)
    migration = NicknameSkinMigration(old_path, new_path, backup)
    try:
        install_local_skin_for_profile(game_dir, new_nickname, skin_source_path)
    except Exception:
        migration.rollback()
        raise
    return migration
