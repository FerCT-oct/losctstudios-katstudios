"""
Gestión de perfiles de KatLauncher.
Cada perfil guarda: nombre, nickname, versión de Minecraft, mod loader
(vanilla/fabric/forge), directorio de juego, ruta de skin local,
argumentos de memoria/JVM y carpeta de mods propia.
"""
from __future__ import annotations

import json
import hashlib
import os
import re
import shutil
import uuid
from dataclasses import dataclass, asdict, fields
from pathlib import Path
from typing import Optional


APP_DIR = Path.home() / ".katlauncher"
PROFILES_FILE = APP_DIR / "profiles.json"
GAME_ROOT = APP_DIR / "instances"  # cada perfil tiene su propia carpeta .minecraft


@dataclass
class Profile:
    id: str
    name: str
    nickname: str
    version: str
    loader: str = "vanilla"           # vanilla | fabric | forge
    loader_version: Optional[str] = None
    min_ram: int = 1024               # MB
    max_ram: int = 2048               # MB
    jvm_args: str = ""
    skin_path: str = ""               # ruta local a un PNG de skin (uso cosmético/local)
    resolution_w: int = 854
    resolution_h: int = 480
    source_type: str = "custom"       # custom | modrinth
    modpack_project_id: str = ""
    modpack_version_id: str = ""
    modpack_version_number: str = ""
    modpack_summary: str = ""
    modpack_icon_url: str = ""
    launch_version_id: str = ""
    offline_uuid_mode: str = "minecraft"  # minecraft | legacy
    server_host: str = ""                  # solo para una conexión directa temporal
    server_port: int = 25565

    @property
    def game_dir(self) -> str:
        d = GAME_ROOT / self.id
        d.mkdir(parents=True, exist_ok=True)
        return str(d)

    @property
    def mods_dir(self) -> str:
        d = Path(self.game_dir) / "mods"
        d.mkdir(parents=True, exist_ok=True)
        return str(d)

    @property
    def skins_dir(self) -> str:
        d = Path(self.game_dir) / "katlauncher_skins"
        d.mkdir(parents=True, exist_ok=True)
        return str(d)


class ProfileManager:
    def __init__(self):
        APP_DIR.mkdir(parents=True, exist_ok=True)
        GAME_ROOT.mkdir(parents=True, exist_ok=True)
        self.profiles: dict[str, Profile] = {}
        self.load()

    def load(self):
        self.profiles = {}
        raw = self._read_profiles_file()
        self._load_profile_records(raw)
        recovered = self._recover_modpack_profiles()
        if not self.profiles:
            # Perfil por defecto para que el usuario tenga algo con qué empezar
            self.create_profile(name="Vanilla", nickname="Jugador", version="")
        elif recovered:
            try:
                self.save()
            except OSError:
                # La instalación recuperada sigue disponible en memoria y se
                # volverá a detectar en el próximo inicio.
                pass

    def _recover_modpack_profiles(self) -> bool:
        """Recupera instalaciones terminadas si el guardado de perfiles falló."""
        recovered = False
        if not GAME_ROOT.exists():
            return False
        try:
            instance_dirs = list(GAME_ROOT.iterdir())
        except OSError:
            return False
        allowed = {item.name for item in fields(Profile)}
        try:
            game_root = GAME_ROOT.resolve()
        except OSError:
            return False
        for instance_dir in instance_dirs:
            try:
                outside_root = instance_dir.resolve().parent != game_root
            except OSError:
                continue
            if instance_dir.is_symlink() or outside_root \
                    or not instance_dir.is_dir() \
                    or not _is_safe_profile_id(instance_dir.name):
                continue
            private_dir = instance_dir / ".katlauncher"
            if (private_dir / "detached").exists():
                continue
            manifest_path = private_dir / "instance.json"
            if not manifest_path.is_file() or any(
                existing.casefold() == instance_dir.name.casefold()
                for existing in self.profiles
            ):
                continue
            try:
                manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
                if not isinstance(manifest, dict):
                    continue
                if manifest.get("schema_version") != 1:
                    continue
                data = manifest.get("profile", {})
                if not isinstance(data, dict):
                    continue
                values = {key: value for key, value in data.items() if key in allowed}
                values["id"] = instance_dir.name
                profile = Profile(**values)
                _normalize_profile(profile)
                validate_nickname(profile.nickname)
                if profile.source_type != "modrinth":
                    continue
                self.profiles[profile.id] = profile
                recovered = True
            except (OSError, ValueError, TypeError, json.JSONDecodeError):
                continue
        return recovered

    def _load_profile_records(self, raw):
        allowed = {item.name for item in fields(Profile)}
        seen_ids = {profile_id.casefold() for profile_id in self.profiles}
        if isinstance(raw, dict):
            for pid, data in raw.items():
                if not isinstance(pid, str) or not isinstance(data, dict):
                    continue
                if pid.casefold() in seen_ids:
                    continue
                try:
                    values = {key: value for key, value in data.items() if key in allowed}
                    values["id"] = pid
                    # Las versiones anteriores usaban uuid3 con namespace DNS.
                    # Se conserva para que mundos/inventarios existentes no cambien de dueño.
                    if "offline_uuid_mode" not in data:
                        values["offline_uuid_mode"] = "legacy"
                    profile = Profile(**values)
                    if not _is_safe_profile_id(profile.id):
                        continue
                    _normalize_profile(profile)
                    try:
                        validate_nickname(profile.nickname)
                    except ValueError:
                        profile.nickname = "Jugador"
                    self.profiles[pid] = profile
                    seen_ids.add(pid.casefold())
                except (TypeError, ValueError):
                    # Un perfil dañado no debe hacer que se pierdan los demás.
                    continue

    def _read_profiles_file(self):
        candidates = (PROFILES_FILE, PROFILES_FILE.with_suffix(".json.bak"))
        for path in candidates:
            if not path.exists():
                continue
            try:
                raw = json.loads(path.read_text(encoding="utf-8"))
                if isinstance(raw, dict):
                    return raw
            except (OSError, ValueError, TypeError, json.JSONDecodeError):
                continue
        return {}

    def save(self):
        data = {pid: asdict(p) for pid, p in self.profiles.items()}
        payload = json.dumps(data, indent=2, ensure_ascii=False)
        temp_file = PROFILES_FILE.with_suffix(".json.tmp")
        backup_file = PROFILES_FILE.with_suffix(".json.bak")
        temp_file.write_text(payload, encoding="utf-8")
        if PROFILES_FILE.exists():
            try:
                current = json.loads(PROFILES_FILE.read_text(encoding="utf-8"))
                if isinstance(current, dict):
                    shutil.copy2(PROFILES_FILE, backup_file)
            except (OSError, ValueError, TypeError, json.JSONDecodeError):
                pass
        os.replace(temp_file, PROFILES_FILE)

    def create_profile(self, name: str, nickname: str, version: str,
                       loader: str = "vanilla", loader_version: Optional[str] = None,
                       profile_id: Optional[str] = None, **kwargs) -> Profile:
        validate_nickname(nickname)
        pid = profile_id or uuid.uuid4().hex[:12]
        if not _is_safe_profile_id(pid):
            raise ValueError("ID de perfil no válido")
        if any(existing.casefold() == pid.casefold() for existing in self.profiles):
            raise ValueError("Ya existe un perfil con ese ID")
        profile = Profile(
            id=pid,
            name=name,
            nickname=nickname,
            version=version,
            loader=loader,
            loader_version=loader_version,
            **kwargs,
        )
        self.register_profile(profile)
        return profile

    def register_profile(self, profile: Profile) -> Profile:
        if not _is_safe_profile_id(profile.id):
            raise ValueError("ID de perfil no válido")
        _normalize_profile(profile)
        validate_nickname(profile.nickname)
        if any(existing.casefold() == profile.id.casefold() for existing in self.profiles):
            raise ValueError("Ya existe un perfil con ese ID")
        self.profiles[profile.id] = profile
        try:
            self.save()
        except Exception:
            self.profiles.pop(profile.id, None)
            raise
        return profile

    def update_profile(self, pid: str, **kwargs) -> Profile:
        profile = self.profiles[pid]
        if "nickname" in kwargs:
            validate_nickname(str(kwargs["nickname"]))
        previous = asdict(profile)
        try:
            for k, v in kwargs.items():
                if k != "id" and hasattr(profile, k):
                    setattr(profile, k, v)
            _normalize_profile(profile)
            self.save()
        except Exception:
            for field_name, value in previous.items():
                setattr(profile, field_name, value)
            raise
        return profile

    def delete_profile(self, pid: str):
        profile = self.profiles.get(pid)
        if profile is None:
            return

        marker = None
        marker_existed = False
        if profile.source_type == "modrinth":
            private_dir = GAME_ROOT / profile.id / ".katlauncher"
            private_dir.mkdir(parents=True, exist_ok=True)
            marker = private_dir / "detached"
            marker_existed = marker.exists()
            marker_temp = private_dir / "detached.tmp"
            try:
                marker_temp.write_text("1", encoding="ascii")
                os.replace(marker_temp, marker)
            except OSError:
                try:
                    marker_temp.unlink(missing_ok=True)
                except OSError:
                    pass
                raise

        del self.profiles[pid]
        try:
            self.save()
        except Exception:
            self.profiles[pid] = profile
            if marker is not None and not marker_existed:
                try:
                    marker.unlink(missing_ok=True)
                except OSError:
                    pass
            raise

    def list_profiles(self) -> list[Profile]:
        return list(self.profiles.values())

    def list_modpack_profiles(self) -> list[Profile]:
        return [profile for profile in self.profiles.values()
                if profile.source_type == "modrinth"]

    def get(self, pid: str) -> Optional[Profile]:
        return self.profiles.get(pid)


def offline_uuid(nickname: str, *, legacy: bool = False) -> str:
    """Genera un UUID determinista tipo 'offline' a partir del nickname,
    igual que hace el cliente vanilla de Minecraft en modo sin conexión."""
    value = "OfflinePlayer:" + nickname
    if legacy:
        return str(uuid.uuid3(uuid.NAMESPACE_DNS, value))
    digest = hashlib.md5(value.encode("utf-8"), usedforsecurity=False).digest()
    return str(uuid.UUID(bytes=digest, version=3))


_PROFILE_ID_RE = re.compile(r"^[A-Za-z0-9_-]{1,64}$")
_NICKNAME_RE = re.compile(r"^[A-Za-z0-9_]{1,16}$")
_WINDOWS_RESERVED = {
    "CON", "PRN", "AUX", "NUL",
    *(f"COM{i}" for i in range(1, 10)),
    *(f"LPT{i}" for i in range(1, 10)),
}


def _is_safe_profile_id(profile_id: str) -> bool:
    return bool(_PROFILE_ID_RE.fullmatch(profile_id)) \
        and profile_id.split(".", 1)[0].upper() not in _WINDOWS_RESERVED


def validate_nickname(nickname: str) -> str:
    """Valida el nombre offline y, además, que sea seguro como nombre de archivo."""
    if not isinstance(nickname, str) or not _NICKNAME_RE.fullmatch(nickname or ""):
        raise ValueError(
            "El nickname debe tener de 1 a 16 caracteres y usar solo letras, números o _."
        )
    if nickname.upper() in _WINDOWS_RESERVED:
        raise ValueError("Ese nickname es un nombre reservado de Windows.")
    return nickname


def _normalize_profile(profile: Profile):
    profile.name = str(profile.name or "Perfil")
    profile.nickname = str(profile.nickname or "Jugador")
    profile.version = str(profile.version or "")
    profile.loader = str(profile.loader or "vanilla").lower()
    if profile.loader not in ("vanilla", "fabric", "forge", "neoforge", "quilt"):
        profile.loader = "vanilla"
        profile.loader_version = None
        profile.launch_version_id = ""
    elif profile.loader_version is not None:
        profile.loader_version = str(profile.loader_version)
    profile.min_ram = max(512, min(_safe_int(profile.min_ram, 1024), 32768))
    profile.max_ram = max(profile.min_ram, min(_safe_int(profile.max_ram, 2048), 32768))
    profile.resolution_w = max(320, min(_safe_int(profile.resolution_w, 854), 7680))
    profile.resolution_h = max(240, min(_safe_int(profile.resolution_h, 480), 4320))
    profile.jvm_args = str(profile.jvm_args or "")
    profile.skin_path = str(profile.skin_path or "")
    profile.source_type = profile.source_type if profile.source_type in ("custom", "modrinth") \
        else "custom"
    profile.offline_uuid_mode = profile.offline_uuid_mode \
        if profile.offline_uuid_mode in ("minecraft", "legacy") else "legacy"
    candidate_host = str(getattr(profile, "server_host", "") or "").strip()[:253]
    profile.server_host = candidate_host if re.fullmatch(r"[A-Za-z0-9._:-]*", candidate_host) else ""
    profile.server_port = max(1, min(_safe_int(getattr(profile, "server_port", 25565), 25565), 65535))
    for field_name in (
        "modpack_project_id", "modpack_version_id", "modpack_version_number",
        "modpack_summary", "modpack_icon_url", "launch_version_id",
    ):
        setattr(profile, field_name, str(getattr(profile, field_name, "") or ""))


def _safe_int(value, default: int) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default
