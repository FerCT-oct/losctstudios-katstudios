"""Puente local autenticado entre KatCraft (Minecraft) y KatLauncher."""
from __future__ import annotations

import hmac
import json
import os
import secrets
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from .. import __version__
from .room_server import list_profile_server_mods, list_profile_worlds
from . import skins_manager
from PySide6.QtCore import QObject, Signal, QTimer


MAX_BODY = 16 * 1024


class KatCraftBridge(QObject):
    game_invites = Signal(list)
    room_start_requested = Signal(object)
    room_stop_requested = Signal()
    room_restart_requested = Signal(object)
    room_command_requested = Signal(str)
    room_join_requested = Signal(object)
    skin_selected = Signal(str)

    def __init__(self, social_service, trophy_manager, parent=None):
        super().__init__(parent)
        self.social = social_service
        self.trophies = trophy_manager
        self.profile = None
        self.token = ""
        self.server: ThreadingHTTPServer | None = None
        self.thread: threading.Thread | None = None
        self.room_host = ""
        self.room_port = 0
        self.room_local_port = 0
        self.room_status = "idle"
        self.room_error = ""
        self.room_id = ""
        self.room_meta = {}
        self.room_log = []
        self.server_players = []
        self.last_room = {}
        self.tweaks = {
            "keystrokes": False,
            "fps_counter": False,
            "ultra_optimized": False,
        }
        self.heartbeat = QTimer(self)
        self.heartbeat.setInterval(45_000)
        self.heartbeat.timeout.connect(self._heartbeat_room)
        self.heartbeat.start()

    def set_room(self, host: str = "", port: int = 0):
        host = str(host or "").strip()
        port = int(port or 0)
        if host and len(host) <= 253 and 1 <= port <= 65535:
            self.room_host = host
            self.room_port = port
            self.room_status = "ready"
            self.room_error = ""
            self._publish_current_room()
        else:
            self._unpublish_current_room()
            self.room_host = ""
            self.room_port = 0
            self.room_local_port = 0
            if self.room_status != "error":
                self.room_status = "idle"

    def set_room_error(self, message: str):
        self.room_host = ""
        self.room_port = 0
        self.room_local_port = 0
        self.room_status = "error"
        self.room_error = str(message or "")[:240]

    def configure_room(self, profile, metadata=None):
        self.profile = profile
        self.room_meta = dict(metadata) if isinstance(metadata, dict) else {}
        if self.room_meta:
            self.last_room = dict(self.room_meta)
            self._save_local_state()
        if self.room_status not in ("starting", "ready"):
            self.room_log.clear()

    def prepare(self, profile) -> Path:
        self.stop(preserve_room=True)
        self.profile = profile
        self._load_local_state()
        self.token = secrets.token_urlsafe(32)
        bridge = self

        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):
                bridge._handle(self)

            def do_POST(self):
                bridge._handle(self)

            def log_message(self, _format, *_args):
                return

        self.server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        self.server.daemon_threads = True
        self.thread = threading.Thread(
            target=self.server.serve_forever,
            name="KatCraftBridge",
            daemon=True,
        )
        self.thread.start()
        config = {
            "schema": 1,
            "port": int(self.server.server_port),
            "token": self.token,
            "nickname": str(profile.nickname),
            "minecraft_version": str(profile.version),
            "loader": str(profile.loader),
            "launcher_version": __version__,
        }
        path = Path(profile.game_dir) / "config" / "katcraft.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_suffix(".json.tmp")
        temporary.write_text(
            json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        os.replace(temporary, path)
        return path

    def stop(self, preserve_room: bool = False):
        server, thread = self.server, self.thread
        self.server = None
        self.thread = None
        self.profile = None
        self.token = ""
        if not preserve_room:
            self._unpublish_current_room()
        if server is not None:
            server.shutdown()
            server.server_close()
        if thread is not None and thread is not threading.current_thread():
            thread.join(timeout=2)

    def _handle(self, handler: BaseHTTPRequestHandler):
        supplied = str(handler.headers.get("X-KatCraft-Token") or "")
        if not self.token or not hmac.compare_digest(supplied, self.token):
            return _reply(handler, 401, {"error": "unauthorized"})
        path = handler.path.split("?", 1)[0]
        try:
            if handler.command == "GET" and path == "/v1/state":
                return _reply(handler, 200, self._state())
            if handler.command == "POST" and path == "/v1/presence":
                body = _body(handler)
                return _reply(handler, 200, self._presence(body))
            if handler.command == "POST" and path == "/v1/invites":
                body = _body(handler)
                return _reply(handler, 200, self._invite(body))
            if handler.command == "POST" and path == "/v1/invites/respond":
                body = _body(handler)
                return _reply(handler, 200, self._respond_invite(body))
            if handler.command == "POST" and path == "/v1/rooms/start":
                body = _body(handler)
                return _reply(handler, 202, self._start_room(body))
            if handler.command == "POST" and path == "/v1/rooms/stop":
                return _reply(handler, 202, self._stop_room())
            if handler.command == "POST" and path == "/v1/rooms/restart":
                return _reply(handler, 202, self._restart_room())
            if handler.command == "POST" and path == "/v1/rooms/command":
                return _reply(handler, 202, self._room_command(_body(handler)))
            if handler.command == "POST" and path == "/v1/rooms/join":
                return _reply(handler, 202, self._join_room(_body(handler)))
            if handler.command == "POST" and path == "/v1/friends/request":
                return _reply(handler, 200, self._friend_request(_body(handler)))
            if handler.command == "POST" and path == "/v1/trophies/unlock":
                return _reply(handler, 200, self._unlock_trophy(_body(handler)))
            if handler.command == "POST" and path == "/v1/skins/select":
                return _reply(handler, 200, self._select_skin(_body(handler)))
            if handler.command == "POST" and path == "/v1/tweaks":
                return _reply(handler, 200, self._update_tweaks(_body(handler)))
            if handler.command == "POST" and path == "/v1/profiles/get":
                return _reply(handler, 200, self._public_profile(_body(handler)))
            return _reply(handler, 404, {"error": "not_found"})
        except (OSError, ValueError, TypeError, RuntimeError) as error:
            return _reply(handler, 400, {"error": str(error)[:300]})
        except Exception:
            return _reply(handler, 503, {"error": "kat_social_unavailable"})

    def _state(self) -> dict:
        service = self.social
        signed = bool(service is not None and service.session)
        friends = []
        invites = []
        if signed:
            try:
                friends = service.rpc("kat_list_katcraft_friends")
                invites = service.rpc("kat_list_game_invites")
            except Exception:
                # KatCraft sigue mostrando los amigos existentes aunque la
                # migración 08 aún no se haya ejecutado en Supabase.
                try:
                    friends = service.friends()
                except Exception:
                    friends = []
        public_rooms = []
        if signed:
            try:
                public_rooms = service.rpc(
                    "kat_list_public_rooms", {"p_search": "", "p_limit": 50}
                ) or []
            except Exception:
                public_rooms = []
            if self.room_id and self.room_status == "ready":
                try:
                    service.rpc("kat_touch_room", {
                        "p_room": self.room_id, "p_players": 0,
                    })
                except Exception:
                    pass
        if invites:
            self.game_invites.emit(list(invites))
        me = service.me if signed and isinstance(service.me, dict) else {}
        return {
            "schema": 2,
            "launcher_version": __version__,
            "signed_in": signed,
            "self": _profile(me),
            "friends": [_profile(item) for item in (friends or [])[:200]],
            "invites": [_invite_row(item) for item in (invites or [])[:30]],
            "public_rooms": [
                _room_row(item) for item in (public_rooms or [])[:100]
            ],
            "worlds": list_profile_worlds(self.profile) if self.profile else [],
            "mods": list_profile_server_mods(self.profile) if self.profile else [],
            "skins": self._local_skins(),
            "capes": self._local_capes(),
            "server_players": list(self.server_players),
            "last_room": dict(self.last_room),
            "tweaks": dict(self.tweaks),
            "trophies": self.trophies.snapshot() if self.trophies else [],
            "skin_root": service.shared_skin_root if service and service.configured else "",
            "room": {
                "active": bool(self.room_host and self.room_port),
                "host": self.room_host,
                "port": self.room_port,
                "local_port": self.room_local_port,
                "status": self.room_status,
                "error": self.room_error,
                "id": self.room_id,
                "name": str(self.room_meta.get("name") or ""),
                "public": self.room_meta.get("visibility") == "public",
                "world_name": str(self.room_meta.get("world_name") or ""),
                "hardcore": bool(self.room_meta.get("hardcore")),
                "log": list(self.room_log[-120:]),
            },
        }

    def _start_room(self, body: dict):
        if self.room_status in ("starting", "ready"):
            return {"ok": True, "status": self.room_status}
        if bool(body.get("continue_last")):
            if not self.last_room:
                raise ValueError("No existe una sala anterior para continuar.")
            supplied = dict(body)
            body = dict(self.last_room)
            body.update({
                "accept_eula": supplied.get("accept_eula", False),
                "continue_last": True,
            })
        if not bool(body.get("accept_eula")):
            raise ValueError("Debes aceptar la EULA de Minecraft.")
        ram_mb = max(1024, min(int(body.get("ram_mb") or 2048), 16384))
        port = int(body.get("port") or 25565)
        if not 1024 <= port <= 65535:
            raise ValueError("El puerto debe estar entre 1024 y 65535.")
        self.room_status = "starting"
        self.room_error = ""
        self.room_meta = {
            "name": str(body.get("name") or "Sala de KatCraft").strip()[:48],
            "description": str(body.get("description") or "").strip()[:240],
            "visibility": (
                "public" if bool(body.get("public", body.get("global", True)))
                else "private"
            ),
            "players_max": max(1, min(int(body.get("players_max") or 8), 1000)),
            "world_id": str(body.get("world_id") or "")[:140],
            "world_name": str(body.get("world_name") or "Nuevo mundo Kat").strip()[:64],
            "create_world": bool(body.get(
                "create_world", not bool(body.get("world_id"))
            )),
            "hardcore": bool(body.get("hardcore")),
            "ram_mb": ram_mb,
            "port": port,
            "global": bool(body.get("global", True)),
            "selected_mods": (
                [str(value)[:180] for value in body.get("selected_mods", [])]
                if isinstance(body.get("selected_mods"), list) else None
            ),
        }
        self.last_room = dict(self.room_meta)
        self._save_local_state()
        self.room_start_requested.emit(dict(self.room_meta))
        return {"ok": True, "status": "starting"}

    def set_room_local_port(self, port: int):
        port = int(port or 0)
        self.room_local_port = port if 1 <= port <= 65535 else 0

    def _stop_room(self):
        self.room_status = "stopping"
        self._unpublish_current_room()
        self.room_stop_requested.emit()
        return {"ok": True, "status": "stopping"}

    def _restart_room(self):
        if self.room_status != "ready" or not self.last_room:
            raise ValueError("No hay una sala lista para reiniciar.")
        options = dict(self.last_room)
        options["accept_eula"] = True
        self.room_status = "restarting"
        self.room_restart_requested.emit(options)
        return {"ok": True, "status": "restarting"}

    def append_room_log(self, line: str):
        clean = str(line or "").replace("\x00", "")[:500]
        if clean:
            self.room_log.append(clean)
            del self.room_log[:-200]

    def _room_command(self, body: dict):
        command = str(body.get("command") or "").strip()
        if not command or len(command) > 200 or any(
            value in command for value in ("\r", "\n", "\x00")
        ):
            raise ValueError("Comando no válido.")
        if self.room_status != "ready":
            raise ValueError("La sala no está lista.")
        self.room_command_requested.emit(command)
        return {"ok": True}

    def _join_room(self, body: dict):
        room = _room_row(body.get("room"))
        if not room["id"] or not room["host"]:
            raise ValueError("Sala no válida.")
        self.room_join_requested.emit(room)
        return {"ok": True, "status": "launcher_requested"}

    def _public_profile(self, body: dict):
        if not self.social or not self.social.session:
            raise ValueError("Inicia sesión en Kat Social.")
        identifier = str(body.get("user_id") or "")
        if not identifier:
            raise ValueError("Perfil no válido.")
        return _profile(self.social.public_profile(identifier))

    def _publish_current_room(self):
        if not self.social or not self.social.session or not self.profile:
            return
        try:
            value = self.social.rpc("kat_publish_room", {
                "p_name": str(self.room_meta.get("name") or "Sala de KatCraft"),
                "p_description": str(self.room_meta.get("description") or ""),
                "p_host": self.room_host,
                "p_port": self.room_port,
                "p_version": str(self.profile.version),
                "p_loader": str(self.profile.loader or "vanilla"),
                "p_loader_version": str(
                    getattr(self.profile, "loader_version", "") or ""
                ),
                "p_launcher_version": __version__,
                "p_modpack_id": "",
                "p_mods": _profile_mod_manifest(self.profile),
                "p_visibility": str(
                    self.room_meta.get("visibility") or "private"
                ),
                "p_players_max": int(self.room_meta.get("players_max") or 8),
            })
            if isinstance(value, dict):
                self.room_id = str(value.get("id") or "")
        except Exception as error:
            self.append_room_log("[Kat Social] " + str(error)[:240])

    def _heartbeat_room(self):
        if not self.room_id or self.room_status != "ready":
            return
        if not self.social or not self.social.session:
            return
        try:
            self.social.rpc("kat_touch_room", {
                "p_room": self.room_id, "p_players": 0,
            })
        except Exception:
            pass

    def _unpublish_current_room(self):
        room_id = self.room_id
        self.room_id = ""
        if room_id and self.social and self.social.session:
            try:
                self.social.rpc("kat_unpublish_room", {"p_room": room_id})
            except Exception:
                pass

    def _presence(self, body: dict):
        if not self.social or not self.social.session or self.profile is None:
            return {"ok": False, "reason": "not_signed_in"}
        active = bool(body.get("active", True))
        names = body.get("players")
        players = [
            str(value)[:16] for value in (names if isinstance(names, list) else [])
            if str(value).strip()
        ][:100]
        result = self.social.rpc("kat_set_katcraft_presence", {
            "p_nickname": str(self.profile.nickname),
            "p_active": active,
            "p_loader": str(self.profile.loader),
            "p_version": str(self.profile.version),
            "p_players": players,
        })
        rows = result.get("players") if isinstance(result, dict) else []
        self.server_players = [
            _profile(item) for item in (rows if isinstance(rows, list) else [])[:100]
        ]
        return result

    def _friend_request(self, body: dict):
        if not self.social or not self.social.session:
            raise ValueError("Inicia sesión en Kat Social.")
        target = str(body.get("user_id") or "").strip()
        if not target:
            raise ValueError("Jugador Kat no válido.")
        self.social.rpc("kat_send_friend_request", {"p_target": target})
        return {"ok": True}

    def _unlock_trophy(self, body: dict):
        trophy_id = str(body.get("trophy_id") or "")[:64]
        if not self.trophies:
            raise ValueError("Los trofeos no están disponibles.")
        unlocked = self.trophies.unlock(trophy_id)
        if unlocked and self.social and self.social.session:
            try:
                self.social.sync_trophies(self.trophies.unlocked_ids)
            except Exception:
                pass
        return {
            "ok": True,
            "unlocked": [
                {
                    "id": item.id, "title": item.title,
                    "description": item.description, "tier": item.tier,
                } for item in unlocked
            ],
        }

    def _local_skins(self) -> list[dict]:
        profile = self.profile
        if profile is None:
            return []
        active = Path(str(getattr(profile, "skin_path", "") or ""))
        result = []
        try:
            skins_dir = getattr(
                profile, "skins_dir", Path(profile.game_dir) / "skins",
            )
            values = skins_manager.list_skins(skins_dir)
        except (OSError, ValueError):
            values = []
        for value in values[:100]:
            path = Path(str(value.path))
            result.append({
                "id": path.name,
                "name": str(value.filename)[:80],
                "active": bool(active and path == active),
            })
        return result

    def _local_capes(self) -> list[dict]:
        if self.profile is None:
            return []
        nickname = str(getattr(self.profile, "nickname", "") or "")
        root = Path(self.profile.game_dir) / "CustomSkinLoader" / "LocalSkin"
        result = []
        for kind, folder in (("cape", "capes"), ("elytra", "elytras")):
            path = root / folder / f"{nickname}.png"
            if path.is_file():
                result.append({
                    "id": kind, "name": path.name,
                    "kind": kind, "active": True,
                })
        return result

    def _select_skin(self, body: dict):
        if self.profile is None:
            raise ValueError("No hay un perfil activo.")
        filename = str(body.get("skin_id") or "").strip()
        if not filename or filename != Path(filename).name or not filename.lower().endswith(".png"):
            raise ValueError("Skin no válida.")
        root = Path(self.profile.skins_dir).resolve()
        target = (root / filename).resolve()
        if target.parent != root or not target.is_file():
            raise ValueError("La skin seleccionada ya no existe.")
        self.skin_selected.emit(str(target))
        return {"ok": True, "skin_id": filename}

    def _update_tweaks(self, body: dict):
        for key in tuple(self.tweaks):
            if key in body:
                self.tweaks[key] = bool(body[key])
        self._save_local_state()
        return {"ok": True, "tweaks": dict(self.tweaks)}

    def _local_state_path(self) -> Path | None:
        if self.profile is None:
            return None
        return Path(self.profile.game_dir) / "config" / "katcraft-state.json"

    def _load_local_state(self):
        path = self._local_state_path()
        try:
            value = json.loads(path.read_text(encoding="utf-8")) if path else {}
        except (OSError, ValueError, json.JSONDecodeError):
            value = {}
        self.last_room = value.get("last_room") \
            if isinstance(value.get("last_room"), dict) else {}
        saved_tweaks = value.get("tweaks") if isinstance(value.get("tweaks"), dict) else {}
        for key in tuple(self.tweaks):
            self.tweaks[key] = bool(saved_tweaks.get(key, self.tweaks[key]))

    def _save_local_state(self):
        path = self._local_state_path()
        if path is None:
            return
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_suffix(".json.tmp")
        temporary.write_text(json.dumps({
            "schema": 1,
            "last_room": self.last_room,
            "tweaks": self.tweaks,
        }, ensure_ascii=False, indent=2), encoding="utf-8")
        os.replace(temporary, path)

    def _invite(self, body: dict):
        if not self.social or not self.social.session:
            raise ValueError("Inicia sesión en Kat Social para invitar amigos.")
        friend = str(body.get("friend_id") or "")
        host = str(body.get("host") or "").strip()
        port = int(body.get("port") or 25565)
        if host.casefold() in ("127.0.0.1", "localhost", "::1") \
                and self.room_host and self.room_port:
            host, port = self.room_host, self.room_port
        if not friend or not host or len(host) > 253 or not 1 <= port <= 65535:
            raise ValueError("La invitación no contiene un servidor válido.")
        return self.social.rpc("kat_send_game_invite", {
            "p_recipient": friend,
            "p_host": host,
            "p_port": port,
            "p_version": str(body.get("version") or "")[:40],
            "p_loader": str(body.get("loader") or "")[:24],
        })

    def _respond_invite(self, body: dict):
        if not self.social or not self.social.session:
            raise ValueError("Inicia sesión en Kat Social.")
        return self.social.rpc("kat_respond_game_invite", {
            "p_invite": int(body.get("invite_id") or 0),
            "p_accept": bool(body.get("accept")),
        })


def _profile(value) -> dict:
    value = value if isinstance(value, dict) else {}
    return {
        "id": str(value.get("id") or ""),
        "display_name": str(
            value.get("display_name") or value.get("nickname") or "Jugador"
        )[:32],
        "online": bool(value.get("online")),
        "rank": _rank(value),
        "platinum": bool(value.get("platinum")),
        "play_seconds": int(value.get("play_seconds") or 0),
        "avatar_path": str(value.get("avatar_path") or "")[:240],
        "launcher_version": str(value.get("launcher_version") or "")[:24],
        "trophies": value.get("trophies")
        if isinstance(value.get("trophies"), list) else [],
        "katcraft": bool(value.get("katcraft")),
        "game_nickname": str(value.get("game_nickname") or "")[:16],
    }


def _rank(value: dict) -> str:
    explicit = str(value.get("rank") or "").strip().lower()
    if explicit:
        return explicit[:24]
    if bool(value.get("platinum")):
        return "platinum"
    seconds = int(value.get("play_seconds") or 0)
    if seconds >= 360000:
        return "diamond"
    if seconds >= 180000:
        return "gold"
    if seconds >= 36000:
        return "bronze"
    return "kat"


def _room_row(value) -> dict:
    value = value if isinstance(value, dict) else {}
    mods = value.get("mods") if isinstance(value.get("mods"), list) else []
    return {
        "id": str(value.get("id") or ""),
        "owner_id": str(value.get("owner_id") or ""),
        "owner_name": str(value.get("owner_name") or "Jugador")[:32],
        "owner_platinum": bool(value.get("owner_platinum")),
        "name": str(value.get("name") or "Sala")[:48],
        "description": str(value.get("description") or "")[:240],
        "host": str(value.get("host") or value.get("server_host") or "")[:253],
        "port": int(value.get("port") or value.get("server_port") or 25565),
        "minecraft_version": str(value.get("minecraft_version") or "")[:40],
        "loader": str(value.get("loader") or "vanilla")[:24],
        "loader_version": str(value.get("loader_version") or "")[:64],
        "launcher_version": str(value.get("launcher_version") or "")[:24],
        "modpack_id": str(value.get("modpack_id") or "")[:128],
        "mods": mods[:500],
        "players_online": int(value.get("players_online") or 0),
        "players_max": int(value.get("players_max") or 8),
        "expires_at": str(value.get("expires_at") or ""),
    }


def _profile_mod_manifest(profile) -> list[dict]:
    directory = Path(getattr(profile, "mods_dir", ""))
    if not directory.is_dir():
        return []
    result = []
    for item in sorted(directory.iterdir(), key=lambda value: value.name.casefold()):
        if item.is_file() and item.suffix.lower() == ".jar":
            try:
                size = item.stat().st_size
            except OSError:
                continue
            result.append({"name": item.stem[:120], "file": item.name[:180], "size": size})
            if len(result) >= 500:
                break
    return result


def _invite_row(value) -> dict:
    value = value if isinstance(value, dict) else {}
    return {
        "id": int(value.get("id") or 0),
        "sender_id": str(value.get("sender_id") or ""),
        "display_name": str(value.get("display_name") or "Jugador")[:32],
        "host": str(value.get("server_host") or "")[:253],
        "port": int(value.get("server_port") or 25565),
        "version": str(value.get("minecraft_version") or "")[:40],
        "loader": str(value.get("loader") or "")[:24],
        "created_at": str(value.get("created_at") or ""),
        "expires_at": str(value.get("expires_at") or ""),
    }


def _body(handler: BaseHTTPRequestHandler) -> dict:
    try:
        length = int(handler.headers.get("Content-Length") or 0)
    except ValueError as error:
        raise ValueError("Longitud inválida.") from error
    if not 0 <= length <= MAX_BODY:
        raise ValueError("Solicitud demasiado grande.")
    try:
        value = json.loads(handler.rfile.read(length).decode("utf-8")) if length else {}
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise ValueError("JSON inválido.") from error
    if not isinstance(value, dict):
        raise ValueError("El cuerpo debe ser un objeto JSON.")
    return value


def _reply(handler: BaseHTTPRequestHandler, status: int, value: dict):
    payload = json.dumps(value, ensure_ascii=False).encode("utf-8")
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Content-Length", str(len(payload)))
    handler.send_header("Cache-Control", "no-store")
    handler.end_headers()
    handler.wfile.write(payload)
