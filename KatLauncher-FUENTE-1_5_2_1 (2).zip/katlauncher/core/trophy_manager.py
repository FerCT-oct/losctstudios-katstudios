"""Trofeos persistentes de KatLauncher, disponibles también sin conexión."""
from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path

from .profile_manager import APP_DIR


TROPHY_FILE = APP_DIR / "trophies.json"


@dataclass(frozen=True)
class Trophy:
    id: str
    title: str
    description: str
    tier: str
    color: str
    target_seconds: int = 0


TROPHIES = (
    Trophy("guide_complete", "Disfruta de KatLauncher",
           "Completa la guía inicial.", "bronce", "#cd7f32"),
    Trophy("play_10h", "Aventurero de bronce",
           "Juega durante 10 horas.", "bronce", "#cd7f32", 10 * 3600),
    Trophy("play_50h", "Leyenda de oro",
           "Juega durante 50 horas.", "oro", "#ffd700", 50 * 3600),
    Trophy("play_100h", "Gato de diamante",
           "Juega durante 100 horas.", "diamante", "#64d8ff", 100 * 3600),
    Trophy("first_friend", "¡Mejores Amigos para siempre!",
           "Consigue tu primera amistad en Kat Social.", "plata", "#c0c0c0"),
    Trophy("first_update", "¡Actualizado!",
           "Completa correctamente tu primera actualización.", "oro", "#ffd700"),
    Trophy("first_mod", "¡Mirad, ahora la vaca tiene alas!",
           "Instala tu primer mod.", "bronce", "#cd7f32"),
    Trophy("first_modpack", "¿Estoy en Minecraft?",
           "Instala o crea tu primer modpack.", "oro", "#ffd700"),
    Trophy("first_global", "¡Miren, soy nuevo!",
           "Envía tu primer mensaje al chat global.", "bronce", "#cd7f32"),
    Trophy("first_post", "¡Genial!",
           "Crea tu primera publicación en Kat Social.", "plata", "#c0c0c0"),
    Trophy("first_potato", "Primero lo primero",
           "Cómete una patata dentro de Minecraft con KatCraft.",
           "bronce", "#cd7f32"),
)

PLATINUM = Trophy(
    "kat_platinum", "Platino de KatLauncher",
    "Desbloquea todos los trofeos de KatLauncher.", "platino", "#e5f4ff",
)
TROPHY_BY_ID = {item.id: item for item in (*TROPHIES, PLATINUM)}


class TrophyManager:
    def __init__(self, path: str | Path | None = None):
        self.path = Path(path) if path else TROPHY_FILE
        self.play_seconds = 0
        self.unlocked: dict[str, str] = {}
        self.load()

    def load(self):
        try:
            value = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError, json.JSONDecodeError):
            value = {}
        self.play_seconds = max(0, int(value.get("play_seconds") or 0))
        unlocked = value.get("unlocked")
        self.unlocked = {
            str(key): str(timestamp)
            for key, timestamp in (unlocked.items() if isinstance(unlocked, dict) else [])
            if key in TROPHY_BY_ID
        }
        self._grant_platinum_if_complete(save=False)

    def save(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = json.dumps({
            "schema": 1,
            "play_seconds": self.play_seconds,
            "unlocked": self.unlocked,
        }, indent=2, ensure_ascii=False)
        temporary = self.path.with_suffix(self.path.suffix + ".tmp")
        temporary.write_text(payload, encoding="utf-8")
        temporary.replace(self.path)

    def unlock(self, trophy_id: str) -> list[Trophy]:
        trophy_id = str(trophy_id or "")
        trophy = TROPHY_BY_ID.get(trophy_id)
        if trophy is None or trophy_id == PLATINUM.id or trophy_id in self.unlocked:
            return []
        self.unlocked[trophy_id] = _now()
        result = [trophy]
        platinum = self._grant_platinum_if_complete(save=False)
        if platinum:
            result.append(platinum)
        self.save()
        return result

    def add_playtime(self, seconds: int) -> list[Trophy]:
        seconds = max(0, min(int(seconds), 24 * 3600))
        if not seconds:
            return []
        self.play_seconds += seconds
        result = []
        for trophy in TROPHIES:
            if trophy.target_seconds and self.play_seconds >= trophy.target_seconds \
                    and trophy.id not in self.unlocked:
                self.unlocked[trophy.id] = _now()
                result.append(trophy)
        platinum = self._grant_platinum_if_complete(save=False)
        if platinum:
            result.append(platinum)
        self.save()
        return result

    def _grant_platinum_if_complete(self, save: bool = True) -> Trophy | None:
        if PLATINUM.id in self.unlocked:
            return None
        if all(item.id in self.unlocked for item in TROPHIES):
            self.unlocked[PLATINUM.id] = _now()
            if save:
                self.save()
            return PLATINUM
        return None

    @property
    def unlocked_ids(self) -> list[str]:
        return [item.id for item in TROPHIES if item.id in self.unlocked]

    @property
    def complete_count(self) -> int:
        return sum(item.id in self.unlocked for item in TROPHIES)

    def snapshot(self) -> list[dict]:
        result = []
        for trophy in (*TROPHIES, PLATINUM):
            value = asdict(trophy)
            value["unlocked_at"] = self.unlocked.get(trophy.id, "")
            value["unlocked"] = trophy.id in self.unlocked
            value["progress_seconds"] = self.play_seconds if trophy.target_seconds else 0
            result.append(value)
        return result


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")
