from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QListWidget, QListWidgetItem, QLabel,
    QLineEdit, QComboBox, QPushButton, QSpinBox, QFormLayout, QGroupBox,
    QMessageBox, QCheckBox
)
from PySide6.QtCore import Qt, Signal, Slot, QUrl
from PySide6.QtGui import QDesktopServices

from ..core.profile_manager import APP_DIR, ProfileManager
from ..core import skins_manager
from .workers import VersionListWorker, RepairProfileWorker
from .worker_registry import WorkerRegistryMixin


class ProfilesTab(WorkerRegistryMixin, QWidget):
    operation_succeeded = Signal()

    def __init__(self, profile_manager: ProfileManager, settings_manager, i18n,
                 on_change=None, parent=None):
        super().__init__(parent)
        self._init_worker_registry()
        self.pm = profile_manager
        self.settings_manager = settings_manager
        self.i18n = i18n
        self.on_change = on_change  # callback para refrescar otras pestañas
        self.current_id = None
        self.all_versions = []
        self.version_worker = None
        self._pending_snapshot_setting = None
        self.repair_worker = None

        root = QHBoxLayout(self)

        # --- Lista de perfiles a la izquierda ---
        left = QVBoxLayout()
        self.profiles_label = QLabel()
        left.addWidget(self.profiles_label)
        self.list_widget = QListWidget()
        self.list_widget.currentItemChanged.connect(self.on_select)
        left.addWidget(self.list_widget)

        list_btns = QHBoxLayout()
        self.new_btn = QPushButton()
        self.new_btn.clicked.connect(self.on_new)
        self.del_btn = QPushButton()
        self.del_btn.clicked.connect(self.on_delete)
        list_btns.addWidget(self.new_btn)
        list_btns.addWidget(self.del_btn)
        left.addLayout(list_btns)

        root.addLayout(left, stretch=1)

        # --- Formulario de edición a la derecha ---
        right = QVBoxLayout()
        self.form_box = QGroupBox()
        form = QFormLayout(self.form_box)

        self.name_edit = QLineEdit()
        self.name_label = QLabel()
        form.addRow(self.name_label, self.name_edit)

        self.nickname_edit = QLineEdit()
        self.nickname_label = QLabel()
        form.addRow(self.nickname_label, self.nickname_edit)

        version_row = QHBoxLayout()
        self.version_combo = QComboBox()
        self.snapshots_check = QCheckBox()
        self.snapshots_check.setChecked(self.settings_manager.settings.include_snapshots)
        self.snapshots_check.stateChanged.connect(self.reload_versions)
        version_row.addWidget(self.version_combo, stretch=1)
        version_row.addWidget(self.snapshots_check)
        self.version_label = QLabel()
        form.addRow(self.version_label, version_row)

        self.loader_combo = QComboBox()
        for loader in ("vanilla", "fabric", "forge", "neoforge", "quilt"):
            self.loader_combo.addItem(loader, loader)
        self.loader_label = QLabel()
        form.addRow(self.loader_label, self.loader_combo)

        ram_row = QHBoxLayout()
        self.min_ram = QSpinBox()
        self.min_ram.setRange(512, 32768)
        self.min_ram.setSingleStep(512)
        self.max_ram = QSpinBox()
        self.max_ram.setRange(512, 32768)
        self.max_ram.setSingleStep(512)
        self.min_ram_label = QLabel()
        self.max_ram_label = QLabel()
        ram_row.addWidget(self.min_ram_label)
        ram_row.addWidget(self.min_ram)
        ram_row.addWidget(self.max_ram_label)
        ram_row.addWidget(self.max_ram)
        self.ram_label = QLabel()
        form.addRow(self.ram_label, ram_row)

        res_row = QHBoxLayout()
        self.res_w = QSpinBox()
        self.res_w.setRange(320, 7680)
        self.res_h = QSpinBox()
        self.res_h.setRange(240, 4320)
        res_row.addWidget(self.res_w)
        res_row.addWidget(QLabel("x"))
        res_row.addWidget(self.res_h)
        self.resolution_label = QLabel()
        form.addRow(self.resolution_label, res_row)

        self.jvm_args_edit = QLineEdit()
        self.jvm_label = QLabel()
        form.addRow(self.jvm_label, self.jvm_args_edit)

        self.managed_label = QLabel()
        self.managed_label.setWordWrap(True)
        form.addRow(self.managed_label)

        right.addWidget(self.form_box)

        self.save_btn = QPushButton()
        self.save_btn.clicked.connect(self.on_save)
        right.addWidget(self.save_btn)
        maintenance_row = QHBoxLayout()
        self.repair_btn = QPushButton()
        self.repair_btn.clicked.connect(self.on_repair)
        self.open_folder_btn = QPushButton()
        self.open_folder_btn.clicked.connect(self.on_open_folder)
        maintenance_row.addWidget(self.repair_btn)
        maintenance_row.addWidget(self.open_folder_btn)
        right.addLayout(maintenance_row)
        right.addStretch()

        root.addLayout(right, stretch=2)

        self.i18n.language_changed.connect(self.retranslate_ui)
        self.retranslate_ui()
        self.reload_versions()
        self.refresh_list()

    def retranslate_ui(self, *_args):
        t = self.i18n.t
        self.profiles_label.setText(t("Perfiles"))
        self.new_btn.setText(t("Nuevo"))
        self.del_btn.setText(t("Eliminar"))
        self.form_box.setTitle(t("Configuración del perfil"))
        self.name_label.setText(t("Nombre del perfil:"))
        self.nickname_label.setText(t("Nickname (offline):"))
        self.snapshots_check.setText(t("Incluir snapshots"))
        self.version_label.setText(t("Versión de Minecraft:"))
        self.loader_label.setText(t("Mod loader:"))
        self.min_ram_label.setText(t("Mín (MB)"))
        self.max_ram_label.setText(t("Máx (MB)"))
        self.ram_label.setText(t("Memoria RAM:"))
        self.resolution_label.setText(t("Resolución:"))
        self.jvm_args_edit.setPlaceholderText(t("Argumentos JVM adicionales (opcional)"))
        self.jvm_label.setText(t("Argumentos JVM:"))
        self.managed_label.setText(t(
            "Este perfil proviene de un modpack. La versión y el loader los administra el modpack."
        ))
        self.save_btn.setText(t("Guardar cambios"))
        self.repair_btn.setText(t("Reparar perfil / modpack"))
        self.open_folder_btn.setText(t("Abrir carpeta de KatLauncher"))

    def on_open_folder(self):
        APP_DIR.mkdir(parents=True, exist_ok=True)
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(APP_DIR)))

    def on_repair(self):
        profile = self.pm.get(self.current_id) if self.current_id else None
        if not profile or not profile.version or self.repair_worker:
            return
        self.repair_btn.setEnabled(False)
        self.repair_worker = self._track_worker(RepairProfileWorker(profile))
        self.repair_worker.completed.connect(self._on_repaired)
        self.repair_worker.failed.connect(self._on_repair_failed)
        self.repair_worker.start()

    @Slot(str)
    def _on_repaired(self, _path):
        self.repair_worker = None
        self.repair_btn.setEnabled(True)
        self.operation_succeeded.emit()
        QMessageBox.information(
            self, self.i18n.t("Reparación completa"), self.i18n.t(
                "El perfil quedó verificado. Tus mundos y configuraciones no se modificaron."
            )
        )

    @Slot(str)
    def _on_repair_failed(self, error):
        self.repair_worker = None
        self.repair_btn.setEnabled(True)
        QMessageBox.warning(self, self.i18n.t("Error"), self.i18n.t(str(error)))

    def refresh_settings(self):
        desired = self.settings_manager.settings.include_snapshots
        if self.snapshots_check.isChecked() == desired:
            self._pending_snapshot_setting = None
            return
        if self.version_worker and self.version_worker.isRunning():
            self._pending_snapshot_setting = desired
        else:
            self.snapshots_check.setChecked(desired)

    # ---------------------------------------------------------------
    def reload_versions(self):
        if self.version_worker and self.version_worker.isRunning():
            return
        self.version_combo.clear()
        self.version_combo.addItem(self.i18n.t("Cargando versiones..."), None)
        self.version_combo.setEnabled(False)
        self.snapshots_check.setEnabled(False)
        self.version_worker = self._track_worker(VersionListWorker(
            include_snapshots=self.snapshots_check.isChecked()
        ))
        self.version_worker.loaded.connect(self._on_versions_loaded)
        self.version_worker.failed.connect(self._on_versions_failed)
        self.version_worker.start()

    @Slot(list)
    def _on_versions_loaded(self, versions):
        self.all_versions = versions
        self.version_combo.clear()
        for v in versions:
            self.version_combo.addItem(v["id"], v["id"])
        self.version_worker = None
        self.snapshots_check.setEnabled(True)
        # vuelve a seleccionar la versión del perfil actual si aplica
        if self.current_id:
            p = self.pm.get(self.current_id)
            if p and p.version:
                idx = self.version_combo.findData(p.version)
                if idx < 0:
                    self.version_combo.addItem(p.version, p.version)
                    idx = self.version_combo.count() - 1
                if idx >= 0:
                    self.version_combo.setCurrentIndex(idx)
            else:
                self.version_combo.setCurrentIndex(-1)
        else:
            self.version_combo.setCurrentIndex(-1)
        self._update_managed_state()
        self._apply_pending_snapshot_setting()

    @Slot(str)
    def _on_versions_failed(self, error):
        self.version_combo.clear()
        current = self.pm.get(self.current_id) if self.current_id else None
        if current and current.version:
            self.version_combo.addItem(current.version, current.version)
        else:
            self.version_combo.addItem(self.i18n.t("Error: {error}", error=error), None)
        self.version_worker = None
        self.snapshots_check.setEnabled(True)
        self._update_managed_state()
        self._apply_pending_snapshot_setting()

    def _apply_pending_snapshot_setting(self):
        desired = self._pending_snapshot_setting
        if desired is None:
            return
        self._pending_snapshot_setting = None
        self.snapshots_check.blockSignals(True)
        self.snapshots_check.setChecked(desired)
        self.snapshots_check.blockSignals(False)
        self.reload_versions()

    # ---------------------------------------------------------------
    def refresh_list(self):
        current_item = self.list_widget.currentItem()
        selected_id = self.current_id or (
            current_item.data(Qt.UserRole) if current_item else None
        )
        self.list_widget.blockSignals(True)
        self.list_widget.clear()
        selected_row = -1
        for p in self.pm.list_profiles():
            item = QListWidgetItem(p.name)
            item.setData(Qt.UserRole, p.id)
            self.list_widget.addItem(item)
            if p.id == selected_id:
                selected_row = self.list_widget.count() - 1
        self.list_widget.blockSignals(False)
        if self.list_widget.count() > 0:
            self.list_widget.setCurrentRow(selected_row if selected_row >= 0 else 0)
        else:
            self.current_id = None
            self._update_managed_state()

    def on_select(self, current, previous):
        if not current:
            return
        pid = current.data(Qt.UserRole)
        self.current_id = pid
        p = self.pm.get(pid)
        if not p:
            return
        self.name_edit.setText(p.name)
        self.nickname_edit.setText(p.nickname)
        loader_index = self.loader_combo.findData(p.loader)
        self.loader_combo.setCurrentIndex(max(loader_index, 0))
        self.min_ram.setValue(p.min_ram)
        self.max_ram.setValue(p.max_ram)
        self.res_w.setValue(p.resolution_w)
        self.res_h.setValue(p.resolution_h)
        self.jvm_args_edit.setText(p.jvm_args)
        if p.version:
            idx = self.version_combo.findData(p.version)
            if idx < 0:
                self.version_combo.addItem(p.version, p.version)
                idx = self.version_combo.count() - 1
            if idx >= 0:
                self.version_combo.setCurrentIndex(idx)
        else:
            self.version_combo.setCurrentIndex(-1)
        self._update_managed_state()

    def _update_managed_state(self):
        profile = self.pm.get(self.current_id) if self.current_id else None
        managed = bool(profile and profile.source_type == "modrinth")
        self.managed_label.setVisible(managed)
        loading = bool(self.version_worker and self.version_worker.isRunning())
        self.version_combo.setEnabled(not managed and not loading)
        self.snapshots_check.setEnabled(not managed and not loading)
        self.loader_combo.setEnabled(not managed)

    def on_new(self):
        settings = self.settings_manager.settings
        try:
            p = self.pm.create_profile(
                name=self.i18n.t("Nuevo perfil"),
                nickname=settings.default_nickname,
                version="",
                min_ram=settings.default_min_ram,
                max_ram=settings.default_max_ram,
                resolution_w=settings.default_resolution_w,
                resolution_h=settings.default_resolution_h,
            )
        except (OSError, ValueError) as error:
            QMessageBox.warning(self, self.i18n.t("Error"), self.i18n.t(str(error)))
            return
        self.refresh_list()
        for i in range(self.list_widget.count()):
            if self.list_widget.item(i).data(Qt.UserRole) == p.id:
                self.list_widget.setCurrentRow(i)
                break
        if self.on_change:
            self.on_change()
        self.operation_succeeded.emit()

    def on_delete(self):
        if not self.current_id:
            return
        confirm = QMessageBox.question(
            self, self.i18n.t("Eliminar perfil"),
            self.i18n.t(
                "¿Seguro que quieres eliminar este perfil? No se borrarán los archivos del juego."
            ),
        )
        if confirm == QMessageBox.Yes:
            try:
                self.pm.delete_profile(self.current_id)
            except (OSError, ValueError) as error:
                QMessageBox.warning(self, self.i18n.t("Error"), self.i18n.t(str(error)))
                return
            self.current_id = None
            self.refresh_list()
            if self.on_change:
                self.on_change()
            self.operation_succeeded.emit()

    def on_save(self):
        if not self.current_id:
            return
        profile = self.pm.get(self.current_id)
        if not profile:
            return
        if self.min_ram.value() > self.max_ram.value():
            QMessageBox.warning(
                self, self.i18n.t("Error"),
                self.i18n.t("La RAM máxima no puede ser menor que la mínima."),
            )
            return
        managed = profile.source_type == "modrinth"
        selected_version = self.version_combo.currentData()
        version = profile.version if managed or not isinstance(selected_version, str) \
            else selected_version
        loader = profile.loader if managed else self.loader_combo.currentData()
        installation_unchanged = version == profile.version and loader == profile.loader
        new_nickname = self.nickname_edit.text().strip() \
            or self.settings_manager.settings.default_nickname
        skin_migration = None
        try:
            if new_nickname != profile.nickname and profile.skin_path:
                skin_migration = skins_manager.stage_nickname_skin_migration(
                    profile.game_dir, profile.nickname, new_nickname, profile.skin_path
                )
            self.pm.update_profile(
                self.current_id,
                name=self.name_edit.text().strip() or self.i18n.t("Perfil"),
                nickname=new_nickname,
                version=version,
                loader=loader,
                loader_version=(profile.loader_version
                                if managed or installation_unchanged else None),
                launch_version_id=(profile.launch_version_id
                                   if managed or installation_unchanged else ""),
                min_ram=self.min_ram.value(),
                max_ram=self.max_ram.value(),
                resolution_w=self.res_w.value(),
                resolution_h=self.res_h.value(),
                jvm_args=self.jvm_args_edit.text(),
            )
        except (ValueError, OSError) as error:
            if skin_migration:
                try:
                    skin_migration.rollback()
                except OSError:
                    pass
            QMessageBox.warning(self, self.i18n.t("Error"), self.i18n.t(str(error)))
            return
        if skin_migration is not None:
            try:
                skin_migration.commit()
            except OSError:
                pass
        self.refresh_list()
        if self.on_change:
            self.on_change()
        self.operation_succeeded.emit()
        QMessageBox.information(
            self, self.i18n.t("Guardado"),
            self.i18n.t("Perfil actualizado correctamente."),
        )
