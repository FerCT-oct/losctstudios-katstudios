"""Guía inicial y selector visual de KatLauncher."""
from __future__ import annotations

from PySide6.QtCore import Qt, QUrl
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import (
    QButtonGroup, QFrame, QGridLayout, QHBoxLayout, QLabel, QPushButton,
    QRadioButton, QVBoxLayout, QWizard, QWizardPage,
)

from .. import __version__
from .theme_manager import THEME_LABELS, ThemeName

DISCORD_INVITE = "https://discord.gg/HqFqWEC8tR"


def _page(title: str, body: str) -> QWizardPage:
    page = QWizardPage()
    page.setTitle(title)
    arrow = QLabel("➜")
    arrow.setObjectName("guideArrow")
    arrow.setAlignment(Qt.AlignCenter)
    arrow.setStyleSheet(
        "font-size:42px;font-weight:900;color:#7048ff;"
        "background:transparent;padding:3px;"
    )
    label = QLabel(body)
    label.setWordWrap(True)
    label.setTextFormat(Qt.RichText)
    label.setOpenExternalLinks(True)
    layout = QVBoxLayout(page)
    layout.addWidget(arrow)
    layout.addWidget(label)
    layout.addStretch()
    return page


class InterfaceSelectionPage(QWizardPage):
    """Selector visual: muestra la estructura antes de aplicar la interfaz."""

    def __init__(self, theme_manager=None, i18n=None, parent=None):
        super().__init__(parent)
        self.theme_manager = theme_manager
        self.i18n = i18n
        t = i18n.t if i18n is not None else (lambda text: text)
        self.setTitle(t("Elige tu interfaz"))
        root = QVBoxLayout(self)
        description = QLabel(t(
            "Puedes cambiarla después desde Configuración. La selección se "
            "aplica de inmediato para que veas cómo se siente."
        ))
        description.setWordWrap(True)
        root.addWidget(description)
        grid = QGridLayout()
        grid.setSpacing(12)
        self.group = QButtonGroup(self)
        self.group.setExclusive(True)
        self.buttons: dict[ThemeName, QRadioButton] = {}
        choices = (
            (ThemeName.XMB, "XMBKat", "Categorías horizontales y entrada tipo consola."),
            (ThemeName.NORMAL, "Kat Normal", "Sidebar clásico de Kat Modern y dashboard."),
            (ThemeName.EPIC, "Kat Epic", "Tarjetas, brillo cósmico y transiciones suaves."),
            (ThemeName.CLASSIC, "Kat Classic", "Pestañas compactas y funcionamiento directo."),
        )
        selected = getattr(theme_manager, "theme", ThemeName.XMB)
        for index, (theme, title, subtitle) in enumerate(choices):
            card = QFrame()
            card.setObjectName("interfacePreviewCard")
            card.setStyleSheet(
                "QFrame#interfacePreviewCard{background:#111421;border:1px solid "
                "#333047;border-radius:12px;padding:4px;}"
            )
            card_layout = QVBoxLayout(card)
            preview = self._preview(theme)
            card_layout.addWidget(preview)
            radio = QRadioButton(t(title))
            radio.setProperty("themeValue", theme.value)
            radio.setChecked(theme is selected)
            card_layout.addWidget(radio)
            note = QLabel(t(subtitle))
            note.setWordWrap(True)
            note.setStyleSheet("color:#9f99af;font-size:10px;")
            card_layout.addWidget(note)
            self.group.addButton(radio)
            self.buttons[theme] = radio
            grid.addWidget(card, index // 2, index % 2)
        root.addLayout(grid, 1)
        self.group.buttonToggled.connect(self._apply_selected)

    @staticmethod
    def _preview(theme: ThemeName) -> QFrame:
        frame = QFrame()
        frame.setFixedHeight(92)
        layout = QHBoxLayout(frame)
        layout.setContentsMargins(7, 7, 7, 7)
        layout.setSpacing(6)
        if theme is ThemeName.XMB:
            frame.setStyleSheet("background:#080b16;border-radius:9px;")
            column = QVBoxLayout()
            bar = QLabel("  ◉    ⚙    🎮    ♪    ▣    ◎  ")
            bar.setStyleSheet("color:#b98bf0;font-size:15px;")
            column.addWidget(bar)
            column.addWidget(QLabel("        Minecraft\n        Perfiles\n        Trofeos"))
            layout.addLayout(column)
        elif theme is ThemeName.CLASSIC:
            frame.setStyleSheet("background:#16181d;border-radius:9px;")
            column = QVBoxLayout()
            column.addWidget(QLabel("Jugar   Perfiles   Mods   Skins"))
            content = QFrame()
            content.setStyleSheet("background:#242730;border:1px solid #3a3d48;")
            column.addWidget(content)
            layout.addLayout(column)
        else:
            frame.setStyleSheet(
                "background:qlineargradient(x1:0,y1:0,x2:1,y2:1,"
                "stop:0 #090b14,stop:1 #24153f);border-radius:9px;"
            )
            sidebar = QFrame()
            sidebar.setFixedWidth(45 if theme is ThemeName.NORMAL else 58)
            sidebar.setStyleSheet("background:#121522;border-radius:7px;")
            layout.addWidget(sidebar)
            content = QFrame()
            content.setStyleSheet(
                "background:qlineargradient(x1:0,y1:0,x2:1,y2:0,"
                "stop:0 #7048ff,stop:1 #06b6d4);border-radius:8px;"
            )
            layout.addWidget(content, 1)
        return frame

    def _apply_selected(self, button, checked: bool):
        if not checked or self.theme_manager is None:
            return
        value = button.property("themeValue")
        if value:
            self.theme_manager.apply(value)


class OnboardingWizard(QWizard):
    def __init__(self, i18n=None, parent=None, theme_manager=None):
        super().__init__(parent)
        t = i18n.t if i18n is not None else (lambda text: text)
        self.setWindowTitle(
            t("Bienvenido a KatLauncher {version}").format(version=__version__)
        )
        self.setMinimumSize(690, 470)
        self.setWizardStyle(QWizard.ModernStyle)
        self.addPage(_page(
            t("Bienvenido a KatLauncher"),
            t("Usa las flechas de abajo para recorrer cada parte del launcher. "
            "Este tutorial es opcional y puedes volver a abrirlo desde Inicio o "
            "Configuración.<br><br><b>No es obligatorio iniciar "
            "sesión con Minecraft Premium ni con Google para jugar tus perfiles "
            "Java sin conexión.</b>"),
        ))
        self.interface_page = InterfaceSelectionPage(
            theme_manager=theme_manager, i18n=i18n, parent=self
        )
        self.addPage(self.interface_page)
        self.addPage(_page(
            t("1. Crea un perfil"),
            t("En <b>Perfiles</b> eliges versión, loader, memoria y nickname. "
            "La primera instalación necesita Internet; después podrás volver a "
            "abrir esa instancia sin conexión."),
        ))
        self.addPage(_page(
            t("2. Mods, modpacks, skins y MCKAT"),
            t("<b>Contenido</b> instala mods y dependencias. <b>Modpacks</b> importa "
            "archivos .mrpack. <b>Skins</b> administra tu apariencia local. El "
            "texture pack MCKAT se añade automáticamente y puede desactivarse "
            "desde Configuración."),
        ))
        self.addPage(_page(
            t("3. Cuentas y Kat Social"),
            t("Google solo conecta <b>Kat Social</b>: amigos, mensajes y comunidad. "
            "No convierte la cuenta en Minecraft Premium. Las cuentas oficiales "
            "de Microsoft/Xbox se mantienen separadas y nunca guardamos un Client Secret."),
        ))
        community = _page(
            t("4. Comunidad y ayuda"),
            t("Puedes cambiar el diseño y los colores en <b>Configuración</b>. "
            "Si algo falla, conserva el mensaje del registro para poder repararlo."),
        )
        discord = QPushButton(t("Entrar al Discord de KatLauncher"))
        discord.clicked.connect(
            lambda: QDesktopServices.openUrl(QUrl(DISCORD_INVITE))
        )
        community.layout().insertWidget(1, discord)
        self.addPage(community)
