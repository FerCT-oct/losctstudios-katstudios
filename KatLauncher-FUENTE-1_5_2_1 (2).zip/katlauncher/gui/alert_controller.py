"""Controlador Qt para la alerta activa de KatLauncher (Supabase).

Combina dos caminos, igual que Kat Social lo hace con los mensajes:
- Sondeo periódico (``check``) como respaldo siempre confiable.
- Realtime (``_start_realtime``) para que un aviso nuevo llegue casi al
  instante, sin necesitar sesión iniciada: usa la misma publishable key
  pública, ya que la tabla es de lectura pública para cualquiera.
"""
from __future__ import annotations

import asyncio

from PySide6.QtCore import QObject, QThread, Signal, Slot
from supabase import AsyncClientOptions, create_async_client

from ..core import alert_manager
from .worker_registry import WorkerRegistryMixin
from .workers import AlertCheckWorker


class AlertRealtimeWorker(QThread):
    changed = Signal()

    def run(self):
        try:
            asyncio.run(self._listen())
        except Exception:
            pass  # El sondeo periódico sigue siendo el respaldo.

    async def _listen(self):
        try:
            config = alert_manager.load_config()
        except Exception:
            return
        url = str(config.get("project_url", "")).rstrip("/")
        key = str(config.get("publishable_key", ""))
        if not url.startswith("https://") or not key:
            return
        client = await create_async_client(
            url, key, AsyncClientOptions(persist_session=False, auto_refresh_token=False),
        )
        channel = client.channel("kat-alerts")
        channel.on_postgres_changes(
            "INSERT",
            lambda _payload: self.changed.emit(),
            schema="public",
            table="kat_alerts",
        )
        channel.on_postgres_changes(
            "UPDATE",
            lambda _payload: self.changed.emit(),
            schema="public",
            table="kat_alerts",
        )
        await channel.subscribe()
        try:
            while not self.isInterruptionRequested():
                await asyncio.sleep(0.5)
        finally:
            try:
                await asyncio.wait_for(channel.unsubscribe(), timeout=1.0)
            except Exception:
                pass


class AlertController(QObject, WorkerRegistryMixin):
    alert_available = Signal(object)
    check_failed = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._init_worker_registry()
        self._check_worker = None
        self._realtime_worker = None

    @property
    def is_configured(self) -> bool:
        return alert_manager.is_configured()

    def check(self) -> bool:
        if not self.is_configured:
            return False
        if self._check_worker and self._check_worker.isRunning():
            return False
        worker = self._track_worker(AlertCheckWorker())
        self._check_worker = worker
        worker.checked.connect(self._on_checked)
        worker.failed.connect(self._on_failed)
        worker.start()
        return True

    def start_realtime(self) -> None:
        if not self.is_configured:
            return
        if self._realtime_worker and self._realtime_worker.isRunning():
            return
        worker = self._track_worker(AlertRealtimeWorker())
        self._realtime_worker = worker
        worker.changed.connect(self.check)
        worker.start()

    def stop_realtime(self) -> None:
        if self._realtime_worker:
            self._realtime_worker.requestInterruption()

    def mark_seen(self, alert_id: str) -> None:
        try:
            alert_manager.record_seen_alert(alert_id)
        except OSError:
            pass

    @Slot(object)
    def _on_checked(self, info):
        if info is not None:
            self.alert_available.emit(info)

    @Slot(str)
    def _on_failed(self, message: str):
        # Las alertas son informativas: un fallo de red no debe interrumpir
        # al usuario, solo se registra para depuración.
        self.check_failed.emit(message)
