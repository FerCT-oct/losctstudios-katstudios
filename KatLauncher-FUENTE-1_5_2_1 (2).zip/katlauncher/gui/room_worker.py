"""Hilo Qt que mantiene viva una sala dedicada sin bloquear la interfaz."""
from __future__ import annotations

from PySide6.QtCore import QThread, Signal

from ..core.katglobal import KatGlobalError, KatGlobalTunnel
from ..core.room_server import DedicatedRoomServer


class RoomServerWorker(QThread):
    status = Signal(str)
    log_line = Signal(str)
    ready = Signal(str, int)
    stopped = Signal(int)
    failed = Signal(str)

    def __init__(
        self,
        profile,
        ram_mb: int,
        port: int,
        java_path: str = "",
        global_enabled: bool = True,
        room_options: dict | None = None,
    ):
        super().__init__()
        options = dict(room_options or {})
        self.server = DedicatedRoomServer(
            profile, ram_mb=ram_mb, port=port, java_path=java_path,
            world_id=str(options.get("world_id") or ""),
            world_name=str(options.get("world_name") or "Nuevo mundo Kat"),
            create_world=bool(options.get("create_world")),
            hardcore=bool(options.get("hardcore")),
            selected_mods=(
                list(options.get("selected_mods"))
                if isinstance(options.get("selected_mods"), list) else None
            ),
        )
        self.global_enabled = bool(global_enabled)
        self.tunnel = None
        self._ready_emitted = False

    def request_stop(self):
        self.requestInterruption()
        if self.tunnel is not None:
            self.tunnel.stop()
        self.server.stop()

    def run(self):
        process = None
        try:
            self.server.prepare(status_cb=self.status.emit)
            if self.isInterruptionRequested():
                return
            self.status.emit("Iniciando sala dedicada…")
            process = self.server.start()
            for line in process.stdout:
                text = line.rstrip()
                self.log_line.emit("[Sala] " + text)
                if not self._ready_emitted and "Done (" in text:
                    self._ready_emitted = True
                    # La consola solo existe en el launcher del creador. El OP
                    # se aplica al nick de su perfil al arrancar la sala.
                    try:
                        self.server.send_command(
                            "op " + str(self.server.profile.nickname)
                        )
                    except Exception as error:
                        self.log_line.emit("[Sala] No se pudo entregar OP: " + str(error))
                    host = self.server.advertised_host
                    advertised_port = self.server.port
                    if self.global_enabled and not self.isInterruptionRequested():
                        self.status.emit("Abriendo Kat Global…")
                        self.tunnel = KatGlobalTunnel(
                            self.server.java_path, self.server.port
                        )
                        try:
                            host = self.tunnel.start(
                                log_cb=self.log_line.emit
                            )
                            advertised_port = 25565
                            self.log_line.emit(
                                f"[Kat Global] Sala pública: {host}"
                            )
                        except KatGlobalError as error:
                            self.log_line.emit(
                                "[Kat Global] No disponible; continuando por LAN: "
                                + str(error)
                            )
                            self.tunnel = None
                    self.ready.emit(host, advertised_port)
                if self.isInterruptionRequested():
                    self.server.stop()
            code = process.wait()
            if not self._ready_emitted and not self.isInterruptionRequested():
                self.failed.emit(
                    f"El servidor se cerró antes de estar listo (código {code})."
                )
            else:
                self.stopped.emit(code)
        except Exception as error:
            if process is not None and process.poll() is None:
                self.server.stop()
            self.failed.emit(str(error))
        finally:
            if self.tunnel is not None:
                self.tunnel.stop()
                self.tunnel = None

    def send_command(self, command: str):
        self.server.send_command(command)
