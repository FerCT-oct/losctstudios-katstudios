"""Interfaz XMB fiel al prototipo pygame aportado por Oliver."""
from __future__ import annotations

import math
import random
import time
from dataclasses import dataclass
from pathlib import Path

from PySide6.QtCore import QPointF, QRectF, QSize, Qt, QTimer, Signal
from PySide6.QtGui import (
    QColor, QFont, QKeyEvent, QKeySequence, QLinearGradient, QMouseEvent,
    QPainter, QPainterPath, QPen, QPixmap, QShortcut,
)
from PySide6.QtWidgets import (
    QDialog, QFrame, QHBoxLayout, QLabel, QPushButton, QStackedWidget, QStyle,
    QVBoxLayout, QWidget,
)

from ..core.controller_support import connected_gamepads, primary_gamepad_state
from .dashboard_tab import DashboardRoute

ASSETS_DIR = Path(__file__).resolve().parent.parent / "assets"
KAT_LOGO_PATH = ASSETS_DIR / "logo.png"
LAUNCH_SEQUENCE_SECONDS = 5.4

@dataclass(frozen=True)
class XmbItem:
    title: str
    subtitle: str
    route: str = ""
    action: str = ""
    icon: str = ""


@dataclass(frozen=True)
class XmbCategory:
    name: str
    color: tuple[int, int, int]
    icon: str
    items: tuple[XmbItem, ...]


CATEGORIES = (
    XmbCategory("Usuarios", (60, 140, 220), "people", (
        XmbItem("Kat Social", "Amigos, chat global y mensajes privados",
                DashboardRoute.FRIENDS),
        XmbItem("Cuentas", "Perfiles offline y acceso Microsoft",
                DashboardRoute.ACCOUNTS),
    )),
    XmbCategory("Ajustes", (150, 150, 150), "gear", (
        XmbItem("Configuración", "Apariencia, Java, sonido y actualizaciones",
                DashboardRoute.SETTINGS),
        XmbItem("Kat Tutorial", "Recorrido opcional con indicaciones",
                action="tutorial"),
        XmbItem("Buscar actualizaciones", "Comprueba la versión más reciente",
                action="check_updates"),
    )),
    XmbCategory("Juegos", (220, 70, 70), "gamepad", (
        XmbItem("Inicio", "Resumen de KatLauncher", DashboardRoute.HOME),
        XmbItem("Iniciar Minecraft", "Arranca el perfil activo",
                action="launch_minecraft", icon="minecraft"),
        XmbItem("Opciones de juego", "Perfil, memoria, registros e instalación",
                DashboardRoute.PLAY, icon="minecraft"),
        XmbItem("Perfiles", "Crea, repara y administra instalaciones",
                DashboardRoute.PROFILES),
        XmbItem("Trofeos", "Progreso, placas y Platino de KatLauncher",
                DashboardRoute.TROPHIES),
        XmbItem("Minecraft Bedrock", "Abre la edición oficial de Windows",
                DashboardRoute.BEDROCK),
    )),
    XmbCategory("Música", (80, 200, 140), "music", (
        XmbItem("Sonidos de Kat", "Configura sonidos y Rich Presence",
                DashboardRoute.SETTINGS),
        XmbItem("Tono secreto de gato", "Reproduce el easter egg de KatLauncher",
                action="cat_sound"),
    )),
    XmbCategory("Fotos", (230, 160, 40), "photo", (
        XmbItem("Capturas", "Galería de screenshots de tus perfiles",
                DashboardRoute.SCREENSHOTS),
        XmbItem("Skins", "Visor 3D, KatSkin, capas y élitros",
                DashboardRoute.SKINS),
    )),
    XmbCategory("Red", (110, 190, 90), "globe", (
        XmbItem("Mods", "Explora Modrinth y CurseForge", DashboardRoute.MODS),
        XmbItem("Modpacks", "Instala o crea paquetes .mrpack",
                DashboardRoute.DOWNLOADS),
        XmbItem("Noticias", "Novedades oficiales de Minecraft",
                DashboardRoute.NEWS),
        XmbItem("Servidores", "Favoritos, ping y conexión directa",
                DashboardRoute.SERVERS),
        XmbItem("Salas públicas", "Descubre partidas alojadas por la comunidad",
                DashboardRoute.ROOMS),
    )),
    XmbCategory("Debug", (90, 90, 100), "bug", (
        XmbItem("Abrir app estilo PS3", "Simula la entrada y abre el Inicio",
                action="open_app"),
        XmbItem("Popup de trofeo de platino",
                "Muestra el aviso de prueba en la esquina", action="trophy"),
        XmbItem("Fondo aleatorio + tema",
                "Genera un fondo nuevo y cambia el color del sistema",
                action="random_theme"),
        XmbItem("Abrir ventana nueva",
                "Abre una ventana secundaria de diagnóstico",
                action="new_window"),
    )),
)


class _RouteButtonProxy(QPushButton):
    """Mantiene la API anterior para traducción/accesibilidad de MainWindow."""

    def __init__(self, route: str, parent=None):
        super().__init__(parent)
        self.route = route
        self.hide()


class XmbMenu(QWidget):
    activate_requested = Signal(str)
    cat_sound_requested = Signal()
    trophy_sound_requested = Signal()
    back_requested = Signal()

    def __init__(self, i18n=None, parent=None):
        super().__init__(parent)
        self.i18n = i18n
        self.setObjectName("xmbMenu")
        self.setFocusPolicy(Qt.StrongFocus)
        self.setMouseTracking(True)
        self.cat_index = 2
        self.item_indices = [0] * len(CATEGORIES)
        self.cat_anim = float(self.cat_index)
        self.item_anim = 0.0
        self.color = list(CATEGORIES[self.cat_index].color)
        self._last_tick = time.monotonic()
        self._elapsed = 0.0
        self._category_rects: list[tuple[QRectF, int]] = []
        self._item_rects: list[tuple[QRectF, int]] = []
        self._hover = QPointF(-1000, -1000)
        self._random_theme: tuple[int, int, int] | None = None
        self._random_blobs: list[tuple[float, float, float, float]] = []
        self._trophy_started = 0.0
        self._flash_started = 0.0
        self._launch_started = 0.0
        self._launch_profile = ""
        self._kat_logo = QPixmap(str(KAT_LOGO_PATH)) if KAT_LOGO_PATH.is_file() \
            else QPixmap()
        self._gamepad_buttons = 0
        self._last_gamepad_move = 0.0
        self._gamepad_name = ""

        self._timer = QTimer(self)
        self._timer.setInterval(16)
        self._timer.timeout.connect(self._tick)
        self._timer.start()

    def _t(self, text: str) -> str:
        return self.i18n.t(text) if self.i18n is not None else text

    @property
    def selected_route(self) -> str:
        item = CATEGORIES[self.cat_index].items[self.item_indices[self.cat_index]]
        return item.route

    def select_route(self, route: str) -> bool:
        for category_index, category in enumerate(CATEGORIES):
            for item_index, item in enumerate(category.items):
                if item.route == route:
                    self.cat_index = category_index
                    self.item_indices[category_index] = item_index
                    return True
        return False

    def _tick(self):
        now = time.monotonic()
        dt = min(now - self._last_tick, 0.1)
        self._last_tick = now
        self._elapsed += dt
        velocity = 1.0 - math.exp(-11.0 * dt)
        self.cat_anim += (self.cat_index - self.cat_anim) * velocity
        target_item = self.item_indices[self.cat_index]
        self.item_anim += (target_item - self.item_anim) * velocity
        target_color = self._random_theme or CATEGORIES[self.cat_index].color
        for index in range(3):
            self.color[index] += (target_color[index] - self.color[index]) * velocity
        self._poll_gamepad(now)
        self.update()

    def _poll_gamepad(self, now: float):
        state = primary_gamepad_state()
        if not state:
            self._gamepad_name = ""
            self._gamepad_buttons = 0
            return
        self._gamepad_name = str(state.get("name") or "Mando")
        buttons = int(state.get("buttons") or 0)
        pressed = buttons & ~self._gamepad_buttons
        self._gamepad_buttons = buttons
        if not self.isVisible():
            if pressed & 2:
                self.back_requested.emit()
            return
        if pressed & 1:
            self.confirm_selection()
        elif pressed & 2:
            self.back_requested.emit()
        if now - self._last_gamepad_move < 0.20:
            return
        x, y = float(state.get("x") or 0), float(state.get("y") or 0)
        pov = int(state.get("pov", -1))
        dx = -1 if x < -0.45 else (1 if x > 0.45 else 0)
        dy = -1 if y < -0.45 else (1 if y > 0.45 else 0)
        if pov in (22500, 27000, 31500):
            dx = -1
        elif pov in (4500, 9000, 13500):
            dx = 1
        if pov in (31500, 0, 4500):
            dy = -1
        elif pov in (13500, 18000, 22500):
            dy = 1
        if dx or dy:
            self.move_selection(dx, dy)
            self._last_gamepad_move = now

    def move_selection(self, dx: int, dy: int):
        if dx:
            self.cat_index = max(0, min(len(CATEGORIES) - 1, self.cat_index + dx))
            self.item_anim = float(self.item_indices[self.cat_index])
        if dy:
            count = len(CATEGORIES[self.cat_index].items)
            current = self.item_indices[self.cat_index]
            self.item_indices[self.cat_index] = max(0, min(count - 1, current + dy))
        self.update()

    def confirm_selection(self):
        item = CATEGORIES[self.cat_index].items[self.item_indices[self.cat_index]]
        if item.route:
            self._flash_started = time.monotonic()
            QTimer.singleShot(430, lambda route=item.route: self.activate_requested.emit(route))
            return
        if item.action == "cat_sound":
            self.cat_sound_requested.emit()
        elif item.action == "open_app":
            self._flash_started = time.monotonic()
            QTimer.singleShot(
                430, lambda: self.activate_requested.emit(DashboardRoute.HOME)
            )
        elif item.action == "trophy":
            self._trophy_started = time.monotonic()
            self.trophy_sound_requested.emit()
        elif item.action == "random_theme":
            themes = (
                (60, 160, 80), (40, 110, 210), (200, 50, 60),
                (120, 70, 190), (220, 120, 40), (30, 170, 190),
            )
            self._random_theme = random.choice(themes)
            self._random_blobs = [
                (
                    random.random(), random.random(),
                    random.uniform(0.04, 0.18), random.uniform(0.12, 0.42),
                )
                for _ in range(60)
            ]
        elif item.action == "new_window":
            self._open_debug_window()
        elif item.action == "launch_minecraft":
            self._flash_started = time.monotonic()
            QTimer.singleShot(430, lambda: self.activate_requested.emit(
                "action:launch_minecraft"
            ))
        self.update()

    def show_minecraft_launch(self, profile_name: str = ""):
        self.cat_index = next(
            (index for index, category in enumerate(CATEGORIES)
             if category.name == "Juegos"), self.cat_index
        )
        self.item_indices[self.cat_index] = 1
        self.item_anim = 1.0
        self._launch_profile = str(profile_name or "")
        self._launch_started = time.monotonic()
        self.update()

    def _open_debug_window(self):
        dialog = QDialog(self)
        dialog.setWindowTitle(self._t("Ventana de Debug"))
        dialog.resize(420, 260)
        layout = QVBoxLayout(dialog)
        title = QLabel(self._t("KatLauncher XMB"))
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet("font-size: 28px; font-weight: 700;")
        layout.addWidget(title, 1)
        close = QPushButton(self._t("Cerrar"))
        close.clicked.connect(dialog.accept)
        layout.addWidget(close)
        dialog.show()
        dialog.raise_()
        dialog.activateWindow()
        self._debug_dialog = dialog

    def keyPressEvent(self, event: QKeyEvent):
        if event.key() == Qt.Key_Left:
            self.move_selection(-1, 0)
        elif event.key() == Qt.Key_Right:
            self.move_selection(1, 0)
        elif event.key() == Qt.Key_Up:
            self.move_selection(0, -1)
        elif event.key() == Qt.Key_Down:
            self.move_selection(0, 1)
        elif event.key() in (Qt.Key_Return, Qt.Key_Enter, Qt.Key_Space):
            self.confirm_selection()
        else:
            super().keyPressEvent(event)
            return
        event.accept()

    def mouseMoveEvent(self, event: QMouseEvent):
        self._hover = event.position()
        self.update()

    def mousePressEvent(self, event: QMouseEvent):
        if event.button() != Qt.LeftButton:
            return
        point = event.position()
        for rect, index in self._category_rects:
            if rect.contains(point):
                self.cat_index = index
                self.item_anim = float(self.item_indices[index])
                self.update()
                return
        for rect, index in self._item_rects:
            if rect.contains(point):
                if self.item_indices[self.cat_index] == index:
                    self.confirm_selection()
                else:
                    self.item_indices[self.cat_index] = index
                self.update()
                return

    def paintEvent(self, _event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        self._paint_background(painter)
        self._paint_categories(painter)
        self._paint_items(painter)
        self._paint_clock(painter)
        self._paint_footer(painter)
        self._paint_trophy(painter)
        self._paint_launch(painter)
        self._paint_flash(painter)

    def _paint_background(self, painter: QPainter):
        base = tuple(int(value) for value in self.color)
        gradient = QLinearGradient(0, 0, 0, self.height())
        gradient.setColorAt(0, QColor(8, 10, 8))
        gradient.setColorAt(1, QColor(
            int(8 + (base[0] - 8) * 0.52),
            int(10 + (base[1] - 10) * 0.52),
            int(8 + (base[2] - 8) * 0.52),
        ))
        painter.fillRect(self.rect(), gradient)
        if self._random_blobs:
            for nx, ny, nr, strength in self._random_blobs:
                color = QColor(*base, int(24 + strength * 55))
                painter.setBrush(color)
                painter.setPen(Qt.NoPen)
                radius = nr * min(self.width(), self.height())
                painter.drawEllipse(QPointF(nx * self.width(), ny * self.height()),
                                    radius, radius)
            return
        for index in range(4):
            path = QPainterPath()
            path.moveTo(0, self.height())
            phase = self._elapsed * 0.5 + index * 1.4
            amplitude = 26 + index * 10
            base_y = self.height() * 0.62 + index * 40
            for x in range(0, self.width() + 20, 24):
                path.lineTo(x, base_y + math.sin(x * 0.006 + phase) * amplitude)
            path.lineTo(self.width(), self.height())
            path.closeSubpath()
            painter.fillPath(path, QColor(255, 255, 255, max(5, 22 - index * 4)))

    def _paint_categories(self, painter: QPainter):
        center_x, row_y, spacing = 260.0, 130.0, 108.0
        self._category_rects.clear()
        for index, category in enumerate(CATEGORIES):
            x = center_x + (index - self.cat_anim) * spacing
            distance = abs(index - self.cat_anim)
            if not -80 < x < self.width() + 80:
                continue
            scale = max(0.6, 1.0 - distance * 0.12)
            alpha = max(70, int(255 - distance * 55))
            selected = distance < 0.5
            color = QColor(255, 255, 255, alpha) if selected \
                else QColor(200, 200, 200, alpha)
            rect = QRectF(x - 45, row_y - 45, 90, 90)
            self._category_rects.append((rect, index))
            self._draw_icon(painter, category.icon, QPointF(x, row_y),
                            46 * scale, color, 3 if selected else 2)
            if selected:
                painter.setPen(QColor(255, 255, 255))
                painter.setFont(QFont("Segoe UI", 16))
                painter.drawText(QRectF(x - 75, row_y + 42, 150, 34),
                                 Qt.AlignHCenter | Qt.AlignTop,
                                 self._t(category.name))

    def _paint_items(self, painter: QPainter):
        category = CATEGORIES[self.cat_index]
        base_y, spacing = 260.0, 58.0
        icon_x, text_x = 205.0, 265.0
        self._item_rects.clear()
        for index, item in enumerate(category.items):
            y = base_y + (index - self.item_anim) * spacing
            distance = abs(index - self.item_anim)
            if not -50 < y < self.height() + 50:
                continue
            row_rect = QRectF(icon_x - 36, y - 29, 700, 58)
            self._item_rects.append((row_rect, index))
            hovered = row_rect.contains(self._hover)
            selected = distance < 0.5 or (hovered and distance < 1.5)
            if selected:
                painter.setBrush(QColor(255, 255, 255, 30))
                painter.setPen(QPen(QColor(255, 255, 255, 90), 2))
                painter.drawRoundedRect(QRectF(icon_x - 36, y - 36, 72, 72), 22, 22)
                self._draw_icon(
                    painter, item.icon or category.icon, QPointF(icon_x, y), 46,
                    QColor(255, 255, 255), 2,
                )
                painter.setPen(QColor(255, 255, 255))
                painter.setFont(QFont("Segoe UI", 21, QFont.Bold))
                painter.drawText(QPointF(text_x, y - 5), self._t(item.title))
                painter.setPen(QColor(225, 225, 225, 210))
                painter.setFont(QFont("Segoe UI", 12))
                painter.drawText(QPointF(text_x, y + 22), self._t(item.subtitle))
            else:
                alpha = max(50, int(255 * max(0.0, 1 - distance * 0.55)))
                painter.setPen(QColor(210, 210, 210, alpha))
                painter.setFont(QFont("Segoe UI", 18))
                painter.drawText(QPointF(text_x, y + 7), self._t(item.title))

    def _paint_launch(self, painter: QPainter):
        if not self._launch_started:
            return
        elapsed = time.monotonic() - self._launch_started
        if elapsed > LAUNCH_SEQUENCE_SECONDS:
            self._launch_started = 0.0
            return
        phase = self.launch_phase(elapsed)
        painter.fillRect(self.rect(), QColor("#050506"))

        if phase == "kat":
            opacity = min(1.0, max(0.0, (elapsed - .25) / .35))
            opacity *= min(1.0, max(0.0, (2.45 - elapsed) / .35))
            painter.setOpacity(opacity)
            size = min(230, int(min(self.width(), self.height()) * .34))
            if not self._kat_logo.isNull():
                logo = self._kat_logo.scaled(
                    size, size, Qt.KeepAspectRatio, Qt.SmoothTransformation
                )
                painter.drawPixmap(
                    int((self.width() - logo.width()) / 2),
                    int(self.height() / 2 - logo.height() * .68),
                    logo,
                )
            painter.setPen(QColor("#ffffff"))
            painter.setFont(QFont("Segoe UI", 30, QFont.Bold))
            painter.drawText(
                QRectF(0, self.height() * .67, self.width(), 52),
                Qt.AlignHCenter | Qt.AlignTop, "KATLAUNCHER",
            )
            painter.setFont(QFont("Segoe UI", 11))
            painter.setPen(QColor("#c6c8d2"))
            painter.drawText(
                QRectF(0, self.height() * .75, self.width(), 30),
                Qt.AlignHCenter | Qt.AlignTop, self._t("PRESENTA"),
            )
            painter.setOpacity(1.0)
        elif phase == "transition":
            progress = min(1.0, max(0.0, (elapsed - 2.45) / .4))
            painter.fillRect(
                self.rect(),
                QColor(
                    int(5 + 206 * progress),
                    int(5 + 15 * progress),
                    int(6 + 19 * progress),
                ),
            )
        elif phase == "mojang":
            painter.fillRect(self.rect(), QColor("#d3141b"))
            opacity = min(1.0, max(0.0, (elapsed - 2.85) / .28))
            opacity *= min(1.0, max(0.0, (4.75 - elapsed) / .3))
            painter.setOpacity(opacity)
            painter.setPen(QColor("#ffffff"))
            painter.setFont(QFont("Arial Black", 54, QFont.Black))
            painter.drawText(
                QRectF(0, self.height() * .36, self.width(), 100),
                Qt.AlignCenter, "MOJANG",
            )
            painter.setFont(QFont("Arial", 18, QFont.Bold))
            painter.drawText(
                QRectF(0, self.height() * .53, self.width(), 45),
                Qt.AlignCenter, "S T U D I O S",
            )
            painter.setOpacity(1.0)
        else:
            painter.setPen(QColor("#ffffff"))
            painter.setFont(QFont("Segoe UI", 20, QFont.Bold))
            painter.drawText(
                QRectF(0, self.height() * .46, self.width(), 50),
                Qt.AlignCenter, self._t("Iniciando Minecraft"),
            )
            if self._launch_profile:
                painter.setFont(QFont("Segoe UI", 11))
                painter.setPen(QColor("#c6c8d2"))
                painter.drawText(
                    QRectF(0, self.height() * .55, self.width(), 30),
                    Qt.AlignCenter, self._launch_profile,
                )

    @staticmethod
    def launch_phase(elapsed: float) -> str:
        if elapsed < 2.45:
            return "kat"
        if elapsed < 2.85:
            return "transition"
        if elapsed < 4.75:
            return "mojang"
        return "starting"

    def _paint_clock(self, painter: QPainter):
        text = time.strftime("%d/%m %H:%M")
        painter.setFont(QFont("Segoe UI", 14))
        width = painter.fontMetrics().horizontalAdvance(text) + 70
        box = QRectF(self.width() - width - 30, 24, width, 46)
        painter.setBrush(QColor(255, 255, 255, 25))
        painter.setPen(QPen(QColor(255, 255, 255, 90), 1))
        painter.drawRoundedRect(box, 6, 6)
        painter.setPen(QColor(255, 255, 255))
        painter.drawText(box.adjusted(16, 0, -34, 0),
                         Qt.AlignVCenter | Qt.AlignLeft, text)
        center = QPointF(box.right() - 24, box.center().y())
        painter.drawEllipse(center, 9, 9)
        painter.drawLine(center, QPointF(center.x(), center.y() - 5))
        painter.drawLine(center, QPointF(center.x() + 4, center.y()))

    def _paint_footer(self, painter: QPainter):
        painter.setFont(QFont("Segoe UI", 11))
        if self._gamepad_name:
            painter.setPen(QColor(200, 255, 200))
            painter.drawText(QPointF(30, self.height() - 58),
                             f"🎮 {self._gamepad_name}")
        painter.setPen(QColor(255, 255, 255, 130))
        painter.drawText(
            QPointF(30, self.height() - 28),
            self._t(
                "← → categorías   ↑ ↓ elementos   "
                "Enter/clic/A seleccionar   Esc volver"
            ),
        )

    def _paint_trophy(self, painter: QPainter):
        if not self._trophy_started:
            return
        elapsed = time.monotonic() - self._trophy_started
        if elapsed > 3.2:
            self._trophy_started = 0.0
            return
        entrance = min(1.0, elapsed / 0.35)
        exit_progress = min(1.0, max(0.0, (elapsed - 2.8) / 0.4))
        progress = entrance - exit_progress
        width = 340.0
        x = self.width() - width * progress - 10
        box = QRectF(x, 90, width, 76)
        painter.setBrush(QColor(15, 15, 20, 230))
        painter.setPen(QPen(QColor(200, 200, 210), 2))
        painter.drawRoundedRect(box, 10, 10)
        painter.setPen(QColor(230, 230, 240))
        painter.setFont(QFont("Segoe UI", 17))
        painter.drawText(QPointF(x + 68, 122), self._t("Trofeo de Platino"))
        painter.setFont(QFont("Segoe UI", 10))
        painter.drawText(QPointF(x + 68, 148),
                         self._t("¡Has conseguido todos los trofeos!"))
        painter.drawEllipse(QPointF(x + 40, 122), 14, 14)
        painter.drawLine(QPointF(x + 40, 136), QPointF(x + 40, 146))
        painter.drawLine(QPointF(x + 30, 146), QPointF(x + 50, 146))

    def _paint_flash(self, painter: QPainter):
        if not self._flash_started:
            return
        elapsed = time.monotonic() - self._flash_started
        if elapsed > 0.43:
            self._flash_started = 0.0
            return
        progress = elapsed / 0.43
        painter.fillRect(self.rect(), QColor(255, 255, 255, int(210 * progress)))
        painter.setBrush(QColor(*CATEGORIES[self.cat_index].color))
        painter.setPen(Qt.NoPen)
        painter.drawEllipse(QPointF(self.rect().center()), 20 + progress * 300,
                            20 + progress * 300)

    @staticmethod
    def _draw_icon(painter: QPainter, name: str, center: QPointF,
                   size: float, color: QColor, width: int):
        painter.save()
        painter.setBrush(Qt.NoBrush)
        painter.setPen(QPen(color, width, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
        x, y, s = center.x(), center.y(), size
        if name == "people":
            painter.drawEllipse(QPointF(x - s * .16, y - s * .08), s * .22, s * .22)
            painter.drawEllipse(QPointF(x + s * .16, y - s * .08), s * .22, s * .22)
            painter.drawArc(QRectF(x - s * .42, y - s * .05, s * .5, s * .55),
                            20 * 16, 145 * 16)
            painter.drawArc(QRectF(x - s * .08, y - s * .05, s * .5, s * .55),
                            20 * 16, 145 * 16)
        elif name == "gear":
            radius = s * .34
            painter.drawEllipse(QPointF(x, y), radius, radius)
            painter.drawEllipse(QPointF(x, y), s * .14, s * .14)
            for index in range(8):
                angle = math.tau * index / 8
                painter.drawLine(
                    QPointF(x + math.cos(angle) * radius,
                            y + math.sin(angle) * radius),
                    QPointF(x + math.cos(angle) * (radius + s * .09),
                            y + math.sin(angle) * (radius + s * .09)),
                )
        elif name == "gamepad":
            painter.drawRoundedRect(QRectF(x - s * .425, y - s * .21,
                                           s * .85, s * .42), s * .2, s * .2)
            painter.drawEllipse(QPointF(x - s * .24, y), s * .06, s * .06)
            painter.drawEllipse(QPointF(x + s * .24, y), s * .06, s * .06)
            painter.drawLine(QPointF(x - s * .36, y), QPointF(x - s * .28, y))
            painter.drawLine(QPointF(x - s * .32, y - s * .04),
                             QPointF(x - s * .32, y + s * .04))
        elif name == "music":
            painter.drawEllipse(QPointF(x - s * .2, y + s * .22), s * .12, s * .12)
            painter.drawEllipse(QPointF(x + s * .22, y + s * .16), s * .12, s * .12)
            painter.drawLine(QPointF(x - s * .08, y + s * .22),
                             QPointF(x - s * .08, y - s * .3))
            painter.drawLine(QPointF(x + s * .34, y + s * .16),
                             QPointF(x + s * .34, y - s * .36))
            painter.drawLine(QPointF(x - s * .08, y - s * .3),
                             QPointF(x + s * .34, y - s * .36))
        elif name == "photo":
            painter.drawRoundedRect(QRectF(x - s * .375, y - s * .3,
                                           s * .75, s * .6), s * .06, s * .06)
            painter.drawEllipse(QPointF(x - s * .18, y - s * .12), s * .07, s * .07)
            path = QPainterPath(QPointF(x - s * .3, y + s * .22))
            for point in (
                QPointF(x - s * .05, y - s * .05),
                QPointF(x + s * .12, y + s * .1),
                QPointF(x + s * .3, y - s * .12),
                QPointF(x + s * .3, y + s * .22),
            ):
                path.lineTo(point)
            painter.drawPath(path)
        elif name == "globe":
            radius = s * .34
            painter.drawEllipse(QPointF(x, y), radius, radius)
            painter.drawEllipse(QRectF(x - radius * .45, y - radius,
                                       radius * .9, radius * 2))
            painter.drawLine(QPointF(x - radius, y), QPointF(x + radius, y))
        elif name == "minecraft":
            # Bloque de césped reconocible incluso en tamaños pequeños.
            cube = QRectF(x - s * .34, y - s * .31, s * .68, s * .62)
            painter.drawRoundedRect(cube, s * .035, s * .035)
            painter.drawLine(
                QPointF(cube.left(), y - s * .08),
                QPointF(cube.right(), y - s * .08),
            )
            painter.drawLine(
                QPointF(x - s * .12, cube.top()),
                QPointF(x - s * .12, y - s * .08),
            )
            painter.drawLine(
                QPointF(x + s * .13, cube.top()),
                QPointF(x + s * .13, y - s * .08),
            )
            painter.drawLine(
                QPointF(x, y - s * .08),
                QPointF(x, cube.bottom()),
            )
        else:
            radius = s * .22
            painter.drawEllipse(QRectF(x - radius * .75, y - radius,
                                       radius * 1.5, radius * 2.2))
            painter.drawEllipse(QPointF(x, y - radius * 1.15),
                                radius * .4, radius * .4)
            for dx, dy in ((-1, -.4), (-1, .2), (-1, .8),
                           (1, -.4), (1, .2), (1, .8)):
                painter.drawLine(QPointF(x, y),
                                 QPointF(x + dx * radius * 1.3,
                                         y + dy * radius * .9))
        painter.restore()


class TrophyToast(QWidget):
    """Popup de trofeo visible sobre la XMB y sobre las aplicaciones abiertas."""

    def __init__(self, i18n=None, parent=None):
        super().__init__(parent)
        self.i18n = i18n
        self.setAttribute(Qt.WA_TransparentForMouseEvents)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self._queue = []
        self._current = None
        self._started = 0.0
        self._timer = QTimer(self)
        self._timer.setInterval(16)
        self._timer.timeout.connect(self._tick)
        self.hide()

    def enqueue(self, trophy):
        self._queue.append(trophy)
        if self._current is None:
            self._next()

    def _next(self):
        if not self._queue:
            self._current = None
            self.hide()
            self._timer.stop()
            return
        self._current = self._queue.pop(0)
        self._started = time.monotonic()
        self.show()
        self.raise_()
        self._timer.start()
        self.update()

    def _tick(self):
        if time.monotonic() - self._started > 3.4:
            self._next()
        else:
            self.update()

    def paintEvent(self, _event):
        if self._current is None:
            return
        elapsed = time.monotonic() - self._started
        entrance = min(1.0, elapsed / 0.32)
        leave = min(1.0, max(0.0, (elapsed - 3.0) / 0.4))
        offset = (1.0 - entrance + leave) * self.width()
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        box = QRectF(offset + 2, 2, self.width() - 4, self.height() - 4)
        painter.setBrush(QColor(15, 15, 20, 238))
        painter.setPen(QPen(QColor(210, 215, 230), 2))
        painter.drawRoundedRect(box, 12, 12)
        color = QColor(getattr(self._current, "color", "#e5f4ff"))
        painter.setBrush(color)
        painter.setPen(QPen(QColor("#ffffff"), 1))
        painter.drawEllipse(QPointF(offset + 45, 45), 22, 22)
        painter.setFont(QFont("Segoe UI", 19, QFont.Bold))
        painter.drawText(QRectF(offset + 24, 23, 42, 44), Qt.AlignCenter, "★")
        painter.setPen(QColor("#ffffff"))
        painter.setFont(QFont("Segoe UI", 15, QFont.Bold))
        title = getattr(self._current, "title", "Trofeo")
        description = getattr(self._current, "description", "")
        if self.i18n is not None:
            title = self.i18n.t(title)
            description = self.i18n.t(description)
        painter.drawText(QPointF(offset + 78, 34), title)
        painter.setPen(QColor("#d1ced8"))
        painter.setFont(QFont("Segoe UI", 10))
        painter.drawText(QRectF(offset + 78, 43, self.width() - 92, 38),
                         Qt.TextWordWrap, description)


class ModernShell(QWidget):
    """XMB de pantalla completa y páginas reales abiertas como aplicaciones."""

    LAUNCH_SEQUENCE_MS = int(LAUNCH_SEQUENCE_SECONDS * 1000)
    route_changed = Signal(str)
    unknown_route_requested = Signal(str)
    logo_clicked = Signal()
    trophy_requested = Signal()
    launch_minecraft_requested = Signal()
    check_updates_requested = Signal()
    tutorial_requested = Signal()

    def __init__(self, i18n=None, parent=None):
        super().__init__(parent)
        self.i18n = i18n
        self.setObjectName("modernShell")
        self._pages: dict[str, QWidget] = {}
        self._buttons: dict[str, _RouteButtonProxy] = {}
        self._active_route = ""

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        self.stack = QStackedWidget()
        self.stack.setObjectName("xmbStack")
        layout.addWidget(self.stack)
        self.menu = XmbMenu(i18n=self.i18n)
        self.stack.addWidget(self.menu)
        self.menu.activate_requested.connect(self._activate)
        self.menu.cat_sound_requested.connect(self.logo_clicked)
        self.menu.trophy_sound_requested.connect(self.trophy_requested)
        self.menu.back_requested.connect(self.show_menu)

        self.app_host = QFrame()
        self.app_host.setObjectName("xmbAppHost")
        app_layout = QVBoxLayout(self.app_host)
        app_layout.setContentsMargins(18, 14, 18, 18)
        app_layout.setSpacing(12)
        header = QFrame()
        header.setObjectName("xmbAppHeader")
        header_layout = QHBoxLayout(header)
        header_layout.setContentsMargins(10, 7, 14, 7)
        self.back_button = QPushButton("←  XMB")
        self.back_button.setObjectName("xmbBackButton")
        self.back_button.clicked.connect(self.show_menu)
        self.app_title = QLabel("KatLauncher")
        self.app_title.setObjectName("xmbAppTitle")
        header_layout.addWidget(self.back_button)
        header_layout.addWidget(self.app_title)
        header_layout.addStretch()
        app_layout.addWidget(header)
        self.page_stack = QStackedWidget()
        self.page_stack.setObjectName("xmbPageStack")
        app_layout.addWidget(self.page_stack, 1)
        self.stack.addWidget(self.app_host)
        self.trophy_toast = TrophyToast(i18n=self.i18n, parent=self)
        self.trophy_toast.setFixedSize(390, 90)
        self._back_shortcut = QShortcut(QKeySequence(Qt.Key_Escape), self)
        self._back_shortcut.setContext(Qt.WidgetWithChildrenShortcut)
        self._back_shortcut.activated.connect(self.show_menu)

    def _activate(self, target: str):
        if target == "action:launch_minecraft":
            self.launch_minecraft_requested.emit()
            return
        if target == "action:check_updates":
            self.check_updates_requested.emit()
            return
        if target == "action:tutorial":
            self.tutorial_requested.emit()
            return
        self.navigate(target)

    @property
    def current_route(self) -> str:
        return self._active_route or self.menu.selected_route

    def register_page(self, route: str, widget: QWidget) -> None:
        route = str(route).strip().lower()
        if not route:
            raise ValueError("La ruta no puede estar vacía")
        previous = self._pages.get(route)
        if previous is widget:
            return
        if previous is not None:
            self.page_stack.removeWidget(previous)
        self._pages[route] = widget
        self.page_stack.addWidget(widget)
        if route not in self._buttons:
            self._buttons[route] = _RouteButtonProxy(route, self)

    def unregister_page(self, route: str) -> QWidget | None:
        page = self._pages.pop(route, None)
        if page is not None:
            self.page_stack.removeWidget(page)
        proxy = self._buttons.pop(route, None)
        if proxy is not None:
            proxy.deleteLater()
        if self._active_route == route:
            self.show_menu()
        return page

    def navigate(self, route: str) -> bool:
        route = str(route).strip().lower()
        page = self._pages.get(route)
        if page is None:
            self.unknown_route_requested.emit(route)
            return False
        self._active_route = route
        self.menu.select_route(route)
        self.page_stack.setCurrentWidget(page)
        self.app_title.setText(self._route_title(route))
        self.stack.setCurrentWidget(self.app_host)
        self.route_changed.emit(route)
        QTimer.singleShot(0, page.focusNextChild)
        return True

    def show_menu(self):
        if self._active_route:
            self.menu.select_route(self._active_route)
        self.stack.setCurrentWidget(self.menu)
        self.menu.setFocus(Qt.OtherFocusReason)

    def show_minecraft_launch(self, profile_name: str = ""):
        self.stack.setCurrentWidget(self.menu)
        self.menu.show_minecraft_launch(profile_name)

    def _route_title(self, route: str) -> str:
        for category in CATEGORIES:
            for item in category.items:
                if item.route == route:
                    return self.i18n.t(item.title) if self.i18n else item.title
        return "KatLauncher"

    def show_trophy(self, trophy):
        self.trophy_toast.enqueue(trophy)
        self._position_trophy_toast()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._position_trophy_toast()

    def _position_trophy_toast(self):
        self.trophy_toast.move(
            max(10, self.width() - self.trophy_toast.width() - 18), 82
        )

    def connect_dashboard(self, dashboard) -> None:
        dashboard.navigate_requested.connect(self.navigate)
        dashboard.logo_clicked.connect(self.logo_clicked)
