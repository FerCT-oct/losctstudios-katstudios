"""Visor interactivo de skins sin dependencias 3D externas."""
from __future__ import annotations

import math
from dataclasses import dataclass

from PySide6.QtCore import QPointF, QRect, Qt, QTimer
from PySide6.QtGui import QColor, QImage, QMouseEvent, QPainter, QPen, QPolygonF, QWheelEvent
from PySide6.QtWidgets import QWidget


@dataclass(frozen=True)
class _Part:
    center: tuple[float, float, float]
    size: tuple[float, float, float]
    regions: dict[str, QRect]
    overlay_regions: dict[str, QRect] | None = None


class SkinPreview3D(QWidget):
    """Renderiza un personaje Minecraft como cubos rotables y coloreados por la skin."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(250, 330)
        self.setMouseTracking(True)
        self.setCursor(Qt.OpenHandCursor)
        self._image = QImage()
        self._yaw = -25.0
        self._pitch = -8.0
        self._zoom = 1.0
        self._last_pos = None
        self._slim = False
        self._legacy = False
        self._repaint_pending = False

    def load_skin(self, path: str) -> bool:
        return self._load_image(QImage(str(path)))

    def load_skin_data(self, data: bytes) -> bool:
        """Carga una skin descargada sin crear archivos temporales."""
        return self._load_image(QImage.fromData(data))

    def _load_image(self, image: QImage) -> bool:
        if image.isNull() or (image.width(), image.height()) not in (
            (64, 32), (64, 64), (128, 64), (128, 128),
        ):
            self._image = QImage()
            self.update()
            return False
        if image.width() == 128:
            image = image.scaled(
                64, image.height() // 2, Qt.IgnoreAspectRatio, Qt.FastTransformation
            )
        self._legacy = image.height() == 32
        if self._legacy:
            # Las skins antiguas comparten textura para ambos brazos/piernas.
            # Se amplía el lienzo, no la imagen: así no se deforma verticalmente.
            canvas = QImage(64, 64, QImage.Format_ARGB32)
            canvas.fill(Qt.transparent)
            copy_painter = QPainter(canvas)
            copy_painter.drawImage(0, 0, image)
            copy_painter.end()
            image = canvas
        self._image = image.convertToFormat(QImage.Format_ARGB32)
        self.update()
        return True

    def clear_skin(self):
        self._image = QImage()
        self.update()

    def set_slim(self, slim: bool):
        self._slim = bool(slim)
        self.update()

    def reset_view(self):
        self._yaw = -25.0
        self._pitch = -8.0
        self._zoom = 1.0
        self.update()

    def paintEvent(self, _event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing, self._last_pos is None)
        painter.fillRect(self.rect(), QColor("#10131a"))
        if self._image.isNull():
            painter.setPen(QColor("#9a9aa5"))
            painter.drawText(self.rect(), Qt.AlignCenter, "Selecciona una skin\nArrastra para girar")
            return

        scale = min(self.width() / 38.0, self.height() / 42.0) * self._zoom
        center = QPointF(self.width() / 2.0, self.height() / 2.0 + scale * 1.5)
        faces = []
        for part in self._parts():
            faces.extend(
                (*face, False) for face in self._part_faces(part, center, scale)
            )
            if part.overlay_regions and not self._legacy:
                overlay = _Part(
                    part.center,
                    tuple(value + 0.5 for value in part.size),
                    part.overlay_regions,
                )
                faces.extend(
                    (*face, True)
                    for face in self._part_faces(overlay, center, scale)
                )
        # Profundidad positiva queda más lejos de la cámara en _project.
        faces.sort(key=lambda value: value[0], reverse=True)
        for _depth, polygon, region, transparent in faces:
            self._paint_textured_face(
                painter, polygon, region, transparent=transparent
            )
            painter.setBrush(Qt.NoBrush)
            painter.setPen(QPen(QColor(0, 0, 0, 120), max(0.7, scale * 0.05)))
            painter.drawPolygon(polygon)

        painter.setPen(QColor("#8991a3"))
        painter.drawText(10, self.height() - 10, "Arrastra · rueda para zoom")

    def _parts(self) -> list[_Part]:
        slim = self._slim and not self._legacy
        arm_width = 3.0 if slim else 4.0
        return [
            _Part((0, -12, 0), (8, 8, 8), _uv_head(), _uv_head_overlay()),
            _Part((0, -2, 0), (8, 12, 4), _uv_body(), _uv_body_overlay()),
            _Part((-(4 + arm_width / 2), -2, 0), (arm_width, 12, 4),
                  _uv_arm(False, slim), _uv_arm_overlay(False, slim)),
            _Part(((4 + arm_width / 2), -2, 0), (arm_width, 12, 4),
                  _uv_arm(False if self._legacy else True, slim),
                  _uv_arm_overlay(True, slim)),
            _Part((-2, 10, 0), (4, 12, 4), _uv_leg(False),
                  _uv_leg_overlay(False)),
            _Part((2, 10, 0), (4, 12, 4), _uv_leg(False if self._legacy else True),
                  _uv_leg_overlay(True)),
        ]

    def _part_faces(self, part: _Part, center: QPointF, scale: float):
        cx, cy, cz = part.center
        w, h, d = part.size
        vertices = [
            (cx + sx * w / 2, cy + sy * h / 2, cz + sz * d / 2)
            for sx, sy, sz in (
                (-1, -1, -1), (1, -1, -1), (1, 1, -1), (-1, 1, -1),
                (-1, -1, 1), (1, -1, 1), (1, 1, 1), (-1, 1, 1),
            )
        ]
        definitions = {
            "back": (0, 1, 2, 3), "front": (4, 5, 6, 7),
            "left": (0, 4, 7, 3), "right": (1, 5, 6, 2),
            "top": (0, 1, 5, 4), "bottom": (3, 2, 6, 7),
        }
        result = []
        for name, indexes in definitions.items():
            transformed = [self._project(vertices[index], center, scale) for index in indexes]
            polygon = QPolygonF([item[0] for item in transformed])
            depth = sum(item[1] for item in transformed) / 4
            region = part.regions.get(name, QRect(8, 8, 8, 8))
            result.append((depth, polygon, region))
        return result

    def _project(self, point, center: QPointF, scale: float):
        x, y, z = point
        yaw = math.radians(self._yaw)
        pitch = math.radians(self._pitch)
        xr = x * math.cos(yaw) + z * math.sin(yaw)
        zr = -x * math.sin(yaw) + z * math.cos(yaw)
        yr = y * math.cos(pitch) - zr * math.sin(pitch)
        depth = y * math.sin(pitch) + zr * math.cos(pitch)
        perspective = 75.0 / max(30.0, 75.0 + depth)
        return QPointF(center.x() + xr * scale * perspective,
                       center.y() + yr * scale * perspective), depth

    def _paint_textured_face(
        self, painter: QPainter, polygon: QPolygonF, region: QRect,
        *, transparent: bool = False,
    ):
        """Proyecta cada texel al cuadrilátero para conservar el aspecto pixelado."""
        if len(polygon) != 4 or region.width() <= 0 or region.height() <= 0:
            return
        points = [polygon[index] for index in range(4)]

        def point_at(u: float, v: float) -> QPointF:
            top = points[0] * (1.0 - u) + points[1] * u
            bottom = points[3] * (1.0 - u) + points[2] * u
            return top * (1.0 - v) + bottom * v

        painter.setPen(Qt.NoPen)
        for row in range(region.height()):
            v0 = row / region.height()
            v1 = (row + 1) / region.height()
            for column in range(region.width()):
                u0 = column / region.width()
                u1 = (column + 1) / region.width()
                x = region.x() + column
                y = region.y() + row
                color = self._image.pixelColor(x, y) \
                    if 0 <= x < self._image.width() and 0 <= y < self._image.height() \
                    else QColor()
                if transparent and color.alpha() < 16:
                    continue
                if color.alpha() < 16:
                    color = QColor("#777c89")
                painter.setBrush(color)
                painter.drawPolygon(QPolygonF([
                    point_at(u0, v0), point_at(u1, v0),
                    point_at(u1, v1), point_at(u0, v1),
                ]))

    def mousePressEvent(self, event: QMouseEvent):
        if event.button() == Qt.LeftButton:
            self._last_pos = event.position()
            self.setCursor(Qt.ClosedHandCursor)

    def mouseMoveEvent(self, event: QMouseEvent):
        if self._last_pos is None:
            return
        delta = event.position() - self._last_pos
        self._last_pos = event.position()
        self._yaw = (self._yaw + delta.x() * 0.7) % 360
        self._pitch = max(-55, min(55, self._pitch + delta.y() * 0.45))
        # Los ratones pueden enviar cientos de eventos por segundo. Limitar el
        # repintado mantiene el arrastre fluido sin recalcular miles de texeles.
        if not self._repaint_pending:
            self._repaint_pending = True
            QTimer.singleShot(33, self._flush_drag_repaint)

    def _flush_drag_repaint(self):
        self._repaint_pending = False
        self.update()

    def mouseReleaseEvent(self, event: QMouseEvent):
        if event.button() == Qt.LeftButton:
            self._last_pos = None
            self.setCursor(Qt.OpenHandCursor)

    def wheelEvent(self, event: QWheelEvent):
        self._zoom = max(0.65, min(1.65, self._zoom + event.angleDelta().y() / 1200.0))
        self.update()


class SkinPreview2D(QWidget):
    """Muñeco frontal 2D, rápido y pixel-perfect, con segunda capa."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(190, 300)
        self._image = QImage()
        self._slim = False

    def load_skin_data(self, data: bytes, *, slim: bool = False) -> bool:
        image = QImage.fromData(data)
        if image.isNull() or (image.width(), image.height()) not in (
            (64, 32), (64, 64), (128, 64), (128, 128),
        ):
            self._image = QImage()
            self.update()
            return False
        if image.width() == 128:
            image = image.scaled(
                64, image.height() // 2, Qt.IgnoreAspectRatio,
                Qt.FastTransformation,
            )
        if image.height() == 32:
            canvas = QImage(64, 64, QImage.Format_ARGB32)
            canvas.fill(Qt.transparent)
            painter = QPainter(canvas)
            painter.drawImage(0, 0, image)
            painter.end()
            image = canvas
        self._image = image.convertToFormat(QImage.Format_ARGB32)
        self._slim = bool(slim)
        self.update()
        return True

    def clear_skin(self):
        self._image = QImage()
        self.update()

    def paintEvent(self, _event):
        painter = QPainter(self)
        painter.fillRect(self.rect(), QColor("#10131a"))
        if self._image.isNull():
            painter.setPen(QColor("#9a9aa5"))
            painter.drawText(
                self.rect(), Qt.AlignCenter,
                "Selecciona una skin\npara verla en 2D",
            )
            return
        scale = max(1, int(min(self.width() / 16, self.height() / 32)))
        origin_x = (self.width() - 16 * scale) // 2
        origin_y = (self.height() - 32 * scale) // 2
        painter.setRenderHint(QPainter.SmoothPixmapTransform, False)

        def draw(source: QRect, x: int, y: int, width=None):
            target_width = source.width() if width is None else width
            target = QRect(
                origin_x + x * scale, origin_y + y * scale,
                target_width * scale, source.height() * scale,
            )
            painter.drawImage(target, self._image, source)

        arm_width = 3 if self._slim else 4
        arm_offset = 1 if self._slim else 0
        # Capa base.
        draw(QRect(8, 8, 8, 8), 4, 0)
        draw(QRect(20, 20, 8, 12), 4, 8)
        draw(QRect(44, 20, arm_width, 12), arm_offset, 8)
        draw(QRect(36, 52, arm_width, 12), 12, 8)
        draw(QRect(4, 20, 4, 12), 4, 20)
        draw(QRect(20, 52, 4, 12), 8, 20)
        # Segunda capa/casco, respetando transparencia.
        draw(QRect(40, 8, 8, 8), 4, 0)
        draw(QRect(20, 36, 8, 12), 4, 8)
        draw(QRect(44, 36, arm_width, 12), arm_offset, 8)
        draw(QRect(52, 52, arm_width, 12), 12, 8)
        draw(QRect(4, 36, 4, 12), 4, 20)
        draw(QRect(4, 52, 4, 12), 8, 20)


class TexturePreview2D(QWidget):
    """Vista pixel-perfect para texturas arbitrarias, como capas de MCStat."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(190, 300)
        self._image = QImage()

    def load_texture_data(self, data: bytes) -> bool:
        image = QImage.fromData(data)
        if image.isNull() or image.width() < 8 or image.height() < 8 \
                or image.width() > 2048 or image.height() > 2048:
            self.clear_texture()
            return False
        self._image = image.convertToFormat(QImage.Format_ARGB32)
        self.update()
        return True

    def clear_texture(self):
        self._image = QImage()
        self.update()

    def paintEvent(self, _event):
        painter = QPainter(self)
        painter.fillRect(self.rect(), QColor("#10131a"))
        if self._image.isNull():
            painter.setPen(QColor("#9a9aa5"))
            painter.drawText(
                self.rect(), Qt.AlignCenter,
                "Selecciona una capa\npara verla en 2D",
            )
            return
        margin = 18
        target = self.rect().adjusted(margin, margin, -margin, -margin)
        scaled = self._image.scaled(
            target.size(), Qt.KeepAspectRatio, Qt.FastTransformation
        )
        x = target.x() + (target.width() - scaled.width()) // 2
        y = target.y() + (target.height() - scaled.height()) // 2
        painter.setRenderHint(QPainter.SmoothPixmapTransform, False)
        painter.drawImage(x, y, scaled)


def _uv_head():
    return {
        "front": QRect(8, 8, 8, 8), "back": QRect(24, 8, 8, 8),
        "left": QRect(0, 8, 8, 8), "right": QRect(16, 8, 8, 8),
        "top": QRect(8, 0, 8, 8), "bottom": QRect(16, 0, 8, 8),
    }


def _uv_head_overlay():
    return {
        "front": QRect(40, 8, 8, 8), "back": QRect(56, 8, 8, 8),
        "left": QRect(32, 8, 8, 8), "right": QRect(48, 8, 8, 8),
        "top": QRect(40, 0, 8, 8), "bottom": QRect(48, 0, 8, 8),
    }


def _uv_body():
    return {
        "front": QRect(20, 20, 8, 12), "back": QRect(32, 20, 8, 12),
        "left": QRect(16, 20, 4, 12), "right": QRect(28, 20, 4, 12),
        "top": QRect(20, 16, 8, 4), "bottom": QRect(28, 16, 8, 4),
    }


def _uv_body_overlay():
    return {
        "front": QRect(20, 36, 8, 12), "back": QRect(32, 36, 8, 12),
        "left": QRect(16, 36, 4, 12), "right": QRect(28, 36, 4, 12),
        "top": QRect(20, 32, 8, 4), "bottom": QRect(28, 32, 8, 4),
    }


def _uv_arm(left: bool, slim: bool = False):
    x = 36 if left else 44
    y = 52 if left else 20
    front_width = 3 if slim else 4
    return {
        "front": QRect(x, y, front_width, 12),
        "back": QRect(x + front_width + 4, y, front_width, 12),
        "left": QRect(x - 4, y, 4, 12),
        "right": QRect(x + front_width, y, 4, 12),
        "top": QRect(x, y - 4, front_width, 4),
        "bottom": QRect(x + front_width, y - 4, front_width, 4),
    }


def _uv_arm_overlay(left: bool, slim: bool = False):
    x = 52 if left else 44
    y = 52 if left else 36
    front_width = 3 if slim else 4
    return {
        "front": QRect(x, y, front_width, 12),
        "back": QRect(x + front_width + 4, y, front_width, 12),
        "left": QRect(x - 4, y, 4, 12),
        "right": QRect(x + front_width, y, 4, 12),
        "top": QRect(x, y - 4, front_width, 4),
        "bottom": QRect(x + front_width, y - 4, front_width, 4),
    }


def _uv_leg(left: bool):
    x = 20 if left else 4
    y = 52 if left else 20
    return {
        "front": QRect(x, y, 4, 12), "back": QRect(x + 8, y, 4, 12),
        "left": QRect(x - 4, y, 4, 12), "right": QRect(x + 4, y, 4, 12),
        "top": QRect(x, y - 4, 4, 4), "bottom": QRect(x + 4, y - 4, 4, 4),
    }


def _uv_leg_overlay(left: bool):
    x = 4 if left else 4
    y = 52 if left else 36
    return {
        "front": QRect(x, y, 4, 12), "back": QRect(x + 8, y, 4, 12),
        "left": QRect(x - 4, y, 4, 12), "right": QRect(x + 4, y, 4, 12),
        "top": QRect(x, y - 4, 4, 4), "bottom": QRect(x + 4, y - 4, 4, 4),
    }
