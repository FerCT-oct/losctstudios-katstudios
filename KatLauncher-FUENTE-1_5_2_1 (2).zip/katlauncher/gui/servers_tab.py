from __future__ import annotations

import os
from concurrent.futures import ThreadPoolExecutor, as_completed

from PySide6.QtCore import QThread, Qt, Signal, Slot
from PySide6.QtWidgets import (
    QComboBox, QFormLayout, QGroupBox, QHBoxLayout, QLabel, QLineEdit,
    QListWidget, QListWidgetItem, QMessageBox, QPushButton, QSpinBox,
    QVBoxLayout, QWidget,
)

from ..core.server_manager import ServerManager, ping_server
from .worker_registry import WorkerRegistryMixin


class _PingWorker(QThread):
    completed = Signal(str, object)

    def __init__(self, servers, parent=None):
        super().__init__(parent)
        self.servers = list(servers)

    def run(self):
        if not self.servers:
            return
        executor = ThreadPoolExecutor(max_workers=min(12, len(self.servers)))
        futures = {
            executor.submit(ping_server, server.host, server.port, 3.0): server
            for server in self.servers
        }
        try:
            for future in as_completed(futures):
                if self.isInterruptionRequested():
                    break
                server = futures[future]
                self.completed.emit(server.id, future.result())
        finally:
            # Tras cancelar, solo se espera a los sockets ya iniciados (máx.
            # tres segundos). No quedan pools invisibles acumulándose.
            executor.shutdown(wait=True, cancel_futures=True)


class ServersTab(WorkerRegistryMixin, QWidget):
    operation_succeeded = Signal()
    launch_requested = Signal(str, str, int)

    def __init__(self, profile_manager, i18n, parent=None):
        super().__init__(parent)
        self._init_worker_registry()
        self.pm = profile_manager
        self.i18n = i18n
        self.manager = ServerManager()
        self.worker = None
        self.statuses = {}

        root = QHBoxLayout(self)
        left = QVBoxLayout()
        self.title_label = QLabel()
        self.title_label.setObjectName("bigTitle")
        left.addWidget(self.title_label)
        self.server_list = QListWidget()
        self.server_list.currentItemChanged.connect(self._update_detail)
        self.server_list.itemDoubleClicked.connect(lambda _item: self.play_selected())
        left.addWidget(self.server_list, stretch=1)
        buttons = QHBoxLayout()
        self.refresh_button = QPushButton()
        self.refresh_button.clicked.connect(self._toggle_refresh)
        self.remove_button = QPushButton()
        self.remove_button.clicked.connect(self.remove_selected)
        buttons.addWidget(self.refresh_button)
        buttons.addWidget(self.remove_button)
        left.addLayout(buttons)
        root.addLayout(left, stretch=2)

        right = QVBoxLayout()
        self.add_box = QGroupBox()
        form = QFormLayout(self.add_box)
        self.name_edit = QLineEdit()
        self.address_edit = QLineEdit()
        self.address_edit.setClearButtonEnabled(True)
        self.address_edit.returnPressed.connect(self.add_server)
        self.port_spin = QSpinBox()
        self.port_spin.setRange(1, 65535)
        self.port_spin.setValue(25565)
        self.name_label = QLabel()
        self.address_label = QLabel()
        self.port_label = QLabel()
        form.addRow(self.name_label, self.name_edit)
        form.addRow(self.address_label, self.address_edit)
        form.addRow(self.port_label, self.port_spin)
        self.add_button = QPushButton()
        self.add_button.clicked.connect(self.add_server)
        form.addRow(self.add_button)
        right.addWidget(self.add_box)
        self.detail_label = QLabel()
        self.detail_label.setWordWrap(True)
        self.detail_label.setTextFormat(Qt.PlainText)
        right.addWidget(self.detail_label)
        self.profile_label = QLabel()
        right.addWidget(self.profile_label)
        self.profile_combo = QComboBox()
        right.addWidget(self.profile_combo)
        self.play_button = QPushButton()
        self.play_button.clicked.connect(self.play_selected)
        right.addWidget(self.play_button)
        right.addStretch()
        root.addLayout(right, stretch=3)

        self.i18n.language_changed.connect(self.retranslate_ui)
        self.retranslate_ui()
        self.refresh_profiles()
        self.refresh_list()
        if os.environ.get("KATLAUNCHER_SMOKE_TEST") != "1":
            # No convierte el inicio en una espera enorme si alguien importó
            # cientos de favoritos. El botón permite comprobar el resto.
            self.refresh_statuses(self.manager.list()[:24])

    def retranslate_ui(self, *_args):
        t = self.i18n.t
        self.title_label.setText(t("Servidores"))
        self.add_box.setTitle(t("Añadir servidor favorito"))
        self.name_label.setText(t("Nombre:"))
        self.address_label.setText(t("Dirección:"))
        self.port_label.setText(t("Puerto:"))
        self.address_edit.setPlaceholderText(t("play.ejemplo.net (Enter)"))
        self.add_button.setText(t("Añadir"))
        self.refresh_button.setText(t("Comprobar estado"))
        self.remove_button.setText(t("Eliminar"))
        self.profile_label.setText(t("Jugar con el perfil:"))
        self.play_button.setText(t("▶ Entrar al servidor"))

    def refresh_profiles(self):
        current = self.profile_combo.currentData()
        self.profile_combo.clear()
        for profile in self.pm.list_profiles():
            self.profile_combo.addItem(profile.name, profile.id)
        index = self.profile_combo.findData(current)
        if index >= 0:
            self.profile_combo.setCurrentIndex(index)

    def refresh_list(self):
        current = self.server_list.currentItem()
        current_id = current.data(Qt.UserRole) if current else None
        self.server_list.clear()
        for server in self.manager.list():
            status = self.statuses.get(server.id)
            if status is None:
                state = "…"
            elif status.online:
                state = f"● {status.players_online}/{status.players_max} · {status.latency_ms} ms"
            else:
                state = "○ offline"
            row = QListWidgetItem(f"{server.name}\n{server.host}:{server.port}   {state}")
            row.setData(Qt.UserRole, server.id)
            self.server_list.addItem(row)
            if server.id == current_id:
                self.server_list.setCurrentItem(row)
        if self.server_list.count() and not self.server_list.currentItem():
            self.server_list.setCurrentRow(0)

    def _selected(self):
        row = self.server_list.currentItem()
        identifier = row.data(Qt.UserRole) if row else None
        return next((item for item in self.manager.list() if item.id == identifier), None)

    @Slot()
    def add_server(self):
        try:
            item = self.manager.add(
                self.name_edit.text(), self.address_edit.text(), self.port_spin.value()
            )
        except (OSError, ValueError) as error:
            QMessageBox.warning(self, self.i18n.t("Error"), self.i18n.t(str(error)))
            return
        self.name_edit.clear()
        self.address_edit.clear()
        self.refresh_list()
        for index in range(self.server_list.count()):
            row = self.server_list.item(index)
            if row.data(Qt.UserRole) == item.id:
                self.server_list.setCurrentItem(row)
                break
        self.operation_succeeded.emit()
        self.refresh_statuses([item])

    def remove_selected(self):
        server = self._selected()
        if not server:
            return
        try:
            self.manager.remove(server.id)
        except OSError as error:
            QMessageBox.warning(self, self.i18n.t("Error"), str(error))
            return
        self.statuses.pop(server.id, None)
        self.refresh_list()
        self.operation_succeeded.emit()

    def refresh_statuses(self, servers=None):
        if self.worker and self.worker.isRunning():
            return
        servers = list(servers or self.manager.list())
        if not servers:
            return
        self.refresh_button.setEnabled(True)
        self.refresh_button.setText(self.i18n.t("Cancelar comprobación"))
        self.worker = self._track_worker(_PingWorker(servers, self))
        self.worker.completed.connect(self._on_status)
        self.worker.finished.connect(self._ping_finished)
        self.worker.start()

    @Slot(str, object)
    def _on_status(self, server_id, status):
        self.statuses[server_id] = status
        self.refresh_list()
        self._update_detail()

    def _ping_finished(self):
        self.worker = None
        self.refresh_button.setEnabled(True)
        self.refresh_button.setText(self.i18n.t("Comprobar estado"))

    def _toggle_refresh(self):
        if self.worker and self.worker.isRunning():
            self.worker.requestInterruption()
            self.refresh_button.setEnabled(False)
            return
        self.refresh_statuses()

    def _update_detail(self, *_args):
        server = self._selected()
        status = self.statuses.get(server.id) if server else None
        if not server:
            self.detail_label.clear()
        elif status is None:
            self.detail_label.setText(self.i18n.t("Estado aún no comprobado."))
        elif status.online:
            self.detail_label.setText(
                f"{status.description}\n{status.version} · "
                f"{status.players_online}/{status.players_max} · {status.latency_ms} ms"
            )
        else:
            self.detail_label.setText(self.i18n.t("Sin conexión: {error}", error=status.error))

    def play_selected(self):
        server = self._selected()
        profile_id = self.profile_combo.currentData()
        if not server or not profile_id:
            return
        self.launch_requested.emit(profile_id, server.host, server.port)
