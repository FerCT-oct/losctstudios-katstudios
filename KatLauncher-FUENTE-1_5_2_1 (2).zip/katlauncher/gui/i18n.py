"""Localización ligera en tiempo de ejecución para español e inglés."""
from __future__ import annotations

import re

from PySide6.QtCore import QObject, Signal


ENGLISH = {
    "Sala Kat Global": "Kat Global room",
    "Jugar por Internet": "Play over the Internet",
    "Crea una sala temporal en tu PC. Kat Global permite invitar amigos por Internet.":
        "Create a temporary room on your PC. Kat Global lets you invite friends over the Internet.",
    "Crear sala Kat Global": "Create a Kat Global room",
    "KatLauncher descargará el servidor oficial de Mojang, reservará {ram} MB de RAM y aceptará la EULA de Minecraft para esta sala.\n\nLa sala usa modo offline. Si activas Kat Global recibirá un dominio temporal compatible con e4mc; compártelo solo con personas de confianza. ¿Aceptas la EULA y quieres continuar?":
        "KatLauncher will download Mojang's official server, reserve {ram} MB of RAM, and accept the Minecraft EULA for this room.\n\nThe room uses offline mode. With Kat Global enabled, it receives a temporary e4mc-compatible domain; share it only with people you trust. Do you accept the EULA and want to continue?",
    "Abriendo Kat Global…": "Opening Kat Global…",
    "Sala dedicada LAN": "Dedicated LAN room",
    "RAM del servidor:": "Server RAM:",
    "Puerto:": "Port:",
    "Crear sala y jugar": "Create room and play",
    "■ Detener sala": "■ Stop room",
    "Crea un servidor temporal en tu PC para jugadores de la misma red.":
        "Create a temporary server on your PC for players on the same network.",
    "⚠ Crea o selecciona un perfil con versión primero.":
        "⚠ Create or select a profile with a version first.",
    "Crear sala dedicada LAN": "Create a dedicated LAN room",
    "KatLauncher descargará el servidor oficial de Mojang, reservará {ram} MB de RAM y aceptará la EULA de Minecraft para esta sala.\n\nLa sala usa modo offline y solo debe compartirse con personas de confianza en tu red local. ¿Aceptas la EULA y quieres continuar?":
        "KatLauncher will download Mojang's official server, reserve {ram} MB of RAM, and accept the Minecraft EULA for this room.\n\nThe room uses offline mode and should only be shared with trusted people on your local network. Do you accept the EULA and want to continue?",
    "Preparando sala…": "Preparing room…",
    "Preparando Java para la sala…": "Preparing Java for the room…",
    "Preparando servidor dedicado de Minecraft…":
        "Preparing the dedicated Minecraft server…",
    "Iniciando sala dedicada…": "Starting dedicated room…",
    "Sala lista en {host}:{port}. Abriendo Minecraft…":
        "Room ready at {host}:{port}. Opening Minecraft…",
    "Deteniendo sala…": "Stopping room…",
    "Inicio de sala cancelado.": "Room launch cancelled.",
    "[Sala] Servidor detenido (código {code}).":
        "[Room] Server stopped (code {code}).",
    "❌ No se pudo crear la sala: {message}":
        "❌ The room could not be created: {message}",
    "Invitación de KatCraft": "KatCraft invitation",
    "{sender} te invitó a jugar en {host}:{port}":
        "{sender} invited you to play at {host}:{port}",
    "Tienes {count} invitaciones nuevas para jugar":
        "You have {count} new invitations to play",
    "Elige tu interfaz": "Choose your interface",
    "Puedes cambiarla después desde Configuración. La selección se aplica de inmediato para que veas cómo se siente.":
        "You can change it later in Settings. Your selection is applied immediately so you can preview how it feels.",
    "Elige XMBKat, Kat Normal, Kat Epic o Kat Classic. El color de acento se aplica a toda la interfaz.":
        "Choose XMBKat, Kat Normal, Kat Epic, or Kat Classic. The accent color applies across the interface.",
    "Elegir color…": "Choose color…",
    "Elige el color de acento": "Choose the accent color",
    "Biblioteca MCStat": "MCStat Library",
    "Capas": "Capes",
    "Buscar capas (Enter)": "Search capes (Enter)",
    "{count} capas encontradas{cached}. Doble clic para instalar.":
        "{count} capes found{cached}. Double-click to install one.",
    "Descargando capa…": "Downloading cape…",
    "Capa instalada para este perfil con CustomSkinLoader.":
        "Cape installed for this profile with CustomSkinLoader.",
    "Capa de MCStat instalada en {path}.": "MCStat cape installed at {path}.",
    "Actualizar capturas": "Refresh screenshots",
    "Capturas": "Screenshots",
    "Galería de screenshots de tus perfiles":
        "Screenshot gallery for your profiles",
    "Abrir carpeta de capturas": "Open screenshots folder",
    "Abrir captura": "Open screenshot",
    "Copiar imagen": "Copy image",
    "Guardar una copia": "Save a copy",
    "No hay ninguna captura seleccionada.": "No screenshot selected.",
    "No se pudo cargar la captura.": "The screenshot could not be loaded.",
    "{name} · {width}×{height} · {size}": "{name} · {width}×{height} · {size}",
    "Imágenes (*.png *.jpg *.jpeg *.webp)": "Images (*.png *.jpg *.jpeg *.webp)",
    "Biblioteca de skins · MCStat": "Skin Library · MCStat",
    "Vista previa 2D": "2D preview",
    "Cargando vista previa…": "Loading preview…",
    "No se pudo cargar la vista previa.": "The preview could not be loaded.",
    "Buscar skins (Enter)": "Search skins (Enter)",
    "Todos los modelos": "All models",
    "Configurar API key": "Configure API key",
    "Pulsa Enter para buscar. Doble clic instala la skin en el perfil.":
        "Press Enter to search. Double-click to install the skin in the profile.",
    "Añadir al perfil": "Add to profile",
    "Configura una API key gratuita de MCStat para explorar su catálogo.":
        "Configure a free MCStat API key to browse its catalog.",
    "API key de MCStat": "MCStat API key",
    "Pega tu API key de mcstat.org:": "Paste your mcstat.org API key:",
    "API key guardada fuera del ejecutable.": "API key saved outside the executable.",
    "Consultando la biblioteca de MCStat…": "Loading the MCStat library…",
    "{count} skins encontradas{cached}. Doble clic para añadir.":
        "{count} skins found{cached}. Double-click to add one.",
    " · caché local": " · local cache",
    "Descargando skin…": "Downloading skin…",
    "Skin añadida. Puedes instalar otra o cerrar la biblioteca.":
        "Skin added. You can install another one or close the library.",
    "Espera a que termine la operación antes de cerrar.":
        "Wait for the operation to finish before closing.",
    "Preparando secuencia de inicio...": "Preparing launch sequence...",
    "PRESENTA": "PRESENTS",
    "Abrir KatLauncher": "Open KatLauncher",
    "Salir": "Exit",
    "Sin PFP": "No profile picture",
    "KatLauncher {version}": "KatLauncher {version}",
    "Versión de KatLauncher no disponible":
        "KatLauncher version unavailable",
    "Ocultar el launcher en la bandeja mientras Minecraft está abierto":
        "Hide the launcher in the system tray while Minecraft is open",
    "Instalar y actualizar KatCraft automáticamente en perfiles compatibles":
        "Install and update KatCraft automatically in compatible profiles",
    "Avisar cuando una instancia Vanilla no pueda usar KatCraft":
        "Warn when a Vanilla instance cannot use KatCraft",
    "KatCraft no está disponible": "KatCraft is not available",
    "Esta instancia usa Vanilla. Minecraft abrirá normalmente, pero las insignias, amigos, invitaciones y etiquetas de KatCraft necesitan Fabric, Quilt, Forge o NeoForge.":
        "This instance uses Vanilla. Minecraft will launch normally, but KatCraft badges, friends, invitations, and tags require Fabric, Quilt, Forge, or NeoForge.",
    "No volver a mostrar esta advertencia": "Do not show this warning again",
    "Kat Social no está disponible temporalmente. Inténtalo nuevamente en unos minutos.":
        "Kat Social is temporarily unavailable. Please try again in a few minutes.",
    "Teclado virtual": "Virtual keyboard",
    "Escribe usando el mando y pulsa Listo.":
        "Type with the controller and select Done.",
    "Espacio": "Space",
    "Limpiar": "Clear",
    "Listo + Enter": "Done + Enter",
    "Ver perfil": "View profile",
    "Enviar solicitud de amistad": "Send friend request",
    "Responder solicitud": "Respond to request",
    "Iniciando...": "Starting...",
    "Cargando perfiles...": "Loading profiles...",
    "Cargando configuración...": "Loading settings...",
    "Comprobando Java instalado...": "Checking installed Java...",
    "Preparando la interfaz...": "Preparing the interface...",
    "¡Listo!": "Ready!",
    "Jugar": "Play",
    "Perfiles": "Profiles",
    "Modpacks": "Modpacks",
    "Mods": "Mods",
    "Skins": "Skins",
    "Configuración": "Settings",
    "Launcher no oficial para Minecraft: Java Edition — modo offline":
        "Unofficial launcher for Minecraft: Java Edition — offline mode",
    "Perfil": "Profile",
    "Listo.": "Ready.",
    "▶  Jugar": "▶  Play",
    "Registro del juego": "Game log",
    "sin versión": "no version",
    "⚠ Crea o selecciona un perfil primero.": "⚠ Create or select a profile first.",
    "⚠ Este perfil no tiene una versión de Minecraft asignada.":
        "⚠ This profile does not have a Minecraft version assigned.",
    "Comprobando/instalando archivos...": "Checking/installing files...",
    "Lanzando Minecraft...": "Launching Minecraft...",
    "El juego se cerró (código {code}).": "The game closed (code {code}).",
    "El perfil seleccionado ya no existe.": "The selected profile no longer exists.",
    "El perfil cambió durante la instalación. Vuelve a pulsar Jugar.":
        "The profile changed during installation. Press Play again.",
    "❌ Error: {message}": "❌ Error: {message}",
    "Nuevo": "New",
    "Eliminar": "Delete",
    "Configuración del perfil": "Profile settings",
    "Nombre del perfil:": "Profile name:",
    "Nickname (offline):": "Nickname (offline):",
    "Incluir snapshots": "Include snapshots",
    "Versión de Minecraft:": "Minecraft version:",
    "Mod loader:": "Mod loader:",
    "Mín (MB)": "Min (MB)",
    "Máx (MB)": "Max (MB)",
    "Memoria RAM:": "RAM memory:",
    "Resolución:": "Resolution:",
    "Argumentos JVM adicionales (opcional)": "Additional JVM arguments (optional)",
    "Argumentos JVM:": "JVM arguments:",
    "Este perfil proviene de un modpack. La versión y el loader los administra el modpack.":
        "This profile comes from a modpack. Its version and loader are managed by the modpack.",
    "Guardar cambios": "Save changes",
    "Cargando versiones...": "Loading versions...",
    "Error: {error}": "Error: {error}",
    "Nuevo perfil": "New profile",
    "Eliminar perfil": "Delete profile",
    "¿Seguro que quieres eliminar este perfil? No se borrarán los archivos del juego.":
        "Are you sure you want to delete this profile? Game files will not be deleted.",
    "Perfil": "Profile",
    "Jugador": "Player",
    "Guardado": "Saved",
    "Perfil actualizado correctamente.": "Profile updated successfully.",
    "Gestión de mods por perfil — instalados y desde Modrinth":
        "Manage mods per profile — installed and from Modrinth",
    "Perfil:": "Profile:",
    "🧑‍🎨 Auto-instalar CustomSkinLoader": "🧑‍🎨 Auto-install CustomSkinLoader",
    "⚠ Los mods (y CustomSkinLoader) requieren un perfil con mod loader y una versión asignada (configúralo en la pestaña Perfiles).":
        "⚠ Mods (and CustomSkinLoader) require a profile with a mod loader and an assigned version (configure it in Profiles).",
    "Mods instalados": "Installed mods",
    "➕ Añadir .jar": "➕ Add .jar",
    "🔁 Activar/Desactivar": "🔁 Enable/Disable",
    "🗑 Eliminar": "🗑 Delete",
    "Buscar en Modrinth": "Search Modrinth",
    "Nombre del mod, p. ej. 'Sodium'": "Mod name, e.g. 'Sodium'",
    "🔍 Buscar": "🔍 Search",
    "⬇ Instalar seleccionado": "⬇ Install selected",
    "Selecciona archivos .jar": "Select .jar files",
    "Solo se permiten archivos .jar": "Only .jar files are allowed",
    "Error": "Error",
    "⚠ Selecciona un perfil primero.": "⚠ Select a profile first.",
    "⚠ Cambia el perfil a un loader compatible para instalar mods.":
        "⚠ Switch the profile to a compatible loader to install mods.",
    "Buscando '{query}' en Modrinth...": "Searching Modrinth for '{query}'...",
    "❌ Error buscando: {error}": "❌ Search error: {error}",
    "Sin resultados compatibles con este loader/versión.":
        "No results compatible with this loader/version.",
    "{count} resultados.": "{count} results.",
    "{title}  —  {author}  ({downloads} descargas)":
        "{title}  —  {author}  ({downloads} downloads)",
    "⚠ Selecciona un mod de la lista de resultados.": "⚠ Select a mod from the results.",
    "Instalando '{name}'...": "Installing '{name}'...",
    "❌ Error instalando: {error}": "❌ Installation error: {error}",
    "✅ Instalado: {filename}": "✅ Installed: {filename}",
    "Buscando e instalando CustomSkinLoader desde Modrinth...":
        "Finding and installing CustomSkinLoader from Modrinth...",
    "✅ CustomSkinLoader instalado: {filename}": "✅ CustomSkinLoader installed: {filename}",
    "❌ No se pudo instalar CustomSkinLoader: {error}":
        "❌ CustomSkinLoader could not be installed: {error}",
    "Skins locales por perfil": "Local skins per profile",
    "ℹ Al marcar una skin como 'activa', KatLauncher la instala en la carpeta local de CustomSkinLoader y fuerza su configuración a usar SOLO esa carpeta (sin consultar Mojang ni servidores de terceros por tu nickname). Esto evita que te aparezca la skin de otra cuenta real que use el mismo nombre que tú.":
        "ℹ When you mark a skin as active, KatLauncher installs it in CustomSkinLoader's local folder and forces it to use ONLY that folder (without querying Mojang or third-party servers for your nickname). This prevents another real account's skin from appearing when it uses the same name.",
    "Sin vista previa": "No preview",
    "Auto-instalar CustomSkinLoader al marcar una skin como activa":
        "Auto-install CustomSkinLoader when setting an active skin",
    "➕ Añadir skin (.png)": "➕ Add skin (.png)",
    "⭐ Marcar como activa": "⭐ Set as active",
    "No se pudo cargar": "Could not load",
    "Selecciona imágenes PNG": "Select PNG images",
    "La skin debe ser un archivo .png": "The skin must be a .png file",
    "⭐ '{name}' establecida como skin activa para este perfil.\nInstalada en: CustomSkinLoader/LocalSkin/skins/{nickname}.png":
        "⭐ '{name}' set as the active skin for this profile.\nInstalled at: CustomSkinLoader/LocalSkin/skins/{nickname}.png",
    "\n⚠ Para verla en juego necesitas usar un loader compatible e instalar CustomSkinLoader (pestaña Mods).":
        "\n⚠ To see it in game, use a compatible loader and install CustomSkinLoader (Mods tab).",
    "\nComprobando CustomSkinLoader...": "\nChecking CustomSkinLoader...",
    "✅ CustomSkinLoader instalado ({filename}). Ya puedes lanzar el juego con tu skin activa.":
        "✅ CustomSkinLoader installed ({filename}). You can now launch the game with your active skin.",
    "❌ No se pudo auto-instalar CustomSkinLoader: {error}":
        "❌ CustomSkinLoader could not be auto-installed: {error}",
    "Explora e instala modpacks de Modrinth como perfiles independientes":
        "Browse and install Modrinth modpacks as independent profiles",
    "Modpacks instalados": "Installed modpacks",
    "No hay modpacks instalados.": "No modpacks installed.",
    "Minecraft {version} · {loader}": "Minecraft {version} · {loader}",
    "Versión del pack: {version}": "Pack version: {version}",
    "Quitar de perfiles": "Remove from profiles",
    "Buscar modpacks en Modrinth": "Search Modrinth modpacks",
    "Nombre del modpack, p. ej. 'Fabulously Optimized'":
        "Modpack name, e.g. 'Fabulously Optimized'",
    "Versión del modpack:": "Modpack version:",
    "Selecciona primero un modpack": "Select a modpack first",
    "Nickname:": "Nickname:",
    "Instalar archivos opcionales del cliente": "Install optional client files",
    "⬇ Instalar como perfil": "⬇ Install as profile",
    "📦 Importar .mrpack": "📦 Import .mrpack",
    "Buscando modpacks...": "Searching modpacks...",
    "No se encontraron modpacks.": "No modpacks found.",
    "Cargando versiones del modpack...": "Loading modpack versions...",
    "No hay versiones instalables para este modpack.": "No installable versions are available for this modpack.",
    "Selecciona un modpack y una versión.": "Select a modpack and a version.",
    "Instalando modpack. Esto puede tardar varios minutos...":
        "Installing modpack. This may take several minutes...",
    "Selecciona un modpack .mrpack": "Select a .mrpack file",
    "Modpacks de Modrinth (*.mrpack)": "Modrinth modpacks (*.mrpack)",
    "Importando modpack...": "Importing modpack...",
    "✅ '{name}' instalado como perfil. Ya aparece en Jugar.":
        "✅ '{name}' installed as a profile. It is now available in Play.",
    "❌ No se pudo instalar el modpack: {error}": "❌ The modpack could not be installed: {error}",
    "Quitar modpack": "Remove modpack",
    "¿Quitar este modpack de la lista de perfiles? Sus archivos no se borrarán.":
        "Remove this modpack from the profile list? Its files will not be deleted.",
    "Ajustes generales del launcher y valores predeterminados para perfiles nuevos":
        "General launcher settings and defaults for new profiles",
    "General": "General",
    "Idioma:": "Language:",
    "Español": "Spanish",
    "Inglés": "English",
    "Mostrar pantalla de carga al iniciar": "Show splash screen on startup",
    "Minimizar el launcher mientras Minecraft está abierto":
        "Minimize the launcher while Minecraft is running",
    "Máximo de líneas del registro:": "Maximum game log lines:",
    "Java": "Java",
    "Ejecutable de Java (vacío = automático):": "Java executable (empty = automatic):",
    "Examinar...": "Browse...",
    "Selecciona java/javaw": "Select java/javaw",
    "Ejecutables (*.exe);;Todos los archivos (*)": "Executables (*.exe);;All files (*)",
    "Valores para perfiles nuevos": "Defaults for new profiles",
    "Nickname predeterminado:": "Default nickname:",
    "RAM predeterminada:": "Default RAM:",
    "Resolución predeterminada:": "Default resolution:",
    "Incluir snapshots al cargar versiones": "Include snapshots when loading versions",
    "Skins": "Skins",
    "Auto-instalar CustomSkinLoader por defecto": "Auto-install CustomSkinLoader by default",
    "Sonido y Discord": "Sound and Discord",
    "Reproducir sonidos de interfaz": "Play interface sounds",
    "Mostrar mi actividad en Discord": "Show my activity on Discord",
    "ID de aplicación de Discord:": "Discord application ID:",
    "Incluido con KatLauncher": "Included with KatLauncher",
    "KatLauncher ya incluye el ID público de su aplicación de Discord. "
    "La presencia está desactivada inicialmente; actívala si quieres compartir tu actividad.":
        "KatLauncher already includes its public Discord application ID. "
        "Presence is initially disabled; enable it if you want to share your activity.",
    "Actualización configurada correctamente.": "Update configured successfully.",
    "Guardar configuración": "Save settings",
    "La ruta de Java no existe o no es un archivo.": "The Java path does not exist or is not a file.",
    "La RAM máxima no puede ser menor que la mínima.": "Maximum RAM cannot be lower than minimum RAM.",
    "Configuración guardada correctamente.": "Settings saved successfully.",
    "El nickname debe tener de 1 a 16 caracteres y usar solo letras, números o _.":
        "The nickname must be 1 to 16 characters long and contain only letters, numbers, or _.",
    "Ese nickname es un nombre reservado de Windows.":
        "That nickname is a reserved Windows name.",
    "⚠ Los modpacks y sus mods ejecutan código de terceros. Instala solo proyectos de confianza.":
        "⚠ Modpacks and their mods run third-party code. Install only projects you trust.",
    "Operación en curso": "Operation in progress",
    "Espera a que terminen las descargas o cierra Minecraft antes de salir.":
        "Wait for downloads to finish or close Minecraft before exiting.",
    "Minecraft ya está instalado. Preparando el inicio...":
        "Minecraft is already installed. Preparing to launch...",
    "Verificando y reparando la instalación...":
        "Verifying and repairing the installation...",
    "Descargando archivo .mrpack...": "Downloading .mrpack file...",
    "Validando el modpack...": "Validating the modpack...",
    "Instalando Minecraft y el mod loader...": "Installing Minecraft and the mod loader...",
    "Descargando los archivos del modpack...": "Downloading modpack files...",
    "Verificando los archivos del modpack...": "Verifying modpack files...",
    "Solo se permiten archivos .jar": "Only .jar files are allowed",
    "La skin debe ser un archivo .png": "The skin must be a .png file",
    "El archivo debe tener extensión .mrpack.": "The file must have a .mrpack extension.",
    "El modpack contiene demasiados archivos.": "The modpack contains too many files.",
    "El contenido descomprimido del modpack es demasiado grande.":
        "The modpack's uncompressed contents are too large.",
    "El archivo .mrpack es demasiado grande.": "The .mrpack file is too large.",
    "El modpack no contiene modrinth.index.json.":
        "The modpack does not contain modrinth.index.json.",
    "El índice del modpack es demasiado grande.": "The modpack index is too large.",
    "modrinth.index.json no es un JSON UTF-8 válido.":
        "modrinth.index.json is not valid UTF-8 JSON.",
    "La versión del formato .mrpack no es compatible.":
        "This .mrpack format version is not supported.",
    "Este modpack no es para Minecraft.": "This modpack is not for Minecraft.",
    "El modpack no indica una versión válida de Minecraft.":
        "The modpack does not specify a valid Minecraft version.",
    "El modpack declara más de un mod loader.": "The modpack declares more than one mod loader.",
    "La versión del mod loader no es válida.": "The mod loader version is invalid.",
    "La lista de archivos del modpack no es válida.": "The modpack file list is invalid.",
    "El índice contiene una entrada de archivo no válida.":
        "The index contains an invalid file entry.",
    "No se encontró el archivo .mrpack seleccionado.":
        "The selected .mrpack file could not be found.",
    "No se seleccionó una versión del modpack.": "No modpack version was selected.",
    "No se pudo reservar una carpeta para el modpack.":
        "A folder could not be reserved for the modpack.",
    "Esta versión no tiene un archivo .mrpack instalable.":
        "This version does not have an installable .mrpack file.",
    "Esta versión del mod no tiene archivos descargables.":
        "This mod version has no downloadable files.",
    "El tamaño anunciado del archivo no es válido.": "The advertised file size is invalid.",
    "La descarga excedió el tamaño esperado.": "The download exceeded the expected size.",
    "El tamaño descargado no coincide con el anunciado.":
        "The downloaded size does not match the advertised size.",
    "El hash SHA-1 del archivo descargado no coincide.":
        "The downloaded file's SHA-1 hash does not match.",
    "El hash SHA-512 del archivo descargado no coincide.":
        "The downloaded file's SHA-512 hash does not match.",
    "Modrinth no proporcionó un hash para verificar la descarga.":
        "Modrinth did not provide a hash to verify the download.",
    "Publicar en Salas": "Publish in Rooms",
    "Nombre de la sala": "Room name",
    "Descripción opcional": "Optional description",
    "Preparando sala…": "Preparing room…",
    "Sala de KatLauncher": "KatLauncher room",
    "Salas": "Rooms",
    "Salas públicas": "Public rooms",
    "Actualizar": "Refresh",
    "Consola del creador: escribe un comando y pulsa Enter":
        "Owner console: type a command and press Enter",
    "Enviar": "Send",
}

ENGLISH.update({
    "Abrir acceso Premium oficial": "Open official Premium access",
    "Las cuentas Premium siguen el acceso oficial de Microsoft/Xbox. KatLauncher no pedirá tu contraseña ni incrustará un Client Secret; mientras se aprueba su acceso directo, este botón abre la ruta oficial de Java & Bedrock.":
        "Premium accounts use the official Microsoft/Xbox access. KatLauncher will not ask for your password or embed a Client Secret; while direct access is awaiting approval, this button opens the official Java & Bedrock route.",
    "Color de acento:": "Accent color:",
    "Skin pública copiada. Revísala en 3D y pulsa Marcar como activa.":
        "Public skin copied. Check it in 3D and click Set as active.",
    "Selecciona la carpeta que convertirás en modpack":
        "Select the folder to convert into a modpack",
    "Explorar NameMC": "Browse NameMC",
    "KatLauncher ya incluye el ID público de su aplicación de Discord. La presencia está activada por defecto y puedes apagarla cuando quieras.":
        "KatLauncher already includes its public Discord application ID. Presence is enabled by default and you can turn it off at any time.",
    "No se pudo copiar la skin: {error}": "The skin could not be copied: {error}",
    "Buscando skin pública de {username}...": "Searching for {username}'s public skin...",
    "Copiar skin del usuario": "Copy user's skin",
    "Instalar automáticamente el texture pack MCKAT":
        "Automatically install the MCKAT texture pack",
    "Crear .mrpack": "Create .mrpack",
    "Añadir capa local": "Add local cape",
    "Quitar capa": "Remove cape",
    "Añadir élitros locales": "Add local elytra",
    "Quitar élitros": "Remove elytra",
    "Selecciona PNG de capa": "Select cape PNG",
    "Selecciona PNG de élitros": "Select elytra PNG",
    "Cosmético local instalado en {path}. Los demás jugadores necesitan un mod compatible para verlo.":
        "Local cosmetic installed at {path}. Other players need a compatible mod to see it.",
    "Cosmético local eliminado.": "Local cosmetic removed.",
    "El cosmético debe ser una capa o unos élitros.":
        "The cosmetic must be a cape or an elytra.",
    "El cosmético debe ser un archivo .png": "The cosmetic must be a .png file",
    "El cosmético no es un PNG válido.": "The cosmetic is not a valid PNG.",
    "Información de {title}": "About {title}",
    "por": "by",
    "Sin descripción.": "No description.",
    "Abrir en Modrinth": "Open on Modrinth",
    "{description}\n\nDescargas: {downloads}\nSeguidores: {followers}\nCategorías: {categories}\nVersiones: {versions}\nÚltima actualización: {updated}\n\nDoble clic muestra información; Instalar seleccionado realiza la instalación.":
        "{description}\n\nDownloads: {downloads}\nFollowers: {followers}\nCategories: {categories}\nVersions: {versions}\nLast updated: {updated}\n\nDouble-click shows details; Install selected performs the installation.",
})

ENGLISH.update({
    "ID de perfil no válido": "Invalid profile ID",
    "Ya existe un perfil con ese ID": "A profile with that ID already exists",
    "Las comillas de los argumentos JVM no están cerradas":
        "The JVM argument quotes are not closed",
    "La RAM máxima no puede ser menor que la mínima":
        "Maximum RAM cannot be lower than minimum RAM",
    "El modpack intenta ocupar una carpeta interna de KatLauncher.":
        "The modpack attempts to use an internal KatLauncher folder.",
    "El índice del modpack contiene demasiadas descargas.":
        "The modpack index contains too many downloads.",
    "Las descargas del modpack exceden el límite de tamaño.":
        "The modpack downloads exceed the size limit.",
    "El resumen del modpack no es válido.": "The modpack summary is invalid.",
    "El modpack contiene un conflicto entre archivo y carpeta.":
        "The modpack contains a file/directory conflict.",
    "Una entrada de carpeta del modpack contiene datos.":
        "A modpack directory entry contains data.",
    "El índice contiene un conflicto entre archivo y carpeta.":
        "The index contains a file/directory conflict.",
    "Un override intentó salir de la carpeta de la instancia.":
        "An override attempted to leave the instance folder.",
    "Un override tiene un conflicto entre archivo y carpeta.":
        "An override contains a file/directory conflict.",
    "El archivo usa una URL de descarga no permitida.":
        "The file uses a disallowed download URL.",
    "La URL de descarga contiene credenciales no permitidas.":
        "The download URL contains disallowed credentials.",
    "La descarga redirigió sin indicar un destino.":
        "The download redirected without a destination.",
    "La descarga superó el límite de redirecciones.":
        "The download exceeded the redirect limit.",
    "Modrinth devolvió un nombre de archivo no válido.":
        "Modrinth returned an invalid filename.",
    "Modrinth devolvió una ruta de archivo no segura.":
        "Modrinth returned an unsafe file path.",
    "Modrinth devolvió un nombre reservado de Windows.":
        "Modrinth returned a reserved Windows filename.",
    "Modrinth devolvió una respuesta de búsqueda no válida.":
        "Modrinth returned an invalid search response.",
    "Modrinth devolvió una lista de versiones no válida.":
        "Modrinth returned an invalid version list.",
    "Modrinth devolvió una versión no válida.":
        "Modrinth returned an invalid version.",
    "CustomSkinLoader requiere un perfil con mod loader compatible (cámbialo en la pestaña Perfiles).":
        "CustomSkinLoader requires a profile with a compatible mod loader (change it in Profiles).",
    "Este perfil no tiene una versión de Minecraft asignada.":
        "This profile does not have a Minecraft version assigned.",
    "Estable": "Release",
    "Beta": "Beta",
    "Alfa": "Alpha",
})

ENGLISH.update({
    "Actualizaciones": "Updates",
    "Buscar actualizaciones automáticamente": "Check for updates automatically",
    "Buscar ahora": "Check now",
    "Cancelar descarga": "Cancel download",
    "Versión instalada: {version}": "Installed version: {version}",
    "Buscando actualizaciones...": "Checking for updates...",
    "KatLauncher está actualizado.": "KatLauncher is up to date.",
    "KatLauncher {version} está disponible.": "KatLauncher {version} is available.",
    "Descargar e instalar": "Download and install",
    "Más tarde": "Later",
    "Descargando...": "Downloading...",
    "Cancelar": "Cancel",
    "Descargando KatLauncher {version}: {downloaded:.1f} de {total:.1f} MB":
        "Downloading KatLauncher {version}: {downloaded:.1f} of {total:.1f} MB",
    "Descargando actualización: {downloaded:.1f} de {total:.1f} MB":
        "Downloading update: {downloaded:.1f} of {total:.1f} MB",
    "No se pudo buscar actualizaciones: {error}":
        "Could not check for updates: {error}",
    "Descarga de la actualización cancelada.": "Update download cancelled.",
    "No se pudo descargar la actualización: {error}":
        "Could not download the update: {error}",
    "Actualización rechazada": "Update rejected",
    "La actualización no se instalará porque no pudo verificarse.\n\n{error}":
        "The update will not be installed because it could not be verified.\n\n{error}",
    "KatLauncher {version} está descargado y verificado.":
        "KatLauncher {version} has been downloaded and verified.",
    "Actualización lista": "Update ready",
    "KatLauncher {version} está listo para instalarse. La aplicación se cerrará y volverá a abrirse cuando termine el instalador. Si Windows no puede completar la actualización, mostrará el error y KatLauncher intentará abrirse de nuevo.\n\n¿Instalar ahora?":
        "KatLauncher {version} is ready to install. The application will close and reopen when the installer finishes. If Windows cannot complete the update, it will show the error and KatLauncher will try to reopen.\n\nInstall now?",
    "KatLauncher ya está abierto.": "KatLauncher is already running.",
    "El canal de actualizaciones todavía no está configurado.":
        "The update channel has not been configured yet.",
    "La versión de la actualización no es válida.": "The update version is invalid.",
    "La configuración del canal de actualizaciones es demasiado grande.":
        "The update channel configuration is too large.",
    "La configuración del canal de actualizaciones no es válida.":
        "The update channel configuration is invalid.",
    "La lista de servidores de actualización no es válida.":
        "The update server list is invalid.",
    "La URL de actualización no es segura.": "The update URL is not secure.",
    "La actualización redirigió a un servidor no permitido.":
        "The update redirected to a disallowed server.",
    "La actualización redirigió sin indicar un destino.":
        "The update redirected without a destination.",
    "La actualización superó el límite de redirecciones.":
        "The update exceeded the redirect limit.",
    "El tamaño del manifiesto no es válido.": "The manifest size is invalid.",
    "El manifiesto de actualización es demasiado grande.":
        "The update manifest is too large.",
    "El manifiesto de actualización no es JSON válido.":
        "The update manifest is not valid JSON.",
    "El manifiesto de actualización no es compatible.":
        "The update manifest is not supported.",
    "El canal de la actualización no es compatible.":
        "The update channel is not supported.",
    "El manifiesto no contiene un instalador válido.":
        "The manifest does not contain a valid installer.",
    "El manifiesto no contiene un instalador de Windows.":
        "The manifest does not contain a Windows installer.",
    "El tamaño del instalador no es válido.": "The installer size is invalid.",
    "El hash SHA-256 del instalador no es válido.":
        "The installer SHA-256 hash is invalid.",
    "Las notas de la actualización no son válidas.": "The update notes are invalid.",
    "La fecha de la actualización no es válida.": "The update date is invalid.",
    "El tamaño anunciado del instalador no es válido.":
        "The advertised installer size is invalid.",
    "El tamaño anunciado del instalador no coincide.":
        "The advertised installer size does not match.",
    "La descarga excedió el tamaño esperado.": "The download exceeded the expected size.",
    "El instalador descargado está incompleto.": "The downloaded installer is incomplete.",
    "El hash SHA-256 del instalador no coincide.":
        "The installer SHA-256 hash does not match.",
    "La ruta del instalador descargado no es válida.":
        "The downloaded installer path is invalid.",
    "El tamaño del instalador descargado no coincide.":
        "The downloaded installer size does not match.",
    "La instalación automática solo está disponible en Windows.":
        "Automatic installation is only available on Windows.",
    "La instalación automática solo está disponible en la aplicación instalada.":
        "Automatic installation is only available in the installed application.",
})

ENGLISH.update({
    "Actualizar todos los mods": "Update all mods",
    "Buscando actualizaciones de mods...": "Checking mod updates...",
    "Mods actualizados: {updated}. Al día: {current}. No reconocidos: {unknown}.":
        "Mods updated: {updated}. Current: {current}. Unrecognized: {unknown}.",
    "No se pudieron actualizar los mods: {error}": "Could not update mods: {error}",
    "Reparar perfil / modpack": "Repair profile / modpack",
    "Abrir carpeta de KatLauncher": "Open KatLauncher folder",
    "Reparación completa": "Repair complete",
    "El perfil quedó verificado. Tus mundos y configuraciones no se modificaron.":
        "The profile was verified. Your worlds and settings were not modified.",
    "Amigos": "Friends",
})

ENGLISH.update({
    "Noticias": "News",
    "Noticias de Minecraft": "Minecraft News",
    "Buscar noticia… (Enter)": "Search news… (Enter)",
    "Actualizar": "Refresh",
    "Abrir fuente oficial": "Open official source",
    "Cargando noticias oficiales…": "Loading official news…",
    "{count} noticias cargadas.": "{count} news items loaded.",
    "No se pudieron cargar noticias: {error}": "Could not load news: {error}",
    "Servidores": "Servers",
    "Añadir servidor favorito": "Add favorite server",
    "Nombre:": "Name:",
    "Dirección:": "Address:",
    "Puerto:": "Port:",
    "play.ejemplo.net (Enter)": "play.example.net (Enter)",
    "Añadir": "Add",
    "Comprobar estado": "Check status",
    "Cancelar comprobación": "Cancel check",
    "Jugar con el perfil:": "Play with profile:",
    "▶ Entrar al servidor": "▶ Join server",
    "Estado aún no comprobado.": "Status has not been checked yet.",
    "Sin conexión: {error}": "Offline: {error}",
    "Cuentas": "Accounts",
    "Nuevo nickname offline (Enter)": "New offline nickname (Enter)",
    "Eliminar cuenta": "Remove account",
    "Cuenta local / servidor offline": "Local account / offline server",
    "Estas identidades no envían contraseñas ni tokens. Elige una y aplícala al perfil con el que jugarás.":
        "These identities never send passwords or tokens. Choose one and apply it to the profile you will use.",
    "Usar esta cuenta en el perfil": "Use this account in the profile",
    "El acceso oficial necesita que Microsoft/Xbox apruebe la aplicación de KatLauncher. "
    "Se activará aquí cuando exista esa autorización; nunca se incrustará un Client Secret en el .exe.":
        "Official access requires Microsoft/Xbox to approve the KatLauncher application. "
        "It will be enabled here after that authorization; a Client Secret will never be embedded in the .exe.",
    "Pendiente de aprobación de Xbox": "Pending Xbox approval",
    "Tu sesión de Google pertenece a Kat Social (amigos y chat), no sustituye una licencia de Minecraft.":
        "Your Google session belongs to Kat Social (friends and chat); it does not replace a Minecraft license.",
    "El perfil ahora jugará como {nickname}.": "The profile will now play as {nickname}.",
    "Centrar vista 3D": "Reset 3D view",
    "Biblioteca Kat por perfil — mods, recursos y shaders desde Modrinth":
        "Per-profile Kat Library — mods, resources and shaders from Modrinth",
    "Contenido:": "Content:",
    "Paquetes de recursos": "Resource packs",
    "Shaders": "Shaders",
    "Paquetes de recursos instalados": "Installed resource packs",
    "Shaders instalados": "Installed shaders",
    "Nombre del paquete de recursos": "Resource pack name",
    "Nombre del shader, p. ej. 'Complementary'": "Shader name, e.g. 'Complementary'",
    "➕ Añadir {suffix}": "➕ Add {suffix}",
    "Selecciona archivos {suffix}": "Select {suffix} files",
    "✅ Instalado: {filename}. Dependencias instaladas: {count}.":
        "✅ Installed: {filename}. Dependencies installed: {count}.",
    "Opcionales no instaladas: {count}.": "Optional dependencies not installed: {count}.",
    "Incompatibilidades declaradas: {items}.": "Declared incompatibilities: {items}.",
    "Inicio": "Home",
    "Apariencia": "Appearance",
    "Tema de interfaz:": "Interface theme:",
    "Kat Modern usa el nuevo dashboard y navegación lateral. Kat Classic conserva el diseño anterior.":
        "Kat Modern uses the new dashboard and side navigation. Kat Classic keeps the previous design.",
    "Descargando actualización…": "Downloading update…",
    "Minecraft está abierto con {profile}.": "Minecraft is running with {profile}.",
    "Todo está listo.": "Everything is ready.",
    "No se pudo guardar el tema: {error}": "Could not save the theme: {error}",
    "Kat Social todavía está cerrando su conexión. Intenta salir de nuevo.":
        "Kat Social is still closing its connection. Try exiting again.",
    "Fuente:": "Source:",
    "Buscar en {provider}": "Search {provider}",
    "Buscando '{query}' en {provider}...": "Searching '{query}' on {provider}...",
    "Abrir en {provider}": "Open on {provider}",
    "Configurar API key": "Configure API key",
    "API key de CurseForge": "CurseForge API key",
    "Pega tu API key oficial (vacío = eliminar):":
        "Paste your official API key (empty = remove):",
    "❌ {error}": "❌ {error}",
})


ENGLISH.update({
    "Detectar mandos y preguntar si deseas instalar Controlify":
        "Detect controllers and ask before installing Controlify",
    "Mando detectado": "Controller detected",
    "KatLauncher detectó un mando. ¿Descargar e instalar Controlify en este perfil para controlar Minecraft?":
        "KatLauncher detected a controller. Download and install Controlify in this profile to control Minecraft?",
    "Este perfil es Vanilla. Para usar el mando dentro de Minecraft, crea un perfil Fabric, Quilt, NeoForge o Forge e instala Controlify.":
        "This is a Vanilla profile. To use a controller inside Minecraft, create a Fabric, Quilt, NeoForge or Forge profile and install Controlify.",
    "Kat Social": "Kat Social",
    "Guardar una copia local de los mensajes que veo":
        "Keep a local copy of the messages I see",
    "El historial se guarda solo en este PC y no vuelve a subirse a Supabase.":
        "History is stored only on this PC and is never uploaded back to Supabase.",
    "Abrir carpeta": "Open folder",
    "Mostrar Kat Presence (versión, loader y skin) en mi perfil":
        "Show Kat Presence (version, loader and skin) on my profile",
    "\nInicia sesión en Kat Social para que otros KatLauncher vean esta skin.":
        "\nSign in to Kat Social so other KatLauncher users can see this skin.",
    "\nPublicando en KatSkin para tus amigos...":
        "\nPublishing to KatSkin for your friends...",
    "\n✅ KatSkin publicada y compartida.":
        "\n✅ KatSkin published and shared.",
    "\n⚠ La skin local funciona, pero KatSkin no pudo publicarse: {error}":
        "\n⚠ The local skin works, but KatSkin could not publish it: {error}",
})

ENGLISH.update({
    # XMB 1.4.1
    "Usuarios": "Users",
    "Ajustes": "Settings",
    "Juegos": "Games",
    "Música": "Music",
    "Fotos": "Photos",
    "Red": "Network",
    "Debug": "Debug",
    "Kat Social": "Kat Social",
    "Amigos, chat global y mensajes privados":
        "Friends, global chat and private messages",
    "Cuentas": "Accounts",
    "Perfiles offline y acceso Microsoft": "Offline profiles and Microsoft access",
    "Apariencia, Java, sonido y actualizaciones":
        "Appearance, Java, sound and updates",
    "Inicio": "Home",
    "Resumen de KatLauncher": "KatLauncher overview",
    "Jugar Minecraft": "Play Minecraft",
    "Selecciona un perfil e inicia el juego":
        "Select a profile and launch the game",
    "Crea, repara y administra instalaciones":
        "Create, repair and manage installations",
    "Trofeos": "Trophies",
    "Progreso, placas y Platino de KatLauncher":
        "Progress, badges and KatLauncher Platinum",
    "Minecraft Bedrock": "Minecraft Bedrock",
    "Abre la edición oficial de Windows": "Open the official Windows edition",
    "Sonidos de Kat": "Kat sounds",
    "Configura sonidos y Rich Presence": "Configure sounds and Rich Presence",
    "Tono secreto de gato": "Secret cat ringtone",
    "Reproduce el easter egg de KatLauncher":
        "Play the KatLauncher easter egg",
    "Visor 3D, KatSkin, capas y élitros":
        "3D viewer, KatSkin, capes and elytra",
    "Explora Modrinth y CurseForge": "Explore Modrinth and CurseForge",
    "Instala o crea paquetes .mrpack": "Install or create .mrpack packages",
    "Noticias": "News",
    "Novedades oficiales de Minecraft": "Official Minecraft news",
    "Servidores": "Servers",
    "Favoritos, ping y conexión directa":
        "Favorites, ping and direct connection",
    "Abrir app estilo PS3": "Open PS3-style app",
    "Simula la entrada y abre el Inicio": "Simulate startup and open Home",
    "Popup de trofeo de platino": "Platinum trophy popup",
    "Muestra el aviso de prueba en la esquina":
        "Show the test notification in the corner",
    "Fondo aleatorio + tema": "Random background + theme",
    "Genera un fondo nuevo y cambia el color del sistema":
        "Generate a new background and change the system color",
    "Abrir ventana nueva": "Open new window",
    "Abre una ventana secundaria de diagnóstico":
        "Open a secondary diagnostics window",
    "Ventana de Debug": "Debug window",
    "Cerrar": "Close",
    "← → categorías   ↑ ↓ elementos   Enter/clic/A seleccionar   Esc volver":
        "← → categories   ↑ ↓ items   Enter/click/A select   Esc back",
    "Trofeo de Platino": "Platinum Trophy",
    "¡Has conseguido todos los trofeos!": "You unlocked every trophy!",
    "Trofeo": "Trophy",

    # Trofeos
    "Trofeos de KatLauncher": "KatLauncher Trophies",
    "{current}/{total} completados · {hours:.1f} horas registradas":
        "{current}/{total} completed · {hours:.1f} hours recorded",
    "{current:.1f}/{target:.0f} horas": "{current:.1f}/{target:.0f} hours",
    "DESBLOQUEADO": "UNLOCKED",
    "BLOQUEADO": "LOCKED",
    "bronce": "bronze",
    "plata": "silver",
    "oro": "gold",
    "diamante": "diamond",
    "platino": "platinum",
    "Disfruta de KatLauncher": "Enjoy KatLauncher",
    "Completa la guía inicial.": "Complete the initial guide.",
    "Aventurero de bronce": "Bronze Adventurer",
    "Juega durante 10 horas.": "Play for 10 hours.",
    "Leyenda de oro": "Golden Legend",
    "Juega durante 50 horas.": "Play for 50 hours.",
    "Gato de diamante": "Diamond Cat",
    "Juega durante 100 horas.": "Play for 100 hours.",
    "¡Mejores Amigos para siempre!": "Best Friends Forever!",
    "Consigue tu primera amistad en Kat Social.":
        "Make your first friend in Kat Social.",
    "¡Actualizado!": "Updated!",
    "Completa correctamente tu primera actualización.":
        "Successfully complete your first update.",
    "¡Mirad, ahora la vaca tiene alas!": "Look, now the cow has wings!",
    "Instala tu primer mod.": "Install your first mod.",
    "¿Estoy en Minecraft?": "Am I in Minecraft?",
    "Instala o crea tu primer modpack.": "Install or create your first modpack.",
    "¡Miren, soy nuevo!": "Look, I'm new!",
    "Envía tu primer mensaje al chat global.":
        "Send your first global chat message.",
    "¡Genial!": "Awesome!",
    "Crea tu primera publicación en Kat Social.":
        "Create your first Kat Social post.",
    "Platino de KatLauncher": "KatLauncher Platinum",
    "Desbloquea todos los trofeos de KatLauncher.":
        "Unlock every KatLauncher trophy.",

    # Bedrock y guía
    "Abrir Minecraft Bedrock": "Open Minecraft Bedrock",
    "Obtener Java & Bedrock oficialmente": "Get Java & Bedrock officially",
    "KatLauncher abre la instalación oficial de Bedrock y deja la cuenta, la licencia, Marketplace y actualizaciones bajo control de Microsoft/Xbox. Bedrock solo está disponible oficialmente en Windows 10/11.":
        "KatLauncher opens the official Bedrock installation while Microsoft/Xbox remains in control of the account, license, Marketplace and updates. Bedrock is officially available only on Windows 10/11.",
    "Bedrock no tiene cliente oficial para Linux; allí KatLauncher usa Java Edition.":
        "Bedrock has no official Linux client; KatLauncher uses Java Edition there.",
    "✓ Minecraft for Windows detectado y listo para abrir.":
        "✓ Minecraft for Windows detected and ready to open.",
    "Minecraft for Windows no fue detectado. Instálalo desde la tienda oficial.":
        "Minecraft for Windows was not detected. Install it from the official store.",
    "Windows no encontró el protocolo de Minecraft. Repara la instalación desde Microsoft Store.":
        "Windows could not find the Minecraft protocol. Repair the installation from Microsoft Store.",
    "Bienvenido a KatLauncher {version}": "Welcome to KatLauncher {version}",
    "Bienvenido a KatLauncher": "Welcome to KatLauncher",
    "¡Por favor no te desesperes! La versión 1.6.0 se acerca. "
    "Mientras tanto seguimos con novedades pequeñas por aquí. 💜":
        "Please don't lose hope! Version 1.6.0 is coming. "
        "In the meantime we'll keep shipping small updates here. 💜",
    "Cerrar aviso": "Close notice",
    "Este recorrido explica lo esencial. <b>No es obligatorio iniciar sesión con Minecraft Premium ni con Google para jugar tus perfiles Java sin conexión.</b>":
        "This tour explains the essentials. <b>You do not need to sign in with Minecraft Premium or Google to play your Java profiles offline.</b>",
    "Usa las flechas de abajo para recorrer cada parte del launcher. Este tutorial es opcional y puedes volver a abrirlo desde Inicio o Configuración.<br><br><b>No es obligatorio iniciar sesión con Minecraft Premium ni con Google para jugar tus perfiles Java sin conexión.</b>":
        "Use the arrows below to explore every part of the launcher. This tutorial is optional and you can reopen it from Home or Settings.<br><br><b>You do not need to sign in with Minecraft Premium or Google to play your Java profiles offline.</b>",
    "1. Crea un perfil": "1. Create a profile",
    "En <b>Perfiles</b> eliges versión, loader, memoria y nickname. La primera instalación necesita Internet; después podrás volver a abrir esa instancia sin conexión.":
        "In <b>Profiles</b>, choose the version, loader, memory and nickname. The first installation needs Internet; afterwards you can launch that instance offline.",
    "2. Mods, modpacks, skins y MCKAT": "2. Mods, modpacks, skins and MCKAT",
    "<b>Contenido</b> instala mods y dependencias. <b>Modpacks</b> importa archivos .mrpack. <b>Skins</b> administra tu apariencia local. El texture pack MCKAT se añade automáticamente y puede desactivarse desde Configuración.":
        "<b>Content</b> installs mods and dependencies. <b>Modpacks</b> imports .mrpack files. <b>Skins</b> manages your local appearance. The MCKAT texture pack is added automatically and can be disabled in Settings.",
    "3. Cuentas y Kat Social": "3. Accounts and Kat Social",
    "Google solo conecta <b>Kat Social</b>: amigos, mensajes y comunidad. No convierte la cuenta en Minecraft Premium. Las cuentas oficiales de Microsoft/Xbox se mantienen separadas y nunca guardamos un Client Secret.":
        "Google only connects <b>Kat Social</b>: friends, messages and community. It does not turn the account into Minecraft Premium. Official Microsoft/Xbox accounts remain separate and we never store a Client Secret.",
    "4. Comunidad y ayuda": "4. Community and help",
    "Puedes cambiar el diseño y los colores en <b>Configuración</b>. Si algo falla, conserva el mensaje del registro para poder repararlo.":
        "You can change the design and colors in <b>Settings</b>. If something fails, keep the log message so it can be repaired.",
    "Entrar al Discord de KatLauncher": "Join the KatLauncher Discord",

    # Kat Social
    "Editar perfil": "Edit profile",
    "Iniciar sesión con Google": "Sign in with Google",
    "Cerrar sesión": "Sign out",
    "Reportar mensaje": "Report message",
    "Bloquear autor": "Block author",
    "Moderar (ocultar + 10 min)": "Moderate (hide + 10 min)",
    "Escribe y pulsa Enter": "Type and press Enter",
    "Enviar": "Send",
    "Buscar nick y pulsar Enter": "Search nickname and press Enter",
    "Buscar": "Search",
    "Enviar mensaje privado": "Send private message",
    "Escribe una publicación y pulsa Enter": "Write a post and press Enter",
    "Publicar": "Post",
    "Chat global": "Global chat",
    "Amigos y solicitudes": "Friends and requests",
    "Mensajes privados": "Private messages",
    "Publicaciones": "Posts",
    "Kat Social está listo, pero falta conectar el proyecto Supabase de KatLauncher.":
        "Kat Social is ready, but the KatLauncher Supabase project still needs to be connected.",
    "Editar perfil de Kat Social": "Edit Kat Social profile",
    "Entre 2 y 32 caracteres": "Between 2 and 32 characters",
    "Nick público:": "Public nickname:",
    "Sin foto nueva": "No new picture",
    "Seleccionar PFP…": "Select profile picture…",
    "Restablecer el nombre de Google": "Restore Google name",
    "Restablecer la foto de Google": "Restore Google picture",
    "Seleccionar foto de perfil": "Select profile picture",
    "Imágenes (*.png *.jpg *.jpeg *.webp);;Todos los archivos (*)":
        "Images (*.png *.jpg *.jpeg *.webp);;All files (*)",
    "Perfil de Kat Social": "Kat Social Profile",
    "horas": "hours",
    "Jugando Minecraft": "Playing Minecraft",
    "Cargando skin…": "Loading skin…",
    "⚫ No está jugando ahora": "⚫ Not playing right now",
    "Placas y trofeos ({count})": "Badges and trophies ({count})",
    "Todavía no tiene trofeos públicos": "No public trophies yet",
    "Enviar solicitud de amistad": "Send friend request",
    "Skin no disponible": "Skin unavailable",
    "doble clic para enviar solicitud": "double-click to send request",
    "solicitud enviada": "request sent",
    "¿Aceptar esta solicitud de amistad?": "Accept this friend request?",
    "Motivo del reporte:": "Report reason:",
    "¿Bloquear a este usuario?": "Block this user?",
    "sin leer": "unread",
    "Solicitud": "Request",
    "Leyenda cósmica": "Cosmic Legend",
    "Gato ancestral": "Ancient Cat",
    "Explorador experto": "Expert Explorer",
    "Aventurero": "Adventurer",
    "Minero": "Miner",
    "Recién llegado": "Newcomer",
    "Usuario Premium (Enter)": "Premium username (Enter)",
    "Classic · 4 px": "Classic · 4 px",
    "Slim · 3 px": "Slim · 3 px",
})


ENGLISH_PREFIXES = (
    ("No se pudo conectar con el servicio de actualizaciones: ",
     "Could not connect to the update service: "),
    ("El servicio de actualizaciones devolvió un error: ",
     "The update service returned an error: "),
    ("No se pudo descargar el manifiesto de actualización: ",
     "Could not download the update manifest: "),
    ("No se pudo descargar el instalador: ",
     "Could not download the installer: "),
    ("No se pudo verificar el instalador descargado: ",
     "Could not verify the downloaded installer: "),
    ("No se pudo iniciar el instalador de la actualización: ",
     "Could not start the update installer: "),
    ("No se pudo preparar el registro de la actualización: ",
     "Could not prepare the update log: "),
    ("No se pudo consultar Modrinth: ", "Could not contact Modrinth: "),
    ("No se pudo descargar el archivo: ", "Could not download the file: "),
    ("Loader desconocido: ", "Unknown loader: "),
    ("El modpack usa dependencias que KatLauncher aún no admite: ",
     "The modpack uses dependencies KatLauncher does not support yet: "),
    ("No se encontró la versión instalada requerida: ",
     "The required installed version was not found: "),
    ("Ruta no segura dentro del modpack: ", "Unsafe path inside the modpack: "),
    ("Ruta absoluta no permitida en el modpack: ",
     "Absolute path not allowed in the modpack: "),
    ("Nombre no válido para Windows en el modpack: ",
     "Invalid Windows name in the modpack: "),
    ("Nombre reservado de Windows en el modpack: ",
     "Reserved Windows name in the modpack: "),
    ("El modpack contiene rutas duplicadas: ", "The modpack contains duplicate paths: "),
    ("No se permiten enlaces simbólicos: ", "Symbolic links are not allowed: "),
    ("Un archivo del modpack es demasiado grande: ", "A modpack file is too large: "),
    ("Relación de compresión sospechosa: ", "Suspicious compression ratio: "),
    ("El archivo .mrpack no es un ZIP válido: ", "The .mrpack file is not a valid ZIP: "),
    ("El índice contiene una ruta duplicada: ", "The index contains a duplicate path: "),
    ("Faltan hashes válidos para ", "Valid hashes are missing for "),
    ("No hay descargas para ", "No downloads are available for "),
    ("Ruta descargada no segura: ", "Unsafe downloaded path: "),
    ("No se descargó un archivo requerido: ", "A required file was not downloaded: "),
    ("El tamaño descargado no coincide: ", "The downloaded size does not match: "),
    ("Los hashes descargados no coinciden: ", "The downloaded hashes do not match: "),
    ("El archivo descargable no termina en ", "The downloadable file does not end in "),
)

ENGLISH_PATTERNS = (
    (re.compile(r"^No se pudo descargar (.+): (.+)$"),
     lambda match: f"Could not download {match.group(1)}: "
                   f"{_translate_english(match.group(2))}"),
    (re.compile(r"^Minecraft (.+) no está instalado$"),
     lambda match: f"Minecraft {match.group(1)} is not installed"),
    (re.compile(r"^Hay varias versiones instaladas de (.+) para Minecraft (.+)$"),
     lambda match: f"Multiple {match.group(1)} versions are installed for Minecraft {match.group(2)}"),
    (re.compile(r"^No se encontró (.+) instalado para Minecraft (.+)$"),
     lambda match: f"No installed {match.group(1)} was found for Minecraft {match.group(2)}"),
    (re.compile(r"^El modpack requiere (.+), pero se instaló (.+)\.$"),
     lambda match: f"The modpack requires {match.group(1)}, but {match.group(2)} was installed."),
    (re.compile(r"^No se encontró una versión de '(.+)' compatible con (.+) (.+)\.$"),
     lambda match: f"No version of '{match.group(1)}' compatible with {match.group(2)} {match.group(3)} was found."),
    (re.compile(r"^La versión de (.+) no es válida\.$"),
     lambda match: f"The {match.group(1)} version is invalid."),
    (re.compile(r"^El tamaño de (.+) no es válido\.$"),
     lambda match: f"The size of {match.group(1)} is invalid."),
    (re.compile(r"^El entorno de (.+) no es válido\.$"),
     lambda match: f"The environment for {match.group(1)} is invalid."),
    (re.compile(r"^El campo (.+) del modpack no es válido\.$"),
     lambda match: f"The modpack field {match.group(1)} is invalid."),
)

SPANISH_EXTERNAL = {
    "Download Libraries": "Descargando librerías",
    "Download Assets": "Descargando recursos",
    "Install java runtime": "Instalando el entorno de Java",
    "Installation complete": "Instalación completada",
    "Running installer": "Ejecutando el instalador",
    "Running fabric installer": "Ejecutando el instalador de Fabric",
    "Running quilt installer": "Ejecutando el instalador de Quilt",
    "Download mrpack files": "Descargando archivos del modpack",
    "Extract overrides": "Extrayendo archivos del modpack",
}


def _translate_english(source: str) -> str:
    exact = ENGLISH.get(source)
    if exact is not None:
        return exact
    for spanish, english in ENGLISH_PREFIXES:
        if source.startswith(spanish):
            return english + source[len(spanish):]
    for pattern, renderer in ENGLISH_PATTERNS:
        match = pattern.fullmatch(source)
        if match:
            return renderer(match)
    return source


def _translate_external_spanish(source: str) -> str:
    exact = SPANISH_EXTERNAL.get(source)
    if exact is not None:
        return exact
    for english, spanish in (
        ("Running processor ", "Ejecutando procesador "),
        ("Download ", "Descargando "),
        ("Extract ", "Extrayendo "),
    ):
        if source.startswith(english):
            return spanish + source[len(english):]
    return source


class I18n(QObject):
    language_changed = Signal(str)

    def __init__(self, language: str = "es"):
        super().__init__()
        self.language = language if language in ("es", "en") else "es"

    def set_language(self, language: str):
        language = language if language in ("es", "en") else "es"
        if language != self.language:
            self.language = language
            self.language_changed.emit(language)

    def t(self, source: str, **kwargs) -> str:
        template = _translate_english(source) if self.language == "en" \
            else _translate_external_spanish(source)
        try:
            return template.format(**kwargs)
        except (KeyError, ValueError):
            return template

    def number(self, value: int) -> str:
        try:
            number = int(value)
        except (TypeError, ValueError):
            number = 0
        formatted = f"{number:,}"
        return formatted if self.language == "en" else formatted.replace(",", ".")
