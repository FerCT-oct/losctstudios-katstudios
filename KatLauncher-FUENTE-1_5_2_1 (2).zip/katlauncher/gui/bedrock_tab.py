"""Puente seguro hacia Minecraft Bedrock oficial en Windows."""
from __future__ import annotations

import os
from pathlib import Path

from PySide6.QtCore import QUrl, Signal
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import QLabel, QMessageBox, QPushButton, QVBoxLayout, QWidget


BEDROCK_PACKAGE = "Microsoft.MinecraftUWP_8wekyb3d8bbwe"
MINECRAFT_STORE_URL = (
    "https://www.minecraft.net/es-es/store/minecraft-java-bedrock-edition-pc"
)


def bedrock_installation_detected() -> bool:
    if os.name != "nt":
        return False
    packages = Path(os.environ.get("LOCALAPPDATA", "")) / "Packages"
    return (packages / BEDROCK_PACKAGE).is_dir()


class BedrockTab(QWidget):
    operation_succeeded = Signal()

    def __init__(self, i18n, parent=None):
        super().__init__(parent)
        self.i18n = i18n
        layout = QVBoxLayout(self)
        self.title = QLabel()
        self.title.setObjectName("bigTitle")
        layout.addWidget(self.title)
        self.status = QLabel()
        self.status.setWordWrap(True)
        layout.addWidget(self.status)
        self.launch_button = QPushButton()
        self.launch_button.setObjectName("modernPlayButton")
        self.launch_button.clicked.connect(self.launch_bedrock)
        layout.addWidget(self.launch_button)
        self.store_button = QPushButton()
        self.store_button.clicked.connect(
            lambda: QDesktopServices.openUrl(QUrl(MINECRAFT_STORE_URL))
        )
        layout.addWidget(self.store_button)
        self.notice = QLabel()
        self.notice.setWordWrap(True)
        layout.addWidget(self.notice)
        layout.addStretch()
        self.i18n.language_changed.connect(self.retranslate_ui)
        self.retranslate_ui()

    def retranslate_ui(self, *_args):
        t = self.i18n.t
        self.title.setText(t("Minecraft Bedrock"))
        self.launch_button.setText(t("Abrir Minecraft Bedrock"))
        self.store_button.setText(t("Obtener Java & Bedrock oficialmente"))
        self.notice.setText(t(
            "KatLauncher abre la instalación oficial de Bedrock y deja la cuenta, "
            "la licencia, Marketplace y actualizaciones bajo control de Microsoft/Xbox. "
            "Bedrock solo está disponible oficialmente en Windows 10/11."
        ))
        self.refresh()

    def refresh(self):
        supported = os.name == "nt"
        installed = bedrock_installation_detected()
        self.launch_button.setEnabled(supported and installed)
        if not supported:
            self.status.setText(self.i18n.t(
                "Bedrock no tiene cliente oficial para Linux; allí KatLauncher usa Java Edition."
            ))
        elif installed:
            self.status.setText(self.i18n.t(
                "✓ Minecraft for Windows detectado y listo para abrir."
            ))
        else:
            self.status.setText(self.i18n.t(
                "Minecraft for Windows no fue detectado. Instálalo desde la tienda oficial."
            ))

    def launch_bedrock(self):
        if not bedrock_installation_detected():
            self.refresh()
            return
        if not QDesktopServices.openUrl(QUrl("minecraft://")):
            QMessageBox.warning(
                self, self.i18n.t("Minecraft Bedrock"),
                self.i18n.t(
                    "Windows no encontró el protocolo de Minecraft. "
                    "Repara la instalación desde Microsoft Store."
                ),
            )
            return
        self.operation_succeeded.emit()
