"""Efectos de sonido ligeros para Windows sin dependencias multimedia externas."""
from __future__ import annotations

import ctypes
import sys
from pathlib import Path

from PySide6.QtCore import QObject, QTimer


ASSETS_DIR = Path(__file__).resolve().parent.parent / "assets"
SUCCESS_SOUND_PATH = ASSETS_DIR / "success.mp3"
CAT_RINGTONE_PATH = ASSETS_DIR / "cat_ringtone.mp3"
UPDATE_SUCCESS_SOUND_PATH = ASSETS_DIR / "update_success.wav"
UI_CLICK_SOUND_PATH = ASSETS_DIR / "ui_click.mp3"
SOFT_SUCCESS_SOUND_PATH = ASSETS_DIR / "soft_success.mp3"
ACHIEVEMENT_SOUND_PATH = ASSETS_DIR / "achievement.mp3"
ERROR_SOUND_PATH = ASSETS_DIR / "error.mp3"
NOTIFICATION_SOUND_PATH = ASSETS_DIR / "notification.mp3"
INVITE_SOUND_PATH = ASSETS_DIR / "invite.mp3"
CREEPER_SOUND_PATH = ASSETS_DIR / "creeper.mp3"


class _MciAudioBackend:
    """Reproduce MP3 con la API multimedia incluida en Windows."""

    def __init__(self):
        winmm = ctypes.WinDLL("winmm")
        self._send = winmm.mciSendStringW
        self._send.argtypes = [
            ctypes.c_wchar_p,
            ctypes.c_wchar_p,
            ctypes.c_uint,
            ctypes.c_void_p,
        ]
        self._send.restype = ctypes.c_uint
        self._error_string = winmm.mciGetErrorStringW
        self._error_string.argtypes = [
            ctypes.c_uint,
            ctypes.c_wchar_p,
            ctypes.c_uint,
        ]
        self._error_string.restype = ctypes.c_bool

    def _command(self, command: str, result_size: int = 0) -> str:
        buffer = ctypes.create_unicode_buffer(result_size) if result_size else None
        code = self._send(command, buffer, result_size, None)
        if code:
            message = ctypes.create_unicode_buffer(256)
            if self._error_string(code, message, len(message)):
                detail = message.value
            else:
                detail = f"código MCI {code}"
            raise OSError(f"No se pudo reproducir el sonido: {detail}")
        return buffer.value if buffer is not None else ""

    def play(self, path: Path, alias: str) -> int:
        if not path.is_file():
            raise OSError(f"No se encontró el sonido: {path.name}")
        self.close(alias)
        # Las rutas son recursos internos controlados por KatLauncher. Se rechazan
        # comillas para que nunca puedan alterar la orden enviada a MCI.
        path_text = str(path)
        if '"' in path_text:
            raise OSError("La ruta del sonido no es válida.")
        media_type = "waveaudio" if path.suffix.lower() == ".wav" else "mpegvideo"
        self._command(f'open "{path_text}" type {media_type} alias {alias}')
        try:
            self._command(f"play {alias} from 0")
            raw_length = self._command(f"status {alias} length", 64)
            return max(0, int(raw_length or 0))
        except Exception:
            self.close(alias)
            raise

    def close(self, alias: str):
        # Cerrar un alias inexistente devuelve error; aquí es intencionalmente
        # ignorado porque close también se usa como limpieza preventiva.
        self._send(f"close {alias}", None, 0, None)


class SoundManager(QObject):
    """Coordina los sonidos de éxito y del easter egg del logotipo."""

    _ALIASES = {
        "success": "katlauncher_success",
        "cat": "katlauncher_cat",
        "update": "katlauncher_update",
        "click": "katlauncher_click",
        "operation": "katlauncher_operation",
        "achievement": "katlauncher_achievement",
        "error": "katlauncher_error",
        "notification": "katlauncher_notification",
        "invite": "katlauncher_invite",
        "creeper": "katlauncher_creeper",
    }

    def __init__(self, enabled: bool = True, parent=None, backend=None):
        super().__init__(parent)
        self.enabled = bool(enabled)
        self._generations = {name: 0 for name in self._ALIASES}
        if backend is not None:
            self._backend = backend
        elif sys.platform == "win32":
            try:
                self._backend = _MciAudioBackend()
            except (AttributeError, OSError):
                self._backend = None
        else:
            self._backend = None

    def set_enabled(self, enabled: bool):
        self.enabled = bool(enabled)
        if not self.enabled:
            self.close()

    def play_success(self) -> bool:
        return self._play("success", SUCCESS_SOUND_PATH)

    def play_cat_ringtone(self) -> bool:
        return self._play("cat", CAT_RINGTONE_PATH)

    def play_update_success(self) -> bool:
        return self._play("update", UPDATE_SUCCESS_SOUND_PATH)

    def play_ui_click(self) -> bool:
        return self._play("click", UI_CLICK_SOUND_PATH)

    def play_operation_success(self) -> bool:
        return self._play("operation", SOFT_SUCCESS_SOUND_PATH)

    def play_achievement(self) -> bool:
        return self._play("achievement", ACHIEVEMENT_SOUND_PATH)

    def play_error(self) -> bool:
        return self._play("error", ERROR_SOUND_PATH)

    def play_warning(self) -> bool:
        return self._play("error", ERROR_SOUND_PATH)

    def play_notification(self) -> bool:
        return self._play("notification", NOTIFICATION_SOUND_PATH)

    def play_invite(self) -> bool:
        return self._play("invite", INVITE_SOUND_PATH)

    def play_creeper(self) -> bool:
        return self._play("creeper", CREEPER_SOUND_PATH)

    def _play(self, name: str, path: Path) -> bool:
        if not self.enabled or self._backend is None:
            return False
        alias = self._ALIASES[name]
        self._generations[name] += 1
        generation = self._generations[name]
        try:
            duration = self._backend.play(path, alias)
        except (OSError, ValueError):
            return False
        QTimer.singleShot(
            max(1000, duration + 500),
            lambda: self._close_if_current(name, generation),
        )
        return True

    def _close_if_current(self, name: str, generation: int):
        if generation != self._generations[name] or self._backend is None:
            return
        self._backend.close(self._ALIASES[name])

    def close(self):
        for name, alias in self._ALIASES.items():
            self._generations[name] += 1
            if self._backend is not None:
                self._backend.close(alias)
