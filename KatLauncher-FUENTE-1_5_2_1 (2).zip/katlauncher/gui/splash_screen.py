from pathlib import Path

from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QProgressBar, QFrame
from PySide6.QtGui import QPixmap, QGuiApplication
from PySide6.QtCore import Qt

ASSETS_DIR = Path(__file__).resolve().parent.parent / "assets"
LOGO_PATH = ASSETS_DIR / "logo.png"

SPLASH_STYLE = """
QFrame#splashPanel {
    background-color: #16181d;
    border: 1px solid #3a2d55;
    border-radius: 18px;
}
QLabel#splashTitle {
    color: #b98bf0;
    font-size: 26px;
    font-weight: bold;
}
QLabel#splashStatus {
    color: #9a9aa5;
    font-size: 12px;
}
QProgressBar {
    border: 1px solid #2a2d35;
    border-radius: 5px;
    background-color: #1e2128;
    text-align: center;
    color: #e8e8ec;
    height: 14px;
}
QProgressBar::chunk {
    background-color: #9b5de5;
    border-radius: 5px;
}
"""


class SplashScreen(QWidget):
    """Pantalla de carga inicial de KatLauncher, con el logo del gato cósmico."""

    def __init__(self, i18n):
        super().__init__()
        self.i18n = i18n
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setFixedSize(380, 460)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(10, 10, 10, 10)

        panel = QFrame(self)
        panel.setObjectName("splashPanel")
        panel.setStyleSheet(SPLASH_STYLE)
        outer.addWidget(panel)

        layout = QVBoxLayout(panel)
        layout.setContentsMargins(28, 28, 28, 24)
        layout.setSpacing(14)
        layout.addStretch()

        logo_label = QLabel()
        if LOGO_PATH.exists():
            pixmap = QPixmap(str(LOGO_PATH)).scaled(
                200, 200, Qt.KeepAspectRatio, Qt.SmoothTransformation
            )
            logo_label.setPixmap(pixmap)
        logo_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(logo_label)

        title = QLabel("KatLauncher")
        title.setObjectName("splashTitle")
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)

        self.status_label = QLabel(self.i18n.t("Iniciando..."))
        self.status_label.setObjectName("splashStatus")
        self.status_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.status_label)

        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        self.progress_bar.setTextVisible(False)
        layout.addWidget(self.progress_bar)

        layout.addStretch()

        self._center_on_screen()

    def _center_on_screen(self):
        screen = QGuiApplication.primaryScreen()
        if not screen:
            return
        geo = screen.availableGeometry()
        x = geo.x() + (geo.width() - self.width()) // 2
        y = geo.y() + (geo.height() - self.height()) // 2
        self.move(x, y)

    def set_status(self, text: str):
        self.status_label.setText(text)

    def set_progress(self, value: int):
        self.progress_bar.setValue(value)
