"""Banner genérico para mostrar alertas remotas (info/advertencia/crítico)."""
from __future__ import annotations

from PySide6.QtCore import Signal
from PySide6.QtWidgets import QFrame, QHBoxLayout, QLabel, QPushButton, QVBoxLayout

_ICONS = {
    "info": "ℹ️",
    "warning": "⚠️",
    "critical": "🛑",
}


class AlertBanner(QFrame):
    """Banner no intrusivo y descartable para alertas empujadas remotamente."""

    dismissed = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.alert_id = ""
        self.setObjectName("alertBanner")
        self.setProperty("severity", "info")
        self.setVisible(False)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(18, 12, 14, 12)
        layout.setSpacing(12)

        self.icon_label = QLabel()
        self.icon_label.setObjectName("alertBannerIcon")
        layout.addWidget(self.icon_label)

        text_column = QVBoxLayout()
        text_column.setSpacing(2)
        self.title_label = QLabel()
        self.title_label.setObjectName("alertBannerTitle")
        self.message_label = QLabel()
        self.message_label.setObjectName("alertBannerMessage")
        self.message_label.setWordWrap(True)
        text_column.addWidget(self.title_label)
        text_column.addWidget(self.message_label)
        layout.addLayout(text_column, stretch=1)

        self.dismiss_button = QPushButton("✕")
        self.dismiss_button.setObjectName("alertBannerDismissButton")
        self.dismiss_button.setFixedSize(26, 26)
        self.dismiss_button.clicked.connect(self._on_dismiss)
        layout.addWidget(self.dismiss_button)

    def show_alert(self, info) -> None:
        self.alert_id = info.id
        self.setProperty("severity", info.severity)
        self.style().unpolish(self)
        self.style().polish(self)
        self.icon_label.setText(_ICONS.get(info.severity, _ICONS["info"]))
        self.title_label.setText(info.title_for(self._current_language()))
        self.message_label.setText(info.message_for(self._current_language()))
        self.setVisible(True)

    def _current_language(self) -> str:
        return getattr(self, "language", "es")

    def set_language(self, language: str) -> None:
        self.language = language

    def _on_dismiss(self) -> None:
        self.setVisible(False)
        self.dismissed.emit(self.alert_id)
