"""Dashboard desacoplado para la interfaz Kat Modern 1.4.0."""
from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QPainter, QPixmap
from PySide6.QtWidgets import (
    QComboBox,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QProgressBar,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)

from .alert_banner import AlertBanner


ASSETS_DIR = Path(__file__).resolve().parent.parent / "assets"
LOGO_PATH = ASSETS_DIR / "logo.png"


class DashboardRoute:
    """Rutas públicas usadas por el dashboard y el shell moderno."""

    HOME = "home"
    PLAY = "play"
    BEDROCK = "bedrock"
    PROFILES = "profiles"
    MODS = "mods"
    FRIENDS = "friends"
    DOWNLOADS = "downloads"
    SKINS = "skins"
    SCREENSHOTS = "screenshots"
    NEWS = "news"
    SERVERS = "servers"
    ROOMS = "rooms"
    ACCOUNTS = "accounts"
    TROPHIES = "trophies"
    SETTINGS = "settings"


class _ClickableLabel(QLabel):
    clicked = Signal()

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton and self.rect().contains(event.position().toPoint()):
            self.clicked.emit()
        super().mouseReleaseEvent(event)


class DashboardTab(QWidget):
    """Página de inicio visual que delega las acciones al controlador principal.

    La clase nunca inicia Minecraft ni cambia de pestaña por su cuenta. Emite
    señales con IDs/rutas estables para que MainWindow conserve el control.
    """

    play_requested = Signal(str)
    navigate_requested = Signal(str)
    active_profile_changed = Signal(str)
    logo_clicked = Signal()
    check_updates_requested = Signal()
    tutorial_requested = Signal()

    def __init__(self, profile_manager, i18n=None, parent=None, settings_manager=None):
        super().__init__(parent)
        self.pm = profile_manager
        self.i18n = i18n
        self.settings_manager = settings_manager
        self._build_ui()
        if self.i18n is not None and hasattr(self.i18n, "language_changed"):
            self.i18n.language_changed.connect(self.retranslate_ui)
        self.retranslate_ui()
        self.refresh_profiles()
        self._apply_roadmap_banner_visibility()

    def _build_ui(self) -> None:
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)

        self.scroll = QScrollArea()
        self.scroll.setObjectName("dashboardScroll")
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QFrame.NoFrame)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        outer.addWidget(self.scroll)

        viewport = QWidget()
        viewport.setObjectName("dashboardViewport")
        self.scroll.setWidget(viewport)
        root = QVBoxLayout(viewport)
        root.setContentsMargins(30, 26, 30, 30)
        root.setSpacing(20)

        header = QHBoxLayout()
        header.setSpacing(13)
        self.logo = _ClickableLabel()
        self.logo.setCursor(Qt.PointingHandCursor)
        self.logo.setToolTip("KatLauncher")
        self.logo.setFixedSize(52, 52)
        self.logo.setAlignment(Qt.AlignCenter)
        if LOGO_PATH.is_file():
            self.logo.setPixmap(
                QPixmap(str(LOGO_PATH)).scaled(
                    50, 50, Qt.KeepAspectRatio, Qt.SmoothTransformation
                )
            )
        self.logo.clicked.connect(self.logo_clicked)
        header.addWidget(self.logo)

        heading = QVBoxLayout()
        heading.setSpacing(2)
        self.title_label = QLabel()
        self.title_label.setObjectName("dashboardTitle")
        self.subtitle_label = QLabel()
        self.subtitle_label.setObjectName("dashboardSubtitle")
        heading.addWidget(self.title_label)
        heading.addWidget(self.subtitle_label)
        header.addLayout(heading)
        header.addStretch()
        self.tutorial_button = QPushButton()
        self.tutorial_button.setObjectName("quickAccessButton")
        self.tutorial_button.clicked.connect(self.tutorial_requested)
        self.update_button = QPushButton()
        self.update_button.setObjectName("quickAccessButton")
        self.update_button.clicked.connect(self.check_updates_requested)
        header.addWidget(self.tutorial_button)
        header.addWidget(self.update_button)
        root.addLayout(header)

        self.alert_banner = AlertBanner()
        root.addWidget(self.alert_banner)

        self.roadmap_banner = QFrame()
        self.roadmap_banner.setObjectName("roadmapBanner")
        roadmap_layout = QHBoxLayout(self.roadmap_banner)
        roadmap_layout.setContentsMargins(18, 12, 14, 12)
        roadmap_layout.setSpacing(12)
        self.roadmap_icon = QLabel("🐾")
        self.roadmap_icon.setObjectName("roadmapIcon")
        roadmap_layout.addWidget(self.roadmap_icon)
        self.roadmap_label = QLabel()
        self.roadmap_label.setObjectName("roadmapLabel")
        self.roadmap_label.setWordWrap(True)
        roadmap_layout.addWidget(self.roadmap_label, stretch=1)
        self.roadmap_dismiss_button = QPushButton("✕")
        self.roadmap_dismiss_button.setObjectName("roadmapDismissButton")
        self.roadmap_dismiss_button.setFixedSize(26, 26)
        self.roadmap_dismiss_button.setCursor(Qt.PointingHandCursor)
        self.roadmap_dismiss_button.clicked.connect(self._dismiss_roadmap_banner)
        roadmap_layout.addWidget(self.roadmap_dismiss_button, alignment=Qt.AlignTop)
        root.addWidget(self.roadmap_banner)

        self.hero_card = QFrame()
        self.hero_card.setObjectName("heroCard")
        hero = QHBoxLayout(self.hero_card)
        hero.setContentsMargins(26, 24, 26, 24)
        hero.setSpacing(22)

        self.avatar_label = QLabel()
        self.avatar_label.setObjectName("accentAvatar")
        self.avatar_label.setFixedSize(94, 94)
        self.avatar_label.setAlignment(Qt.AlignCenter)
        hero.addWidget(self.avatar_label, alignment=Qt.AlignVCenter)

        profile_column = QVBoxLayout()
        profile_column.setSpacing(5)
        self.profile_caption = QLabel()
        self.profile_caption.setObjectName("cardCaption")
        self.profile_name = QLabel()
        self.profile_name.setObjectName("profileName")
        self.profile_name.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Preferred)
        self.profile_meta = QLabel()
        self.profile_meta.setObjectName("profileMeta")
        self.profile_nickname = QLabel()
        self.profile_nickname.setObjectName("profileMeta")
        profile_column.addWidget(self.profile_caption)
        profile_column.addWidget(self.profile_name)
        profile_column.addWidget(self.profile_meta)
        profile_column.addWidget(self.profile_nickname)
        profile_column.addStretch()
        hero.addLayout(profile_column, stretch=1)

        actions = QVBoxLayout()
        actions.setSpacing(10)
        self.profile_combo = QComboBox()
        self.profile_combo.setMinimumWidth(220)
        self.profile_combo.setMinimumContentsLength(18)
        self.profile_combo.setSizeAdjustPolicy(QComboBox.AdjustToMinimumContentsLengthWithIcon)
        self.profile_combo.currentIndexChanged.connect(self._on_profile_selected)
        actions.addWidget(self.profile_combo)
        self.play_button = QPushButton()
        self.play_button.setObjectName("modernPlayButton")
        self.play_button.setCursor(Qt.PointingHandCursor)
        self.play_button.clicked.connect(self._request_play)
        actions.addWidget(self.play_button)
        hero.addLayout(actions)
        root.addWidget(self.hero_card)

        content_grid = QGridLayout()
        content_grid.setHorizontalSpacing(18)
        content_grid.setVerticalSpacing(18)

        self.quick_card = QFrame()
        self.quick_card.setObjectName("modernCard")
        quick_layout = QVBoxLayout(self.quick_card)
        quick_layout.setContentsMargins(20, 18, 20, 18)
        self.quick_title = QLabel()
        self.quick_title.setObjectName("cardTitle")
        quick_layout.addWidget(self.quick_title)

        quick_grid = QGridLayout()
        quick_grid.setSpacing(8)
        self.quick_buttons = {}
        quick_items = (
            (DashboardRoute.PROFILES, "Perfiles", "Administra versiones y memoria"),
            (DashboardRoute.MODS, "Mods", "Explora y actualiza contenido"),
            (DashboardRoute.FRIENDS, "Amigos", "Kat Social y mensajes"),
            (DashboardRoute.DOWNLOADS, "Descargas", "Progreso y operaciones"),
        )
        for position, (route, title, subtitle) in enumerate(quick_items):
            button = QPushButton()
            button.setObjectName("quickAccessButton")
            button.setCursor(Qt.PointingHandCursor)
            button.setProperty("titleKey", title)
            button.setProperty("subtitleKey", subtitle)
            button.setToolTip(subtitle)
            button.clicked.connect(
                lambda _checked=False, selected=route: self.navigate_requested.emit(selected)
            )
            # Ignorar el ancho sugerido por el subtítulo evita una barra
            # horizontal en ventanas pequeñas; el tooltip conserva el texto.
            button.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Preferred)
            button.setMinimumWidth(0)
            quick_grid.addWidget(button, position // 2, position % 2)
            self.quick_buttons[route] = button
        quick_layout.addLayout(quick_grid)
        content_grid.addWidget(self.quick_card, 0, 0, 2, 1)

        self.social_card = QFrame()
        self.social_card.setObjectName("statusCard")
        social_layout = QVBoxLayout(self.social_card)
        social_layout.setContentsMargins(20, 18, 20, 18)
        self.social_title = QLabel()
        self.social_title.setObjectName("cardTitle")
        self.social_summary = QLabel()
        self.social_summary.setObjectName("mutedLabel")
        self.social_summary.setWordWrap(True)
        social_layout.addWidget(self.social_title)
        social_layout.addWidget(self.social_summary)
        social_layout.addStretch()
        self.open_friends_button = QPushButton()
        self.open_friends_button.clicked.connect(
            lambda: self.navigate_requested.emit(DashboardRoute.FRIENDS)
        )
        social_layout.addWidget(self.open_friends_button)
        content_grid.addWidget(self.social_card, 0, 1)

        self.download_card = QFrame()
        self.download_card.setObjectName("statusCard")
        download_layout = QVBoxLayout(self.download_card)
        download_layout.setContentsMargins(20, 18, 20, 18)
        self.download_title = QLabel()
        self.download_title.setObjectName("cardTitle")
        self.download_detail = QLabel()
        self.download_detail.setObjectName("downloadDetail")
        self.download_detail.setWordWrap(True)
        self.download_progress = QProgressBar()
        self.download_progress.setRange(0, 100)
        self.download_progress.setValue(0)
        download_layout.addWidget(self.download_title)
        download_layout.addWidget(self.download_detail)
        download_layout.addWidget(self.download_progress)
        content_grid.addWidget(self.download_card, 1, 1)

        content_grid.setColumnStretch(0, 3)
        content_grid.setColumnStretch(1, 2)
        root.addLayout(content_grid)
        root.addStretch()

    def _t(self, text: str, **kwargs) -> str:
        if self.i18n is not None:
            return self.i18n.t(text, **kwargs)
        return text.format(**kwargs) if kwargs else text

    def retranslate_ui(self, *_args) -> None:
        self.alert_banner.set_language(self.i18n.language if self.i18n else "es")
        self.roadmap_label.setText(
            self._t(
                "¡Por favor no te desesperes! La versión 1.6.0 se acerca. "
                "Mientras tanto seguimos con novedades pequeñas por aquí. 💜"
            )
        )
        self.roadmap_dismiss_button.setToolTip(self._t("Cerrar aviso"))
        self.title_label.setText(self._t("Bienvenido a KatLauncher"))
        self.subtitle_label.setText(self._t("Tu aventura está lista en un clic."))
        self.tutorial_button.setText(self._t("Kat Tutorial"))
        self.update_button.setText(self._t("Buscar actualizaciones"))
        self.profile_caption.setText(self._t("PERFIL ACTIVO"))
        self.play_button.setText(self._t("▶  Jugar"))
        self.quick_title.setText(self._t("Accesos rápidos"))
        self.social_title.setText(self._t("Kat Social"))
        self.open_friends_button.setText(self._t("Abrir amigos"))
        self.download_title.setText(self._t("Descargas y operaciones"))
        if not self.social_summary.text():
            self.social_summary.setText(self._t("Conecta con tus amigos desde Kat Social."))
        if not self.download_detail.text():
            self.download_detail.setText(self._t("Todo está listo."))
        for button in self.quick_buttons.values():
            title = self._t(str(button.property("titleKey")))
            subtitle = self._t(str(button.property("subtitleKey")))
            button.setText(f"{title}\n{subtitle}")
        self._update_profile_card()

    @property
    def active_profile_id(self) -> str:
        return str(self.profile_combo.currentData() or "")

    @property
    def active_profile(self):
        profile_id = self.active_profile_id
        return self.pm.get(profile_id) if profile_id else None

    def set_active_profile(self, profile_id: str) -> bool:
        index = self.profile_combo.findData(profile_id)
        if index < 0:
            return False
        self.profile_combo.setCurrentIndex(index)
        return True

    def refresh_profiles(self) -> None:
        current = self.active_profile_id
        self.profile_combo.blockSignals(True)
        self.profile_combo.clear()
        for profile in self.pm.list_profiles():
            version = profile.version or self._t("sin versión")
            self.profile_combo.addItem(
                f"{profile.name}  ·  {version}  ·  {profile.loader}", profile.id
            )
        if current:
            index = self.profile_combo.findData(current)
            if index >= 0:
                self.profile_combo.setCurrentIndex(index)
        self.profile_combo.blockSignals(False)
        self._update_profile_card()

    def set_social_summary(self, text: str) -> None:
        self.social_summary.setText(str(text))

    def set_download_status(self, text: str, value: int = 0, maximum: int = 100) -> None:
        maximum = max(0, int(maximum))
        value = max(0, int(value))
        self.download_detail.setText(str(text))
        if maximum == 0:
            self.download_progress.setRange(0, 0)
        else:
            self.download_progress.setRange(0, maximum)
            self.download_progress.setValue(min(value, maximum))

    def _apply_roadmap_banner_visibility(self) -> None:
        dismissed = False
        if self.settings_manager is not None:
            dismissed = bool(
                getattr(
                    self.settings_manager.settings,
                    "roadmap_1_6_0_banner_dismissed",
                    False,
                )
            )
        self.roadmap_banner.setVisible(not dismissed)

    def _dismiss_roadmap_banner(self) -> None:
        self.roadmap_banner.setVisible(False)
        if self.settings_manager is not None:
            self.settings_manager.update(roadmap_1_6_0_banner_dismissed=True)

    def _on_profile_selected(self, _index: int) -> None:
        self._update_profile_card()
        if self.active_profile_id:
            self.active_profile_changed.emit(self.active_profile_id)

    def _request_play(self) -> None:
        if self.active_profile_id:
            self.play_requested.emit(self.active_profile_id)

    def _update_profile_card(self) -> None:
        profile = self.active_profile
        self.play_button.setEnabled(profile is not None and bool(profile.version))
        if profile is None:
            self.profile_name.setText(self._t("Sin perfiles"))
            self.profile_meta.setText(self._t("Crea un perfil para comenzar."))
            self.profile_nickname.clear()
            self._set_avatar(None)
            return
        version = profile.version or self._t("sin versión")
        loader = str(profile.loader or "vanilla").title()
        self.profile_name.setText(str(profile.name))
        self.profile_meta.setText(f"Minecraft {version}  ·  {loader}")
        self.profile_nickname.setText(self._t("Jugando como {name}", name=profile.nickname))
        self._set_avatar(getattr(profile, "skin_path", ""))

    def _set_avatar(self, skin_path) -> None:
        avatar = _minecraft_face(Path(skin_path)) if skin_path else QPixmap()
        if avatar.isNull() and LOGO_PATH.is_file():
            avatar = QPixmap(str(LOGO_PATH))
        if avatar.isNull():
            self.avatar_label.setText("K")
            self.avatar_label.setObjectName("cosmicMark")
            return
        self.avatar_label.setObjectName("")
        self.avatar_label.setText("")
        self.avatar_label.setPixmap(
            avatar.scaled(72, 72, Qt.KeepAspectRatio, Qt.FastTransformation)
        )


def _minecraft_face(path: Path) -> QPixmap:
    """Extrae la cara y su segunda capa de una skin 64x32/64 sin OpenGL."""

    if not path.is_file():
        return QPixmap()
    skin = QPixmap(str(path))
    if skin.isNull() or skin.width() < 64 or skin.height() < 32:
        return QPixmap()
    face = skin.copy(8, 8, 8, 8).scaled(64, 64, Qt.IgnoreAspectRatio, Qt.FastTransformation)
    if skin.height() >= 64:
        overlay = skin.copy(40, 8, 8, 8).scaled(
            64, 64, Qt.IgnoreAspectRatio, Qt.FastTransformation
        )
        combined = QPixmap(64, 64)
        combined.fill(Qt.transparent)
        painter = QPainter(combined)
        painter.drawPixmap(0, 0, face)
        painter.drawPixmap(0, 0, overlay)
        painter.end()
        return combined
    return face
