"""Controlador Qt único para comprobar y descargar actualizaciones."""
from __future__ import annotations

from PySide6.QtCore import QObject, Signal, Slot

from ..core import update_manager
from .worker_registry import WorkerRegistryMixin
from .workers import UpdateCheckWorker, UpdateDownloadWorker


class UpdateController(QObject, WorkerRegistryMixin):
    checking_changed = Signal(bool)
    update_available = Signal(object)
    up_to_date = Signal()
    check_failed = Signal(str, bool)
    download_started = Signal(object)
    download_progress = Signal(int, int)
    download_cancelled = Signal()
    download_failed = Signal(str)
    update_ready = Signal(object, str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._init_worker_registry()
        self._check_worker = None
        self._download_worker = None
        self._manual_check = False
        self._download_maximum = 0
        self._channel_error = ""
        try:
            self.channel = update_manager.load_update_channel()
        except update_manager.UpdateError as error:
            self.channel = None
            self._channel_error = str(error)

    @property
    def is_configured(self) -> bool:
        return self.channel is not None

    def check(self, *, manual: bool = False) -> bool:
        if self._check_worker and self._check_worker.isRunning():
            return False
        if not self.channel:
            if manual:
                message = self._channel_error or (
                    "El canal de actualizaciones todavía no está configurado."
                )
                self.check_failed.emit(message, True)
            return False
        if not manual and not update_manager.should_check_automatically():
            return False
        self._manual_check = manual
        self.checking_changed.emit(True)
        worker = self._track_worker(UpdateCheckWorker(self.channel))
        self._check_worker = worker
        worker.checked.connect(self._on_checked)
        worker.failed.connect(self._on_check_failed)
        worker.finished.connect(self._on_check_finished)
        worker.start()
        return True

    def download(self, info) -> bool:
        if not self.channel or (self._download_worker and self._download_worker.isRunning()):
            return False
        self._download_maximum = int(info.installer_size)
        self.download_started.emit(info)
        worker = self._track_worker(UpdateDownloadWorker(info, self.channel))
        self._download_worker = worker
        worker.maximum.connect(self._on_download_maximum)
        worker.progress.connect(self._on_download_progress)
        worker.downloaded.connect(self._on_downloaded)
        worker.cancelled.connect(self._on_download_cancelled)
        worker.failed.connect(self._on_download_failed)
        worker.finished.connect(self._on_download_finished)
        worker.start()
        return True

    def cancel_download(self):
        if self._download_worker and self._download_worker.isRunning():
            self._download_worker.requestInterruption()

    @Slot(object)
    def _on_checked(self, info):
        try:
            update_manager.record_successful_check()
        except OSError:
            pass
        if info is None:
            if self._manual_check:
                self.up_to_date.emit()
        else:
            self.update_available.emit(info)

    @Slot(str)
    def _on_check_failed(self, error: str):
        self.check_failed.emit(error, self._manual_check)

    @Slot()
    def _on_check_finished(self):
        self._check_worker = None
        self.checking_changed.emit(False)

    @Slot(int)
    def _on_download_maximum(self, maximum: int):
        self._download_maximum = maximum
        self.download_progress.emit(0, maximum)

    @Slot(int)
    def _on_download_progress(self, progress: int):
        self.download_progress.emit(progress, self._download_maximum)

    @Slot(object, str)
    def _on_downloaded(self, info, path: str):
        self.update_ready.emit(info, path)

    @Slot()
    def _on_download_cancelled(self):
        self.download_cancelled.emit()

    @Slot(str)
    def _on_download_failed(self, error: str):
        self.download_failed.emit(error)

    @Slot()
    def _on_download_finished(self):
        self._download_worker = None
