from pathlib import Path

from pathlib import Path

from PySide6.QtCore import QThread, Signal

from ..core import (
    alert_manager, curseforge_api, katcraft_manager, launcher_core,
    modpack_manager, modrinth_api, update_manager,
)
from ..core.controller_support import connected_gamepads
from ..core.profile_manager import Profile


class InstallWorker(QThread):
    status = Signal(str)
    progress = Signal(int)
    maximum = Signal(int)
    finished_ok = Signal(str)
    failed = Signal(str)

    def __init__(
        self, profile: Profile, java_path: str = "", auto_controlify: bool = True,
        auto_katcraft: bool = True, auto_csl: bool = True,
    ):
        super().__init__()
        self.profile = profile
        self.java_path = java_path
        self.auto_controlify = bool(auto_controlify)
        self.auto_katcraft = bool(auto_katcraft)
        self.auto_csl = bool(auto_csl)

    def run(self):
        try:
            version_id = launcher_core.install_version(
                self.profile,
                status_cb=lambda s: self.status.emit(s),
                progress_cb=lambda p: self.progress.emit(p),
                max_cb=lambda m: self.maximum.emit(m),
                java_path=self.java_path,
            )
            if self.auto_katcraft and self.profile.loader != "vanilla":
                self.status.emit("Preparando KatCraft...")
                try:
                    katcraft_path = katcraft_manager.ensure_katcraft(self.profile)
                    if katcraft_path:
                        self.status.emit(
                            f"KatCraft instalado: {Path(katcraft_path).name}"
                        )
                        if self.profile.loader in ("fabric", "quilt"):
                            self.status.emit("Preparando Fabric API para KatCraft...")
                            modrinth_api.ensure_fabric_api(self.profile)
                        if self.auto_csl:
                            self.status.emit(
                                "Preparando skins compartidas de KatLauncher..."
                            )
                            modrinth_api.ensure_customskinloader(self.profile)
                    else:
                        self.status.emit(
                            "KatCraft todavía no tiene una variante para este perfil."
                        )
                except Exception as error:
                    self.status.emit(
                        f"KatCraft no está disponible para este perfil: {error}"
                    )
            if self.auto_controlify:
                gamepads = connected_gamepads()
                if gamepads:
                    if self.profile.loader == "vanilla":
                        self.status.emit(
                            "Mando detectado; Controlify necesita un perfil con mod loader."
                        )
                    else:
                        self.status.emit(
                            f"Mando detectado ({gamepads[0]}). Preparando Controlify..."
                        )
                        try:
                            modrinth_api.ensure_controlify(self.profile)
                        except Exception as error:
                            # Un complemento opcional nunca impide arrancar Minecraft.
                            self.status.emit(
                                f"Controlify no está disponible para este perfil: {error}"
                            )
            self.finished_ok.emit(version_id)
        except Exception as e:
            self.failed.emit(str(e))


class VersionListWorker(QThread):
    loaded = Signal(list)
    failed = Signal(str)

    def __init__(self, include_snapshots=False, include_old=False):
        super().__init__()
        self.include_snapshots = include_snapshots
        self.include_old = include_old

    def run(self):
        try:
            versions = launcher_core.get_version_list(self.include_snapshots, self.include_old)
            self.loaded.emit(versions)
        except Exception as e:
            self.failed.emit(str(e))


class UpdateCheckWorker(QThread):
    checked = Signal(object)
    failed = Signal(str)

    def __init__(self, channel):
        super().__init__()
        self.channel = channel

    def run(self):
        try:
            self.checked.emit(update_manager.check_for_update(self.channel))
        except Exception as error:
            self.failed.emit(str(error))


class AlertCheckWorker(QThread):
    checked = Signal(object)
    failed = Signal(str)

    def run(self):
        try:
            self.checked.emit(alert_manager.check_for_new_alert())
        except Exception as error:
            self.failed.emit(str(error))


class UpdateDownloadWorker(QThread):
    progress = Signal(int)
    maximum = Signal(int)
    downloaded = Signal(object, str)
    cancelled = Signal()
    failed = Signal(str)

    def __init__(self, info, channel):
        super().__init__()
        self.info = info
        self.channel = channel

    def run(self):
        try:
            path = update_manager.download_update(
                self.info,
                self.channel,
                progress_cb=self.progress.emit,
                max_cb=self.maximum.emit,
                cancel_cb=self.isInterruptionRequested,
            )
            self.downloaded.emit(self.info, str(path))
        except update_manager.UpdateCancelled:
            self.cancelled.emit()
        except Exception as error:
            self.failed.emit(str(error))


class ModrinthSearchWorker(QThread):
    results = Signal(list)
    failed = Signal(str)

    def __init__(self, query: str, loader: str, version: str,
                 project_type: str = "mod"):
        super().__init__()
        self.query = query
        self.loader = loader
        self.version = version
        self.project_type = project_type

    def run(self):
        try:
            hits = modrinth_api.search_projects(
                self.query, self.project_type, self.loader, self.version
            )
            self.results.emit(hits)
        except Exception as e:
            self.failed.emit(str(e))


class CurseForgeSearchWorker(QThread):
    results = Signal(list)
    failed = Signal(str)

    def __init__(self, query: str, loader: str, version: str,
                 project_type: str = "mod"):
        super().__init__()
        self.query = query
        self.loader = loader
        self.version = version
        self.project_type = project_type

    def run(self):
        try:
            self.results.emit(curseforge_api.search_projects(
                self.query, self.project_type, self.loader, self.version
            ))
        except Exception as error:
            self.failed.emit(str(error))


class ModpackSearchWorker(QThread):
    results = Signal(list)
    failed = Signal(str)

    def __init__(self, query: str):
        super().__init__()
        self.query = query

    def run(self):
        try:
            self.results.emit(modrinth_api.search_modpacks(self.query))
        except Exception as e:
            self.failed.emit(str(e))


class ModpackVersionsWorker(QThread):
    results = Signal(list)
    failed = Signal(str)

    def __init__(self, project_id: str):
        super().__init__()
        self.project_id = project_id

    def run(self):
        try:
            versions = modrinth_api.get_versions(self.project_id)
            usable = [version for version in versions
                      if any(str(file.get("filename", "")).lower().endswith(".mrpack")
                             for file in version.get("files", []))]
            self.results.emit(usable)
        except Exception as e:
            self.failed.emit(str(e))


class ModpackInstallWorker(QThread):
    status = Signal(str)
    progress = Signal(int)
    maximum = Signal(int)
    installed = Signal(object)
    failed = Signal(str)

    def __init__(self, *, nickname: str, version=None, local_path: str = "",
                 project=None, include_optional: bool = True, java_path: str = "",
                 profile_defaults=None):
        super().__init__()
        self.options = {
            "nickname": nickname,
            "version": version,
            "local_path": local_path,
            "project": project,
            "include_optional": include_optional,
            "java_path": java_path,
            "profile_defaults": profile_defaults,
        }

    def run(self):
        try:
            result = modpack_manager.install_modpack(
                **self.options,
                status_cb=lambda value: self.status.emit(value),
                progress_cb=lambda value: self.progress.emit(value),
                max_cb=lambda value: self.maximum.emit(value),
            )
            self.installed.emit(result)
        except Exception as e:
            self.failed.emit(str(e))


class ModrinthInstallWorker(QThread):
    installed = Signal(str)
    completed = Signal(dict)
    status = Signal(str)
    failed = Signal(str)

    def __init__(self, project_id: str, loader: str, version: str,
                 destination_dir: str, project_type: str = "mod"):
        super().__init__()
        self.project_id = project_id
        self.loader = loader
        self.version = version
        self.destination_dir = destination_dir
        # El atributo antiguo se conserva para extensiones que lo inspeccionen.
        self.mods_dir = destination_dir
        self.project_type = project_type

    def run(self):
        try:
            report = modrinth_api.install_content_latest(
                self.project_id, self.project_type, self.loader, self.version,
                self.destination_dir, status_cb=self.status.emit,
                cancel_cb=self.isInterruptionRequested,
            )
            self.completed.emit(report)
            self.installed.emit(report["primary_path"])
        except Exception as e:
            self.failed.emit(str(e))


class CurseForgeInstallWorker(QThread):
    completed = Signal(dict)
    status = Signal(str)
    failed = Signal(str)

    def __init__(self, project_id: int, loader: str, version: str,
                 destination_dir: str, project_type: str = "mod"):
        super().__init__()
        self.project_id = project_id
        self.loader = loader
        self.version = version
        self.destination_dir = destination_dir
        self.project_type = project_type

    def run(self):
        try:
            self.completed.emit(curseforge_api.install_content_latest(
                self.project_id, self.project_type, self.loader, self.version,
                self.destination_dir, status_cb=self.status.emit,
                cancel_cb=self.isInterruptionRequested,
            ))
        except Exception as error:
            self.failed.emit(str(error))


class CustomSkinLoaderWorker(QThread):
    installed = Signal(str)
    failed = Signal(str)

    def __init__(self, profile: Profile):
        super().__init__()
        self.profile = profile

    def run(self):
        try:
            path = modrinth_api.ensure_customskinloader(self.profile)
            self.installed.emit(path)
        except Exception as e:
            self.failed.emit(str(e))


class SharedSkinWorker(QThread):
    published = Signal(object)
    failed = Signal(str)

    def __init__(self, service, nickname: str, path: str, model: str):
        super().__init__()
        self.service = service
        self.nickname = nickname
        self.path = path
        self.model = model

    def run(self):
        try:
            payload = Path(self.path).read_bytes()
            self.published.emit(
                self.service.upload_shared_skin(
                    self.nickname, payload, self.model
                )
            )
        except Exception as error:
            self.failed.emit(str(error))


class ModsUpdateWorker(QThread):
    status = Signal(str)
    completed = Signal(dict)
    failed = Signal(str)

    def __init__(self, profile: Profile):
        super().__init__()
        self.profile = profile

    def run(self):
        try:
            result = modrinth_api.update_mods(
                self.profile.mods_dir, self.profile.loader, self.profile.version,
                status_cb=self.status.emit,
            )
            self.completed.emit(result)
        except Exception as error:
            self.failed.emit(str(error))


class RepairProfileWorker(QThread):
    status = Signal(str)
    completed = Signal(str)
    failed = Signal(str)

    def __init__(self, profile: Profile, java_path: str = ""):
        super().__init__()
        self.profile = profile
        self.java_path = java_path

    def run(self):
        try:
            if self.profile.source_type == "modrinth":
                path = modpack_manager.repair_modpack(
                    self.profile, java_path=self.java_path, status_cb=self.status.emit
                )
            else:
                launcher_core.install_version(
                    self.profile, java_path=self.java_path, status_cb=self.status.emit
                )
                path = self.profile.game_dir
            self.completed.emit(path)
        except Exception as error:
            self.failed.emit(str(error))


class LaunchWorker(QThread):
    log_line = Signal(str)
    game_closed = Signal(int)
    failed = Signal(str)

    game_started = Signal()

    def __init__(self, profile: Profile, java_path: str = ""):
        super().__init__()
        self.profile = profile
        self.java_path = java_path

    def run(self):
        process = None
        try:
            process = launcher_core.launch(self.profile, java_path=self.java_path)
            self.game_started.emit()
            try:
                for line in process.stdout:
                    self.log_line.emit(line.rstrip())
            except (OSError, UnicodeError) as error:
                self.log_line.emit(f"[KatLauncher] {error}")
            code = process.wait()
            self.game_closed.emit(code)
        except Exception as e:
            if process is not None and process.poll() is None:
                try:
                    process.wait()
                except Exception:
                    pass
            self.failed.emit(str(e))
