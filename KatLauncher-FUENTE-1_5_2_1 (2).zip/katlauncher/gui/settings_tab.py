from pathlib import Path

from PySide6.QtCore import QUrl, Signal
from PySide6.QtGui import QColor, QDesktopServices
from PySide6.QtWidgets import (
    QCheckBox, QColorDialog, QComboBox, QFileDialog, QFormLayout, QGroupBox, QHBoxLayout,
    QLabel, QLineEdit, QMessageBox, QProgressBar, QPushButton, QScrollArea,
    QSpinBox, QVBoxLayout, QWidget,
)

from .. import __version__
from ..core.profile_manager import validate_nickname
from ..core.social_service import SOCIAL_HISTORY_FILE


class SettingsTab(QWidget):
    settings_saved = Signal()
    operation_succeeded = Signal()
    check_updates_requested = Signal()
    cancel_update_download_requested = Signal()

    def __init__(self, settings_manager, i18n, theme_manager=None, parent=None):
        super().__init__(parent)
        self.manager = settings_manager
        self.i18n = i18n
        self.theme_manager = theme_manager

        root_layout = QVBoxLayout(self)
        root_layout.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QScrollArea.NoFrame)
        content = QWidget()
        layout = QVBoxLayout(content)
        scroll.setWidget(content)
        root_layout.addWidget(scroll)
        self._update_downloading = False
        self._update_status_source = "Versión instalada: {version}"
        self._update_status_kwargs = {"version": __version__}
        self.intro_label = QLabel()
        self.intro_label.setWordWrap(True)
        layout.addWidget(self.intro_label)

        self.general_box = QGroupBox()
        general_form = QFormLayout(self.general_box)
        self.language_combo = QComboBox()
        self.language_combo.addItem("Español", "es")
        self.language_combo.addItem("English", "en")
        self.language_label = QLabel()
        general_form.addRow(self.language_label, self.language_combo)
        self.show_splash_check = QCheckBox()
        general_form.addRow(self.show_splash_check)
        self.minimize_check = QCheckBox()
        general_form.addRow(self.minimize_check)
        self.log_lines_spin = QSpinBox()
        self.log_lines_spin.setRange(200, 20000)
        self.log_lines_spin.setSingleStep(200)
        self.log_lines_label = QLabel()
        general_form.addRow(self.log_lines_label, self.log_lines_spin)
        layout.addWidget(self.general_box)

        self.appearance_box = QGroupBox()
        appearance_form = QFormLayout(self.appearance_box)
        self.theme_combo = QComboBox()
        self.theme_label = QLabel()
        appearance_form.addRow(self.theme_label, self.theme_combo)
        self.accent_combo = QComboBox()
        self.accent_label = QLabel()
        accent_row = QHBoxLayout()
        accent_row.addWidget(self.accent_combo, 1)
        self.custom_accent_button = QPushButton()
        self.custom_accent_button.clicked.connect(self.choose_custom_accent)
        accent_row.addWidget(self.custom_accent_button)
        appearance_form.addRow(self.accent_label, accent_row)
        self.theme_help_label = QLabel()
        self.theme_help_label.setWordWrap(True)
        appearance_form.addRow(self.theme_help_label)
        layout.addWidget(self.appearance_box)
        if self.theme_manager is not None:
            self.theme_manager.bind_combo(self.theme_combo)
            self.theme_manager.bind_accent_combo(self.accent_combo)
            self.theme_manager.theme_change_failed.connect(
                lambda error: QMessageBox.warning(
                    self, self.i18n.t("Error"),
                    self.i18n.t("No se pudo guardar el tema: {error}", error=error),
                )
            )
        else:
            self.appearance_box.setVisible(False)

        self.java_box = QGroupBox()
        java_form = QFormLayout(self.java_box)
        java_row = QHBoxLayout()
        self.java_edit = QLineEdit()
        self.java_browse_button = QPushButton()
        self.java_browse_button.clicked.connect(self.on_browse_java)
        java_row.addWidget(self.java_edit, stretch=1)
        java_row.addWidget(self.java_browse_button)
        self.java_label = QLabel()
        java_form.addRow(self.java_label, java_row)
        layout.addWidget(self.java_box)

        self.defaults_box = QGroupBox()
        defaults_form = QFormLayout(self.defaults_box)
        self.nickname_edit = QLineEdit()
        self.nickname_label = QLabel()
        defaults_form.addRow(self.nickname_label, self.nickname_edit)

        ram_row = QHBoxLayout()
        self.min_ram = QSpinBox()
        self.min_ram.setRange(512, 32768)
        self.min_ram.setSingleStep(512)
        self.max_ram = QSpinBox()
        self.max_ram.setRange(512, 32768)
        self.max_ram.setSingleStep(512)
        self.min_ram_label = QLabel()
        self.max_ram_label = QLabel()
        ram_row.addWidget(self.min_ram_label)
        ram_row.addWidget(self.min_ram)
        ram_row.addWidget(self.max_ram_label)
        ram_row.addWidget(self.max_ram)
        self.ram_label = QLabel()
        defaults_form.addRow(self.ram_label, ram_row)

        resolution_row = QHBoxLayout()
        self.res_w = QSpinBox()
        self.res_w.setRange(320, 7680)
        self.res_h = QSpinBox()
        self.res_h.setRange(240, 4320)
        resolution_row.addWidget(self.res_w)
        resolution_row.addWidget(QLabel("x"))
        resolution_row.addWidget(self.res_h)
        self.resolution_label = QLabel()
        defaults_form.addRow(self.resolution_label, resolution_row)
        self.snapshots_check = QCheckBox()
        defaults_form.addRow(self.snapshots_check)
        layout.addWidget(self.defaults_box)

        self.skins_box = QGroupBox()
        skins_layout = QVBoxLayout(self.skins_box)
        self.auto_csl_check = QCheckBox()
        skins_layout.addWidget(self.auto_csl_check)
        self.auto_katcraft_check = QCheckBox()
        skins_layout.addWidget(self.auto_katcraft_check)
        self.vanilla_katcraft_warning_check = QCheckBox()
        skins_layout.addWidget(self.vanilla_katcraft_warning_check)
        self.auto_controlify_check = QCheckBox()
        skins_layout.addWidget(self.auto_controlify_check)
        self.auto_mckat_check = QCheckBox()
        skins_layout.addWidget(self.auto_mckat_check)
        layout.addWidget(self.skins_box)

        self.social_box = QGroupBox()
        social_layout = QVBoxLayout(self.social_box)
        self.social_history_check = QCheckBox()
        social_layout.addWidget(self.social_history_check)
        self.kat_presence_check = QCheckBox()
        social_layout.addWidget(self.kat_presence_check)
        social_note = QHBoxLayout()
        self.social_history_note = QLabel()
        self.social_history_note.setWordWrap(True)
        self.open_social_history = QPushButton()
        self.open_social_history.clicked.connect(
            lambda: QDesktopServices.openUrl(
                QUrl.fromLocalFile(str(SOCIAL_HISTORY_FILE.parent))
            )
        )
        social_note.addWidget(self.social_history_note, 1)
        social_note.addWidget(self.open_social_history)
        social_layout.addLayout(social_note)
        layout.addWidget(self.social_box)

        self.integrations_box = QGroupBox()
        integrations_form = QFormLayout(self.integrations_box)
        self.sound_effects_check = QCheckBox()
        integrations_form.addRow(self.sound_effects_check)
        self.discord_presence_check = QCheckBox()
        self.discord_presence_check.toggled.connect(self._update_discord_controls)
        integrations_form.addRow(self.discord_presence_check)
        self.discord_client_id_edit = QLineEdit()
        self.discord_client_id_edit.setMaxLength(24)
        self.discord_client_id_edit.setReadOnly(True)
        self.discord_client_id_label = QLabel()
        integrations_form.addRow(
            self.discord_client_id_label, self.discord_client_id_edit
        )
        self.discord_help_label = QLabel()
        self.discord_help_label.setWordWrap(True)
        integrations_form.addRow(self.discord_help_label)
        layout.addWidget(self.integrations_box)

        self.updates_box = QGroupBox()
        updates_layout = QVBoxLayout(self.updates_box)
        self.auto_updates_check = QCheckBox()
        updates_layout.addWidget(self.auto_updates_check)
        self.update_status_label = QLabel()
        self.update_status_label.setWordWrap(True)
        updates_layout.addWidget(self.update_status_label)
        self.update_progress = QProgressBar()
        self.update_progress.setVisible(False)
        updates_layout.addWidget(self.update_progress)
        update_actions = QHBoxLayout()
        update_actions.addStretch()
        self.check_updates_button = QPushButton()
        self.check_updates_button.clicked.connect(self._on_update_button)
        update_actions.addWidget(self.check_updates_button)
        updates_layout.addLayout(update_actions)
        layout.addWidget(self.updates_box)

        self.save_button = QPushButton()
        self.save_button.clicked.connect(self.on_save)
        layout.addWidget(self.save_button)
        layout.addStretch()

        self.load_values()
        self.i18n.language_changed.connect(self.retranslate_ui)
        self.retranslate_ui()

    def load_values(self):
        settings = self.manager.settings
        index = self.language_combo.findData(settings.language)
        self.language_combo.setCurrentIndex(max(index, 0))
        self.show_splash_check.setChecked(settings.show_splash)
        self.minimize_check.setChecked(settings.minimize_on_launch)
        self.log_lines_spin.setValue(settings.log_max_lines)
        self.java_edit.setText(settings.java_path)
        self.nickname_edit.setText(settings.default_nickname)
        self.min_ram.setValue(settings.default_min_ram)
        self.max_ram.setValue(settings.default_max_ram)
        self.res_w.setValue(settings.default_resolution_w)
        self.res_h.setValue(settings.default_resolution_h)
        self.snapshots_check.setChecked(settings.include_snapshots)
        self.auto_csl_check.setChecked(settings.auto_install_custom_skin_loader)
        self.auto_katcraft_check.setChecked(settings.auto_install_katcraft)
        self.vanilla_katcraft_warning_check.setChecked(
            settings.warn_vanilla_katcraft
        )
        self.auto_controlify_check.setChecked(settings.auto_install_controlify)
        self.auto_mckat_check.setChecked(settings.auto_install_mckat_pack)
        self.social_history_check.setChecked(settings.social_keep_local_history)
        self.kat_presence_check.setChecked(settings.kat_presence_enabled)
        self.sound_effects_check.setChecked(settings.sound_effects_enabled)
        self.discord_presence_check.setChecked(settings.discord_rich_presence)
        self.discord_client_id_edit.setText(settings.discord_client_id)
        self._update_discord_controls(settings.discord_rich_presence)
        self.auto_updates_check.setChecked(settings.auto_check_updates)

    def retranslate_ui(self, *_args):
        t = self.i18n.t
        self.intro_label.setText(t(
            "Ajustes generales del launcher y valores predeterminados para perfiles nuevos"
        ))
        self.general_box.setTitle(t("General"))
        self.language_label.setText(t("Idioma:"))
        current = self.language_combo.currentData()
        self.language_combo.setItemText(0, t("Español"))
        self.language_combo.setItemText(1, t("Inglés"))
        self.language_combo.setCurrentIndex(self.language_combo.findData(current))
        self.show_splash_check.setText(t("Mostrar pantalla de carga al iniciar"))
        self.minimize_check.setText(t(
            "Ocultar el launcher en la bandeja mientras Minecraft está abierto"
        ))
        self.log_lines_label.setText(t("Máximo de líneas del registro:"))
        self.appearance_box.setTitle(t("Apariencia"))
        self.theme_label.setText(t("Tema de interfaz:"))
        self.accent_label.setText(t("Color de acento:"))
        self.custom_accent_button.setText(t("Elegir color…"))
        self.theme_help_label.setText(t(
            "Elige XMBKat, Kat Normal, Kat Epic o Kat Classic. El color de "
            "acento se aplica a toda la interfaz."
        ))
        self.java_box.setTitle(t("Java"))
        self.java_label.setText(t("Ejecutable de Java (vacío = automático):"))
        self.java_browse_button.setText(t("Examinar..."))
        self.defaults_box.setTitle(t("Valores para perfiles nuevos"))
        self.nickname_label.setText(t("Nickname predeterminado:"))
        self.ram_label.setText(t("RAM predeterminada:"))
        self.min_ram_label.setText(t("Mín (MB)"))
        self.max_ram_label.setText(t("Máx (MB)"))
        self.resolution_label.setText(t("Resolución predeterminada:"))
        self.snapshots_check.setText(t("Incluir snapshots al cargar versiones"))
        self.skins_box.setTitle(t("Skins"))
        self.auto_csl_check.setText(t("Auto-instalar CustomSkinLoader por defecto"))
        self.auto_katcraft_check.setText(t(
            "Instalar y actualizar KatCraft automáticamente en perfiles compatibles"
        ))
        self.vanilla_katcraft_warning_check.setText(t(
            "Avisar cuando una instancia Vanilla no pueda usar KatCraft"
        ))
        self.auto_controlify_check.setText(t(
            "Detectar mandos y preguntar si deseas instalar Controlify"
        ))
        self.auto_mckat_check.setText(t("Instalar automáticamente el texture pack MCKAT"))
        self.social_box.setTitle(t("Kat Social"))
        self.social_history_check.setText(t(
            "Guardar una copia local de los mensajes que veo"
        ))
        self.kat_presence_check.setText(t(
            "Mostrar Kat Presence (versión, loader y skin) en mi perfil"
        ))
        self.social_history_note.setText(t(
            "El historial se guarda solo en este PC y no vuelve a subirse a Supabase."
        ))
        self.open_social_history.setText(t("Abrir carpeta"))
        self.integrations_box.setTitle(t("Sonido y Discord"))
        self.sound_effects_check.setText(t("Reproducir sonidos de interfaz"))
        self.discord_presence_check.setText(t("Mostrar mi actividad en Discord"))
        self.discord_client_id_label.setText(t("ID de aplicación de Discord:"))
        self.discord_client_id_edit.setPlaceholderText(t("Incluido con KatLauncher"))
        self.discord_help_label.setText(t(
            "KatLauncher ya incluye el ID público de su aplicación de Discord. "
            "La presencia está activada por defecto y puedes apagarla cuando quieras."
        ))
        self.updates_box.setTitle(t("Actualizaciones"))
        self.auto_updates_check.setText(t("Buscar actualizaciones automáticamente"))
        self.update_status_label.setText(t(
            self._update_status_source, **self._update_status_kwargs
        ))
        self.check_updates_button.setText(
            t("Cancelar descarga") if self._update_downloading else t("Buscar ahora")
        )
        self.save_button.setText(t("Guardar configuración"))

    def _on_update_button(self):
        if self._update_downloading:
            self.cancel_update_download_requested.emit()
        else:
            self.check_updates_requested.emit()

    def set_update_checking(self, checking: bool):
        if self._update_downloading:
            return
        self.check_updates_button.setEnabled(not checking)
        if checking:
            self.set_update_status("Buscando actualizaciones...")

    def set_update_status(self, source: str, **kwargs):
        self._update_status_source = source
        self._update_status_kwargs = kwargs
        self.update_status_label.setText(self.i18n.t(source, **kwargs))

    def set_update_progress(self, current: int, maximum: int):
        self._update_downloading = True
        self.update_progress.setVisible(True)
        self.update_progress.setRange(0, max(maximum, 1))
        self.update_progress.setValue(max(0, min(current, max(maximum, 1))))
        self.check_updates_button.setEnabled(True)
        self.check_updates_button.setText(self.i18n.t("Cancelar descarga"))
        self.set_update_status(
            "Descargando actualización: {downloaded:.1f} de {total:.1f} MB",
            downloaded=current / (1024 * 1024),
            total=(maximum / (1024 * 1024)) if maximum else 0,
        )

    def finish_update_download(self):
        self._update_downloading = False
        self.update_progress.setVisible(False)
        self.check_updates_button.setEnabled(True)
        self.check_updates_button.setText(self.i18n.t("Buscar ahora"))

    def choose_custom_accent(self):
        if self.theme_manager is None:
            return
        color = QColorDialog.getColor(
            QColor(self.theme_manager.accent_pair[0]),
            self,
            self.i18n.t("Elige el color de acento"),
        )
        if not color.isValid():
            return
        try:
            self.theme_manager.apply_custom_accent(color.name())
        except OSError as error:
            QMessageBox.warning(
                self, self.i18n.t("Error"),
                self.i18n.t("No se pudo guardar el tema: {error}", error=error),
            )

    def on_browse_java(self):
        path, _ = QFileDialog.getOpenFileName(
            self,
            self.i18n.t("Selecciona java/javaw"),
            self.java_edit.text(),
            self.i18n.t("Ejecutables (*.exe);;Todos los archivos (*)"),
        )
        if path:
            self.java_edit.setText(path)

    def _update_discord_controls(self, enabled: bool):
        self.discord_client_id_label.setEnabled(enabled)
        self.discord_client_id_edit.setEnabled(enabled)
        self.discord_help_label.setEnabled(enabled)

    def on_save(self):
        java_path = self.java_edit.text().strip()
        if java_path and not Path(java_path).is_file():
            QMessageBox.warning(
                self, self.i18n.t("Error"),
                self.i18n.t("La ruta de Java no existe o no es un archivo."),
            )
            return
        if self.max_ram.value() < self.min_ram.value():
            QMessageBox.warning(
                self, self.i18n.t("Error"),
                self.i18n.t("La RAM máxima no puede ser menor que la mínima."),
            )
            return
        try:
            validate_nickname(self.nickname_edit.text().strip())
        except ValueError as error:
            QMessageBox.warning(self, self.i18n.t("Error"), self.i18n.t(str(error)))
            return
        discord_client_id = self.discord_client_id_edit.text().strip()
        language = self.language_combo.currentData()
        try:
            self.manager.update(
                language=language,
                java_path=java_path,
                show_splash=self.show_splash_check.isChecked(),
                minimize_on_launch=self.minimize_check.isChecked(),
                log_max_lines=self.log_lines_spin.value(),
                sound_effects_enabled=self.sound_effects_check.isChecked(),
                discord_rich_presence=self.discord_presence_check.isChecked(),
                discord_client_id=discord_client_id,
                include_snapshots=self.snapshots_check.isChecked(),
                auto_install_custom_skin_loader=self.auto_csl_check.isChecked(),
                auto_install_katcraft=self.auto_katcraft_check.isChecked(),
                warn_vanilla_katcraft=(
                    self.vanilla_katcraft_warning_check.isChecked()
                ),
                auto_install_controlify=self.auto_controlify_check.isChecked(),
                auto_install_mckat_pack=self.auto_mckat_check.isChecked(),
                social_keep_local_history=self.social_history_check.isChecked(),
                kat_presence_enabled=self.kat_presence_check.isChecked(),
                auto_check_updates=self.auto_updates_check.isChecked(),
                default_nickname=self.nickname_edit.text().strip(),
                default_min_ram=self.min_ram.value(),
                default_max_ram=self.max_ram.value(),
                default_resolution_w=self.res_w.value(),
                default_resolution_h=self.res_h.value(),
            )
        except (OSError, ValueError) as error:
            QMessageBox.warning(self, self.i18n.t("Error"), self.i18n.t(str(error)))
            return
        self.i18n.set_language(language)
        self.settings_saved.emit()
        self.operation_succeeded.emit()
        QMessageBox.information(
            self, self.i18n.t("Guardado"),
            self.i18n.t("Configuración guardada correctamente."),
        )
