"""Utilidad para conservar QThreads hasta que terminen y cerrar de forma segura."""
from __future__ import annotations

from PySide6.QtCore import Slot


class WorkerRegistryMixin:
    def _init_worker_registry(self):
        self._active_workers = set()

    def _track_worker(self, worker):
        self._active_workers.add(worker)
        worker.finished.connect(self._cleanup_worker)
        return worker

    @Slot()
    def _cleanup_worker(self):
        worker = self.sender()
        if worker is not None:
            self._active_workers.discard(worker)
            worker.deleteLater()

    def has_running_workers(self) -> bool:
        # Si el hilo terminó mientras el bucle de eventos estaba ocupado, su
        # señal queued puede seguir pendiente. Drenamos esas referencias antes
        # de decidir si la ventana puede cerrarse.
        for worker in tuple(self._active_workers):
            if worker.isFinished():
                self._active_workers.discard(worker)
                worker.deleteLater()
        return any(worker.isRunning() for worker in self._active_workers)
