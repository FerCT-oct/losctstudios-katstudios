"""Directorio de salas Kat Global compartido con KatCraft."""
from __future__ import annotations

from PySide6.QtCore import QThread, Qt, Signal, Slot
from PySide6.QtWidgets import (
    QComboBox, QHBoxLayout, QLabel, QLineEdit, QListWidget, QListWidgetItem,
    QMessageBox, QPushButton, QVBoxLayout, QWidget,
)


class _RoomsWorker(QThread):
    completed = Signal(list)
    failed = Signal(str)

    def __init__(self, service, search: str, parent=None):
        super().__init__(parent)
        self.service = service
        self.search = str(search or "")[:64]

    def run(self):
        try:
            rows = self.service.rpc("kat_list_public_rooms", {
                "p_search": self.search, "p_limit": 100,
            }) or []
            self.completed.emit(rows if isinstance(rows, list) else [])
        except Exception as error:
            self.failed.emit(str(error)[:300])


class RoomsTab(QWidget):
    operation_succeeded = Signal()
    launch_requested = Signal(str, str, int)
    profiles_changed = Signal()

    def __init__(self, profile_manager, social_service, i18n, parent=None):
        super().__init__(parent)
        self.pm = profile_manager
        self.service = social_service
        self.i18n = i18n
        self.worker = None
        self.rows = []

        root = QHBoxLayout(self)
        left = QVBoxLayout()
        title = QLabel("Salas públicas")
        title.setObjectName("bigTitle")
        left.addWidget(title)
        search_row = QHBoxLayout()
        self.search = QLineEdit()
        self.search.setPlaceholderText("Buscar sala, creador o descripción (Enter)")
        self.search.setClearButtonEnabled(True)
        self.search.returnPressed.connect(self.refresh)
        self.refresh_button = QPushButton("Actualizar")
        self.refresh_button.clicked.connect(self.refresh)
        search_row.addWidget(self.search, stretch=1)
        search_row.addWidget(self.refresh_button)
        left.addLayout(search_row)
        self.list = QListWidget()
        self.list.currentItemChanged.connect(self._show_detail)
        self.list.itemDoubleClicked.connect(lambda _item: self.join_selected())
        left.addWidget(self.list, stretch=1)
        root.addLayout(left, stretch=3)

        right = QVBoxLayout()
        self.detail = QLabel("Selecciona una sala.")
        self.detail.setWordWrap(True)
        self.detail.setTextFormat(Qt.PlainText)
        right.addWidget(self.detail)
        right.addWidget(QLabel("Perfil compatible:"))
        self.profiles = QComboBox()
        right.addWidget(self.profiles)
        self.join_button = QPushButton("▶ Unirse")
        self.join_button.clicked.connect(self.join_selected)
        right.addWidget(self.join_button)
        note = QLabel(
            "Si no existe un perfil compatible, KatLauncher puede crearlo con "
            "la versión, loader y versión del loader indicados por el creador."
        )
        note.setWordWrap(True)
        right.addWidget(note)
        right.addStretch()
        root.addLayout(right, stretch=2)

        self.refresh_profiles()
        self.refresh()

    def refresh_profiles(self):
        current = self.profiles.currentData()
        self.profiles.clear()
        for profile in self.pm.list_profiles():
            loader_version = getattr(profile, "loader_version", "") or "auto"
            self.profiles.addItem(
                f"{profile.name} · {profile.version} · "
                f"{profile.loader} {loader_version}",
                profile.id,
            )
        index = self.profiles.findData(current)
        if index >= 0:
            self.profiles.setCurrentIndex(index)

    @Slot()
    def refresh(self):
        if self.worker and self.worker.isRunning():
            return
        if not self.service or not self.service.session:
            self.list.clear()
            self.detail.setText("Inicia sesión en Kat Social para descubrir salas.")
            return
        self.refresh_button.setEnabled(False)
        self.refresh_button.setText("Buscando…")
        self.worker = _RoomsWorker(self.service, self.search.text(), self)
        self.worker.completed.connect(self._loaded)
        self.worker.failed.connect(self._failed)
        self.worker.finished.connect(self._finished)
        self.worker.start()

    @Slot(list)
    def _loaded(self, rows):
        self.rows = [row for row in rows if isinstance(row, dict)]
        self.list.clear()
        for row in self.rows:
            mods = row.get("mods") if isinstance(row.get("mods"), list) else []
            loader = str(row.get("loader") or "vanilla")
            loader_version = str(row.get("loader_version") or "")
            players = (
                f"{int(row.get('players_online') or 0)}/"
                f"{int(row.get('players_max') or 8)}"
            )
            item = QListWidgetItem(
                f"{row.get('name') or 'Sala'}  ·  {players}\n"
                f"{row.get('minecraft_version') or '?'} · {loader} "
                f"{loader_version} · {len(mods)} mods · "
                f"{row.get('owner_name') or 'Jugador'}"
            )
            item.setData(Qt.UserRole, str(row.get("id") or ""))
            self.list.addItem(item)
        if self.list.count():
            self.list.setCurrentRow(0)
        else:
            self.detail.setText("No hay salas públicas que coincidan.")

    @Slot(str)
    def _failed(self, message):
        if "kat_list_public_rooms" in message or "PGRST202" in message:
            self.detail.setText(
                "Falta ejecutar supabase/09_kat_rooms_151.sql en Supabase."
            )
        else:
            self.detail.setText("No se pudieron cargar las salas: " + message)

    def _finished(self):
        self.worker = None
        self.refresh_button.setEnabled(True)
        self.refresh_button.setText("Actualizar")

    def _selected(self):
        item = self.list.currentItem()
        identifier = str(item.data(Qt.UserRole) or "") if item else ""
        return next(
            (row for row in self.rows if str(row.get("id") or "") == identifier),
            None,
        )

    def _show_detail(self, *_args):
        room = self._selected()
        if not room:
            return
        mods = room.get("mods") if isinstance(room.get("mods"), list) else []
        mod_names = []
        for mod in mods[:12]:
            if isinstance(mod, dict):
                mod_names.append(str(mod.get("name") or mod.get("id") or "mod"))
            else:
                mod_names.append(str(mod))
        text = (
            f"{room.get('name') or 'Sala'}\n"
            f"Creada por {room.get('owner_name') or 'Jugador'}\n\n"
            f"{room.get('description') or 'Sin descripción.'}\n\n"
            f"Minecraft {room.get('minecraft_version') or '?'} · "
            f"{room.get('loader') or 'vanilla'} "
            f"{room.get('loader_version') or '(automático)'}\n"
            f"{room.get('host') or '?'}:{int(room.get('port') or 25565)}\n"
            f"Mods: {', '.join(mod_names) if mod_names else 'ninguno declarado'}"
        )
        self.detail.setText(text)
        match = self._compatible_profile(room)
        if match:
            index = self.profiles.findData(match.id)
            if index >= 0:
                self.profiles.setCurrentIndex(index)

    def _compatible_profile(self, room):
        version = str(room.get("minecraft_version") or "")
        loader = str(room.get("loader") or "vanilla").lower()
        loader_version = str(room.get("loader_version") or "")
        return next((
            profile for profile in self.pm.list_profiles()
            if str(profile.version) == version
            and str(profile.loader).lower() == loader
            and (
                not loader_version
                or str(getattr(profile, "loader_version", "") or "") == loader_version
            )
        ), None)

    def join_selected(self):
        room = self._selected()
        if not room:
            return
        profile = self._compatible_profile(room)
        selected = self.pm.get(str(self.profiles.currentData() or ""))
        if profile is None and selected and (
            str(selected.version) == str(room.get("minecraft_version") or "")
            and str(selected.loader).lower() == str(room.get("loader") or "vanilla").lower()
        ):
            profile = selected
        if profile is None:
            answer = QMessageBox.question(
                self,
                "Crear perfil compatible",
                "No tienes la instancia exacta de esta sala. ¿Quieres que "
                "KatLauncher cree un perfil compatible ahora?",
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.Yes,
            )
            if answer != QMessageBox.Yes:
                return
            nickname = next(
                (item.nickname for item in self.pm.list_profiles() if item.nickname),
                "Player",
            )
            try:
                profile = self.pm.create_profile(
                    name=("Sala " + str(room.get("name") or "Kat"))[:64],
                    nickname=nickname,
                    version=str(room.get("minecraft_version") or ""),
                    loader=str(room.get("loader") or "vanilla").lower(),
                    loader_version=str(room.get("loader_version") or "") or None,
                )
            except (OSError, ValueError) as error:
                QMessageBox.warning(self, "No se pudo crear el perfil", str(error))
                return
            self.refresh_profiles()
            self.profiles_changed.emit()
            self.operation_succeeded.emit()
        mods = room.get("mods") if isinstance(room.get("mods"), list) else []
        if mods:
            QMessageBox.information(
                self,
                "Compatibilidad de mods",
                "La sala declara mods. KatLauncher preparará el loader exacto; "
                "si el creador publicó un modpack, se instalarán sus dependencias "
                "antes de entrar. Los mods privados deben compartirse aparte.",
            )
        self.launch_requested.emit(
            profile.id,
            str(room.get("host") or ""),
            int(room.get("port") or 25565),
        )

    def join_room(self, room: dict):
        """Recibe una sala elegida dentro de KatCraft y reutiliza el flujo seguro."""
        if not isinstance(room, dict):
            return
        identifier = str(room.get("id") or "")
        if not any(str(item.get("id") or "") == identifier for item in self.rows):
            self.rows.insert(0, dict(room))
            item = QListWidgetItem(str(room.get("name") or "Sala KatCraft"))
            item.setData(Qt.UserRole, identifier)
            self.list.insertItem(0, item)
        for index in range(self.list.count()):
            if str(self.list.item(index).data(Qt.UserRole) or "") == identifier:
                self.list.setCurrentRow(index)
                break
        self.join_selected()
