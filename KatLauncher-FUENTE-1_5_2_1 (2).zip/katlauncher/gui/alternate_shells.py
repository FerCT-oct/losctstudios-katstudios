"""Interfaces alternativas que alojan las páginas reales de KatLauncher.

``KatNormalShell`` recupera la navegación lateral de Kat Modern 1.3.
``KatEpicShell`` adapta el prototipo aportado por Oliver sin duplicar ninguna
función: las mismas páginas, perfiles y señales viven dentro de ambos shells.
"""
from __future__ import annotations

import math

from PySide6.QtCore import QEasingCurve, QPropertyAnimation, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QIcon, QLinearGradient, QPainter, QRadialGradient
from PySide6.QtWidgets import (
    QButtonGroup, QFrame, QGraphicsOpacityEffect, QHBoxLayout, QLabel,
    QPushButton, QScrollArea, QStackedWidget, QVBoxLayout, QWidget,
)

from .dashboard_tab import DashboardRoute
from .modern_shell import KAT_LOGO_PATH


ROUTES = (
    (DashboardRoute.HOME, "⌂", "Inicio"),
    (DashboardRoute.PLAY, "▶", "Jugar"),
    (DashboardRoute.PROFILES, "◆", "Perfiles"),
    (DashboardRoute.DOWNLOADS, "▣", "Modpacks"),
    (DashboardRoute.MODS, "⚒", "Mods"),
    (DashboardRoute.SKINS, "◉", "Skins"),
    (DashboardRoute.SCREENSHOTS, "▧", "Capturas"),
    (DashboardRoute.NEWS, "▤", "Noticias"),
    (DashboardRoute.SERVERS, "◎", "Servidores"),
    (DashboardRoute.ROOMS, "⌘", "Salas"),
    (DashboardRoute.FRIENDS, "♟", "Amigos"),
    (DashboardRoute.ACCOUNTS, "●", "Cuentas"),
    (DashboardRoute.TROPHIES, "★", "Trofeos"),
    (DashboardRoute.BEDROCK, "▦", "Bedrock"),
    (DashboardRoute.SETTINGS, "⚙", "Configuración"),
)


class _CosmicBackdrop(QWidget):
    """Fondo ligero inspirado en el prototipo, sin OpenGL ni recursos externos."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._phase = 0.0
        self._primary = QColor("#7048ff")
        self._secondary = QColor("#06b6d4")
        self._timer = QTimer(self)
        self._timer.setInterval(33)
        self._timer.timeout.connect(self._advance)
        self._timer.start()

    def set_accent(self, primary: str, secondary: str) -> None:
        self._primary = QColor(primary)
        self._secondary = QColor(secondary)
        self.update()

    def _advance(self):
        self._phase += 0.025
        self.update()

    def paintEvent(self, _event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        base = QLinearGradient(0, 0, self.width(), self.height())
        base.setColorAt(0, QColor("#080a12"))
        base.setColorAt(1, QColor("#12101c"))
        painter.fillRect(self.rect(), base)
        for color, x_factor, y_factor, radius, offset in (
            (self._primary, .24, .22, 310, 0.0),
            (self._secondary, .82, .76, 270, 1.8),
        ):
            x = self.width() * x_factor + math.sin(self._phase + offset) * 55
            y = self.height() * y_factor + math.cos(self._phase * .8 + offset) * 38
            glow = QRadialGradient(x, y, radius)
            start = QColor(color)
            start.setAlpha(72)
            end = QColor(color)
            end.setAlpha(0)
            glow.setColorAt(0, start)
            glow.setColorAt(1, end)
            painter.setPen(Qt.NoPen)
            painter.setBrush(glow)
            painter.drawEllipse(int(x - radius), int(y - radius), radius * 2, radius * 2)


class _RouteShell(QWidget):
    route_changed = Signal(str)
    unknown_route_requested = Signal(str)
    logo_clicked = Signal()
    launch_minecraft_requested = Signal()
    check_updates_requested = Signal()
    tutorial_requested = Signal()

    def __init__(self, i18n=None, parent=None):
        super().__init__(parent)
        self.i18n = i18n
        self._pages: dict[str, QWidget] = {}
        self._buttons: dict[str, QPushButton] = {}
        self._active_route = ""
        self.page_stack = QStackedWidget()

    def _t(self, text: str) -> str:
        return self.i18n.t(text) if self.i18n is not None else text

    @property
    def current_route(self) -> str:
        return self._active_route or DashboardRoute.HOME

    def register_page(self, route: str, widget: QWidget) -> None:
        route = str(route).strip().lower()
        if not route:
            raise ValueError("La ruta no puede estar vacía")
        previous = self._pages.get(route)
        if previous is widget:
            return
        if previous is not None:
            self.page_stack.removeWidget(previous)
        self._pages[route] = widget
        self.page_stack.addWidget(widget)
        self._ensure_button(route)

    def unregister_page(self, route: str) -> QWidget | None:
        route = str(route).strip().lower()
        page = self._pages.pop(route, None)
        if page is not None:
            self.page_stack.removeWidget(page)
        button = self._buttons.pop(route, None)
        if button is not None:
            self._remove_button(button)
            button.deleteLater()
        return page

    def navigate(self, route: str) -> bool:
        route = str(route).strip().lower()
        page = self._pages.get(route)
        if page is None:
            self.unknown_route_requested.emit(route)
            return False
        self._active_route = route
        self.page_stack.setCurrentWidget(page)
        for candidate, button in self._buttons.items():
            button.setChecked(candidate == route)
        self._after_navigate(route, page)
        self.route_changed.emit(route)
        QTimer.singleShot(0, page.focusNextChild)
        return True

    def show_menu(self):
        self.navigate(DashboardRoute.HOME)

    def _ensure_button(self, route: str):
        raise NotImplementedError

    def _remove_button(self, button: QPushButton):
        button.setParent(None)

    def _after_navigate(self, route: str, page: QWidget):
        pass

    def retranslate_ui(self):
        for route, button in self._buttons.items():
            icon, label = next(
                ((icon, label) for candidate, icon, label in ROUTES
                 if candidate == route),
                ("•", route.title()),
            )
            button.setText(f"{icon}   {self._t(label)}")


class KatNormalShell(_RouteShell):
    """Kat Modern original, renombrado Kat Normal."""

    def __init__(self, i18n=None, parent=None):
        super().__init__(i18n, parent)
        self.setObjectName("normalShell")
        root = QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)
        self.sidebar = QFrame()
        self.sidebar.setObjectName("normalSidebar")
        self.sidebar.setFixedWidth(210)
        self.sidebar_layout = QVBoxLayout(self.sidebar)
        self.sidebar_layout.setContentsMargins(14, 18, 14, 18)
        self.sidebar_layout.setSpacing(5)
        brand = QPushButton("  KatLauncher")
        brand.setObjectName("normalBrand")
        brand.clicked.connect(self.logo_clicked)
        if KAT_LOGO_PATH.is_file():
            brand.setIcon(QIcon(str(KAT_LOGO_PATH)))
        self.sidebar_layout.addWidget(brand)
        self.sidebar_layout.addSpacing(12)
        self.button_group = QButtonGroup(self)
        self.button_group.setExclusive(True)
        self.sidebar_layout.addStretch()
        self.version_label = QLabel("Kat Normal")
        self.version_label.setObjectName("mutedLabel")
        self.sidebar_layout.addWidget(self.version_label)
        root.addWidget(self.sidebar)
        host = QFrame()
        host.setObjectName("normalContent")
        host_layout = QVBoxLayout(host)
        host_layout.setContentsMargins(18, 16, 18, 18)
        host_layout.addWidget(self.page_stack)
        root.addWidget(host, 1)

    def _ensure_button(self, route: str):
        if route in self._buttons:
            return
        icon, label = next(
            ((icon, label) for candidate, icon, label in ROUTES if candidate == route),
            ("•", route.title()),
        )
        button = QPushButton(f"{icon}   {self._t(label)}")
        button.setObjectName("normalNavButton")
        button.setProperty("routeKey", route)
        button.setCheckable(True)
        button.clicked.connect(lambda _checked=False, selected=route: self.navigate(selected))
        self.button_group.addButton(button)
        self._buttons[route] = button
        self.sidebar_layout.insertWidget(self.sidebar_layout.count() - 2, button)


class KatEpicShell(_RouteShell):
    """Interfaz de tarjetas, brillo y transiciones basada en epic_launcher."""

    def __init__(self, i18n=None, parent=None):
        super().__init__(i18n, parent)
        self.setObjectName("epicShell")
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        self.backdrop = _CosmicBackdrop()
        root.addWidget(self.backdrop)
        backdrop_layout = QVBoxLayout(self.backdrop)
        backdrop_layout.setContentsMargins(22, 14, 22, 22)
        backdrop_layout.setSpacing(14)

        titlebar = QHBoxLayout()
        self.brand = QPushButton("🐾  KATLAUNCHER")
        self.brand.setObjectName("epicBrand")
        self.brand.clicked.connect(self.logo_clicked)
        titlebar.addWidget(self.brand)
        titlebar.addStretch()
        self.update_button = QPushButton(self._t("Buscar actualizaciones"))
        self.update_button.setObjectName("epicTopButton")
        self.update_button.clicked.connect(self.check_updates_requested.emit)
        self.tutorial_button = QPushButton(self._t("Tutorial"))
        self.tutorial_button.setObjectName("epicTopButton")
        self.tutorial_button.clicked.connect(self.tutorial_requested.emit)
        titlebar.addWidget(self.update_button)
        titlebar.addWidget(self.tutorial_button)
        backdrop_layout.addLayout(titlebar)

        body = QHBoxLayout()
        body.setSpacing(20)
        self.sidebar = QFrame()
        self.sidebar.setObjectName("epicSidebar")
        self.sidebar.setFixedWidth(220)
        self.sidebar_layout = QVBoxLayout(self.sidebar)
        self.sidebar_layout.setContentsMargins(14, 20, 14, 20)
        self.sidebar_layout.setSpacing(6)
        identity = QLabel(self._t("Tu universo Minecraft"))
        identity.setObjectName("epicIdentity")
        identity.setWordWrap(True)
        self.sidebar_layout.addWidget(identity)
        self.sidebar_layout.addSpacing(14)
        self.button_group = QButtonGroup(self)
        self.button_group.setExclusive(True)
        self.sidebar_layout.addStretch()
        body.addWidget(self.sidebar)

        self.content = QFrame()
        self.content.setObjectName("epicContent")
        content_layout = QVBoxLayout(self.content)
        content_layout.setContentsMargins(16, 16, 16, 16)
        content_layout.addWidget(self.page_stack)
        self._opacity = QGraphicsOpacityEffect(self.page_stack)
        self._opacity.setOpacity(1.0)
        self.page_stack.setGraphicsEffect(self._opacity)
        body.addWidget(self.content, 1)
        backdrop_layout.addLayout(body, 1)

    def retranslate_ui(self):
        super().retranslate_ui()
        self.update_button.setText(self._t("Buscar actualizaciones"))
        self.tutorial_button.setText(self._t("Kat Tutorial"))

    def set_accent(self, primary: str, secondary: str):
        self.backdrop.set_accent(primary, secondary)

    def _ensure_button(self, route: str):
        if route in self._buttons:
            return
        icon, label = next(
            ((icon, label) for candidate, icon, label in ROUTES if candidate == route),
            ("•", route.title()),
        )
        button = QPushButton(f"{icon}   {self._t(label)}")
        button.setObjectName("epicNavButton")
        button.setProperty("routeKey", route)
        button.setCheckable(True)
        button.clicked.connect(lambda _checked=False, selected=route: self.navigate(selected))
        self.button_group.addButton(button)
        self._buttons[route] = button
        self.sidebar_layout.insertWidget(self.sidebar_layout.count() - 1, button)

    def _after_navigate(self, route: str, page: QWidget):
        animation = QPropertyAnimation(self._opacity, b"opacity", self)
        animation.setDuration(230)
        animation.setStartValue(0.2)
        animation.setEndValue(1.0)
        animation.setEasingCurve(QEasingCurve.OutExpo)
        self._fade_animation = animation
        animation.start()
