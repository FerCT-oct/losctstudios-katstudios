"""Banner no intrusivo para avisar y descargar actualizaciones."""
from __future__ import annotations

from PySide6.QtCore import Signal
from PySide6.QtWidgets import (
    QFrame, QHBoxLayout, QLabel, QProgressBar, QPushButton, QVBoxLayout,
)


class UpdateBanner(QFrame):
    download_requested = Signal(object)
    dismiss_requested = Signal()
    cancel_requested = Signal()

    def __init__(self, i18n, parent=None):
        super().__init__(parent)
        self.i18n = i18n
        self.info = None
        self.setObjectName("updateBanner")
        self.setVisible(False)

        layout = QVBoxLayout(self)
        top = QHBoxLayout()
        self.message_label = QLabel()
        self.message_label.setWordWrap(True)
        top.addWidget(self.message_label, stretch=1)
        self.download_button = QPushButton()
        self.download_button.clicked.connect(self._on_download)
        top.addWidget(self.download_button)
        self.dismiss_button = QPushButton()
        self.dismiss_button.clicked.connect(self._on_dismiss)
        top.addWidget(self.dismiss_button)
        layout.addLayout(top)

        self.progress = QProgressBar()
        self.progress.setVisible(False)
        layout.addWidget(self.progress)
        self.i18n.language_changed.connect(self.retranslate_ui)

    def show_available(self, info):
        self.info = info
        self.progress.setVisible(False)
        self.download_button.setEnabled(True)
        self.dismiss_button.setEnabled(True)
        self.setVisible(True)
        self.retranslate_ui()

    def show_downloading(self, info):
        self.info = info
        self.progress.setRange(0, max(int(info.installer_size), 1))
        self.progress.setValue(0)
        self.progress.setVisible(True)
        self.download_button.setEnabled(False)
        self.dismiss_button.setEnabled(True)
        self.retranslate_ui()

    def set_progress(self, current: int, maximum: int):
        self.progress.setRange(0, max(maximum, 1))
        self.progress.setValue(max(0, min(current, max(maximum, 1))))
        downloaded = current / (1024 * 1024)
        total = maximum / (1024 * 1024) if maximum else 0
        self.message_label.setText(self.i18n.t(
            "Descargando KatLauncher {version}: {downloaded:.1f} de {total:.1f} MB",
            version=self.info.version if self.info else "",
            downloaded=downloaded,
            total=total,
        ))

    def retranslate_ui(self, *_args):
        if not self.info:
            return
        if self.progress.isVisible():
            self.download_button.setText(self.i18n.t("Descargando..."))
            self.dismiss_button.setText(self.i18n.t("Cancelar"))
            return
        notes = self.info.notes_for(self.i18n.language)
        message = self.i18n.t(
            "KatLauncher {version} está disponible.", version=self.info.version
        )
        if notes:
            message += "\n" + notes
        self.message_label.setText(message)
        self.download_button.setText(self.i18n.t("Descargar e instalar"))
        self.dismiss_button.setText(self.i18n.t("Más tarde"))

    def _on_download(self):
        if self.info:
            self.download_requested.emit(self.info)

    def _on_dismiss(self):
        if self.progress.isVisible():
            self.cancel_requested.emit()
        else:
            self.setVisible(False)
            self.dismiss_requested.emit()
