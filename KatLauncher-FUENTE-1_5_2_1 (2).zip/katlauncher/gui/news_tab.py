from __future__ import annotations

from datetime import datetime
import os

from PySide6.QtCore import QSize, Qt, QThread, QUrl, Signal, Slot
from PySide6.QtGui import QDesktopServices, QIcon, QPixmap
from PySide6.QtNetwork import QNetworkAccessManager, QNetworkReply, QNetworkRequest
from PySide6.QtWidgets import (
    QHBoxLayout, QLabel, QLineEdit, QListWidget, QListWidgetItem, QPlainTextEdit,
    QPushButton, QSplitter, QVBoxLayout, QWidget,
)

from ..core.news_service import NewsService
from .worker_registry import WorkerRegistryMixin


class _NewsWorker(QThread):
    loaded = Signal(list)
    failed = Signal(str)

    def __init__(self, service: NewsService, parent=None):
        super().__init__(parent)
        self.service = service

    def run(self):
        try:
            self.loaded.emit(self.service.fetch())
        except Exception as error:
            self.failed.emit(str(error))


class NewsTab(WorkerRegistryMixin, QWidget):
    operation_succeeded = Signal()

    def __init__(self, i18n, parent=None):
        super().__init__(parent)
        self._init_worker_registry()
        self.i18n = i18n
        self.service = NewsService()
        self.items = []
        self.worker = None
        self._image_cache = {}
        self._image_pending = set()
        self.network = QNetworkAccessManager(self)
        self.network.finished.connect(self._image_finished)

        layout = QVBoxLayout(self)
        header = QHBoxLayout()
        self.title_label = QLabel()
        self.title_label.setObjectName("bigTitle")
        header.addWidget(self.title_label)
        header.addStretch()
        self.search_edit = QLineEdit()
        self.search_edit.setClearButtonEnabled(True)
        self.search_edit.returnPressed.connect(self.apply_filter)
        self.search_edit.textChanged.connect(self.apply_filter)
        header.addWidget(self.search_edit)
        self.refresh_button = QPushButton()
        self.refresh_button.clicked.connect(self.refresh)
        header.addWidget(self.refresh_button)
        layout.addLayout(header)

        splitter = QSplitter()
        self.list_widget = QListWidget()
        self.list_widget.setIconSize(QSize(86, 64))
        self.list_widget.currentItemChanged.connect(self._show_item)
        splitter.addWidget(self.list_widget)
        detail = QWidget()
        detail_layout = QVBoxLayout(detail)
        self.detail_title = QLabel()
        self.detail_title.setWordWrap(True)
        self.detail_title.setObjectName("bigTitle")
        detail_layout.addWidget(self.detail_title)
        self.detail_meta = QLabel()
        detail_layout.addWidget(self.detail_meta)
        self.detail_summary = QPlainTextEdit()
        self.detail_summary.setReadOnly(True)
        detail_layout.addWidget(self.detail_summary, stretch=1)
        self.open_button = QPushButton()
        self.open_button.clicked.connect(self.open_source)
        detail_layout.addWidget(self.open_button)
        splitter.addWidget(detail)
        splitter.setStretchFactor(0, 2)
        splitter.setStretchFactor(1, 3)
        layout.addWidget(splitter, stretch=1)
        self.status_label = QLabel()
        layout.addWidget(self.status_label)

        self.i18n.language_changed.connect(self.retranslate_ui)
        self.retranslate_ui()
        if os.environ.get("KATLAUNCHER_SMOKE_TEST") != "1":
            self.refresh()

    def retranslate_ui(self, *_args):
        t = self.i18n.t
        self.title_label.setText(t("Noticias de Minecraft"))
        self.search_edit.setPlaceholderText(t("Buscar noticia… (Enter)"))
        self.refresh_button.setText(t("Actualizar"))
        self.open_button.setText(t("Abrir fuente oficial"))

    def refresh(self):
        if self.worker and self.worker.isRunning():
            return
        self.refresh_button.setEnabled(False)
        self.status_label.setText(self.i18n.t("Cargando noticias oficiales…"))
        self.worker = self._track_worker(_NewsWorker(self.service, self))
        self.worker.loaded.connect(self._on_loaded)
        self.worker.failed.connect(self._on_failed)
        self.worker.start()

    @Slot(list)
    def _on_loaded(self, items):
        self.worker = None
        self.items = list(items)
        self.refresh_button.setEnabled(True)
        self.status_label.setText(self.i18n.t(
            "{count} noticias cargadas.", count=len(self.items)
        ))
        self.apply_filter()

    @Slot(str)
    def _on_failed(self, error):
        self.worker = None
        self.refresh_button.setEnabled(True)
        self.status_label.setText(self.i18n.t("No se pudieron cargar noticias: {error}", error=error))

    @Slot()
    def apply_filter(self):
        query = self.search_edit.text().strip().casefold()
        current_id = None
        current = self.list_widget.currentItem()
        if current:
            current_id = current.data(256)
        self.list_widget.clear()
        for item in self.items:
            haystack = f"{item.title} {item.summary} {item.version}".casefold()
            if query and query not in haystack:
                continue
            date = _friendly_date(item.date)
            label = item.title + (f"\n{date} · {item.version}" if date or item.version else "")
            row = QListWidgetItem(label)
            row.setData(256, item.id)
            row.setData(257, item.image_url)
            icon = self._image_cache.get(item.image_url)
            if icon is not None:
                row.setIcon(icon)
            self.list_widget.addItem(row)
            if item.id == current_id:
                self.list_widget.setCurrentItem(row)
        if self.list_widget.count() and not self.list_widget.currentItem():
            self.list_widget.setCurrentRow(0)
        self._queue_images()

    def _queue_images(self):
        for index in range(self.list_widget.count()):
            row = self.list_widget.item(index)
            url = str(row.data(257) or "")
            if not url or url in self._image_cache or url in self._image_pending:
                continue
            request = QNetworkRequest(QUrl(url))
            request.setAttribute(
                QNetworkRequest.RedirectPolicyAttribute,
                QNetworkRequest.NoLessSafeRedirectPolicy,
            )
            reply = self.network.get(request)
            reply.setProperty("kat_news_image", url)
            self._image_pending.add(url)

    def _image_finished(self, reply: QNetworkReply):
        url = str(reply.property("kat_news_image") or "")
        self._image_pending.discard(url)
        try:
            data = bytes(reply.readAll())
            if reply.error() != QNetworkReply.NoError or not data or len(data) > 2 * 1024 * 1024:
                return
            pixmap = QPixmap()
            if not pixmap.loadFromData(data):
                return
            icon = QIcon(pixmap.scaled(
                86, 64, Qt.KeepAspectRatio, Qt.SmoothTransformation
            ))
            self._image_cache[url] = icon
            for index in range(self.list_widget.count()):
                row = self.list_widget.item(index)
                if row.data(257) == url:
                    row.setIcon(icon)
        finally:
            reply.deleteLater()

    def _current_news(self):
        row = self.list_widget.currentItem()
        identifier = row.data(256) if row else None
        return next((item for item in self.items if item.id == identifier), None)

    def _show_item(self, *_args):
        item = self._current_news()
        if not item:
            self.detail_title.clear()
            self.detail_meta.clear()
            self.detail_summary.clear()
            return
        self.detail_title.setText(item.title)
        self.detail_meta.setText(" · ".join(
            part for part in (_friendly_date(item.date), item.version, item.category) if part
        ))
        self.detail_summary.setPlainText(item.summary)

    def open_source(self):
        item = self._current_news()
        QDesktopServices.openUrl(QUrl(item.source_url if item else "https://www.minecraft.net/en-us/articles"))


def _friendly_date(value: str) -> str:
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00")).date().isoformat()
    except (TypeError, ValueError):
        return str(value or "")[:10]
