"""Navegación global con mando para widgets Qt y diálogos de KatLauncher."""
from __future__ import annotations

import time

from PySide6.QtCore import QEvent, QObject, QPoint, Qt, QTimer, Signal
from PySide6.QtGui import QKeyEvent
from PySide6.QtWidgets import (
    QAbstractButton, QAbstractItemView, QAbstractSlider, QAbstractSpinBox,
    QApplication, QComboBox, QDialog, QFrame, QGridLayout, QHBoxLayout, QLabel,
    QLineEdit, QPlainTextEdit, QPushButton, QTabBar, QTextEdit, QVBoxLayout,
    QWidget,
)

from ..core.controller_support import primary_gamepad_state


class ControllerFocusIndicator(QObject):
    """Borde pulsante que hace visible el foco movido por el mando."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._overlay: QFrame | None = None
        self._target: QWidget | None = None
        self._bright = False
        self._timer = QTimer(self)
        self._timer.setInterval(360)
        self._timer.timeout.connect(self._pulse)

    def show_for(self, widget):
        if widget is None or not isinstance(widget, QWidget) \
                or not widget.isVisible() or not widget.isEnabled():
            self.hide()
            return
        window = widget.window()
        if window is widget:
            self.hide()
            return
        if self._overlay is None or self._overlay.parentWidget() is not window:
            if self._overlay is not None:
                self._overlay.deleteLater()
            self._overlay = QFrame(window)
            self._overlay.setObjectName("katControllerFocusIndicator")
            self._overlay.setAttribute(Qt.WA_TransparentForMouseEvents)
            self._overlay.setFocusPolicy(Qt.NoFocus)
        self._target = widget
        self._bright = True
        self._position()
        self._apply_style()
        self._overlay.show()
        self._overlay.raise_()
        self._timer.start()

    def hide(self):
        self._target = None
        self._timer.stop()
        if self._overlay is not None:
            self._overlay.hide()

    def _position(self):
        if self._overlay is None or self._target is None:
            return
        window = self._target.window()
        top_left = self._target.mapTo(window, QPoint(0, 0))
        geometry = self._target.rect().translated(top_left).adjusted(-3, -3, 3, 3)
        geometry = geometry.intersected(window.rect().adjusted(1, 1, -1, -1))
        self._overlay.setGeometry(geometry)

    def _pulse(self):
        if self._target is None or not self._target.isVisible():
            self.hide()
            return
        self._bright = not self._bright
        self._position()
        self._apply_style()
        self._overlay.raise_()

    def _apply_style(self):
        if self._overlay is None:
            return
        color = "#f4e8ff" if self._bright else "#8b5cf6"
        width = 4 if self._bright else 2
        self._overlay.setStyleSheet(
            "QFrame#katControllerFocusIndicator {"
            f"background: transparent; border: {width}px solid {color};"
            "border-radius: 8px;"
            "}"
        )


class VirtualKeyboardDialog(QDialog):
    """Teclado compacto utilizable por mando para cualquier editor de texto."""

    def __init__(self, target, i18n=None, parent=None):
        super().__init__(parent)
        self.target = target
        self.i18n = i18n
        self.submit_on_accept = False
        self.setWindowTitle(self._t("Teclado virtual"))
        self.setModal(True)
        self.setMinimumWidth(690)

        root = QVBoxLayout(self)
        root.addWidget(QLabel(self._t("Escribe usando el mando y pulsa Listo.")))
        self.preview = QLineEdit(self._target_text())
        self.preview.setFocusPolicy(Qt.NoFocus)
        if isinstance(target, QLineEdit):
            self.preview.setMaxLength(target.maxLength())
            self.preview.setEchoMode(target.echoMode())
            self.preview.setCursorPosition(target.cursorPosition())
        else:
            self.preview.setCursorPosition(len(self.preview.text()))
        root.addWidget(self.preview)

        keys = QGridLayout()
        rows = ("1234567890", "QWERTYUIOP", "ASDFGHJKLÑ", "ZXCVBNM")
        first_button = None
        for row, characters in enumerate(rows):
            offset = 0 if row < 2 else row - 1
            for column, character in enumerate(characters):
                button = QPushButton(character)
                button.setMinimumSize(52, 44)
                button.clicked.connect(
                    lambda _checked=False, value=character: self.preview.insert(value)
                )
                keys.addWidget(button, row, column + offset)
                first_button = first_button or button
        root.addLayout(keys)

        editing = QHBoxLayout()
        space = QPushButton(self._t("Espacio"))
        space.clicked.connect(lambda: self.preview.insert(" "))
        backspace = QPushButton("⌫")
        backspace.clicked.connect(self.preview.backspace)
        clear = QPushButton(self._t("Limpiar"))
        clear.clicked.connect(self.preview.clear)
        editing.addWidget(space, 2)
        editing.addWidget(backspace)
        editing.addWidget(clear)
        root.addLayout(editing)

        actions = QHBoxLayout()
        cancel = QPushButton(self._t("Cancelar"))
        cancel.clicked.connect(self.reject)
        done = QPushButton(self._t("Listo"))
        done.clicked.connect(lambda: self._finish(False))
        submit = QPushButton(self._t("Listo + Enter"))
        submit.clicked.connect(lambda: self._finish(True))
        actions.addStretch()
        actions.addWidget(cancel)
        actions.addWidget(done)
        actions.addWidget(submit)
        root.addLayout(actions)
        if first_button is not None:
            first_button.setFocus(Qt.OtherFocusReason)

    def _t(self, text: str) -> str:
        return self.i18n.t(text) if self.i18n is not None else text

    def _target_text(self) -> str:
        if isinstance(self.target, QLineEdit):
            return self.target.text()
        return self.target.toPlainText()

    def _finish(self, submit: bool):
        self.submit_on_accept = bool(submit)
        self.accept()

    def apply(self):
        text = self.preview.text()
        if isinstance(self.target, QLineEdit):
            self.target.setText(text)
            self.target.setCursorPosition(len(text))
        else:
            self.target.setPlainText(text)
            cursor = self.target.textCursor()
            cursor.movePosition(cursor.MoveOperation.End)
            self.target.setTextCursor(cursor)


class ControllerNavigator(QObject):
    """Convierte DirectInput/WinMM en navegación de teclado para toda la app."""

    back_requested = Signal()
    next_page_requested = Signal()
    previous_page_requested = Signal()
    interaction = Signal()
    secret_unlocked = Signal()
    gamepad_changed = Signal(str)

    def __init__(self, xmb_menu=None, i18n=None, parent=None):
        super().__init__(parent)
        self.xmb_menu = xmb_menu
        self.i18n = i18n
        self._buttons = 0
        self._name = ""
        self._last_move = 0.0
        self._sequence: list[str] = []
        self._sequence_direction = ""
        self.focus_indicator = ControllerFocusIndicator(self)
        self._timer = QTimer(self)
        self._timer.setInterval(35)
        self._timer.timeout.connect(self._poll)
        self._timer.start()

    def _poll(self):
        state = primary_gamepad_state()
        if not state:
            self._buttons = 0
            self.focus_indicator.hide()
            if self._name:
                self._name = ""
                self.gamepad_changed.emit("")
            return
        name = str(state.get("name") or "Mando")
        if name != self._name:
            self._name = name
            self.gamepad_changed.emit(name)

        buttons = int(state.get("buttons") or 0)
        pressed = buttons & ~self._buttons
        self._buttons = buttons
        xmb_visible = self.xmb_menu is not None and self.xmb_menu.isVisible()
        if xmb_visible:
            self.focus_indicator.hide()
        if pressed & 1:  # A
            unlocked = self._record("a")
            if not xmb_visible and not unlocked:
                self._activate()
        if pressed & 2:  # B
            self._record("b")
            waiting_for_a = self._sequence == [
                "up", "up", "down", "down", "left",
                "right", "left", "right", "b",
            ]
            if not xmb_visible and not waiting_for_a:
                self._back()
        if pressed & 4 and not xmb_visible:  # X
            self._send_key(Qt.Key_Space)
            self.interaction.emit()
        if pressed & 8 and not xmb_visible:  # Y
            self._focus(False)
            self.interaction.emit()
        if pressed & 16 and not xmb_visible:  # LB
            self.previous_page_requested.emit()
            self.interaction.emit()
        if pressed & 32 and not xmb_visible:  # RB
            self.next_page_requested.emit()
            self.interaction.emit()

        direction = self._direction(state)
        if direction != self._sequence_direction:
            self._sequence_direction = direction
            if direction:
                self._record(direction)
        if xmb_visible:
            return
        now = time.monotonic()
        if now - self._last_move < 0.20:
            return
        if direction:
            self._move(direction)
            self._last_move = now

    @staticmethod
    def _direction(state) -> str:
        x, y = float(state.get("x") or 0), float(state.get("y") or 0)
        pov = int(state.get("pov", -1))
        if pov in (31500, 0, 4500):
            return "up"
        if pov in (13500, 18000, 22500):
            return "down"
        if pov in (22500, 27000, 31500):
            return "left"
        if pov in (4500, 9000, 13500):
            return "right"
        if abs(y) > abs(x) and y < -0.45:
            return "up"
        if abs(y) > abs(x) and y > 0.45:
            return "down"
        if x < -0.45:
            return "left"
        if x > 0.45:
            return "right"
        return ""

    def _move(self, direction: str):
        widget = QApplication.focusWidget()
        directional = (
            QAbstractItemView, QAbstractSlider, QAbstractSpinBox, QComboBox,
            QLineEdit, QPlainTextEdit, QTabBar, QTextEdit,
        )
        if widget is not None and isinstance(widget, directional):
            key = {
                "up": Qt.Key_Up, "down": Qt.Key_Down,
                "left": Qt.Key_Left, "right": Qt.Key_Right,
            }[direction]
            self._send_key(key, widget)
        else:
            self._focus(direction in ("down", "right"))
        self._show_focus()
        self.interaction.emit()

    @staticmethod
    def _focus(forward: bool):
        window = QApplication.activeWindow()
        if window is not None:
            window.focusNextPrevChild(bool(forward))

    def _activate(self):
        widget = QApplication.focusWidget()
        if self._editable_widget(widget):
            self._open_virtual_keyboard(widget)
        elif isinstance(widget, QAbstractButton) and widget.isEnabled():
            widget.click()
        elif isinstance(widget, QComboBox) and widget.isEnabled():
            widget.showPopup()
        else:
            self._send_key(Qt.Key_Return, widget)
        self._show_focus()
        self.interaction.emit()

    @staticmethod
    def _editable_widget(widget) -> bool:
        return isinstance(widget, (QLineEdit, QPlainTextEdit, QTextEdit)) \
            and widget.isEnabled() and not widget.isReadOnly()

    def _open_virtual_keyboard(self, widget):
        dialog = VirtualKeyboardDialog(
            widget, i18n=self.i18n, parent=widget.window()
        )
        accepted = dialog.exec() == QDialog.Accepted
        if accepted:
            dialog.apply()
        widget.setFocus(Qt.OtherFocusReason)
        if accepted and dialog.submit_on_accept:
            QTimer.singleShot(0, lambda target=widget: self._send_key(
                Qt.Key_Return, target
            ))

    def _show_focus(self):
        widget = QApplication.focusWidget()
        if widget is not None:
            self.focus_indicator.show_for(widget)

    def _back(self):
        window = QApplication.activeWindow()
        if isinstance(window, QDialog):
            self._send_key(Qt.Key_Escape, window)
        else:
            self.back_requested.emit()
        self.interaction.emit()

    @staticmethod
    def _send_key(key, widget=None):
        target = widget or QApplication.focusWidget() or QApplication.activeWindow()
        if target is None:
            return
        press = QKeyEvent(QEvent.KeyPress, key, Qt.NoModifier)
        release = QKeyEvent(QEvent.KeyRelease, key, Qt.NoModifier)
        QApplication.sendEvent(target, press)
        QApplication.sendEvent(target, release)

    def _record(self, token: str) -> bool:
        self._sequence.append(token)
        self._sequence = self._sequence[-10:]
        if self._sequence == [
            "up", "up", "down", "down", "left",
            "right", "left", "right", "b", "a",
        ]:
            self._sequence.clear()
            self.secret_unlocked.emit()
            return True
        return False


class UiClickFilter(QObject):
    """Emite un clic SFX solo para controles interactivos reales."""

    clicked = Signal()

    def eventFilter(self, watched, event):
        if event.type() == QEvent.MouseButtonRelease \
                and getattr(event, "button", lambda: None)() == Qt.LeftButton \
                and isinstance(watched, (QAbstractButton, QComboBox, QTabBar)):
            self.clicked.emit()
        return False
