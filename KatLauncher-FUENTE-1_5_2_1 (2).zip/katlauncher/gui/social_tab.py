from __future__ import annotations

import asyncio
import sqlite3
from datetime import datetime
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from PySide6.QtCore import (
    QByteArray, QBuffer, QIODevice, QSize, QThread, QTimer, Qt, Signal, Slot, QUrl,
)
from PySide6.QtGui import QDesktopServices, QIcon, QImage, QImageReader, QPixmap
from PySide6.QtNetwork import QNetworkAccessManager, QNetworkReply, QNetworkRequest
from PySide6.QtWidgets import (
    QCheckBox, QComboBox, QDialog, QDialogButtonBox, QFileDialog, QFormLayout,
    QGroupBox, QHBoxLayout, QLabel, QLineEdit, QListWidget, QListWidgetItem,
    QMessageBox, QInputDialog, QMenu, QPushButton, QSplitter, QTabWidget,
    QVBoxLayout, QWidget,
)
from supabase import AsyncClientOptions, create_async_client

from ..core.social_service import (
    MAX_AVATAR_BYTES, SocialError, SocialHistoryArchive, SocialService,
)
from .worker_registry import WorkerRegistryMixin
from .i18n import I18n
from .skin_3d_widget import SkinPreview3D


MAX_SOURCE_AVATAR_BYTES = 8 * 1024 * 1024
AVATAR_ROLE = Qt.UserRole + 1


def friendly_social_error(error) -> str:
    """Evita mostrar respuestas HTML/Cloudflare y errores enormes del backend."""
    text = str(error or "").strip()
    lowered = text.lower()
    temporary_markers = (
        "<!doctype", "<html", "cloudflare", "error code 520",
        "'code': 520", '"code": 520', "json could not be generated",
        "bad gateway", "service unavailable", "gateway timeout",
        "connection timed out", "connection reset",
    )
    if not text or len(text) > 600 or any(
        marker in lowered for marker in temporary_markers
    ):
        return (
            "Kat Social no está disponible temporalmente. "
            "Inténtalo nuevamente en unos minutos."
        )
    return text


def prepare_avatar_png(path: str | Path) -> tuple[bytes, QImage]:
    """Decodifica, recorta y re-encodea la PFP para no subir el archivo original."""
    source = Path(path)
    try:
        source_size = source.stat().st_size
    except OSError as error:
        raise SocialError("No se pudo abrir la foto seleccionada.") from error
    if not 1 <= source_size <= MAX_SOURCE_AVATAR_BYTES:
        raise SocialError("La imagen original no puede superar 8 MB.")

    reader = QImageReader(str(source))
    reader.setDecideFormatFromContent(True)
    dimensions = reader.size()
    if dimensions.isValid() and (
        dimensions.width() > 4096 or dimensions.height() > 4096
    ):
        raise SocialError("La imagen no puede superar 4096 × 4096 píxeles.")
    image = reader.read()
    if image.isNull():
        raise SocialError("El archivo seleccionado no es una imagen compatible.")

    square = image.scaled(
        512, 512, Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation,
    )
    left = max(0, (square.width() - 512) // 2)
    top = max(0, (square.height() - 512) // 2)
    square = square.copy(left, top, 512, 512).convertToFormat(QImage.Format_RGBA8888)

    data = QByteArray()
    buffer = QBuffer(data)
    if not buffer.open(QIODevice.WriteOnly) or not square.save(buffer, "PNG"):
        raise SocialError("No se pudo preparar la foto de perfil.")
    payload = bytes(data)
    if len(payload) > MAX_AVATAR_BYTES:
        raise SocialError("La foto procesada no puede superar 2 MB.")
    return payload, square


def _format_timestamp(value) -> str:
    if not value:
        return ""
    try:
        parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00")).astimezone()
    except (TypeError, ValueError):
        return ""
    now = datetime.now().astimezone()
    return parsed.strftime("%H:%M") if parsed.date() == now.date() else parsed.strftime("%d/%m %H:%M")


def _rank_name(profile: dict | None, i18n=None) -> str:
    profile = profile or {}
    if profile.get("rank_name"):
        value = str(profile["rank_name"])
        return i18n.t(value) if i18n is not None else value
    seconds = int(profile.get("play_seconds") or 0)
    if seconds >= 360000:
        value = "Leyenda cósmica"
    elif seconds >= 180000:
        value = "Gato ancestral"
    elif seconds >= 72000:
        value = "Explorador experto"
    elif seconds >= 18000:
        value = "Aventurero"
    elif seconds >= 3600:
        value = "Minero"
    else:
        value = "Recién llegado"
    return i18n.t(value) if i18n is not None else value


def _display_name(profile: dict | None) -> str:
    profile = profile or {}
    return ("🏆 " if profile.get("platinum") else "") + str(
        profile.get("display_name") or "?"
    )


class EditProfileDialog(QDialog):
    def __init__(self, profile: dict | None, i18n, parent=None):
        super().__init__(parent)
        self.i18n = i18n or I18n("es")
        t = self.i18n.t
        profile = profile or {}
        self.avatar_png: bytes | None = None
        self.setWindowTitle(t("Editar perfil de Kat Social"))
        self.setMinimumWidth(380)

        root = QVBoxLayout(self)
        form = QFormLayout()
        self.nickname = QLineEdit(str(profile.get("display_name") or ""))
        self.nickname.setMaxLength(32)
        self.nickname.setPlaceholderText(t("Entre 2 y 32 caracteres"))
        form.addRow(t("Nick público:"), self.nickname)
        root.addLayout(form)

        avatar_row = QHBoxLayout()
        self.preview = QLabel(t("Sin foto nueva"))
        self.preview.setAlignment(Qt.AlignCenter)
        self.preview.setFixedSize(96, 96)
        self.preview.setStyleSheet("border: 1px solid #4b5563; border-radius: 12px;")
        choose = QPushButton(t("Seleccionar PFP…"))
        choose.clicked.connect(self._choose_avatar)
        avatar_row.addWidget(self.preview)
        avatar_row.addWidget(choose, 1)
        root.addLayout(avatar_row)

        self.reset_name = QCheckBox(t("Restablecer el nombre de Google"))
        self.reset_avatar = QCheckBox(t("Restablecer la foto de Google"))
        root.addWidget(self.reset_name)
        root.addWidget(self.reset_avatar)

        buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        root.addWidget(buttons)

    def _choose_avatar(self):
        path, _filter = QFileDialog.getOpenFileName(
            self,
            self.i18n.t("Seleccionar foto de perfil"),
            "",
            self.i18n.t(
                "Imágenes (*.png *.jpg *.jpeg *.webp);;Todos los archivos (*)"
            ),
        )
        if not path:
            return
        try:
            self.avatar_png, image = prepare_avatar_png(path)
        except SocialError as error:
            QMessageBox.warning(self, "Kat Social", self.i18n.t(str(error)))
            return
        self.reset_avatar.setChecked(False)
        self.preview.setText("")
        self.preview.setPixmap(QPixmap.fromImage(image).scaled(
            self.preview.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation,
        ))


class PublicProfileDialog(QDialog):
    def __init__(self, profile: dict, service: SocialService, i18n, parent=None):
        super().__init__(parent)
        self.i18n = i18n or I18n("es")
        t = self.i18n.t
        self.profile = profile or {}
        self.add_friend = False
        self.setWindowTitle(t("Perfil de Kat Social"))
        self.setMinimumSize(480, 480)
        root = QVBoxLayout(self)

        header = QHBoxLayout()
        self.avatar = QLabel(t("Sin PFP"))
        self.avatar.setObjectName("accentAvatar")
        self.avatar.setAlignment(Qt.AlignCenter)
        self.avatar.setFixedSize(84, 84)
        header.addWidget(self.avatar)
        identity = QVBoxLayout()
        platinum = " 🏆 PLATINO" if self.profile.get("platinum") else ""
        title = QLabel(
            f"{self.profile.get('display_name', 'Kat Social')}{platinum}"
        )
        title.setObjectName("bigTitle")
        identity.addWidget(title)
        identity.addWidget(QLabel(
            f"{_rank_name(self.profile, self.i18n)} · "
            f"{int(self.profile.get('play_seconds') or 0) / 3600:.1f} "
            f"{t('horas')}"
        ))
        launcher_version = str(self.profile.get("launcher_version") or "").strip()
        identity.addWidget(QLabel(
            t("KatLauncher {version}", version=launcher_version)
            if launcher_version else t("Versión de KatLauncher no disponible")
        ))
        identity.addStretch()
        header.addLayout(identity, 1)
        root.addLayout(header)
        avatar_url = service.avatar_url(self.profile)
        if avatar_url:
            self._avatar_network = QNetworkAccessManager(self)
            self._avatar_network.finished.connect(self._avatar_loaded)
            request = QNetworkRequest(QUrl(avatar_url))
            request.setTransferTimeout(5000)
            self._avatar_network.get(request)

        presence = self.profile.get("presence") or {}
        presence_box = QGroupBox("Kat Presence")
        presence_layout = QVBoxLayout(presence_box)
        if presence.get("enabled") and presence.get("active"):
            presence_layout.addWidget(QLabel(
                f"🟢 {t('Jugando Minecraft')} {presence.get('version') or '?'} · "
                f"{str(presence.get('loader') or 'vanilla').title()}"
            ))
            skin = str(presence.get("skin") or "")
            self.skin_preview = SkinPreview3D()
            self.skin_preview.setMinimumSize(180, 220)
            self.skin_status = QLabel(t("Cargando skin…"))
            self.skin_status.setAlignment(Qt.AlignCenter)
            presence_layout.addWidget(self.skin_status)
            presence_layout.addWidget(self.skin_preview)
            if skin:
                self._skin_network = QNetworkAccessManager(self)
                self._skin_network.finished.connect(self._skin_loaded)
                request = QNetworkRequest(QUrl(
                    f"{service.shared_skin_root}/{skin}.png"
                ))
                request.setTransferTimeout(5000)
                self._skin_network.get(request)
        else:
            presence_layout.addWidget(QLabel(t("⚫ No está jugando ahora")))
        root.addWidget(presence_box)

        trophies = self.profile.get("trophies") or []
        badges = self.profile.get("badges") or []
        trophy_box = QGroupBox(
            t("Placas y trofeos ({count})", count=len(trophies))
        )
        trophy_layout = QVBoxLayout(trophy_box)
        if badges:
            trophy_layout.addWidget(QLabel(
                "  ".join(f"◆ {item.get('label', '?')}" for item in badges)
            ))
        trophy_list = QListWidget()
        for trophy in trophies:
            trophy_list.addItem(
                f"★ {t(trophy.get('title') or trophy.get('id', '?'))} · "
                f"{t(str(trophy.get('tier') or '')).upper()}"
            )
        if not trophies:
            trophy_list.addItem(t("Todavía no tiene trofeos públicos"))
        trophy_layout.addWidget(trophy_list)
        root.addWidget(trophy_box, 1)

        actions = QDialogButtonBox(QDialogButtonBox.Close)
        actions.rejected.connect(self.reject)
        if not self.profile.get("is_self") and not self.profile.get("is_friend"):
            friend = actions.addButton(
                t("Enviar solicitud de amistad"), QDialogButtonBox.ActionRole
            )
            friend.clicked.connect(self._request_friend)
        root.addWidget(actions)

    def _request_friend(self):
        self.add_friend = True
        self.accept()

    def _skin_loaded(self, reply: QNetworkReply):
        try:
            if reply.error() != QNetworkReply.NoError:
                self.skin_status.setText(self.i18n.t("Skin no disponible"))
                return
            data = bytes(reply.readAll())
            if not self.skin_preview.load_skin_data(data):
                self.skin_status.setText(self.i18n.t("Skin no disponible"))
                return
            self.skin_status.setText("")
        finally:
            reply.deleteLater()

    def _avatar_loaded(self, reply: QNetworkReply):
        try:
            if reply.error() != QNetworkReply.NoError:
                return
            image = QImage.fromData(bytes(reply.readAll()))
            if image.isNull():
                return
            self.avatar.setText("")
            self.avatar.setPixmap(QPixmap.fromImage(image).scaled(
                self.avatar.size(), Qt.KeepAspectRatioByExpanding,
                Qt.SmoothTransformation,
            ))
        finally:
            reply.deleteLater()


class SocialCallWorker(QThread):
    completed = Signal(object)
    failed = Signal(str)

    def __init__(self, function, *args):
        super().__init__()
        self.function = function
        self.args = args

    def run(self):
        try:
            self.completed.emit(self.function(*self.args))
        except Exception as error:
            self.failed.emit(str(error))


class OAuthCallbackWorker(QThread):
    completed = Signal(object)
    failed = Signal(str)
    open_url = Signal(str)

    def __init__(self, service):
        super().__init__()
        self.service = service

    def run(self):
        worker = self

        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):
                query = parse_qs(urlparse(self.path).query)
                code = (query.get("code") or [""])[0]
                body = "KatLauncher recibió tu inicio de sesión. Ya puedes cerrar esta pestaña."
                self.send_response(200)
                self.send_header("Content-Type", "text/plain; charset=utf-8")
                self.end_headers()
                self.wfile.write(body.encode("utf-8"))
                self.server.code = code

            def log_message(self, *_args):
                pass

        try:
            server = HTTPServer(("127.0.0.1", 8765), Handler)
            server.timeout = 180
            self.open_url.emit(self.service.oauth_url())
            server.handle_request()
            server.server_close()
            code = getattr(server, "code", "")
            if not code:
                raise RuntimeError("Google no devolvió un código de acceso.")
            worker.completed.emit(self.service.exchange_code(code))
        except Exception as error:
            worker.failed.emit(str(error))


class RealtimeWorker(QThread):
    changed = Signal()

    def __init__(self, service):
        super().__init__()
        self.service = service

    def run(self):
        try:
            asyncio.run(self._listen())
        except Exception:
            pass  # El refresco periódico sigue siendo respaldo.

    async def _listen(self):
        session = self.service.session
        if not session:
            return
        client = await create_async_client(
            self.service.url,
            self.service.key,
            AsyncClientOptions(persist_session=False, auto_refresh_token=False),
        )
        await client.auth.set_session(session.access_token, session.refresh_token)
        channel = client.channel("kat-social-messages")
        channel.on_postgres_changes(
            "INSERT",
            lambda _payload: self.changed.emit(),
            schema="public",
            table="kat_messages",
        )
        if self.service.posts_supported:
            channel.on_postgres_changes(
                "INSERT",
                lambda _payload: self.changed.emit(),
                schema="public",
                table="kat_posts",
            )
        channel.on_postgres_changes(
            "INSERT",
            lambda _payload: self.changed.emit(),
            schema="public",
            table="kat_group_messages",
        )
        await channel.subscribe()
        try:
            while not self.isInterruptionRequested():
                await asyncio.sleep(0.5)
        finally:
            try:
                await asyncio.wait_for(channel.unsubscribe(), timeout=1.0)
            except Exception:
                pass


class SocialTab(WorkerRegistryMixin, QWidget):
    operation_succeeded = Signal()
    milestone = Signal(str)
    game_invites = Signal(list)

    def __init__(
        self, i18n, settings_manager=None, trophy_manager=None, parent=None,
    ):
        super().__init__(parent)
        self._init_worker_registry()
        self.i18n = i18n or I18n("es")
        self.settings_manager = settings_manager
        self.trophy_manager = trophy_manager
        self.service = SocialService()
        self.history_archive = None
        self.refresh_settings()
        self.worker = None
        self.refresh_worker = None
        self.realtime_worker = None
        self._shutting_down = False
        self._icon_cache: dict[str, QIcon] = {}
        self._avatar_pending: set[str] = set()
        self._identity_avatar_url = ""
        self._game_active = False
        self._pending_notice = ""
        self._version_synced = False
        self._latest_friends = []

        self.network = QNetworkAccessManager(self)
        self.network.finished.connect(self._avatar_finished)

        root = QVBoxLayout(self)
        head = QHBoxLayout()
        self.identity_avatar = QLabel()
        self.identity_avatar.setFixedSize(40, 40)
        self.identity_avatar.setAlignment(Qt.AlignCenter)
        self.identity_avatar.setStyleSheet("border-radius: 20px; background: #24283b;")
        self.identity = QLabel()
        head.addWidget(self.identity_avatar)
        head.addWidget(self.identity, 1)
        self.edit_profile = QPushButton("Editar perfil")
        self.edit_profile.clicked.connect(self.on_edit_profile)
        self.login = QPushButton("Iniciar sesión con Google")
        self.login.clicked.connect(self.on_login)
        self.logout = QPushButton("Cerrar sesión")
        self.logout.clicked.connect(self.on_logout)
        head.addWidget(self.edit_profile)
        head.addWidget(self.login)
        head.addWidget(self.logout)
        root.addLayout(head)

        self.notice = QLabel()
        self.notice.setWordWrap(True)
        root.addWidget(self.notice)

        self.pages = QTabWidget()
        self.pages.currentChanged.connect(self.refresh)
        root.addWidget(self.pages, 1)

        global_page = QWidget()
        global_layout = QVBoxLayout(global_page)
        self.global_list = QListWidget()
        self.global_list.setIconSize(QSize(32, 32))
        self.global_list.itemDoubleClicked.connect(self.on_show_message_profile)
        self._enable_profile_menu(self.global_list, "message")
        global_layout.addWidget(self.global_list)
        safety_row = QHBoxLayout()
        self.report = QPushButton("Reportar mensaje")
        self.report.clicked.connect(self.on_report)
        self.block = QPushButton("Bloquear autor")
        self.block.clicked.connect(self.on_block_author)
        self.moderate = QPushButton("Moderar (ocultar + 10 min)")
        self.moderate.clicked.connect(self.on_moderate)
        safety_row.addWidget(self.report)
        safety_row.addWidget(self.block)
        safety_row.addWidget(self.moderate)
        safety_row.addStretch()
        global_layout.addLayout(safety_row)
        send_row = QHBoxLayout()
        self.message = QLineEdit()
        self.message.setMaxLength(500)
        self.message.setPlaceholderText("Escribe y pulsa Enter")
        self.message.returnPressed.connect(self.on_send_global)
        self.send = QPushButton("Enviar")
        self.send.clicked.connect(self.on_send_global)
        send_row.addWidget(self.message, 1)
        send_row.addWidget(self.send)
        global_layout.addLayout(send_row)
        self.pages.addTab(global_page, "Chat global")

        friends_page = QWidget()
        friends_layout = QVBoxLayout(friends_page)
        find_row = QHBoxLayout()
        self.user_search = QLineEdit()
        self.user_search.setPlaceholderText("Buscar nick y pulsar Enter")
        self.user_search.returnPressed.connect(self.on_search)
        self.find = QPushButton("Buscar")
        self.find.clicked.connect(self.on_search)
        find_row.addWidget(self.user_search, 1)
        find_row.addWidget(self.find)
        friends_layout.addLayout(find_row)
        split = QSplitter(Qt.Horizontal)
        self.search_results = QListWidget()
        self.friends_list = QListWidget()
        self.requests_list = QListWidget()
        self.search_results.setIconSize(QSize(32, 32))
        self.friends_list.setIconSize(QSize(32, 32))
        self.requests_list.setIconSize(QSize(32, 32))
        self.search_results.itemDoubleClicked.connect(self.on_send_friend_request)
        self.friends_list.itemDoubleClicked.connect(self.on_private_message)
        self.requests_list.itemDoubleClicked.connect(self.on_accept_request)
        self._enable_profile_menu(self.search_results, "search")
        self._enable_profile_menu(self.friends_list, "friend")
        self._enable_profile_menu(self.requests_list, "request")
        split.addWidget(self.search_results)
        split.addWidget(self.friends_list)
        split.addWidget(self.requests_list)
        friends_layout.addWidget(split)
        self.pages.addTab(friends_page, "Amigos y solicitudes")

        dm_page = QWidget()
        dm_layout = QVBoxLayout(dm_page)
        self.dm_friend = QComboBox()
        self.dm_friend.setIconSize(QSize(28, 28))
        self.dm_friend.currentIndexChanged.connect(self.refresh)
        self.dm_list = QListWidget()
        self.dm_list.setIconSize(QSize(32, 32))
        self.dm_list.itemDoubleClicked.connect(self.on_show_message_profile)
        self._enable_profile_menu(self.dm_list, "message")
        self.dm_message = QLineEdit()
        self.dm_message.setMaxLength(500)
        self.dm_message.setPlaceholderText("Escribe y pulsa Enter")
        self.dm_message.returnPressed.connect(self.on_send_private)
        self.dm_send = QPushButton("Enviar mensaje privado")
        self.dm_send.clicked.connect(self.on_send_private)
        dm_layout.addWidget(self.dm_friend)
        dm_layout.addWidget(self.dm_list, 1)
        dm_row = QHBoxLayout()
        dm_row.addWidget(self.dm_message, 1)
        dm_row.addWidget(self.dm_send)
        dm_layout.addLayout(dm_row)
        self.pages.addTab(dm_page, "Mensajes privados")

        posts_page = QWidget()
        posts_layout = QVBoxLayout(posts_page)
        self.posts_list = QListWidget()
        self.posts_list.setIconSize(QSize(32, 32))
        self.posts_list.itemDoubleClicked.connect(self.on_show_message_profile)
        self._enable_profile_menu(self.posts_list, "post")
        posts_layout.addWidget(self.posts_list, 1)
        post_row = QHBoxLayout()
        self.post_message = QLineEdit()
        self.post_message.setMaxLength(1000)
        self.post_message.setPlaceholderText("Escribe una publicación y pulsa Enter")
        self.post_message.returnPressed.connect(self.on_create_post)
        self.post_send = QPushButton("Publicar")
        self.post_send.clicked.connect(self.on_create_post)
        post_row.addWidget(self.post_message, 1)
        post_row.addWidget(self.post_send)
        posts_layout.addLayout(post_row)
        self.pages.addTab(posts_page, "Publicaciones")

        groups_page = QWidget()
        groups_layout = QVBoxLayout(groups_page)
        groups_head = QHBoxLayout()
        self.group_select = QComboBox()
        self.group_select.currentIndexChanged.connect(self.refresh)
        self.group_create = QPushButton("Crear grupo")
        self.group_create.clicked.connect(self.on_create_group)
        self.group_add = QPushButton("Añadir amigo")
        self.group_add.clicked.connect(self.on_add_group_friend)
        groups_head.addWidget(self.group_select, 1)
        groups_head.addWidget(self.group_create)
        groups_head.addWidget(self.group_add)
        self.group_list = QListWidget()
        self.group_list.setIconSize(QSize(32, 32))
        self.group_list.itemDoubleClicked.connect(self.on_show_message_profile)
        self._enable_profile_menu(self.group_list, "message")
        groups_send = QHBoxLayout()
        self.group_message = QLineEdit()
        self.group_message.setMaxLength(500)
        self.group_message.setPlaceholderText("Mensaje al grupo; pulsa Enter")
        self.group_message.returnPressed.connect(self.on_send_group)
        self.group_send = QPushButton("Enviar al grupo")
        self.group_send.clicked.connect(self.on_send_group)
        groups_send.addWidget(self.group_message, 1)
        groups_send.addWidget(self.group_send)
        groups_layout.addLayout(groups_head)
        groups_layout.addWidget(self.group_list, 1)
        groups_layout.addLayout(groups_send)
        self.pages.addTab(groups_page, "Grupos")

        self.timer = QTimer(self)
        self.timer.setInterval(2500)
        self.timer.timeout.connect(self.refresh)
        self.presence_timer = QTimer(self)
        self.presence_timer.setInterval(45000)
        self.presence_timer.timeout.connect(self._touch_presence)
        self.realtime_restart_timer = QTimer(self)
        self.realtime_restart_timer.setSingleShot(True)
        self.realtime_restart_timer.setInterval(2000)
        self.realtime_restart_timer.timeout.connect(self._start_realtime)
        self.i18n.language_changed.connect(self.retranslate_ui)
        self.retranslate_ui()
        self._sync_state()
        self.timer.start()
        self.presence_timer.start()

    def refresh_settings(self):
        enabled = bool(
            self.settings_manager
            and self.settings_manager.settings.social_keep_local_history
        )
        if enabled and self.history_archive is None:
            self.history_archive = SocialHistoryArchive()
        elif not enabled:
            self.history_archive = None

    def retranslate_ui(self, *_args):
        t = self.i18n.t
        self.edit_profile.setText(t("Editar perfil"))
        self.login.setText(t("Iniciar sesión con Google"))
        self.logout.setText(t("Cerrar sesión"))
        self.report.setText(t("Reportar mensaje"))
        self.block.setText(t("Bloquear autor"))
        self.moderate.setText(t("Moderar (ocultar + 10 min)"))
        self.message.setPlaceholderText(t("Escribe y pulsa Enter"))
        self.send.setText(t("Enviar"))
        self.user_search.setPlaceholderText(t("Buscar nick y pulsar Enter"))
        self.find.setText(t("Buscar"))
        self.dm_message.setPlaceholderText(t("Escribe y pulsa Enter"))
        self.dm_send.setText(t("Enviar mensaje privado"))
        self.post_message.setPlaceholderText(
            t("Escribe una publicación y pulsa Enter")
        )
        self.post_send.setText(t("Publicar"))
        for index, text in enumerate((
            "Chat global", "Amigos y solicitudes",
            "Mensajes privados", "Publicaciones",
        )):
            self.pages.setTabText(index, t(text))
        self._sync_state()

    def _sync_state(self):
        configured = self.service.configured
        signed = bool(self.service.session)
        self.login.setEnabled(configured and not signed)
        self.logout.setEnabled(signed)
        self.edit_profile.setEnabled(signed)
        self.pages.setEnabled(signed)
        role = (self.service.me or {}).get("role") if isinstance(self.service.me, dict) else None
        self.moderate.setVisible(role in ("moderator", "admin"))
        display_name = _display_name(self.service.me) \
            if isinstance(self.service.me, dict) else ""
        self.identity.setText(f"Kat Social — {display_name}" if signed and display_name else "Kat Social")
        self.notice.setText(
            "" if configured else
            self.i18n.t(
                "Kat Social está listo, pero falta conectar el proyecto "
                "Supabase de KatLauncher."
            )
        )
        self._set_identity_avatar(self.service.me if signed else None)
        if signed:
            self.sync_trophies()
            if not self._version_synced:
                self._version_synced = True
                QTimer.singleShot(200, self._sync_launcher_version)
            self.refresh()
            self._start_realtime()
        else:
            self._version_synced = False
            if self.realtime_worker:
                self.realtime_worker.requestInterruption()

    def _sync_launcher_version(self):
        if not self.service.session:
            self._version_synced = False
            return
        if not self._call(
            self.service.sync_launcher_version,
            completed=lambda _profile: self._sync_identity(),
            silent=True,
        ):
            self._version_synced = False

    def _start_realtime(self):
        if self._shutting_down or self._game_active:
            return
        if self.realtime_worker and self.realtime_worker.isRunning():
            return
        self.realtime_worker = RealtimeWorker(self.service)
        self.realtime_worker.changed.connect(self.refresh)
        self.realtime_worker.finished.connect(self._realtime_finished)
        self.realtime_worker.start()

    def _realtime_finished(self):
        worker = self.realtime_worker
        self.realtime_worker = None
        if worker is not None:
            worker.deleteLater()
        if not self._shutting_down and not self._game_active \
                and self.service.session:
            self.realtime_restart_timer.start()

    def set_game_active(self, active: bool):
        """Pausa Kat Social mientras Minecraft está abierto, sin mostrar modales."""
        active = bool(active)
        if self._game_active == active:
            return
        self._game_active = active
        if active:
            self.timer.stop()
            self.presence_timer.stop()
            self.realtime_restart_timer.stop()
            if self.realtime_worker:
                self.realtime_worker.requestInterruption()
            return
        if not self._shutting_down:
            self.timer.start()
            self.presence_timer.start()
            if self.service.session:
                self._start_realtime()
                self.refresh()
        if self._pending_notice:
            self.notice.setText(self.i18n.t(self._pending_notice))
            self._pending_notice = ""

    def shutdown(self):
        self._shutting_down = True
        self.timer.stop()
        self.presence_timer.stop()
        self.realtime_restart_timer.stop()
        if self.realtime_worker:
            self.realtime_worker.requestInterruption()
            return self.realtime_worker.wait(3000)
        return True

    def _call(
        self, function, *args, completed=None, is_refresh=False, silent=False,
        finalized=None,
    ):
        attribute = "refresh_worker" if is_refresh else "worker"
        current = getattr(self, attribute)
        if current and current.isRunning():
            return False
        call = self._track_worker(SocialCallWorker(function, *args))
        setattr(self, attribute, call)
        outcome = {}
        call.completed.connect(
            lambda value: outcome.update({"completed": True, "value": value})
        )
        call.failed.connect(
            lambda error: outcome.update({"completed": False, "error": error})
        )

        def finalize(name=attribute, worker=call):
            if getattr(self, name) is worker:
                setattr(self, name, None)
            if outcome.get("completed"):
                (completed or (lambda _value: self.refresh()))(outcome.get("value"))
            elif not silent and outcome.get("error"):
                if is_refresh:
                    self._background_failed(outcome["error"])
                else:
                    self._failed(outcome["error"])
            if finalized:
                finalized()

        call.finished.connect(finalize)
        call.start()
        return True

    def on_login(self):
        if self.worker:
            return
        self.worker = self._track_worker(OAuthCallbackWorker(self.service))
        self.worker.open_url.connect(lambda url: QDesktopServices.openUrl(QUrl(url)))
        self.worker.completed.connect(
            lambda _session: (self.operation_succeeded.emit(), self._sync_state())
        )
        self.worker.failed.connect(self._failed)
        self.worker.finished.connect(lambda: setattr(self, "worker", None))
        self.worker.start()

    def on_logout(self):
        self.service.sign_out()
        self._sync_state()

    def on_edit_profile(self):
        dialog = EditProfileDialog(self.service.me, self.i18n, self)
        if dialog.exec() != QDialog.Accepted:
            return
        self._call(
            self._save_profile,
            dialog.nickname.text(),
            dialog.avatar_png,
            dialog.reset_name.isChecked(),
            dialog.reset_avatar.isChecked(),
            completed=lambda _profile: (
                self.operation_succeeded.emit(), self._sync_state()
            ),
        )

    def _save_profile(self, nickname, avatar_png, reset_name, reset_avatar):
        if reset_name or reset_avatar:
            self.service.reset_profile(reset_name, reset_avatar)
        if not reset_name:
            self.service.update_display_name(nickname)
        if avatar_png is not None:
            self.service.upload_avatar(avatar_png)
        return self.service.me

    def on_send_global(self):
        text = self.message.text().strip()
        if text and self._call(
            self.service.rpc, "kat_send_message", {"p_body": text},
            completed=lambda _value: (
                self.milestone.emit("first_global"), self.refresh()
            ),
        ):
            self.message.clear()

    def on_search(self):
        query = self.user_search.text().strip()
        if query:
            self._call(
                self.service.rpc,
                "kat_search_users",
                {"p_query": query},
                completed=self._show_search,
            )

    def _show_search(self, users):
        self.search_results.clear()
        for user in users or []:
            status = "🟢" if user.get("online") else "⚫"
            item = QListWidgetItem(
                f"{status} {_display_name(user)} · "
                f"{_rank_name(user, self.i18n)} — "
                f"{self.i18n.t('doble clic para enviar solicitud')}"
            )
            item.setData(Qt.UserRole, {"user_id": user.get("id")})
            self._set_item_avatar(item, user)
            self.search_results.addItem(item)

    def on_send_friend_request(self, item):
        data = item.data(Qt.UserRole) or {}
        target = data.get("user_id")
        if not target:
            return
        self.search_results.setEnabled(False)

        def completed(_value):
            item.setText(
                item.text().split(" —", 1)[0]
                + " — " + self.i18n.t("solicitud enviada")
            )
            self.refresh()

        if not self._call(
            self.service.rpc,
            "kat_send_friend_request",
            {"p_target": target},
            completed=completed,
            finalized=lambda: self.search_results.setEnabled(True),
        ):
            self.search_results.setEnabled(True)

    def on_accept_request(self, item):
        data = item.data(Qt.UserRole) or {}
        request_id = data.get("request_id")
        if not request_id:
            return
        answer = QMessageBox.question(
            self, "Kat Social", self.i18n.t("¿Aceptar esta solicitud de amistad?")
        )
        self.requests_list.setEnabled(False)
        if not self._call(
            self.service.rpc,
            "kat_respond_friend_request",
            {
                "p_request": data.get("request_id"),
                "p_accept": answer == QMessageBox.Yes,
            },
            completed=lambda _value: self.refresh(),
            finalized=lambda: self.requests_list.setEnabled(True),
        ):
            self.requests_list.setEnabled(True)

    def on_private_message(self, item):
        data = item.data(Qt.UserRole) or {}
        index = self.dm_friend.findData(data.get("user_id"))
        if index >= 0:
            self.dm_friend.setCurrentIndex(index)
        self.pages.setCurrentIndex(2)

    def on_send_private(self):
        text = self.dm_message.text().strip()
        friend = self.dm_friend.currentData()
        if text and friend and self._call(
            self.service.rpc,
            "kat_send_message",
            {"p_body": text, "p_recipient": friend},
        ):
            self.dm_message.clear()

    def on_create_post(self):
        text = self.post_message.text().strip()
        if text and self._call(
            self.service.rpc, "kat_create_post", {"p_body": text},
            completed=lambda _value: (
                self.milestone.emit("first_post"), self.refresh()
            ),
        ):
            self.post_message.clear()

    def on_create_group(self):
        name, accepted = QInputDialog.getText(
            self, "Nuevo grupo", "Nombre del grupo (podrás agregar amigos):"
        )
        if accepted and name.strip():
            self._call(self.service.create_group, name.strip(), [],
                       completed=lambda _value: self.refresh())

    def on_send_group(self):
        text = self.group_message.text().strip()
        group_id = self.group_select.currentData()
        if text and group_id and self._call(
            self.service.send_group_message, group_id, text,
            completed=lambda _value: self.refresh(),
        ):
            self.group_message.clear()

    def on_add_group_friend(self):
        group_id = self.group_select.currentData()
        choices = [
            (_display_name(row), row.get("id")) for row in self._latest_friends
            if row.get("id")
        ]
        if not group_id or not choices:
            return
        labels = [item[0] for item in choices]
        label, accepted = QInputDialog.getItem(
            self, "Añadir amigo", "Amigo:", labels, 0, False,
        )
        if accepted and label in labels:
            user_id = choices[labels.index(label)][1]
            self._call(self.service.add_group_member, group_id, user_id,
                       completed=lambda _value: self.refresh())

    def sync_trophies(self, attempt: int = 0):
        if not self.service.session or self.trophy_manager is None:
            return
        if self._call(
            self.service.sync_trophies,
            self.trophy_manager.unlocked_ids,
            completed=lambda _profile: (self._sync_identity(), self.refresh()),
            silent=True,
        ):
            return
        if attempt < 3:
            QTimer.singleShot(1800, lambda: self.sync_trophies(attempt + 1))

    def set_game_presence(self, profile, active: bool, attempt: int = 0):
        if not self.service.session:
            return
        enabled = bool(
            self.settings_manager
            and self.settings_manager.settings.kat_presence_enabled
        )
        desired = bool(active and enabled and profile is not None)
        loader = getattr(profile, "loader", "") if desired else ""
        version = getattr(profile, "version", "") if desired else ""
        skin = getattr(profile, "nickname", "") if desired else ""
        if self._call(
            self.service.set_presence, desired, loader, version, skin, enabled,
            completed=lambda _profile: self._sync_identity(),
            silent=True,
        ):
            return
        if attempt < 3:
            QTimer.singleShot(
                1800,
                lambda: self.set_game_presence(profile, active, attempt + 1),
            )

    def on_show_message_profile(self, item):
        user_id = str((item.data(Qt.UserRole) or {}).get("user_id") or "")
        if not user_id:
            return
        self._call(
            self.service.public_profile,
            user_id,
            completed=self._show_public_profile,
        )

    def _enable_profile_menu(self, widget: QListWidget, source: str):
        widget.setContextMenuPolicy(Qt.CustomContextMenu)
        widget.customContextMenuRequested.connect(
            lambda position, current=widget, kind=source:
                self._show_user_context_menu(current, position, kind)
        )

    def _show_user_context_menu(
        self, widget: QListWidget, position, source: str
    ):
        item = widget.itemAt(position)
        if item is None or not (item.data(Qt.UserRole) or {}).get("user_id"):
            return
        widget.setCurrentItem(item)
        menu = QMenu(widget)
        view_profile = menu.addAction(self.i18n.t("Ver perfil"))
        secondary = None
        if source == "friend":
            secondary = menu.addAction(self.i18n.t("Enviar mensaje privado"))
        elif source == "search":
            secondary = menu.addAction(self.i18n.t("Enviar solicitud de amistad"))
        elif source == "request":
            secondary = menu.addAction(self.i18n.t("Responder solicitud"))
        selected = menu.exec(widget.viewport().mapToGlobal(position))
        if selected == view_profile:
            self.on_show_message_profile(item)
        elif selected == secondary:
            if source == "friend":
                self.on_private_message(item)
            elif source == "search":
                self.on_send_friend_request(item)
            elif source == "request":
                self.on_accept_request(item)

    def _show_public_profile(self, profile):
        if not isinstance(profile, dict):
            return
        dialog = PublicProfileDialog(profile, self.service, self.i18n, self)
        if dialog.exec() == QDialog.Accepted and dialog.add_friend:
            self._call(
                self.service.rpc,
                "kat_send_friend_request",
                {"p_target": profile.get("id")},
                completed=lambda _value: self.refresh(),
            )

    def record_playtime(self, seconds: int, attempt: int = 0):
        seconds = max(0, min(int(seconds), 21600))
        if seconds < 30 or not self.service.session:
            return
        if self._call(
            self.service.add_playtime,
            seconds,
            completed=lambda _profile: self._sync_identity(),
            silent=True,
        ):
            return
        if attempt < 3:
            QTimer.singleShot(
                2500, lambda: self.record_playtime(seconds, attempt + 1)
            )

    def on_report(self):
        item = self.global_list.currentItem()
        if not item:
            return
        reason, ok = QInputDialog.getText(
            self, self.i18n.t("Reportar mensaje"),
            self.i18n.t("Motivo del reporte:")
        )
        if ok and len(reason.strip()) >= 3:
            self._call(
                self.service.rpc,
                "kat_report_message",
                {
                    "p_message": (item.data(Qt.UserRole) or {}).get("message_id"),
                    "p_reason": reason.strip()[:300],
                },
            )

    def on_block_author(self):
        item = self.global_list.currentItem()
        if not item:
            return
        if QMessageBox.question(
            self, "Kat Social", self.i18n.t("¿Bloquear a este usuario?")
        ) == QMessageBox.Yes:
            self._call(
                self.service.rpc,
                "kat_block_user",
                {"p_target": (item.data(Qt.UserRole) or {}).get("user_id")},
            )

    def on_moderate(self):
        item = self.global_list.currentItem()
        if not item:
            return
        self._call(
            self.service.rpc,
            "kat_moderate_message",
            {
                "p_message": (item.data(Qt.UserRole) or {}).get("message_id"),
                "p_hide": True,
                "p_timeout_minutes": 10,
            },
        )

    def _touch_presence(self):
        if not self._game_active and self.service.session and not self.worker:
            self._call(
                self.service.touch_presence,
                completed=lambda _profile: self._sync_identity(),
                silent=True,
            )

    def _sync_identity(self):
        profile = self.service.me if isinstance(self.service.me, dict) else {}
        name = _display_name(profile) if profile else "Kat Social"
        self.identity.setText(
            f"Kat Social — {name} · {_rank_name(profile, self.i18n)}"
        )
        self._set_identity_avatar(profile)

    def refresh(self, *_args):
        if self._game_active or not self.service.session or self.worker:
            return
        self._call(
            self._snapshot,
            self.dm_friend.currentData(),
            self.pages.currentIndex() == 2,
            completed=self._render,
            is_refresh=True,
        )

    def _snapshot(self, friend, mark_read):
        messages = self.service.global_messages()
        posts = self.service.posts()
        requests = self.service.requests()
        private = self.service.private_messages(friend)
        if mark_read and private:
            self.service.mark_private_read(friend, private[-1].get("id"))
        friends = self.service.friends()
        try:
            game_invites = self.service.rpc("kat_list_game_invites") or []
        except Exception:
            game_invites = []
        groups = self.service.groups()
        selected_group = self.group_select.currentData()
        if not selected_group and groups:
            selected_group = groups[0].get("id")
        group_messages = self.service.group_messages(selected_group)
        return (messages, friends, requests, private, posts, game_invites,
                groups, group_messages)

    @Slot(object)
    def _render(self, snapshot):
        (messages, friends, requests, private, posts, game_invites,
         groups, group_messages) = snapshot
        self._latest_friends = list(friends)
        if game_invites:
            self.game_invites.emit(list(game_invites))
        self._clear_temporary_notice()
        if friends:
            self.milestone.emit("first_friend")
        if self.history_archive is not None:
            try:
                self.history_archive.save(messages, "global")
                friend_id = str(self.dm_friend.currentData() or "")
                if friend_id:
                    self.history_archive.save(private, "private", friend_id)
            except (OSError, sqlite3.Error):
                # La copia local es opcional y nunca debe romper el chat.
                pass
        self.global_list.clear()
        self.friends_list.clear()
        self.requests_list.clear()

        for row in messages:
            time = _format_timestamp(row.get("created_at"))
            prefix = f"[{time}] " if time else ""
            item = QListWidgetItem(
                f"{prefix}{_display_name(row)}: {row.get('body', '')}"
            )
            item.setData(Qt.UserRole, {
                "message_id": row.get("id"), "user_id": row.get("sender_id"),
            })
            self._set_item_avatar(item, row)
            self.global_list.addItem(item)

        for row in friends:
            status = "🟢" if row.get("online") else "⚫"
            unread = int(row.get("unread_count") or 0)
            suffix = (
                f" — {unread} {self.i18n.t('sin leer')}" if unread else ""
            )
            item = QListWidgetItem(
                f"{status} {_display_name(row)} · "
                f"{_rank_name(row, self.i18n)}{suffix}"
            )
            item.setData(Qt.UserRole, {"user_id": row.get("id")})
            self._set_item_avatar(item, row)
            self.friends_list.addItem(item)

        current_friend = self.dm_friend.currentData()
        self.dm_friend.blockSignals(True)
        self.dm_friend.clear()
        for row in friends:
            status = "🟢" if row.get("online") else "⚫"
            self.dm_friend.addItem(f"{status} {_display_name(row)}", row.get("id"))
            index = self.dm_friend.count() - 1
            url = self._queue_avatar(row)
            self.dm_friend.setItemData(index, url, AVATAR_ROLE)
            if url in self._icon_cache:
                self.dm_friend.setItemIcon(index, self._icon_cache[url])
        index = self.dm_friend.findData(current_friend)
        if index >= 0:
            self.dm_friend.setCurrentIndex(index)
        self.dm_friend.blockSignals(False)

        for row in requests:
            status = "🟢" if row.get("online") else "⚫"
            item = QListWidgetItem(
                f"{status} {self.i18n.t('Solicitud')}: {_display_name(row)}"
            )
            item.setData(Qt.UserRole, {
                "request_id": row.get("request_id"), "user_id": row.get("id"),
            })
            self._set_item_avatar(item, row)
            self.requests_list.addItem(item)

        self.dm_list.clear()
        for row in private:
            time = _format_timestamp(row.get("created_at"))
            prefix = f"[{time}] " if time else ""
            item = QListWidgetItem(
                f"{prefix}{_display_name(row)}: {row.get('body', '')}"
            )
            item.setData(Qt.UserRole, {
                "message_id": row.get("id"), "user_id": row.get("sender_id"),
            })
            self._set_item_avatar(item, row)
            self.dm_list.addItem(item)

        self.posts_list.clear()
        for row in posts:
            time = _format_timestamp(row.get("created_at"))
            prefix = f"[{time}] " if time else ""
            item = QListWidgetItem(
                f"{prefix}{_display_name(row)} · "
                f"{_rank_name(row, self.i18n)}\n"
                f"{row.get('body', '')}"
            )
            item.setData(Qt.UserRole, {
                "post_id": row.get("id"), "user_id": row.get("author_id"),
            })
            self._set_item_avatar(item, row)
            self.posts_list.addItem(item)

        current_group = self.group_select.currentData()
        self.group_select.blockSignals(True)
        self.group_select.clear()
        for row in groups:
            self.group_select.addItem(
                f"{row.get('name', 'Grupo')} · {row.get('members', 1)} miembros",
                row.get("id"),
            )
        group_index = self.group_select.findData(current_group)
        if group_index >= 0:
            self.group_select.setCurrentIndex(group_index)
        self.group_select.blockSignals(False)
        self.group_list.clear()
        for row in group_messages:
            time = _format_timestamp(row.get("created_at"))
            prefix = f"[{time}] " if time else ""
            item = QListWidgetItem(
                f"{prefix}{_display_name(row)}: {row.get('body', '')}"
            )
            item.setData(Qt.UserRole, {
                "message_id": row.get("id"), "user_id": row.get("sender_id"),
            })
            self._set_item_avatar(item, row)
            self.group_list.addItem(item)
        self._refresh_avatar_icons()
        self.dm_list.scrollToBottom()
        self.global_list.scrollToBottom()

    def _queue_avatar(self, profile: dict | None) -> str:
        url = self.service.avatar_url(profile)
        if not url or url in self._icon_cache or url in self._avatar_pending:
            return url
        request = QNetworkRequest(QUrl(url))
        request.setTransferTimeout(5000)
        reply = self.network.get(request)
        reply.setProperty("kat_avatar_url", url)
        self._avatar_pending.add(url)
        return url

    def _set_item_avatar(self, item: QListWidgetItem, profile: dict | None):
        url = self._queue_avatar(profile)
        item.setData(AVATAR_ROLE, url)
        if url in self._icon_cache:
            item.setIcon(self._icon_cache[url])

    def _set_identity_avatar(self, profile: dict | None):
        self._identity_avatar_url = self._queue_avatar(profile)
        self._refresh_avatar_icons()

    @Slot(QNetworkReply)
    def _avatar_finished(self, reply):
        url = str(reply.property("kat_avatar_url") or "")
        self._avatar_pending.discard(url)
        try:
            if reply.error() != QNetworkReply.NoError:
                return
            data = bytes(reply.readAll())
            if not data or len(data) > MAX_AVATAR_BYTES:
                return
            image = QImage.fromData(data)
            if image.isNull() or image.width() > 4096 or image.height() > 4096:
                return
            pixmap = QPixmap.fromImage(image).scaled(
                64, 64, Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation,
            )
            self._icon_cache[url] = QIcon(pixmap)
            self._refresh_avatar_icons()
        finally:
            reply.deleteLater()

    def _refresh_avatar_icons(self):
        for widget in (
            self.global_list, self.posts_list, self.search_results, self.friends_list,
            self.requests_list, self.dm_list,
            self.group_list,
        ):
            for index in range(widget.count()):
                item = widget.item(index)
                url = item.data(AVATAR_ROLE)
                if url in self._icon_cache:
                    item.setIcon(self._icon_cache[url])
        for index in range(self.dm_friend.count()):
            url = self.dm_friend.itemData(index, AVATAR_ROLE)
            if url in self._icon_cache:
                self.dm_friend.setItemIcon(index, self._icon_cache[url])
        if self._identity_avatar_url in self._icon_cache:
            pixmap = self._icon_cache[self._identity_avatar_url].pixmap(40, 40)
            self.identity_avatar.setPixmap(pixmap)
        elif not self._identity_avatar_url:
            self.identity_avatar.clear()

    @Slot(str)
    def _failed(self, error):
        message = friendly_social_error(error)
        if self._game_active:
            self._pending_notice = message
            return
        QMessageBox.warning(self, "Kat Social", self.i18n.t(message))

    @Slot(str)
    def _background_failed(self, error):
        message = friendly_social_error(error)
        if self._game_active:
            self._pending_notice = message
            return
        self.notice.setText(self.i18n.t(message))

    def _clear_temporary_notice(self):
        if self.service.configured:
            self.notice.clear()
