from pathlib import Path

from PySide6.QtCore import QThread, Qt, Signal, Slot
from PySide6.QtWidgets import (
    QCheckBox, QComboBox, QFileDialog, QGroupBox, QHBoxLayout, QLabel, QLineEdit,
    QListWidget, QListWidgetItem, QMessageBox, QProgressBar, QPushButton, QSplitter,
    QInputDialog,
    QVBoxLayout, QWidget,
)

from ..core.profile_manager import Profile, ProfileManager
from ..core.modpack_manager import export_folder_to_mrpack
from .worker_registry import WorkerRegistryMixin
from .workers import ModpackInstallWorker, ModpackSearchWorker, ModpackVersionsWorker


class ModpackExportWorker(QThread):
    exported = Signal(str)
    failed = Signal(str)
    status = Signal(str)

    def __init__(self, source, output, options):
        super().__init__()
        self.source = source
        self.output = output
        self.options = options

    def run(self):
        try:
            self.exported.emit(export_folder_to_mrpack(
                self.source, self.output, status_cb=self.status.emit, **self.options
            ))
        except Exception as error:
            self.failed.emit(str(error))


class ModpacksTab(WorkerRegistryMixin, QWidget):
    operation_succeeded = Signal()
    modpack_completed = Signal()

    def __init__(self, profile_manager: ProfileManager, settings_manager, i18n,
                 on_change=None, parent=None):
        super().__init__(parent)
        self._init_worker_registry()
        self.pm = profile_manager
        self.settings_manager = settings_manager
        self.i18n = i18n
        self.on_change = on_change
        self._search_hits = []
        self._search_worker = None
        self._versions_worker = None
        self._install_worker = None
        self._export_worker = None

        layout = QVBoxLayout(self)
        self.intro_label = QLabel()
        layout.addWidget(self.intro_label)
        self.security_label = QLabel(
            "⚠ Los modpacks y sus mods ejecutan código de terceros. Instala solo proyectos de confianza."
        )
        self.security_label.setWordWrap(True)
        layout.addWidget(self.security_label)

        splitter = QSplitter(Qt.Horizontal)
        self.installed_box = QGroupBox()
        installed_layout = QVBoxLayout(self.installed_box)
        self.installed_list = QListWidget()
        self.installed_list.currentItemChanged.connect(self._show_installed_details)
        installed_layout.addWidget(self.installed_list)
        self.installed_details = QLabel()
        self.installed_details.setWordWrap(True)
        installed_layout.addWidget(self.installed_details)
        self.remove_button = QPushButton()
        self.remove_button.clicked.connect(self.on_remove)
        installed_layout.addWidget(self.remove_button)
        splitter.addWidget(self.installed_box)

        self.search_box = QGroupBox()
        search_layout = QVBoxLayout(self.search_box)
        search_row = QHBoxLayout()
        self.search_edit = QLineEdit()
        self.search_edit.returnPressed.connect(self.on_search)
        self.search_button = QPushButton()
        self.search_button.clicked.connect(self.on_search)
        search_row.addWidget(self.search_edit, stretch=1)
        search_row.addWidget(self.search_button)
        search_layout.addLayout(search_row)

        self.results_list = QListWidget()
        self.results_list.currentItemChanged.connect(self.on_project_selected)
        search_layout.addWidget(self.results_list, stretch=1)

        version_row = QHBoxLayout()
        self.version_label = QLabel()
        self.version_combo = QComboBox()
        version_row.addWidget(self.version_label)
        version_row.addWidget(self.version_combo, stretch=1)
        search_layout.addLayout(version_row)

        nickname_row = QHBoxLayout()
        self.nickname_label = QLabel()
        self.nickname_edit = QLineEdit()
        nickname_row.addWidget(self.nickname_label)
        nickname_row.addWidget(self.nickname_edit, stretch=1)
        search_layout.addLayout(nickname_row)

        self.optional_check = QCheckBox()
        self.optional_check.setChecked(True)
        search_layout.addWidget(self.optional_check)
        self.status_label = QLabel()
        self.status_label.setWordWrap(True)
        search_layout.addWidget(self.status_label)
        self.progress_bar = QProgressBar()
        self.progress_bar.setValue(0)
        search_layout.addWidget(self.progress_bar)

        actions = QHBoxLayout()
        self.install_button = QPushButton()
        self.install_button.clicked.connect(self.on_install)
        self.import_button = QPushButton()
        self.import_button.clicked.connect(self.on_import)
        self.export_button = QPushButton()
        self.export_button.clicked.connect(self.on_export)
        actions.addWidget(self.install_button)
        actions.addWidget(self.import_button)
        actions.addWidget(self.export_button)
        search_layout.addLayout(actions)
        splitter.addWidget(self.search_box)
        splitter.setStretchFactor(0, 1)
        splitter.setStretchFactor(1, 2)
        layout.addWidget(splitter, stretch=1)

        self._default_nickname = self.settings_manager.settings.default_nickname
        self.nickname_edit.setText(self._default_nickname)
        self.install_button.setEnabled(False)
        self.i18n.language_changed.connect(self.retranslate_ui)
        self.retranslate_ui()
        self.refresh_installed()

    def retranslate_ui(self, *_args):
        t = self.i18n.t
        self.intro_label.setText(t(
            "Explora e instala modpacks de Modrinth como perfiles independientes"
        ))
        self.security_label.setText(t(
            "⚠ Los modpacks y sus mods ejecutan código de terceros. Instala solo proyectos de confianza."
        ))
        self.installed_box.setTitle(t("Modpacks instalados"))
        self.remove_button.setText(t("Quitar de perfiles"))
        self.search_box.setTitle(t("Buscar modpacks en Modrinth"))
        self.search_edit.setPlaceholderText(t(
            "Nombre del modpack, p. ej. 'Fabulously Optimized'"
        ))
        self.search_button.setText(t("🔍 Buscar"))
        self.version_label.setText(t("Versión del modpack:"))
        self.nickname_label.setText(t("Nickname:"))
        self.optional_check.setText(t("Instalar archivos opcionales del cliente"))
        self.install_button.setText(t("⬇ Instalar como perfil"))
        self.import_button.setText(t("📦 Importar .mrpack"))
        self.export_button.setText(t("Crear .mrpack"))
        self.refresh_installed()
        self._render_search_hits()
        self._retranslate_versions()

    def refresh_settings(self):
        new_default = self.settings_manager.settings.default_nickname
        current = self.nickname_edit.text()
        if not current.strip() or current == self._default_nickname:
            self.nickname_edit.setText(new_default)
        self._default_nickname = new_default

    def refresh_installed(self):
        if not hasattr(self, "installed_list"):
            return
        current_item = self.installed_list.currentItem()
        current = current_item.data(Qt.UserRole) if current_item else None
        self.installed_list.blockSignals(True)
        self.installed_list.clear()
        for profile in self.pm.list_modpack_profiles():
            item = QListWidgetItem(profile.name)
            item.setData(Qt.UserRole, profile.id)
            self.installed_list.addItem(item)
        self.installed_list.blockSignals(False)
        if current:
            for index in range(self.installed_list.count()):
                if self.installed_list.item(index).data(Qt.UserRole) == current:
                    self.installed_list.setCurrentRow(index)
                    break
        if self.installed_list.currentRow() < 0 and self.installed_list.count():
            self.installed_list.setCurrentRow(0)
        if not self.installed_list.count():
            self.installed_details.setText(self.i18n.t("No hay modpacks instalados."))

    def _show_installed_details(self, current, _previous):
        profile = self.pm.get(current.data(Qt.UserRole)) if current else None
        if not profile:
            self.installed_details.setText(self.i18n.t("No hay modpacks instalados."))
            return
        lines = [self.i18n.t(
            "Minecraft {version} · {loader}", version=profile.version, loader=profile.loader
        )]
        if profile.modpack_version_number:
            lines.append(self.i18n.t(
                "Versión del pack: {version}", version=profile.modpack_version_number
            ))
        if profile.modpack_summary:
            lines.append(profile.modpack_summary)
        self.installed_details.setText("\n".join(lines))

    def on_search(self):
        if self._has_foreground_operation():
            return
        query = self.search_edit.text().strip()
        if not query:
            return
        self._search_hits = []
        self.results_list.clear()
        self.version_combo.clear()
        self._set_search_busy(True)
        self.status_label.setText(self.i18n.t("Buscando modpacks..."))
        self._search_worker = self._track_worker(ModpackSearchWorker(query))
        self._search_worker.results.connect(self._on_search_results)
        self._search_worker.failed.connect(self._on_search_failed)
        self._search_worker.start()

    @Slot(list)
    def _on_search_results(self, hits):
        self._search_worker = None
        self._search_hits = hits
        self._render_search_hits()
        if not hits:
            self.status_label.setText(self.i18n.t("No se encontraron modpacks."))
        else:
            self.status_label.setText(self.i18n.t("{count} resultados.", count=len(hits)))
        self._set_search_busy(False)

    @Slot(str)
    def _on_search_failed(self, error):
        self._search_worker = None
        self._set_search_busy(False)
        self.install_button.setEnabled(False)
        self.status_label.setText(self.i18n.t(
            "❌ Error buscando: {error}", error=self.i18n.t(str(error))
        ))

    def _render_search_hits(self):
        if not hasattr(self, "results_list"):
            return
        selected_id = None
        if self.results_list.currentItem():
            data = self.results_list.currentItem().data(Qt.UserRole) or {}
            selected_id = data.get("project_id")
        self.results_list.blockSignals(True)
        self.results_list.clear()
        for hit in self._search_hits:
            text = self.i18n.t(
                "{title}  —  {author}  ({downloads} descargas)",
                title=hit.get("title", "?"), author=hit.get("author", ""),
                downloads=self.i18n.number(hit.get("downloads", 0)),
            )
            item = QListWidgetItem(text)
            item.setData(Qt.UserRole, hit)
            self.results_list.addItem(item)
            if hit.get("project_id") == selected_id:
                self.results_list.setCurrentItem(item)
        self.results_list.blockSignals(False)

    def on_project_selected(self, current, _previous):
        self.version_combo.clear()
        if not current:
            self.version_combo.addItem(self.i18n.t("Selecciona primero un modpack"))
            return
        if self._has_foreground_operation():
            return
        project = current.data(Qt.UserRole)
        project_id = project.get("project_id") or project.get("slug")
        self._set_versions_busy(True)
        self.version_combo.addItem(self.i18n.t("Cargando versiones del modpack..."))
        self._versions_worker = self._track_worker(ModpackVersionsWorker(project_id))
        self._versions_worker.results.connect(self._on_versions_loaded)
        self._versions_worker.failed.connect(self._on_versions_failed)
        self._versions_worker.start()

    @Slot(list)
    def _on_versions_loaded(self, versions):
        self._versions_worker = None
        self.version_combo.clear()
        for version in versions:
            self.version_combo.addItem(self._version_text(version), version)
        if not versions:
            self.version_combo.addItem(self.i18n.t("No hay versiones instalables para este modpack."))
        self._set_versions_busy(False)

    def _version_text(self, version: dict) -> str:
        number = version.get("version_number", "?")
        name = version.get("name", "")
        channel = version.get("version_type", "")
        channel_label = {
            "release": self.i18n.t("Estable"),
            "beta": self.i18n.t("Beta"),
            "alpha": self.i18n.t("Alfa"),
        }.get(channel, channel)
        return f"{number} — {name} ({channel_label})"

    def _retranslate_versions(self):
        versions = [
            self.version_combo.itemData(index)
            for index in range(self.version_combo.count())
            if isinstance(self.version_combo.itemData(index), dict)
        ]
        if not versions:
            return
        current = self.version_combo.currentData()
        self.version_combo.blockSignals(True)
        self.version_combo.clear()
        for version in versions:
            self.version_combo.addItem(self._version_text(version), version)
        if isinstance(current, dict):
            for index in range(self.version_combo.count()):
                if self.version_combo.itemData(index).get("id") == current.get("id"):
                    self.version_combo.setCurrentIndex(index)
                    break
        self.version_combo.blockSignals(False)

    @Slot(str)
    def _on_versions_failed(self, error):
        self._versions_worker = None
        self.version_combo.clear()
        self.version_combo.addItem(self.i18n.t("Error: {error}", error=error))
        self.status_label.setText(self.i18n.t(
            "❌ Error buscando: {error}", error=self.i18n.t(str(error))
        ))
        self._set_versions_busy(False)

    def on_install(self):
        project_item = self.results_list.currentItem()
        version = self.version_combo.currentData()
        if not project_item or not isinstance(version, dict):
            self.status_label.setText(self.i18n.t("Selecciona un modpack y una versión."))
            return
        self._start_install(
            version=version,
            project=project_item.data(Qt.UserRole),
            local_path="",
        )

    def on_import(self):
        if self._has_foreground_operation():
            return
        path, _ = QFileDialog.getOpenFileName(
            self, self.i18n.t("Selecciona un modpack .mrpack"), "",
            self.i18n.t("Modpacks de Modrinth (*.mrpack)"),
        )
        if path:
            self._start_install(version=None, project=None, local_path=path)

    def on_export(self):
        if self._has_foreground_operation():
            return
        source = QFileDialog.getExistingDirectory(
            self, self.i18n.t("Selecciona la carpeta que convertirás en modpack")
        )
        if not source:
            return
        name, ok = QInputDialog.getText(self, "Crear .mrpack", "Nombre del modpack:")
        if not ok or not name.strip():
            return
        minecraft_version, ok = QInputDialog.getText(
            self, "Crear .mrpack", "Versión de Minecraft:", text="1.21.1"
        )
        if not ok or not minecraft_version.strip():
            return
        loader, ok = QInputDialog.getItem(
            self, "Crear .mrpack", "Loader:",
            ["vanilla", "fabric", "quilt", "forge", "neoforge"], 0, False,
        )
        if not ok:
            return
        loader_version = ""
        if loader != "vanilla":
            loader_version, ok = QInputDialog.getText(
                self, "Crear .mrpack", f"Versión de {loader}:"
            )
            if not ok or not loader_version.strip():
                return
        output, _filter = QFileDialog.getSaveFileName(
            self, "Guardar modpack", str(Path(source).with_suffix(".mrpack")),
            "Modpacks de Modrinth (*.mrpack)",
        )
        if not output:
            return
        self._set_install_busy(True)
        self.status_label.setText("Creando modpack...")
        self._export_worker = self._track_worker(ModpackExportWorker(
            source, output, {
                "name": name.strip(),
                "minecraft_version": minecraft_version.strip(),
                "loader": loader,
                "loader_version": loader_version.strip(),
            },
        ))
        self._export_worker.status.connect(self.status_label.setText)
        self._export_worker.exported.connect(self._on_exported)
        self._export_worker.failed.connect(self._on_export_failed)
        self._export_worker.start()

    @Slot(str)
    def _on_exported(self, path):
        self._export_worker = None
        self._set_install_busy(False)
        self.status_label.setText(f"✅ Modpack creado: {path}")
        self.operation_succeeded.emit()
        self.modpack_completed.emit()

    @Slot(str)
    def _on_export_failed(self, error):
        self._export_worker = None
        self._set_install_busy(False)
        self.status_label.setText(f"❌ No se pudo crear el modpack: {error}")

    def _start_install(self, *, version, project, local_path):
        if self._has_foreground_operation():
            return
        self._set_install_busy(True)
        self.progress_bar.setValue(0)
        self.status_label.setText(self.i18n.t(
            "Importando modpack..." if local_path else
            "Instalando modpack. Esto puede tardar varios minutos..."
        ))
        settings = self.settings_manager.settings
        self._install_worker = self._track_worker(ModpackInstallWorker(
            nickname=self.nickname_edit.text().strip(),
            version=version,
            local_path=local_path,
            project=project,
            include_optional=self.optional_check.isChecked(),
            java_path=settings.java_path,
            profile_defaults={
                "min_ram": settings.default_min_ram,
                "max_ram": settings.default_max_ram,
                "resolution_w": settings.default_resolution_w,
                "resolution_h": settings.default_resolution_h,
            },
        ))
        self._install_worker.status.connect(self._on_install_status)
        self._install_worker.progress.connect(self.progress_bar.setValue)
        self._install_worker.maximum.connect(self.progress_bar.setMaximum)
        self._install_worker.installed.connect(self._on_installed)
        self._install_worker.failed.connect(self._on_install_failed)
        self._install_worker.start()

    @Slot(str)
    def _on_install_status(self, value):
        self.status_label.setText(self.i18n.t(value))

    @Slot(object)
    def _on_installed(self, data):
        self._install_worker = None
        self._set_install_busy(False)
        try:
            profile = self.pm.register_profile(Profile(**data))
        except Exception as error:
            self.status_label.setText(self.i18n.t(
                "❌ No se pudo instalar el modpack: {error}",
                error=self.i18n.t(str(error))
            ))
            return
        self.status_label.setText(self.i18n.t(
            "✅ '{name}' instalado como perfil. Ya aparece en Jugar.", name=profile.name
        ))
        self.refresh_installed()
        if self.on_change:
            self.on_change()
        self.operation_succeeded.emit()
        self.modpack_completed.emit()

    @Slot(str)
    def _on_install_failed(self, error):
        self._install_worker = None
        self._set_install_busy(False)
        self.status_label.setText(self.i18n.t(
            "❌ No se pudo instalar el modpack: {error}",
            error=self.i18n.t(str(error))
        ))

    def on_remove(self):
        item = self.installed_list.currentItem()
        if not item:
            return
        answer = QMessageBox.question(
            self, self.i18n.t("Quitar modpack"),
            self.i18n.t(
                "¿Quitar este modpack de la lista de perfiles? Sus archivos no se borrarán."
            ),
        )
        if answer == QMessageBox.Yes:
            try:
                self.pm.delete_profile(item.data(Qt.UserRole))
            except (OSError, ValueError) as error:
                QMessageBox.warning(
                    self, self.i18n.t("Error"), self.i18n.t(str(error))
                )
                return
            self.refresh_installed()
            if self.on_change:
                self.on_change()
            self.operation_succeeded.emit()

    def _set_search_busy(self, busy: bool):
        self._set_foreground_busy(busy)

    def _set_versions_busy(self, busy: bool):
        self._set_foreground_busy(busy)

    def _set_install_busy(self, busy: bool):
        self._set_foreground_busy(busy)

    def _set_foreground_busy(self, busy: bool):
        for widget in (
            self.import_button, self.export_button, self.results_list, self.version_combo,
            self.search_button, self.search_edit, self.nickname_edit,
            self.optional_check,
        ):
            widget.setEnabled(not busy)
        self.install_button.setEnabled(
            not busy and isinstance(self.version_combo.currentData(), dict)
        )

    def _has_foreground_operation(self) -> bool:
        return any(worker is not None for worker in (
            self._search_worker, self._versions_worker, self._install_worker,
            self._export_worker,
        ))
