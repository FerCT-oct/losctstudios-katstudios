"""Galería local de capturas de las instancias de Minecraft."""
from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import QSize, Qt, QUrl, Signal
from PySide6.QtGui import QDesktopServices, QImageReader, QPixmap
from PySide6.QtWidgets import (
    QApplication, QComboBox, QFileDialog, QHBoxLayout, QLabel, QListWidget,
    QListWidgetItem, QMessageBox, QPushButton, QSplitter, QVBoxLayout, QWidget,
)


IMAGE_SUFFIXES = {".png", ".jpg", ".jpeg", ".webp"}
MAX_SCREENSHOT_BYTES = 64 * 1024 * 1024


class ScreenshotsTab(QWidget):
    operation_succeeded = Signal()

    def __init__(self, profile_manager, i18n, parent=None):
        super().__init__(parent)
        self.pm = profile_manager
        self.i18n = i18n
        self._current_pixmap = QPixmap()
        self._current_path: Path | None = None

        root = QVBoxLayout(self)
        header = QHBoxLayout()
        self.profile_label = QLabel()
        self.profile_combo = QComboBox()
        self.profile_combo.currentIndexChanged.connect(self.refresh)
        self.refresh_button = QPushButton()
        self.refresh_button.clicked.connect(self.refresh)
        self.folder_button = QPushButton()
        self.folder_button.clicked.connect(self.open_folder)
        header.addWidget(self.profile_label)
        header.addWidget(self.profile_combo, 1)
        header.addWidget(self.refresh_button)
        header.addWidget(self.folder_button)
        root.addLayout(header)

        splitter = QSplitter()
        self.list = QListWidget()
        self.list.setIconSize(QSize(128, 72))
        self.list.currentItemChanged.connect(self.show_selected)
        self.list.itemDoubleClicked.connect(lambda _item: self.open_selected())
        splitter.addWidget(self.list)

        preview_host = QWidget()
        preview_layout = QVBoxLayout(preview_host)
        self.preview = QLabel()
        self.preview.setAlignment(Qt.AlignCenter)
        self.preview.setMinimumSize(420, 300)
        self.preview.setStyleSheet(
            "background:#0b0d14;border:1px solid #30344a;border-radius:10px;"
        )
        self.preview.setTextInteractionFlags(Qt.NoTextInteraction)
        preview_layout.addWidget(self.preview, 1)
        self.details = QLabel()
        self.details.setWordWrap(True)
        preview_layout.addWidget(self.details)
        actions = QHBoxLayout()
        self.open_button = QPushButton()
        self.open_button.clicked.connect(self.open_selected)
        self.copy_button = QPushButton()
        self.copy_button.clicked.connect(self.copy_selected)
        self.export_button = QPushButton()
        self.export_button.clicked.connect(self.export_selected)
        actions.addWidget(self.open_button)
        actions.addWidget(self.copy_button)
        actions.addWidget(self.export_button)
        preview_layout.addLayout(actions)
        splitter.addWidget(preview_host)
        splitter.setStretchFactor(0, 1)
        splitter.setStretchFactor(1, 3)
        root.addWidget(splitter, 1)

        self.i18n.language_changed.connect(self.retranslate_ui)
        self.retranslate_ui()
        self.refresh_profiles()

    def retranslate_ui(self, *_args):
        t = self.i18n.t
        self.profile_label.setText(t("Perfil:"))
        self.refresh_button.setText(t("Actualizar capturas"))
        self.folder_button.setText(t("Abrir carpeta de capturas"))
        self.open_button.setText(t("Abrir captura"))
        self.copy_button.setText(t("Copiar imagen"))
        self.export_button.setText(t("Guardar una copia"))
        if self._current_path is None:
            self.preview.setText(t("No hay ninguna captura seleccionada."))

    def refresh_profiles(self):
        selected = self.profile_combo.currentData()
        self.profile_combo.blockSignals(True)
        self.profile_combo.clear()
        for profile in self.pm.list_profiles():
            self.profile_combo.addItem(profile.name, profile.id)
        self.profile_combo.blockSignals(False)
        if selected:
            index = self.profile_combo.findData(selected)
            if index >= 0:
                self.profile_combo.setCurrentIndex(index)
        self.refresh()

    def _profile(self):
        profile_id = self.profile_combo.currentData()
        return self.pm.get(profile_id) if profile_id else None

    def _folder(self, *, create=False) -> Path | None:
        profile = self._profile()
        if profile is None:
            return None
        folder = Path(profile.game_dir) / "screenshots"
        if create:
            folder.mkdir(parents=True, exist_ok=True)
        return folder

    def refresh(self):
        self.list.clear()
        self._current_path = None
        self._current_pixmap = QPixmap()
        self.details.clear()
        self.preview.clear()
        self.preview.setText(self.i18n.t("No hay ninguna captura seleccionada."))
        folder = self._folder()
        if folder is None or not folder.is_dir():
            return
        try:
            paths = sorted(
                (
                    path for path in folder.iterdir()
                    if path.is_file() and path.suffix.lower() in IMAGE_SUFFIXES
                    and path.stat().st_size <= MAX_SCREENSHOT_BYTES
                ),
                key=lambda path: path.stat().st_mtime,
                reverse=True,
            )
        except OSError:
            return
        for path in paths:
            reader = QImageReader(str(path))
            reader.setAutoTransform(True)
            reader.setScaledSize(QSize(160, 90))
            thumbnail = reader.read()
            item = QListWidgetItem(path.name)
            if not thumbnail.isNull():
                item.setIcon(QPixmap.fromImage(thumbnail))
            item.setData(Qt.UserRole, str(path))
            self.list.addItem(item)
        if self.list.count():
            self.list.setCurrentRow(0)

    def show_selected(self, current, _previous=None):
        if current is None:
            return
        path = Path(str(current.data(Qt.UserRole) or ""))
        folder = self._folder()
        try:
            safe = folder is not None and path.resolve().parent == folder.resolve()
            size = path.stat().st_size
        except OSError:
            safe = False
            size = 0
        if not safe or not path.is_file() or size > MAX_SCREENSHOT_BYTES:
            self.preview.setText(self.i18n.t("No se pudo cargar la captura."))
            return
        reader = QImageReader(str(path))
        reader.setAutoTransform(True)
        image = reader.read()
        if image.isNull():
            self.preview.setText(self.i18n.t("No se pudo cargar la captura."))
            return
        self._current_path = path
        self._current_pixmap = QPixmap.fromImage(image)
        self._render_preview()
        self.details.setText(self.i18n.t(
            "{name} · {width}×{height} · {size}",
            name=path.name, width=image.width(), height=image.height(),
            size=QLocaleSize.format(size),
        ))

    def _render_preview(self):
        if self._current_pixmap.isNull():
            return
        self.preview.setPixmap(self._current_pixmap.scaled(
            self.preview.size() - QSize(18, 18),
            Qt.KeepAspectRatio, Qt.SmoothTransformation,
        ))

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._render_preview()

    def open_selected(self):
        if self._current_path is not None:
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(self._current_path)))

    def open_folder(self):
        folder = self._folder(create=True)
        if folder is not None:
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(folder)))

    def copy_selected(self):
        if self._current_pixmap.isNull():
            return
        QApplication.clipboard().setPixmap(self._current_pixmap)
        self.operation_succeeded.emit()

    def export_selected(self):
        if self._current_path is None:
            return
        destination, _ = QFileDialog.getSaveFileName(
            self, self.i18n.t("Guardar una copia"),
            self._current_path.name,
            self.i18n.t("Imágenes (*.png *.jpg *.jpeg *.webp)"),
        )
        if not destination:
            return
        try:
            Path(destination).write_bytes(self._current_path.read_bytes())
        except OSError as error:
            QMessageBox.warning(self, self.i18n.t("Error"), str(error))
            return
        self.operation_succeeded.emit()


class QLocaleSize:
    @staticmethod
    def format(size: int) -> str:
        value = float(max(0, size))
        for unit in ("B", "KB", "MB", "GB"):
            if value < 1024 or unit == "GB":
                return f"{value:.0f} {unit}" if unit == "B" else f"{value:.1f} {unit}"
            value /= 1024
        return f"{size} B"
