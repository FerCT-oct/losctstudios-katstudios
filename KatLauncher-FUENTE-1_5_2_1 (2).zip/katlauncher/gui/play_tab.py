from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QComboBox, QPushButton,
    QProgressBar, QPlainTextEdit, QGroupBox, QToolButton, QSizePolicy,
    QMessageBox, QCheckBox, QSpinBox, QLineEdit,
)
from PySide6.QtGui import QPixmap
from PySide6.QtCore import Qt, Signal, Slot, QTimer
from dataclasses import replace
from pathlib import Path

from ..core.profile_manager import ProfileManager
from ..core import modrinth_api
from ..core.controller_support import has_gamepad
from .workers import InstallWorker, LaunchWorker
from .room_worker import RoomServerWorker
from .worker_registry import WorkerRegistryMixin

ASSETS_DIR = Path(__file__).resolve().parent.parent / "assets"
LOGO_PATH = ASSETS_DIR / "logo.png"


class _ClickableLogo(QLabel):
    clicked = Signal()

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton and self.rect().contains(event.position().toPoint()):
            self.clicked.emit()
        super().mouseReleaseEvent(event)


class PlayTab(WorkerRegistryMixin, QWidget):
    game_started = Signal(object)
    game_finished = Signal()
    operation_succeeded = Signal()
    logo_clicked = Signal()
    launch_prepared = Signal(object, str)
    room_advertised = Signal(str, int)
    room_local_ready = Signal(int)
    room_ended = Signal()
    room_failed = Signal(str)
    room_configured = Signal(object, object)
    room_log_line = Signal(str)

    def __init__(self, profile_manager: ProfileManager, settings_manager, i18n, parent=None):
        super().__init__(parent)
        self._init_worker_registry()
        self.pm = profile_manager
        self.settings_manager = settings_manager
        self.i18n = i18n
        self.install_worker = None
        self.launch_worker = None
        self.room_worker = None
        self._room_address = None
        self._room_cancelled = False
        self._room_started_from_game = False
        self._active_room_metadata = {}
        self._pending_room_restart = None
        self._pending_profile_id = None
        self._pending_install_signature = None
        self._game_active = False
        self._active_profile = None
        self._server_override = None

        layout = QVBoxLayout(self)

        header_row = QHBoxLayout()
        self.logo_label = _ClickableLogo()
        if LOGO_PATH.exists():
            self.logo_label.setPixmap(
                QPixmap(str(LOGO_PATH)).scaled(56, 56, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            )
        self.logo_label.setCursor(Qt.PointingHandCursor)
        self.logo_label.clicked.connect(self.logo_clicked.emit)
        header_row.addWidget(self.logo_label)

        title_col = QVBoxLayout()
        header = QLabel("KatLauncher")
        header.setObjectName("bigTitle")
        title_col.addWidget(header)

        self.subtitle = QLabel()
        self.subtitle.setObjectName("subtitle")
        title_col.addWidget(self.subtitle)

        header_row.addLayout(title_col)
        header_row.addStretch()
        layout.addLayout(header_row)

        self.selector_box = QGroupBox()
        selector_layout = QHBoxLayout(self.selector_box)
        self.profile_combo = QComboBox()
        selector_layout.addWidget(self.profile_combo)
        layout.addWidget(self.selector_box)

        self.status_label = QLabel()
        layout.addWidget(self.status_label)

        self.progress_bar = QProgressBar()
        self.progress_bar.setValue(0)
        layout.addWidget(self.progress_bar)

        btn_row = QHBoxLayout()
        self.play_button = QPushButton()
        self.play_button.setObjectName("playButton")
        self.play_button.clicked.connect(self.play_selected)
        btn_row.addWidget(self.play_button)
        layout.addLayout(btn_row)

        self.room_box = QGroupBox()
        room_layout = QVBoxLayout(self.room_box)
        identity_row = QHBoxLayout()
        self.room_name = QLineEdit()
        self.room_name.setMaxLength(48)
        self.room_name.setText("Sala de KatLauncher")
        self.room_description = QLineEdit()
        self.room_description.setMaxLength(240)
        self.room_public = QCheckBox()
        self.room_public.setChecked(True)
        identity_row.addWidget(self.room_name, stretch=2)
        identity_row.addWidget(self.room_description, stretch=3)
        identity_row.addWidget(self.room_public)
        room_layout.addLayout(identity_row)
        options_row = QHBoxLayout()
        self.room_ram_label = QLabel()
        self.room_ram = QSpinBox()
        self.room_ram.setRange(1024, 16384)
        self.room_ram.setSingleStep(512)
        self.room_ram.setValue(2048)
        self.room_ram.setSuffix(" MB")
        self.room_port_label = QLabel()
        self.room_port = QSpinBox()
        self.room_port.setRange(1024, 65535)
        self.room_port.setValue(25565)
        self.room_global = QCheckBox()
        self.room_global.setChecked(True)
        self.room_button = QPushButton()
        self.room_button.clicked.connect(self.toggle_room)
        options_row.addWidget(self.room_ram_label)
        options_row.addWidget(self.room_ram)
        options_row.addWidget(self.room_port_label)
        options_row.addWidget(self.room_port)
        options_row.addWidget(self.room_global)
        options_row.addWidget(self.room_button)
        room_layout.addLayout(options_row)
        layout.addWidget(self.room_box)
        self.room_status = QLabel()
        self.room_status.setWordWrap(True)
        layout.addWidget(self.room_status)
        console_row = QHBoxLayout()
        self.room_console = QLineEdit()
        self.room_console.setPlaceholderText(
            "Consola del creador: escribe un comando y pulsa Enter"
        )
        self.room_console.setEnabled(False)
        self.room_console.returnPressed.connect(self._send_console_command)
        self.room_console_button = QPushButton("Enviar")
        self.room_console_button.setEnabled(False)
        self.room_console_button.clicked.connect(self._send_console_command)
        console_row.addWidget(self.room_console, stretch=1)
        console_row.addWidget(self.room_console_button)
        layout.addLayout(console_row)
        # La creación de salas vive en KatCraft. Conservamos estos controles
        # únicamente como backend interno para el puente local.
        self.room_box.hide()
        self.room_status.hide()
        self.room_console.hide()
        self.room_console_button.hide()

        self.log_toggle = QToolButton()
        self.log_toggle.setCheckable(True)
        self.log_toggle.setChecked(True)
        self.log_toggle.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
        self.log_toggle.setArrowType(Qt.DownArrow)
        self.log_toggle.toggled.connect(self._set_logs_expanded)
        layout.addWidget(self.log_toggle)
        self.log_view = QPlainTextEdit()
        self.log_view.setReadOnly(True)
        self.log_view.setMaximumBlockCount(self.settings_manager.settings.log_max_lines)
        layout.addWidget(self.log_view, stretch=1)
        self._collapsed_filler = QWidget()
        self._collapsed_filler.setSizePolicy(
            QSizePolicy.Preferred, QSizePolicy.Expanding
        )
        self._collapsed_filler.setVisible(False)
        layout.addWidget(self._collapsed_filler, stretch=1)

        self.i18n.language_changed.connect(self.retranslate_ui)
        self.retranslate_ui()
        self.refresh_profiles()

    def retranslate_ui(self, *_args):
        self.subtitle.setText(self.i18n.t(
            "Launcher no oficial para Minecraft: Java Edition — modo offline"
        ))
        self.selector_box.setTitle(self.i18n.t("Perfil"))
        self.play_button.setText(self.i18n.t("▶  Jugar"))
        self.room_box.setTitle(self.i18n.t("Sala Kat Global"))
        self.room_ram_label.setText(self.i18n.t("RAM del servidor:"))
        self.room_port_label.setText(self.i18n.t("Puerto:"))
        self.room_global.setText(self.i18n.t("Jugar por Internet"))
        self.room_public.setText(self.i18n.t("Publicar en Salas"))
        self.room_name.setPlaceholderText(self.i18n.t("Nombre de la sala"))
        self.room_description.setPlaceholderText(self.i18n.t("Descripción opcional"))
        self.room_button.setText(self.i18n.t(
            "■ Detener sala" if self.room_worker else "Crear sala y jugar"
        ))
        if not self.room_worker:
            self.room_status.setText(self.i18n.t(
                "Crea una sala temporal en tu PC. Kat Global permite invitar amigos por Internet."
            ))
        self.log_toggle.setText(self.i18n.t("Registro del juego"))
        if not self.install_worker and not self.launch_worker:
            self.status_label.setText(self.i18n.t("Listo."))
        self.refresh_profiles()

    def refresh_settings(self):
        self.log_view.setMaximumBlockCount(self.settings_manager.settings.log_max_lines)

    @Slot(bool)
    def _set_logs_expanded(self, expanded: bool):
        self.log_view.setVisible(expanded)
        self._collapsed_filler.setVisible(not expanded)
        self.log_toggle.setArrowType(Qt.DownArrow if expanded else Qt.RightArrow)

    def refresh_profiles(self):
        current = self.profile_combo.currentData()
        self.profile_combo.clear()
        for p in self.pm.list_profiles():
            version = p.version or self.i18n.t("sin versión")
            label = f"{p.name}  ({version} · {p.loader})"
            self.profile_combo.addItem(label, p.id)
        if current:
            idx = self.profile_combo.findData(current)
            if idx >= 0:
                self.profile_combo.setCurrentIndex(idx)

    def _selected_profile(self):
        pid = self.profile_combo.currentData()
        return self.pm.get(pid) if pid else None

    def play_selected(self):
        self._server_override = None
        self.on_play()

    def play_server(self, profile_id: str, host: str, port: int):
        """Lanza un favorito sin convertirlo en un ajuste permanente del perfil."""
        if self.install_worker or self.launch_worker:
            return
        index = self.profile_combo.findData(profile_id)
        if index < 0:
            self.status_label.setText(self.i18n.t("El perfil seleccionado ya no existe."))
            return
        self.profile_combo.setCurrentIndex(index)
        self._server_override = (str(host), int(port))
        self.on_play()

    def toggle_room(self):
        if self.room_worker:
            self.stop_room()
            return
        if self.install_worker or self.launch_worker or self._game_active:
            return
        profile = self._selected_profile()
        if not profile or not profile.version:
            self.status_label.setText(self.i18n.t(
                "⚠ Crea o selecciona un perfil con versión primero."
            ))
            return
        answer = QMessageBox.question(
            self,
            self.i18n.t("Crear sala Kat Global"),
            self.i18n.t(
                "KatLauncher descargará el servidor oficial de Mojang, reservará "
                "{ram} MB de RAM y aceptará la EULA de Minecraft para esta sala.\n\n"
                "La sala usa modo offline. Si activas Kat Global recibirá un dominio "
                "temporal compatible con e4mc; compártelo solo con personas de "
                "confianza. ¿Aceptas la EULA y quieres continuar?",
                ram=self.room_ram.value(),
            ),
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if answer != QMessageBox.Yes:
            return
        self._start_room(
            profile, self.room_ram.value(), self.room_port.value(),
            self.room_global.isChecked(), from_game=False,
        )

    @Slot(object)
    def start_room_from_katcraft(self, options):
        """Inicia una sala solicitada desde la pantalla del mod KatCraft."""
        if self.room_worker:
            return
        options = dict(options) if isinstance(options, dict) else {}
        ram_mb = int(options.get("ram_mb") or 2048)
        port = int(options.get("port") or 25565)
        use_global = bool(options.get("global", True))
        profile = self._selected_profile()
        if not profile or not profile.version:
            self.room_failed.emit("No hay un perfil jugable seleccionado.")
            return
        self.room_ram.setValue(max(1024, min(int(ram_mb), 16384)))
        self.room_port.setValue(max(1024, min(int(port), 65535)))
        self.room_global.setChecked(bool(use_global))
        self._start_room(
            profile, self.room_ram.value(), self.room_port.value(),
            self.room_global.isChecked(), from_game=True,
            room_options=options,
        )

    def _start_room(
        self, profile, ram_mb, port, use_global, *, from_game,
        room_options=None,
    ):
        self.log_view.clear()
        self._room_cancelled = False
        self._room_started_from_game = bool(from_game)
        self.play_button.setEnabled(False)
        self.profile_combo.setEnabled(False)
        self.room_ram.setEnabled(False)
        self.room_port.setEnabled(False)
        self.room_global.setEnabled(False)
        self.room_name.setEnabled(False)
        self.room_description.setEnabled(False)
        self.room_public.setEnabled(False)
        self.room_button.setText(self.i18n.t("■ Detener sala"))
        self.room_status.setText(self.i18n.t("Preparando sala…"))
        metadata = dict(room_options or {})
        metadata.update({
            "name": str(metadata.get("name") or self.room_name.text().strip()
                        or "Sala de KatCraft")[:48],
            "description": str(metadata.get("description")
                               or self.room_description.text().strip())[:240],
            "visibility": str(metadata.get("visibility") or (
                "public" if self.room_public.isChecked() else "private"
            )),
            "players_max": max(
                1, min(int(metadata.get("players_max") or 8), 1000)
            ),
        })
        self._active_room_metadata = dict(metadata)
        self.room_configured.emit(profile, metadata)
        self.room_worker = self._track_worker(RoomServerWorker(
            replace(profile),
            int(ram_mb),
            int(port),
            self.settings_manager.settings.java_path,
            bool(use_global),
            room_options=metadata,
        ))
        self.room_worker.status.connect(self._on_room_status)
        self.room_worker.log_line.connect(self.log_view.appendPlainText)
        self.room_worker.log_line.connect(self.room_log_line.emit)
        self.room_worker.ready.connect(self._on_room_ready)
        self.room_worker.stopped.connect(self._on_room_stopped)
        self.room_worker.failed.connect(self._on_room_failed)
        self.room_worker.start()

    def stop_room(self):
        worker = self.room_worker
        if worker is None:
            return
        self.room_button.setEnabled(False)
        self._room_cancelled = True
        self.room_status.setText(self.i18n.t("Deteniendo sala…"))
        worker.request_stop()

    @Slot(object)
    def restart_room_from_katcraft(self, options):
        self._pending_room_restart = dict(options) if isinstance(options, dict) else {}
        worker = self.room_worker
        if worker is None:
            pending = self._pending_room_restart
            self._pending_room_restart = None
            self.start_room_from_katcraft(pending)
            return
        worker.request_stop()

    @Slot(str)
    def send_room_command(self, command: str):
        worker = self.room_worker
        if worker is None:
            self.log_view.appendPlainText("[Sala] No hay una sala en ejecución.")
            return
        try:
            worker.send_command(command)
        except Exception as error:
            self.log_view.appendPlainText("[Sala] " + str(error))

    def _send_console_command(self):
        command = self.room_console.text().strip()
        if not command:
            return
        self.send_room_command(command)
        self.log_view.appendPlainText("> " + command)
        self.room_console.clear()

    @Slot(str)
    def _on_room_status(self, value):
        self.room_status.setText(self.i18n.t(value))

    @Slot(str, int)
    def _on_room_ready(self, host: str, port: int):
        self._room_address = (str(host), int(port))
        local_port = int(self.room_port.value())
        if self.room_worker is not None:
            local_port = int(self.room_worker.server.port)
            self.room_port.setValue(local_port)
            folder = str(self.room_worker.server.world_folder or "")
            if folder:
                self._active_room_metadata.update({
                    "world_id": "room:" + folder,
                    "world_name": str(
                        self._active_room_metadata.get("world_name") or folder
                    ),
                    "create_world": False,
                })
                profile = self._selected_profile()
                if profile is not None:
                    self.room_configured.emit(
                        profile, dict(self._active_room_metadata)
                    )
        self.room_status.setText(self.i18n.t(
            "Sala lista en {host}:{port}. Abriendo Minecraft…",
            host=host, port=port,
        ))
        self.room_advertised.emit(str(host), int(port))
        self.room_console.setEnabled(True)
        self.room_console_button.setEnabled(True)
        self.room_local_ready.emit(local_port)
        if not self._room_started_from_game:
            self._server_override = ("127.0.0.1", local_port)
            self.on_play()

    @Slot(int)
    def _on_room_stopped(self, code: int):
        self.log_view.appendPlainText(
            self.i18n.t("[Sala] Servidor detenido (código {code}).", code=code)
        )
        pending = self._pending_room_restart
        self._pending_room_restart = None
        self._reset_room_ui()
        if pending is not None:
            QTimer.singleShot(250, lambda: self.start_room_from_katcraft(pending))

    @Slot(str)
    def _on_room_failed(self, message: str):
        self.room_failed.emit(str(message))
        self.status_label.setText(self.i18n.t(
            "❌ No se pudo crear la sala: {message}", message=str(message)
        ))
        self._reset_room_ui()

    def _reset_room_ui(self):
        self.room_worker = None
        self._room_address = None
        self._room_started_from_game = False
        self._active_room_metadata = {}
        self.room_ended.emit()
        self.room_button.setEnabled(True)
        self.room_button.setText(self.i18n.t("Crear sala y jugar"))
        self.room_ram.setEnabled(True)
        self.room_port.setEnabled(True)
        self.room_global.setEnabled(True)
        self.room_name.setEnabled(True)
        self.room_description.setEnabled(True)
        self.room_public.setEnabled(True)
        self.room_console.setEnabled(False)
        self.room_console_button.setEnabled(False)
        self.profile_combo.setEnabled(not self._game_active)
        if not self._game_active and not self.install_worker and not self.launch_worker:
            self.play_button.setEnabled(True)
        self.room_status.setText(self.i18n.t(
            "Crea una sala temporal en tu PC. Kat Global permite invitar amigos por Internet."
        ))

    def on_play(self):
        profile = self._selected_profile()
        if not profile:
            self.status_label.setText(self.i18n.t("⚠ Crea o selecciona un perfil primero."))
            return
        if not profile.version:
            self.status_label.setText(self.i18n.t(
                "⚠ Este perfil no tiene una versión de Minecraft asignada."
            ))
            return

        if profile.loader == "vanilla" \
                and self.settings_manager.settings.warn_vanilla_katcraft:
            warning = QMessageBox(self)
            warning.setIcon(QMessageBox.Warning)
            warning.setWindowTitle(self.i18n.t("KatCraft no está disponible"))
            warning.setText(self.i18n.t(
                "Esta instancia usa Vanilla. Minecraft abrirá normalmente, pero "
                "las insignias, amigos, invitaciones y etiquetas de KatCraft "
                "necesitan Fabric, Quilt, Forge o NeoForge."
            ))
            never_again = QCheckBox(self.i18n.t(
                "No volver a mostrar esta advertencia"
            ))
            warning.setCheckBox(never_again)
            warning.setStandardButtons(QMessageBox.Ok)
            warning.exec()
            if never_again.isChecked():
                self.settings_manager.update(warn_vanilla_katcraft=False)

        install_controlify = False
        if self.settings_manager.settings.auto_install_controlify and has_gamepad():
            if profile.loader in ("fabric", "quilt", "neoforge", "forge"):
                if not modrinth_api.controlify_installed(profile):
                    answer = QMessageBox.question(
                        self,
                        self.i18n.t("Mando detectado"),
                        self.i18n.t(
                            "KatLauncher detectó un mando. ¿Descargar e instalar "
                            "Controlify en este perfil para controlar Minecraft?"
                        ),
                        QMessageBox.Yes | QMessageBox.No,
                        QMessageBox.Yes,
                    )
                    install_controlify = answer == QMessageBox.Yes
            else:
                QMessageBox.information(
                    self,
                    self.i18n.t("Mando detectado"),
                    self.i18n.t(
                        "Este perfil es Vanilla. Para usar el mando dentro de Minecraft, "
                        "crea un perfil Fabric, Quilt, NeoForge o Forge e instala Controlify."
                    ),
                )

        self.play_button.setEnabled(False)
        self.log_view.clear()
        self.status_label.setText(self.i18n.t("Comprobando/instalando archivos..."))
        self.progress_bar.setValue(0)

        self.install_worker = self._track_worker(InstallWorker(
            replace(profile),
            java_path=self.settings_manager.settings.java_path,
            auto_controlify=install_controlify,
            auto_katcraft=self.settings_manager.settings.auto_install_katcraft,
            auto_csl=self.settings_manager.settings.auto_install_custom_skin_loader,
        ))
        self._pending_profile_id = profile.id
        self._pending_install_signature = (
            profile.version, profile.loader, profile.loader_version,
        )
        self.install_worker.status.connect(self._on_install_status)
        self.install_worker.progress.connect(self.progress_bar.setValue)
        self.install_worker.maximum.connect(self.progress_bar.setMaximum)
        self.install_worker.finished_ok.connect(self._on_install_finished)
        self.install_worker.failed.connect(self._on_error)
        self.install_worker.start()

    @Slot(str)
    def _on_install_status(self, value):
        self.status_label.setText(self.i18n.t(value))

    @Slot(str)
    def _on_install_finished(self, version_id):
        profile = self.pm.get(self._pending_profile_id) if self._pending_profile_id else None
        self.install_worker = None
        if self._room_cancelled:
            self._pending_profile_id = None
            self._pending_install_signature = None
            self.play_button.setEnabled(True)
            self.status_label.setText(self.i18n.t("Inicio de sala cancelado."))
            return
        if profile is None:
            self._on_error("El perfil seleccionado ya no existe.")
            return
        current_signature = (profile.version, profile.loader, profile.loader_version)
        if current_signature != self._pending_install_signature:
            self._on_error("El perfil cambió durante la instalación. Vuelve a pulsar Jugar.")
            return
        self.status_label.setText(self.i18n.t("Preparando secuencia de inicio..."))
        self.launch_prepared.emit(profile, version_id)

    def start_prepared_game(self, profile, version_id):
        """Continúa cuando termina la presentación visual del launcher."""
        if self.launch_worker or self._game_active:
            return
        self._start_game(profile, version_id)

    def _start_game(self, profile, version_id):
        try:
            if version_id and profile.launch_version_id != version_id:
                self.pm.update_profile(profile.id, launch_version_id=version_id)
        except (OSError, ValueError) as error:
            self._on_error(str(error))
            return
        self.status_label.setText(self.i18n.t("Lanzando Minecraft..."))
        launch_profile = replace(profile)
        if self._server_override:
            launch_profile.server_host, launch_profile.server_port = self._server_override
        self._active_profile = replace(launch_profile)
        self.launch_worker = self._track_worker(LaunchWorker(
            replace(launch_profile), java_path=self.settings_manager.settings.java_path
        ))
        self._server_override = None
        self.launch_worker.log_line.connect(self.log_view.appendPlainText)
        self.launch_worker.game_started.connect(self._on_game_started)
        self.launch_worker.game_closed.connect(self._on_game_closed)
        self.launch_worker.failed.connect(self._on_error)
        self.launch_worker.start()

    @Slot(int)
    def _on_game_closed(self, code):
        self.status_label.setText(self.i18n.t("El juego se cerró (código {code}).", code=code))
        self.play_button.setEnabled(True)
        self.install_worker = None
        self.launch_worker = None
        self._pending_profile_id = None
        self._pending_install_signature = None
        self._game_active = False
        self._active_profile = None
        self._server_override = None
        self.game_finished.emit()
        if self.room_worker:
            self.stop_room()

    @Slot()
    def _on_game_started(self):
        self._game_active = True
        self._room_cancelled = False
        self.operation_succeeded.emit()
        self.game_started.emit(self._active_profile)

    @Slot(str)
    def _on_error(self, message):
        self.status_label.setText(self.i18n.t(
            "❌ Error: {message}", message=self.i18n.t(str(message))
        ))
        self.play_button.setEnabled(True)
        self.install_worker = None
        self.launch_worker = None
        self._pending_profile_id = None
        self._pending_install_signature = None
        self._active_profile = None
        self._server_override = None
        if self.room_worker:
            self.stop_room()
        if self._game_active:
            self._game_active = False
            self.game_finished.emit()
