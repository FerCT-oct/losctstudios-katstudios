from PySide6.QtCore import QSize, Qt, Signal
from PySide6.QtGui import QColor, QIcon, QPainter, QPixmap
from PySide6.QtWidgets import (
    QGroupBox, QLabel, QListWidget, QListWidgetItem, QProgressBar, QVBoxLayout,
    QWidget,
)

from ..core.trophy_manager import PLATINUM, TROPHIES, TrophyManager


class TrophiesTab(QWidget):
    operation_succeeded = Signal()

    def __init__(self, manager: TrophyManager, i18n=None, parent=None):
        super().__init__(parent)
        self.manager = manager
        self.i18n = i18n
        layout = QVBoxLayout(self)
        self.title = QLabel()
        self.title.setObjectName("bigTitle")
        layout.addWidget(self.title)
        self.summary = QLabel()
        layout.addWidget(self.summary)
        self.progress = QProgressBar()
        self.progress.setRange(0, len(TROPHIES))
        layout.addWidget(self.progress)
        self.list = QListWidget()
        self.list.setIconSize(QSize(48, 48))
        self.list.setSpacing(5)
        layout.addWidget(self.list, 1)
        if self.i18n is not None:
            self.i18n.language_changed.connect(self.retranslate_ui)
        self.retranslate_ui()

    def _t(self, text: str) -> str:
        return self.i18n.t(text) if self.i18n is not None else text

    def retranslate_ui(self, *_args):
        self.title.setText(self._t("Trofeos de KatLauncher"))
        self.refresh()

    def refresh(self):
        self.list.clear()
        self.progress.setValue(self.manager.complete_count)
        self.summary.setText(self._t(
            "{current}/{total} completados · {hours:.1f} horas registradas"
        ).format(
            current=self.manager.complete_count,
            total=len(TROPHIES),
            hours=self.manager.play_seconds / 3600,
        ))
        for trophy in (*TROPHIES, PLATINUM):
            unlocked = trophy.id in self.manager.unlocked
            if trophy.target_seconds:
                current = min(self.manager.play_seconds, trophy.target_seconds)
                detail = (
                    self._t("{current:.1f}/{target:.0f} horas").format(
                        current=current / 3600,
                        target=trophy.target_seconds / 3600,
                    )
                )
            else:
                detail = self._t(trophy.description)
            status = self._t("DESBLOQUEADO" if unlocked else "BLOQUEADO")
            item = QListWidgetItem(
                f"{self._t(trophy.title)}  ·  "
                f"{self._t(trophy.tier).upper()}  ·  {status}\n{detail}"
            )
            item.setIcon(_medal_icon(trophy.color, unlocked))
            item.setData(Qt.UserRole, trophy.id)
            if not unlocked:
                item.setForeground(QColor("#8c8799"))
            self.list.addItem(item)


def _medal_icon(color: str, unlocked: bool) -> QIcon:
    pixmap = QPixmap(48, 48)
    pixmap.fill(Qt.transparent)
    painter = QPainter(pixmap)
    painter.setRenderHint(QPainter.Antialiasing)
    fill = QColor(color if unlocked else "#45424d")
    painter.setBrush(fill)
    painter.setPen(QColor("#ffffff" if unlocked else "#77727f"))
    painter.drawEllipse(7, 4, 34, 34)
    painter.drawText(pixmap.rect(), Qt.AlignCenter, "★" if unlocked else "•")
    painter.end()
    return QIcon(pixmap)
