"""Temas visuales intercambiables para KatLauncher.

Este módulo no depende de ``MainWindow`` ni de ``SettingsManager``. Eso permite
integrarlo de forma gradual: la interfaz actual puede seguir usando Kat Classic
mientras Kat Modern se desarrolla en paralelo.
"""
from __future__ import annotations

import json
import os
import colorsys
from enum import Enum
from pathlib import Path

from PySide6.QtCore import QObject, Signal
from PySide6.QtWidgets import QApplication, QComboBox, QWidget

from ..core.profile_manager import APP_DIR


class ThemeName(str, Enum):
    """Identificadores estables que se guardan en disco."""

    XMB = "xmb"
    MODERN = "xmb"  # alias compatible con extensiones y pruebas 1.3/1.4
    NORMAL = "normal"
    EPIC = "epic"
    CLASSIC = "classic"


class AccentName(str, Enum):
    PURPLE = "purple"
    BLUE = "blue"
    GREEN = "green"
    ORANGE = "orange"
    PINK = "pink"
    CUSTOM = "custom"


THEME_LABELS = {
    ThemeName.XMB: "XMBKat",
    ThemeName.NORMAL: "Kat Normal",
    ThemeName.EPIC: "Kat Epic",
    ThemeName.CLASSIC: "Kat Classic",
}

ACCENT_LABELS = {
    AccentName.PURPLE: "Violeta cósmico",
    AccentName.BLUE: "Azul eléctrico",
    AccentName.GREEN: "Verde creeper",
    AccentName.ORANGE: "Naranja fuego",
    AccentName.PINK: "Rosa neón",
    AccentName.CUSTOM: "Personalizado",
}

_ACCENT_TOKENS = (
    "#7048ff", "#a855f7", "#7547e8", "#7747ed", "#9b5de5",
    "#b98bf0", "#7c4dff", "#7952d6", "#6d4aff", "#b358ff",
)
_ACCENT_COLORS = {
    AccentName.PURPLE: ("#7048ff", "#a855f7"),
    AccentName.BLUE: ("#2563eb", "#06b6d4"),
    AccentName.GREEN: ("#16a34a", "#84cc16"),
    AccentName.ORANGE: ("#ea580c", "#fbbf24"),
    AccentName.PINK: ("#db2777", "#f472b6"),
}


def _custom_pair(color: str) -> tuple[str, str]:
    value = str(color or "").strip().lower()
    if not re_full_hex(value):
        value = "#7048ff"
    red, green, blue = (int(value[index:index + 2], 16) / 255
                        for index in (1, 3, 5))
    hue, lightness, saturation = colorsys.rgb_to_hls(red, green, blue)
    secondary_rgb = colorsys.hls_to_rgb(
        (hue + 0.09) % 1.0, min(0.72, lightness + 0.16),
        min(1.0, saturation * 0.88 + 0.1),
    )
    secondary = "#" + "".join(f"{round(channel * 255):02x}"
                              for channel in secondary_rgb)
    return value, secondary


def re_full_hex(value: str) -> bool:
    return len(value) == 7 and value.startswith("#") and all(
        character in "0123456789abcdef" for character in value[1:].lower()
    )


# Réplica autónoma del estilo de la serie 1.2.x. MainWindow puede pasar su
# DARK_STYLE al constructor si en el futuro el clásico recibe ajustes menores.
CLASSIC_STYLE = """
QWidget { background-color: #16181d; color: #e8e8ec; font-size: 13px; }
QMainWindow { background-color: #16181d; }
QTabWidget::pane { border: 1px solid #2a2d35; }
QTabBar::tab {
    background: #1e2128; padding: 8px 18px; margin-right: 2px;
    border-top-left-radius: 6px; border-top-right-radius: 6px;
}
QTabBar::tab:selected { background: #9b5de5; color: white; }
QGroupBox {
    border: 1px solid #2a2d35; border-radius: 8px; margin-top: 10px; padding-top: 10px;
}
QGroupBox::title {
    subcontrol-origin: margin; left: 10px; padding: 0 4px; color: #b98bf0;
}
QPushButton {
    background-color: #2a2d35; border: none; border-radius: 6px; padding: 8px 14px;
}
QPushButton:hover { background-color: #383c47; }
QPushButton#playButton {
    background-color: #9b5de5; font-weight: bold; font-size: 15px; padding: 12px;
}
QPushButton#playButton:hover { background-color: #b073f0; }
QLineEdit, QComboBox, QSpinBox, QListWidget, QPlainTextEdit {
    background-color: #1e2128; border: 1px solid #2a2d35;
    border-radius: 5px; padding: 4px;
}
QLabel#bigTitle { font-size: 26px; font-weight: bold; color: #b98bf0; }
QLabel#subtitle { color: #9a9aa5; margin-bottom: 8px; }
QProgressBar { border: 1px solid #2a2d35; border-radius: 5px; text-align: center; }
QProgressBar::chunk { background-color: #9b5de5; }
QFrame#updateBanner {
    background-color: #242032; border: 1px solid #9b5de5;
    border-radius: 7px; margin: 6px; padding: 3px;
}
QFrame#roadmapBanner {
    background-color: #242032; border: 1px solid #9b5de5;
    border-radius: 7px; margin: 6px; padding: 3px;
}
QLabel#roadmapLabel { color: #f0e8ff; font-weight: 600; }
QPushButton#roadmapDismissButton {
    background: transparent; border: none; color: #cbb8f0; font-weight: 700;
}
QFrame#alertBanner {
    background-color: #242032; border: 1px solid #9b5de5;
    border-radius: 7px; margin: 6px; padding: 3px;
}
QFrame#alertBanner[severity="warning"] { border: 1px solid #d8a94f; }
QFrame#alertBanner[severity="critical"] { border: 1px solid #e05d5d; }
QLabel#alertBannerTitle { color: #ffffff; font-weight: 700; }
QLabel#alertBannerMessage { color: #e6e1f5; }
QPushButton#alertBannerDismissButton {
    background: transparent; border: none; color: #cbb8f0; font-weight: 700;
}
"""


# El estilo moderno usa colores planos y gradientes compatibles con Qt Style
# Sheets; no necesita QtQuick, OpenGL ni dependencias web.
MODERN_STYLE = """
QWidget {
    background-color: #090b14;
    color: #f4f1ff;
    font-family: "Segoe UI";
    font-size: 13px;
}
QMainWindow, QWidget#modernShell, QScrollArea#dashboardScroll,
QWidget#dashboardViewport {
    background-color: #090b14;
}
QToolTip {
    color: #ffffff;
    background-color: #1b1830;
    border: 1px solid #7c4dff;
    padding: 5px;
}
QFrame#modernSidebar {
    background-color: #101322;
    border-right: 1px solid #29233f;
}
QFrame#xmbBackdrop {
    background-color: #080b16;
    border-bottom: 1px solid #2e2750;
}
QFrame#xmbAppHost { background:#090b12; }
QFrame#xmbAppHeader {
    background:rgba(24,28,43,235);
    border:1px solid #7048ff;
    border-radius:12px;
}
QLabel#xmbAppTitle {
    color:#ffffff; font-size:18px; font-weight:700; padding-left:8px;
}
QPushButton#xmbBackButton {
    background:#7048ff; color:white; border:0;
    border-radius:8px; padding:8px 14px; font-weight:700;
}
QStackedWidget#xmbPageStack {
    background:rgba(12,14,23,245);
    border:1px solid #a855f7;
    border-radius:14px;
}
QScrollArea#xmbNavScroll, QWidget#xmbNavHost, QStackedWidget#xmbStack {
    background: transparent;
    border: none;
}
QPushButton#xmbBrandButton {
    min-width: 68px;
    min-height: 30px;
    color: #ffffff;
    background-color: rgba(119, 71, 237, 170);
    border: 1px solid #a982ff;
    border-radius: 15px;
    font-weight: 800;
}
QLabel#xmbRouteTitle { font-size: 18px; font-weight: 750; color: #ffffff; }
QLabel#xmbClock { font-size: 17px; font-weight: 650; color: #ffffff; }
QLabel#xmbStatus { color: #b7afca; padding-right: 14px; }
QPushButton#xmbButton {
    min-height: 48px;
    color: #a9a4b9;
    background-color: transparent;
    border: none;
    border-bottom: 3px solid transparent;
    border-radius: 9px;
    padding: 7px 10px;
    font-weight: 600;
}
QPushButton#xmbButton:hover {
    color: #ffffff;
    background-color: rgba(255, 255, 255, 18);
}
QPushButton#xmbButton:checked {
    color: #ffffff;
    background-color: rgba(119, 71, 237, 85);
    border-bottom: 3px solid #a855f7;
}
QLabel#brandTitle {
    color: #ffffff;
    font-size: 19px;
    font-weight: 700;
}
QLabel#brandSubtitle, QLabel#mutedLabel, QLabel#cardCaption,
QLabel#profileMeta, QLabel#downloadDetail {
    color: #9993ae;
}
QLabel#dashboardTitle {
    color: #ffffff;
    font-size: 30px;
    font-weight: 750;
}
QLabel#dashboardSubtitle { color: #aaa3bc; font-size: 14px; }
QLabel#accentAvatar {
    background-color:#0b0d17;
    border:2px solid #7048ff;
    border-radius:18px;
}
QLabel#cardTitle { color: #ffffff; font-size: 17px; font-weight: 650; }
QLabel#profileName { color: #ffffff; font-size: 24px; font-weight: 750; }
QLabel#cosmicMark { color: #b997ff; font-size: 23px; font-weight: 800; }
QFrame#roadmapBanner {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop:0 #2a1a4d, stop:1 #4a1f6e);
    border: 1px solid #a855f7;
    border-radius: 14px;
}
QLabel#roadmapIcon { font-size: 20px; }
QLabel#roadmapLabel { color: #f0e8ff; font-size: 13px; font-weight: 600; }
QPushButton#roadmapDismissButton {
    background: transparent;
    border: none;
    border-radius: 13px;
    color: #cbb8f0;
    font-weight: 700;
}
QPushButton#roadmapDismissButton:hover {
    background: rgba(255, 255, 255, 30);
    color: #ffffff;
}
QFrame#alertBanner {
    border-radius: 14px;
    border: 1px solid #574187;
    background-color: #1c1a2e;
    margin-bottom: 4px;
}
QFrame#alertBanner[severity="info"] {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop:0 #17213d, stop:1 #1f2f57);
    border: 1px solid #4f7bd8;
}
QFrame#alertBanner[severity="warning"] {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop:0 #3d2f14, stop:1 #57451f);
    border: 1px solid #d8a94f;
}
QFrame#alertBanner[severity="critical"] {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop:0 #3d1717, stop:1 #571f1f);
    border: 1px solid #e05d5d;
}
QLabel#alertBannerIcon { font-size: 22px; }
QLabel#alertBannerTitle { color: #ffffff; font-size: 14px; font-weight: 700; }
QLabel#alertBannerMessage { color: #e6e1f5; font-size: 13px; }
QPushButton#alertBannerDismissButton {
    background: transparent;
    border: none;
    border-radius: 13px;
    color: #cbb8f0;
    font-weight: 700;
}
QPushButton#alertBannerDismissButton:hover {
    background: rgba(255, 255, 255, 30);
    color: #ffffff;
}
QFrame#heroCard {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
        stop:0 #17152a, stop:0.55 #211743, stop:1 #30165e);
    border: 1px solid #52358d;
    border-radius: 22px;
}
QFrame#modernCard, QFrame#quickCard, QFrame#statusCard {
    background-color: #121522;
    border: 1px solid #29283a;
    border-radius: 18px;
}
QFrame#modernCard:hover, QFrame#quickCard:hover {
    border: 1px solid #574187;
    background-color: #151827;
}
QPushButton {
    min-height: 20px;
    color: #eeeaff;
    background-color: #202336;
    border: 1px solid #30334a;
    border-radius: 10px;
    padding: 8px 14px;
}
QPushButton:hover { background-color: #2a2e45; border-color: #5f4b8b; }
QPushButton:pressed {
    color: #ffffff;
    background-color: #181a29;
    border-color: #8c66e8;
}
QPushButton:disabled {
    color: #928da3;
    background-color: #171925;
    border-color: #2a2b3b;
}
QPushButton#modernPlayButton {
    min-height: 30px;
    color: #ffffff;
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop:0 #7048ff, stop:1 #a855f7);
    border: 1px solid #b58aff;
    border-radius: 13px;
    padding: 11px 25px;
    font-size: 15px;
    font-weight: 700;
}
QPushButton#modernPlayButton:hover {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop:0 #8060ff, stop:1 #bb65ff);
}
QPushButton#quickAccessButton {
    min-height: 54px;
    text-align: left;
    background-color: transparent;
    border: none;
    border-radius: 13px;
    padding: 12px 14px;
    font-size: 14px;
    font-weight: 600;
}
QPushButton#quickAccessButton:hover { background-color: #211c35; color: #c8acff; }
QPushButton#sidebarButton {
    min-height: 28px;
    max-height: 44px;
    background-color: transparent;
    border: none;
    border-radius: 12px;
    padding: 7px 12px;
    text-align: left;
    font-size: 13px;
    font-weight: 600;
}
QPushButton#sidebarButton:hover { background-color: #211d35; }
QPushButton#sidebarButton:checked {
    color: #ffffff;
    background-color: #7747ed;
}
QPushButton#sidebarButton:pressed, QPushButton#sidebarButton:focus {
    color: #ffffff;
}
QPushButton#sidebarBrandButton {
    min-height: 42px;
    color: #ffffff;
    background-color: transparent;
    border: none;
    border-radius: 12px;
    padding: 5px 9px;
    text-align: left;
    font-size: 13px;
    font-weight: 800;
}
QPushButton#sidebarBrandButton:hover { background-color: #211d35; }
QComboBox, QLineEdit, QSpinBox, QListWidget, QPlainTextEdit {
    color: #f4f1ff;
    background-color: #111421;
    border: 1px solid #333047;
    border-radius: 10px;
    padding: 7px 10px;
    selection-background-color: #7547e8;
}
QComboBox:hover, QLineEdit:hover { border-color: #604b8a; }
QComboBox:focus, QLineEdit:focus { border-color: #9a6bff; }
QComboBox::drop-down { border: none; width: 25px; }
QComboBox QAbstractItemView {
    background-color: #151827;
    border: 1px solid #39334f;
    selection-background-color: #6e42d5;
    padding: 4px;
}
QProgressBar {
    min-height: 8px;
    max-height: 8px;
    color: transparent;
    background-color: #202338;
    border: none;
    border-radius: 4px;
}
QProgressBar::chunk {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop:0 #6d4aff, stop:1 #b358ff);
    border-radius: 4px;
}
QTabWidget::pane { border: none; background-color: #090b14; }
QTabBar::tab {
    color: #aaa3ba;
    background-color: transparent;
    border: none;
    border-radius: 9px;
    padding: 9px 17px;
    margin: 3px;
}
QTabBar::tab:hover { color: #e8dcff; background-color: #191628; }
QTabBar::tab:selected { color: #ffffff; background-color: #7547e8; }
QGroupBox {
    background-color: #111421;
    border: 1px solid #2c2b3e;
    border-radius: 14px;
    margin-top: 12px;
    padding-top: 12px;
}
QGroupBox::title {
    subcontrol-origin: margin;
    left: 12px;
    padding: 0 5px;
    color: #c6a8ff;
    font-weight: 600;
}
QScrollBar:vertical { background: transparent; width: 10px; margin: 3px; }
QScrollBar::handle:vertical {
    background-color: #353047;
    min-height: 30px;
    border-radius: 4px;
}
QScrollBar::handle:vertical:hover { background-color: #604d82; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
QFrame#updateBanner {
    background-color: #1b1730;
    border: 1px solid #7952d6;
    border-radius: 12px;
    margin: 6px;
    padding: 4px;
}
QWidget#normalShell, QFrame#normalContent { background-color: #090b14; }
QFrame#normalSidebar {
    background-color: #101322;
    border-right: 1px solid #29233f;
}
QPushButton#normalBrand {
    min-height: 48px;
    color: #ffffff;
    background: transparent;
    border: none;
    text-align: left;
    font-size: 16px;
    font-weight: 800;
}
QPushButton#normalNavButton {
    min-height: 34px;
    color: #aaa3bc;
    background: transparent;
    border: none;
    border-radius: 10px;
    padding: 7px 12px;
    text-align: left;
    font-weight: 600;
}
QPushButton#normalNavButton:hover { color:#ffffff; background:#211d35; }
QPushButton#normalNavButton:checked {
    color:#ffffff;
    background:#7048ff;
    border-left:3px solid #a855f7;
}
QFrame#epicSidebar {
    background-color: rgba(18, 18, 28, 205);
    border: 1px solid #29233f;
    border-radius: 18px;
}
QFrame#epicContent {
    background-color: rgba(10, 11, 20, 220);
    border: 1px solid #29233f;
    border-radius: 20px;
}
QPushButton#epicBrand {
    min-height: 40px;
    color:#ffffff;
    background:transparent;
    border:none;
    text-align:left;
    font-size:15px;
    font-weight:900;
    letter-spacing:2px;
}
QPushButton#epicTopButton {
    min-height: 30px;
    background-color: rgba(32,35,54,220);
    border:1px solid #574187;
    border-radius:10px;
}
QLabel#epicIdentity { color:#b98bf0; font-size:13px; font-weight:700; }
QPushButton#epicNavButton {
    min-height:34px;
    color:#aaa3bc;
    background:transparent;
    border:none;
    border-radius:10px;
    padding:7px 12px;
    text-align:left;
    font-weight:600;
}
QPushButton#epicNavButton:hover { color:#ffffff; background:#211d35; }
QPushButton#epicNavButton:checked {
    color:#ffffff;
    background: qlineargradient(x1:0,y1:0,x2:1,y2:0,
        stop:0 #7048ff, stop:1 #a855f7);
    border:1px solid #b98bf0;
}
"""


def coerce_theme(value: ThemeName | str) -> ThemeName:
    """Convierte valores de configuración y rechaza nombres desconocidos."""

    if isinstance(value, ThemeName):
        return value
    normalized = str(value or "").strip().lower()
    aliases = {
        # ``modern`` era el identificador de XMBKat en 1.4.x. Mantenerlo
        # como alias evita cambiar la interfaz elegida al actualizar.
        "modern": ThemeName.XMB,
        "kat modern": ThemeName.XMB,
        "xmb": ThemeName.XMB,
        "xmbkat": ThemeName.XMB,
        "xmb kat": ThemeName.XMB,
        "normal": ThemeName.NORMAL,
        "kat normal": ThemeName.NORMAL,
        "epic": ThemeName.EPIC,
        "kat epic": ThemeName.EPIC,
        "classic": ThemeName.CLASSIC,
        "kat classic": ThemeName.CLASSIC,
    }
    try:
        return aliases[normalized]
    except KeyError as error:
        raise ValueError(f"Tema desconocido: {value!r}") from error


def coerce_accent(value: AccentName | str) -> AccentName:
    if isinstance(value, AccentName):
        return value
    try:
        return AccentName(str(value or "").strip().lower())
    except ValueError as error:
        raise ValueError(f"Color de acento desconocido: {value!r}") from error


def _apply_accent(
    stylesheet: str, accent: AccentName, custom_color: str = "#7048ff",
) -> str:
    if accent is AccentName.PURPLE:
        return stylesheet
    primary, secondary = (
        _custom_pair(custom_color) if accent is AccentName.CUSTOM
        else _ACCENT_COLORS[accent]
    )
    result = stylesheet
    for index, token in enumerate(_ACCENT_TOKENS):
        result = result.replace(token, primary if index % 2 == 0 else secondary)
    return result


class ThemeManager(QObject):
    """Carga, aplica y persiste el tema sin reiniciar KatLauncher."""

    theme_changed = Signal(str)
    accent_changed = Signal(str)
    theme_change_failed = Signal(str)

    def __init__(
        self,
        *,
        state_file: str | Path | None = None,
        classic_stylesheet: str | None = None,
        parent: QObject | None = None,
    ):
        super().__init__(parent)
        self.state_file = Path(state_file) if state_file else APP_DIR / "appearance.json"
        self.classic_stylesheet = classic_stylesheet or CLASSIC_STYLE
        self._theme, self._accent, self._custom_accent = self._read_state()

    @property
    def theme(self) -> ThemeName:
        return self._theme

    @property
    def accent(self) -> AccentName:
        return self._accent

    @property
    def accent_pair(self) -> tuple[str, str]:
        if self._accent is AccentName.CUSTOM:
            return _custom_pair(self._custom_accent)
        return _ACCENT_COLORS[self._accent]

    @property
    def custom_accent(self) -> str:
        return self._custom_accent

    def stylesheet_for(self, theme: ThemeName | str) -> str:
        selected = coerce_theme(theme)
        base = self.classic_stylesheet if selected is ThemeName.CLASSIC else MODERN_STYLE
        return _apply_accent(base, self._accent, self._custom_accent)

    def apply(
        self,
        theme: ThemeName | str | None = None,
        *,
        target: QApplication | QWidget | None = None,
        persist: bool = True,
    ) -> ThemeName:
        """Aplica un tema al instante.

        ``target`` puede ser ``QApplication`` para toda la app o una ventana
        durante la migración. Si se omite, se usa la aplicación actual.
        """

        selected = self._theme if theme is None else coerce_theme(theme)
        destination = target or QApplication.instance()
        if destination is None:
            raise RuntimeError("Se necesita una QApplication para aplicar el tema")
        previous = self._theme
        changed = selected is not previous
        if persist and changed:
            self._theme = selected
            try:
                self._write_theme()
            except OSError:
                self._theme = previous
                raise
        else:
            self._theme = selected
        destination.setStyleSheet(self.stylesheet_for(selected))
        if changed:
            self.theme_changed.emit(selected.value)
        return selected

    def use_modern(self, *, target=None, persist: bool = True) -> ThemeName:
        """Compatibilidad: el antiguo Kat Modern ahora se llama XMBKat."""
        return self.apply(ThemeName.XMB, target=target, persist=persist)

    def use_xmb(self, *, target=None, persist: bool = True) -> ThemeName:
        return self.apply(ThemeName.XMB, target=target, persist=persist)

    def use_normal(self, *, target=None, persist: bool = True) -> ThemeName:
        return self.apply(ThemeName.NORMAL, target=target, persist=persist)

    def use_epic(self, *, target=None, persist: bool = True) -> ThemeName:
        return self.apply(ThemeName.EPIC, target=target, persist=persist)

    def use_classic(self, *, target=None, persist: bool = True) -> ThemeName:
        return self.apply(ThemeName.CLASSIC, target=target, persist=persist)

    def apply_accent(
        self, accent: AccentName | str, *, target=None, persist: bool = True,
    ) -> AccentName:
        selected = coerce_accent(accent)
        destination = target or QApplication.instance()
        if destination is None:
            raise RuntimeError("Se necesita una QApplication para aplicar el color")
        previous = self._accent
        changed = selected is not previous
        self._accent = selected
        try:
            if persist and changed:
                self._write_theme()
            destination.setStyleSheet(self.stylesheet_for(self._theme))
        except OSError:
            self._accent = previous
            destination.setStyleSheet(self.stylesheet_for(self._theme))
            raise
        if changed:
            self.accent_changed.emit(selected.value)
        return selected

    def apply_custom_accent(
        self, color: str, *, target=None, persist: bool = True,
    ) -> AccentName:
        primary, _secondary = _custom_pair(color)
        destination = target or QApplication.instance()
        if destination is None:
            raise RuntimeError("Se necesita una QApplication para aplicar el color")
        previous_accent = self._accent
        previous_custom = self._custom_accent
        self._custom_accent = primary
        self._accent = AccentName.CUSTOM
        try:
            if persist:
                self._write_theme()
            destination.setStyleSheet(self.stylesheet_for(self._theme))
        except OSError:
            self._accent = previous_accent
            self._custom_accent = previous_custom
            destination.setStyleSheet(self.stylesheet_for(self._theme))
            raise
        self.accent_changed.emit(AccentName.CUSTOM.value)
        return AccentName.CUSTOM

    def bind_combo(self, combo: QComboBox, *, target=None) -> None:
        """Conecta un selector a este gestor y lo sincroniza en ambos sentidos."""

        combo.clear()
        for theme in ThemeName:
            combo.addItem(THEME_LABELS[theme], theme.value)
        index = combo.findData(self._theme.value)
        combo.setCurrentIndex(max(0, index))

        def on_selected(_index: int) -> None:
            value = combo.currentData()
            if value:
                try:
                    self.apply(value, target=target)
                except OSError as error:
                    combo.blockSignals(True)
                    combo.setCurrentIndex(combo.findData(self._theme.value))
                    combo.blockSignals(False)
                    self.theme_change_failed.emit(str(error))

        def on_theme_changed(value: str) -> None:
            selected_index = combo.findData(value)
            if selected_index >= 0 and selected_index != combo.currentIndex():
                combo.setCurrentIndex(selected_index)

        combo.currentIndexChanged.connect(on_selected)
        self.theme_changed.connect(on_theme_changed)

    def bind_accent_combo(self, combo: QComboBox, *, target=None) -> None:
        combo.clear()
        for accent in AccentName:
            combo.addItem(ACCENT_LABELS[accent], accent.value)
        combo.setCurrentIndex(max(0, combo.findData(self._accent.value)))

        def on_selected(_index: int) -> None:
            value = combo.currentData()
            if value:
                try:
                    self.apply_accent(value, target=target)
                except OSError as error:
                    combo.blockSignals(True)
                    combo.setCurrentIndex(combo.findData(self._accent.value))
                    combo.blockSignals(False)
                    self.theme_change_failed.emit(str(error))

        combo.currentIndexChanged.connect(on_selected)
        self.accent_changed.connect(
            lambda value: combo.setCurrentIndex(combo.findData(value))
        )

    def _read_state(self) -> tuple[ThemeName, AccentName, str]:
        try:
            raw = json.loads(self.state_file.read_text(encoding="utf-8"))
            if isinstance(raw, dict):
                return (
                    coerce_theme(raw.get("theme", ThemeName.XMB.value)),
                    coerce_accent(raw.get("accent", AccentName.PURPLE.value)),
                    _custom_pair(raw.get("custom_accent", "#7048ff"))[0],
                )
        except (OSError, ValueError, TypeError, json.JSONDecodeError):
            pass
        # 1.3.0 estrena Kat Modern. Los usuarios pueden volver a Classic en
        # cualquier momento y esa elección sí queda persistida.
        return ThemeName.XMB, AccentName.PURPLE, "#7048ff"

    def _write_theme(self) -> None:
        self.state_file.parent.mkdir(parents=True, exist_ok=True)
        payload = json.dumps(
            {
                "schema_version": 2,
                "theme": self._theme.value,
                "accent": self._accent.value,
                "custom_accent": self._custom_accent,
            },
            indent=2,
            ensure_ascii=False,
        )
        temporary = self.state_file.with_suffix(self.state_file.suffix + ".tmp")
        temporary.write_text(payload, encoding="utf-8")
        os.replace(temporary, self.state_file)
