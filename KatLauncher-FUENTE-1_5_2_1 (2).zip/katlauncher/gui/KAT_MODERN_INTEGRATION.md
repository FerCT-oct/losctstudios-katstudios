# Integración de Kat Modern 1.3.0

Los módulos nuevos son deliberadamente independientes de `MainWindow`:

- `theme_manager.py`: aplica y guarda `Kat Modern` o `Kat Classic`.
- `dashboard_tab.py`: dashboard con perfil activo, botón Jugar y accesos rápidos.
- `modern_shell.py`: barra lateral y contenedor de páginas opcional.

## Integración mínima sin reemplazar las pestañas

1. Crear `ThemeManager(classic_stylesheet=DARK_STYLE)` después de construir la
   ventana.
2. Llamar `theme_manager.apply(target=window)`. El tema guardado en
   `~/.katlauncher/appearance.json` se aplicará al instante. Si todavía no hay
   preferencia guardada, 1.3.0 arranca en **Kat Modern**.
3. Añadir un `QComboBox` en Configuración y ejecutar
   `theme_manager.bind_combo(combo, target=window)`. El selector queda
   sincronizado y no necesita reinicio.
4. Crear `DashboardTab(pm, i18n)` y añadirlo como primera pestaña.
5. Conectar sus señales:

```python
dashboard.play_requested.connect(play_from_dashboard)
dashboard.navigate_requested.connect(open_route)
dashboard.logo_clicked.connect(sound_manager.play_cat_ringtone)
```

El controlador puede iniciar un perfil reutilizando `PlayTab`:

```python
def play_from_dashboard(profile_id):
    index = play_tab.profile_combo.findData(profile_id)
    if index >= 0:
        play_tab.profile_combo.setCurrentIndex(index)
        play_tab.on_play()
```

El mapa recomendado para `open_route` es:

```python
{
    "profiles": profiles_tab,
    "mods": mods_tab,
    "friends": social_tab,
    "downloads": settings_tab,  # hasta que exista un centro de descargas
}
```

Después de cambiar perfiles hay que llamar también
`dashboard.refresh_profiles()`. El progreso del actualizador/instalador puede
reflejarse con `dashboard.set_download_status(text, value, maximum)`, y Kat
Social puede resumirse con `dashboard.set_social_summary(text)`.

## Integración completa con barra lateral

`ModernShell` acepta cualquier `QWidget` existente mediante
`register_page(route, widget)`. No contiene lógica de negocio. En una migración
completa puede reemplazar visualmente el `QTabWidget` mientras conserva las
mismas instancias de `PlayTab`, `ProfilesTab`, `ModsTab`, `SocialTab`, etc.

Antes de reparentar las pestañas actuales debe ajustarse `MainWindow` como una
sola operación, porque un widget Qt solo puede pertenecer a un contenedor. El
modo Classic debe volver a colocarlas en el `QTabWidget`, o bien mantener dos
capas de navegación que compartan controladores y creen vistas separadas.

## Contratos estables

- Temas guardados: `modern`, `classic`.
- Rutas: `home`, `play`, `profiles`, `mods`, `friends`, `downloads`, `settings`.
- `play_requested` siempre entrega el ID del perfil, nunca el objeto mutable.
- Cambiar el tema no modifica perfiles, mods, cuentas ni sesiones.
