import sys
import time
from pathlib import Path

from PySide6.QtCore import QTimer
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QMenu, QMessageBox, QStackedWidget,
    QSystemTrayIcon, QTabWidget, QVBoxLayout, QWidget,
)
from PySide6.QtGui import QAction, QIcon

from ..core.profile_manager import ProfileManager
from ..core import skins_manager, update_manager
from ..core.bundled_content import install_mckat_resource_pack
from ..core.discord_presence import DiscordRichPresence
from ..core.trophy_manager import TrophyManager
from ..core.katcraft_bridge import KatCraftBridge
from .play_tab import PlayTab
from .profiles_tab import ProfilesTab
from .mods_tab import ModsTab
from .skins_tab import SkinsTab
from .screenshots_tab import ScreenshotsTab
from .modpacks_tab import ModpacksTab
from .social_tab import SocialTab
from .settings_tab import SettingsTab
from .news_tab import NewsTab
from .servers_tab import ServersTab
from .rooms_tab import RoomsTab
from .accounts_tab import AccountsTab
from .bedrock_tab import BedrockTab
from .dashboard_tab import DashboardRoute, DashboardTab
from .modern_shell import ModernShell
from .alternate_shells import KatEpicShell, KatNormalShell
from .theme_manager import (
    ThemeManager, ThemeName, coerce_theme,
)
from .update_banner import UpdateBanner
from .update_controller import UpdateController
from .alert_controller import AlertController
from .sound_manager import SoundManager
from .onboarding import OnboardingWizard
from .trophies_tab import TrophiesTab
from .controller_navigation import ControllerNavigator, UiClickFilter

ASSETS_DIR = Path(__file__).resolve().parent.parent / "assets"
LOGO_PATH = ASSETS_DIR / "logo.png"

DARK_STYLE = """
QWidget { background-color: #16181d; color: #e8e8ec; font-size: 13px; }
QMainWindow { background-color: #16181d; }
QTabWidget::pane { border: 1px solid #2a2d35; }
QTabBar::tab {
    background: #1e2128; padding: 8px 18px; margin-right: 2px;
    border-top-left-radius: 6px; border-top-right-radius: 6px;
}
QTabBar::tab:selected { background: #9b5de5; color: white; }
QGroupBox {
    border: 1px solid #2a2d35; border-radius: 8px; margin-top: 10px; padding-top: 10px;
}
QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 4px; color: #b98bf0; }
QPushButton {
    background-color: #2a2d35; border: none; border-radius: 6px; padding: 8px 14px;
}
QPushButton:hover { background-color: #383c47; }
QPushButton#playButton {
    background-color: #9b5de5; font-weight: bold; font-size: 15px; padding: 12px;
}
QPushButton#playButton:hover { background-color: #b073f0; }
QLineEdit, QComboBox, QSpinBox, QListWidget, QPlainTextEdit {
    background-color: #1e2128; border: 1px solid #2a2d35; border-radius: 5px; padding: 4px;
}
QLabel#bigTitle { font-size: 26px; font-weight: bold; color: #b98bf0; }
QLabel#subtitle { color: #9a9aa5; margin-bottom: 8px; }
QProgressBar { border: 1px solid #2a2d35; border-radius: 5px; text-align: center; }
QProgressBar::chunk { background-color: #9b5de5; }
QFrame#updateBanner {
    background-color: #242032; border: 1px solid #9b5de5;
    border-radius: 7px; margin: 6px; padding: 3px;
}
"""


class MainWindow(QMainWindow):
    def __init__(self, profile_manager: ProfileManager, settings_manager, i18n):
        super().__init__()
        self.setWindowTitle("KatLauncher")
        self.resize(1120, 720)
        if LOGO_PATH.exists():
            self.setWindowIcon(QIcon(str(LOGO_PATH)))

        self.pm = profile_manager or ProfileManager()
        self.settings_manager = settings_manager
        self.i18n = i18n
        self.theme_manager = ThemeManager(classic_stylesheet=DARK_STYLE, parent=self)
        self._modern_layout = None
        self._active_layout = None
        self._active_shell = None
        self._minimized_for_game = False
        self._pending_update = None
        self._notification_tray = None
        self._seen_game_invite_ids = set()
        self._tray_game_active = False
        self._launch_sequence_active = False
        self._pending_launch_sequence = None
        self._launch_sequence_timer = QTimer(self)
        self._launch_sequence_timer.setSingleShot(True)
        self._launch_sequence_timer.timeout.connect(
            self._finish_pending_launch_sequence
        )
        self._game_started_at = None
        self._kat_presence_profile = None
        self._alert_poll_timer = None
        self._logo_clicks = 0
        self._last_logo_click = 0.0
        self.trophy_manager = TrophyManager()
        settings = self.settings_manager.settings
        self.sound_manager = SoundManager(
            enabled=settings.sound_effects_enabled, parent=self
        )
        self._discord_client_id_setting = settings.discord_client_id
        self.discord_presence = DiscordRichPresence(
            settings.discord_client_id or None,
            enabled=settings.discord_rich_presence,
        )
        self._sync_bundled_content()

        self.tabs = QTabWidget()
        self.modern_shell = ModernShell(i18n=self.i18n)
        self.normal_shell = KatNormalShell(i18n=self.i18n)
        self.epic_shell = KatEpicShell(i18n=self.i18n)
        self.controller_navigator = ControllerNavigator(
            self.modern_shell.menu, i18n=self.i18n, parent=self
        )
        self.ui_click_filter = UiClickFilter(self)
        app = QApplication.instance()
        if app is not None:
            app.installEventFilter(self.ui_click_filter)
        self.view_stack = QStackedWidget()
        self.view_stack.addWidget(self.tabs)
        self.view_stack.addWidget(self.modern_shell)
        self.view_stack.addWidget(self.normal_shell)
        self.view_stack.addWidget(self.epic_shell)
        self.update_banner = UpdateBanner(self.i18n)
        central = QWidget()
        central_layout = QVBoxLayout(central)
        central_layout.setContentsMargins(0, 0, 0, 0)
        central_layout.setSpacing(0)
        central_layout.addWidget(self.update_banner)
        central_layout.addWidget(self.view_stack, stretch=1)
        self.setCentralWidget(central)

        self.play_tab = PlayTab(self.pm, self.settings_manager, self.i18n)
        self.bedrock_tab = BedrockTab(self.i18n)
        self.profiles_tab = ProfilesTab(
            self.pm, self.settings_manager, self.i18n, on_change=self.on_profiles_changed
        )
        self.modpacks_tab = ModpacksTab(
            self.pm, self.settings_manager, self.i18n, on_change=self.on_profiles_changed
        )
        self.mods_tab = ModsTab(self.pm, self.i18n)
        self.social_tab = SocialTab(
            self.i18n, settings_manager=self.settings_manager,
            trophy_manager=self.trophy_manager,
        )
        self.katcraft_bridge = KatCraftBridge(
            self.social_tab.service, self.trophy_manager, parent=self
        )
        self.social_tab.game_invites.connect(self._on_game_invites)
        self.katcraft_bridge.game_invites.connect(self._on_game_invites)
        self.play_tab.room_advertised.connect(self.katcraft_bridge.set_room)
        self.play_tab.room_configured.connect(self.katcraft_bridge.configure_room)
        self.play_tab.room_log_line.connect(self.katcraft_bridge.append_room_log)
        self.play_tab.room_local_ready.connect(
            self.katcraft_bridge.set_room_local_port
        )
        self.play_tab.room_failed.connect(self.katcraft_bridge.set_room_error)
        self.katcraft_bridge.room_start_requested.connect(
            self.play_tab.start_room_from_katcraft
        )
        self.katcraft_bridge.room_stop_requested.connect(self.play_tab.stop_room)
        self.katcraft_bridge.room_restart_requested.connect(
            self.play_tab.restart_room_from_katcraft
        )
        self.katcraft_bridge.room_command_requested.connect(
            self.play_tab.send_room_command
        )
        self.katcraft_bridge.room_join_requested.connect(
            self._join_room_from_katcraft
        )
        self.play_tab.room_ended.connect(
            lambda: self.katcraft_bridge.set_room("", 0)
        )
        self.trophies_tab = TrophiesTab(self.trophy_manager, self.i18n)
        self.skins_tab = SkinsTab(
            self.pm, self.settings_manager, self.i18n,
            social_service=self.social_tab.service,
        )
        self.katcraft_bridge.skin_selected.connect(
            self.skins_tab.activate_from_katcraft
        )
        self.screenshots_tab = ScreenshotsTab(self.pm, self.i18n)
        self.news_tab = NewsTab(self.i18n)
        self.servers_tab = ServersTab(self.pm, self.i18n)
        self.rooms_tab = RoomsTab(
            self.pm, self.social_tab.service, self.i18n
        )
        self.accounts_tab = AccountsTab(
            self.pm, self.settings_manager, self.i18n
        )
        self.settings_tab = SettingsTab(
            self.settings_manager, self.i18n, theme_manager=self.theme_manager
        )
        self.dashboard_tab = DashboardTab(
            self.pm, self.i18n, settings_manager=self.settings_manager
        )
        self.update_controller = UpdateController(self)
        self.alert_controller = AlertController(self)

        self._page_specs = (
            (DashboardRoute.PLAY, self.play_tab, "Jugar"),
            (DashboardRoute.BEDROCK, self.bedrock_tab, "Bedrock"),
            (DashboardRoute.PROFILES, self.profiles_tab, "Perfiles"),
            (DashboardRoute.DOWNLOADS, self.modpacks_tab, "Modpacks"),
            (DashboardRoute.MODS, self.mods_tab, "Mods"),
            (DashboardRoute.SKINS, self.skins_tab, "Skins"),
            (DashboardRoute.SCREENSHOTS, self.screenshots_tab, "Capturas"),
            (DashboardRoute.NEWS, self.news_tab, "Noticias"),
            (DashboardRoute.SERVERS, self.servers_tab, "Servidores"),
            (DashboardRoute.ROOMS, self.rooms_tab, "Salas"),
            (DashboardRoute.FRIENDS, self.social_tab, "Amigos"),
            (DashboardRoute.ACCOUNTS, self.accounts_tab, "Cuentas"),
            (DashboardRoute.TROPHIES, self.trophies_tab, "Trofeos"),
            (DashboardRoute.SETTINGS, self.settings_tab, "Configuración"),
        )
        self.tabs.currentChanged.connect(self.on_tab_changed)
        for shell in (self.modern_shell, self.normal_shell, self.epic_shell):
            shell.route_changed.connect(self._on_modern_route_changed)
            shell.logo_clicked.connect(self._on_logo_clicked)
            shell.launch_minecraft_requested.connect(self._launch_active_xmb_profile)
            shell.check_updates_requested.connect(
                lambda: self.update_controller.check(manual=True)
            )
            shell.tutorial_requested.connect(self.show_onboarding)
        self.modern_shell.trophy_requested.connect(self.sound_manager.play_achievement)
        self.mods_tab.mod_installed.connect(
            lambda: self.unlock_trophy("first_mod")
        )
        self.modpacks_tab.modpack_completed.connect(
            lambda: self.unlock_trophy("first_modpack")
        )
        self.social_tab.milestone.connect(self.unlock_trophy)
        self.dashboard_tab.logo_clicked.connect(self._on_logo_clicked)
        self.dashboard_tab.navigate_requested.connect(self._navigate_route)
        self.dashboard_tab.play_requested.connect(self._play_from_dashboard)
        self.dashboard_tab.active_profile_changed.connect(self._sync_play_profile)
        self.dashboard_tab.check_updates_requested.connect(
            lambda: self.update_controller.check(manual=True)
        )
        self.dashboard_tab.tutorial_requested.connect(self.show_onboarding)
        self.alert_controller.alert_available.connect(self._on_alert_available)
        self.dashboard_tab.alert_banner.dismissed.connect(self.alert_controller.mark_seen)
        self.play_tab.game_started.connect(self.on_game_started)
        self.play_tab.game_finished.connect(self.on_game_finished)
        self.play_tab.launch_prepared.connect(self._show_launch_sequence)
        self.play_tab.logo_clicked.connect(self._on_logo_clicked)
        self.servers_tab.launch_requested.connect(self._launch_server)
        self.rooms_tab.launch_requested.connect(self._launch_server)
        self.rooms_tab.profiles_changed.connect(self.on_profiles_changed)
        self.accounts_tab.profiles_changed.connect(self.on_profiles_changed)
        for tab in (
            self.play_tab, self.bedrock_tab, self.profiles_tab, self.modpacks_tab,
            self.mods_tab, self.skins_tab, self.news_tab, self.servers_tab,
            self.rooms_tab, self.screenshots_tab,
            self.settings_tab, self.social_tab, self.accounts_tab,
            self.trophies_tab,
        ):
            tab.operation_succeeded.connect(self.sound_manager.play_operation_success)
        self.ui_click_filter.clicked.connect(self.sound_manager.play_ui_click)
        self.controller_navigator.interaction.connect(self.sound_manager.play_ui_click)
        self.controller_navigator.back_requested.connect(self._controller_back)
        self.controller_navigator.next_page_requested.connect(
            lambda: self._controller_change_page(1)
        )
        self.controller_navigator.previous_page_requested.connect(
            lambda: self._controller_change_page(-1)
        )
        self.controller_navigator.secret_unlocked.connect(
            self._controller_easter_egg
        )
        self.settings_tab.settings_saved.connect(self.on_settings_saved)
        self.settings_tab.check_updates_requested.connect(
            lambda: self.update_controller.check(manual=True)
        )
        self.settings_tab.cancel_update_download_requested.connect(
            self.update_controller.cancel_download
        )
        self.update_banner.download_requested.connect(self._download_update)
        self.update_banner.cancel_requested.connect(self.update_controller.cancel_download)
        self.update_controller.checking_changed.connect(
            self.settings_tab.set_update_checking
        )
        self.update_controller.update_available.connect(self._on_update_available)
        self.update_controller.up_to_date.connect(self._on_up_to_date)
        self.update_controller.check_failed.connect(self._on_update_check_failed)
        self.update_controller.download_started.connect(self._on_update_download_started)
        self.update_controller.download_progress.connect(self._on_update_download_progress)
        self.update_controller.download_cancelled.connect(self._on_update_download_cancelled)
        self.update_controller.download_failed.connect(self._on_update_download_failed)
        self.update_controller.update_ready.connect(self._on_update_ready)
        self.i18n.language_changed.connect(self.retranslate_ui)
        self.theme_manager.theme_changed.connect(self._on_theme_changed)
        self.theme_manager.accent_changed.connect(self._on_accent_changed)
        self._on_accent_changed(self.theme_manager.accent.value)
        self.theme_manager.apply(
            target=QApplication.instance() or self, persist=False
        )
        self._apply_theme_layout(self.theme_manager.theme)
        self.retranslate_ui()
        self.discord_presence.show_launcher(language=self.i18n.language)

    def _ensure_tray(self):
        if not QSystemTrayIcon.isSystemTrayAvailable():
            return None
        if self._notification_tray is not None:
            return self._notification_tray
        tray = QSystemTrayIcon(self.windowIcon(), self)
        tray.setToolTip("KatLauncher")
        menu = QMenu(self)
        restore = QAction(self.i18n.t("Abrir KatLauncher"), menu)
        restore.triggered.connect(self._restore_from_tray)
        quit_action = QAction(self.i18n.t("Salir"), menu)
        quit_action.triggered.connect(self.close)
        menu.addAction(restore)
        menu.addSeparator()
        menu.addAction(quit_action)
        tray.setContextMenu(menu)
        tray.activated.connect(
            lambda reason: self._restore_from_tray()
            if reason in (
                QSystemTrayIcon.ActivationReason.Trigger,
                QSystemTrayIcon.ActivationReason.DoubleClick,
            ) else None
        )
        self._notification_tray = tray
        return tray

    def _restore_from_tray(self):
        self.showNormal()
        self.activateWindow()
        self.raise_()

    def _minimize_to_tray_for_game(self):
        tray = self._ensure_tray()
        if tray is None:
            self.showMinimized()
            return
        self._tray_game_active = True
        tray.show()
        self.hide()

    def _launch_active_xmb_profile(self):
        profile = self.dashboard_tab.active_profile
        if profile is None:
            self._navigate_route(DashboardRoute.PLAY)
            return
        self._sync_play_profile(profile.id)
        self.play_tab.play_selected()

    def _show_launch_sequence(self, profile, version_id: str):
        if self._launch_sequence_active:
            return
        try:
            service = self.social_tab.service
            shared_root = service.shared_skin_root if service.configured else ""
            skins_manager.configure_shared_skin_source(
                profile.game_dir, shared_root
            )
        except (OSError, ValueError, AttributeError):
            # La skin no debe impedir que Minecraft abra; el respaldo local
            # seguirá disponible si ya existía una configuración válida.
            pass
        if profile.loader in ("fabric", "quilt", "forge", "neoforge") \
                and self.settings_manager.settings.auto_install_katcraft:
            try:
                self.katcraft_bridge.prepare(profile)
            except (OSError, ValueError):
                self.katcraft_bridge.stop()
        else:
            self.katcraft_bridge.stop()
        self._launch_sequence_active = True
        self._pending_launch_sequence = (profile, version_id)
        self._launch_return_widget = self.view_stack.currentWidget()
        self.view_stack.setCurrentWidget(self.modern_shell)
        self.modern_shell.show_minecraft_launch(
            getattr(profile, "name", "Minecraft")
        )
        self._launch_sequence_timer.start(self.modern_shell.LAUNCH_SEQUENCE_MS)

    def _finish_pending_launch_sequence(self):
        if not self._launch_sequence_active:
            return
        pending = self._pending_launch_sequence
        self._pending_launch_sequence = None
        self._launch_sequence_active = False
        if not pending:
            return
        profile, version_id = pending
        if self._active_shell is not None:
            self.view_stack.setCurrentWidget(self._active_shell)
            self._active_shell.navigate(DashboardRoute.PLAY)
        else:
            self.view_stack.setCurrentWidget(self.tabs)
            self.tabs.setCurrentWidget(self.play_tab)
        self.play_tab.start_prepared_game(profile, version_id)

    def start_auto_update_check(self):
        if getattr(sys, "frozen", False) \
                and self.settings_manager.settings.auto_check_updates:
            self.update_controller.check(manual=False)

    def start_alert_check(self):
        self.alert_controller.check()
        self.alert_controller.start_realtime()
        if self._alert_poll_timer is None:
            self._alert_poll_timer = QTimer(self)
            self._alert_poll_timer.setInterval(15 * 60 * 1000)
            self._alert_poll_timer.timeout.connect(self.alert_controller.check)
            self._alert_poll_timer.start()

    def _controller_back(self):
        if self._active_shell is not None:
            self._active_shell.show_menu()

    def _on_accent_changed(self, accent: str):
        primary, secondary = self.theme_manager.accent_pair
        self.epic_shell.set_accent(primary, secondary)

    def _controller_change_page(self, delta: int):
        routes = [route for route, _widget, _label in self._page_specs]
        current = self._current_route()
        try:
            index = routes.index(current)
        except ValueError:
            index = 0
        self._navigate_route(routes[(index + int(delta)) % len(routes)])

    def _controller_easter_egg(self):
        self.sound_manager.play_achievement()
        QMessageBox.information(
            self,
            "KatLauncher",
            "↑ ↑ ↓ ↓ ← → ← → B A\n\n¡Código gatuno desbloqueado! 🐈",
        )

    def _on_logo_clicked(self):
        now = time.monotonic()
        if now - self._last_logo_click > 2.5:
            self._logo_clicks = 0
        self._last_logo_click = now
        self._logo_clicks += 1
        if self._logo_clicks >= 7:
            self._logo_clicks = 0
            self.sound_manager.play_creeper()
            QMessageBox.information(
                self, "KatLauncher", "Creeper gatuno: MIAAAAU— ¡BOOM! 💥"
            )
        else:
            self.sound_manager.play_cat_ringtone()

    def show_onboarding(self):
        wizard = OnboardingWizard(
            self.i18n, self, theme_manager=self.theme_manager
        )
        if wizard.exec():
            try:
                self.settings_manager.update(onboarding_completed=True)
            except OSError:
                pass
            self.unlock_trophy("guide_complete")

    def show_onboarding_if_needed(self):
        if self.settings_manager.settings.onboarding_completed:
            return
        self.show_onboarding()

    def show_update_success_notification(self):
        """Confirma el éxito solo tras el relanzamiento de una autoactualización."""
        self.unlock_trophy("first_update")
        self.sound_manager.play_update_success()
        if not QSystemTrayIcon.isSystemTrayAvailable() \
                or not QSystemTrayIcon.supportsMessages():
            return
        tray = self._ensure_tray()
        if tray is None:
            return
        tray.show()
        tray.showMessage(
            "KatLauncher",
            self.i18n.t("Actualización configurada correctamente."),
            QSystemTrayIcon.MessageIcon.Information,
            8000,
        )
        if not self._tray_game_active:
            QTimer.singleShot(12_000, tray.hide)

    def _on_alert_available(self, info):
        if info.sound:
            self.sound_manager.play_warning()
        if info.display == "dialog":
            icon = {
                "warning": QMessageBox.Warning,
                "critical": QMessageBox.Critical,
            }.get(info.severity, QMessageBox.Information)
            box = QMessageBox(self)
            box.setIcon(icon)
            box.setWindowTitle(info.title_for(self.i18n.language))
            box.setText(info.message_for(self.i18n.language))
            box.setStandardButtons(QMessageBox.Ok)
            box.exec()
            self.alert_controller.mark_seen(info.id)
        else:
            self.dashboard_tab.alert_banner.show_alert(info)

    def _on_update_available(self, info):
        self.sound_manager.play_notification()
        self.update_banner.show_available(info)
        self.dashboard_tab.set_download_status(
            self.i18n.t(
                "KatLauncher {version} está disponible.",
                version=info.version,
            ),
            0,
            max(int(info.installer_size or 0), 1),
        )
        self.settings_tab.set_update_status(
            "KatLauncher {version} está disponible.", version=info.version
        )

    def _on_game_invites(self, invitations):
        invitations = [
            item for item in (invitations or []) if isinstance(item, dict)
        ]
        new_items = []
        for item in invitations:
            try:
                invite_id = int(item.get("id") or 0)
            except (TypeError, ValueError):
                invite_id = 0
            if invite_id > 0 and invite_id not in self._seen_game_invite_ids:
                self._seen_game_invite_ids.add(invite_id)
                new_items.append(item)
        if not new_items:
            return
        latest = new_items[0]
        sender = str(latest.get("display_name") or "Un amigo")[:32]
        host = str(
            latest.get("server_host") or latest.get("host") or "un servidor"
        )[:253]
        port = int(latest.get("server_port") or latest.get("port") or 25565)
        if len(new_items) == 1:
            message = self.i18n.t(
                "{sender} te invitó a jugar en {host}:{port}"
            ).format(sender=sender, host=host, port=port)
        else:
            message = self.i18n.t(
                "Tienes {count} invitaciones nuevas para jugar"
            ).format(count=len(new_items))
        tray = self._ensure_tray()
        if tray is not None and QSystemTrayIcon.supportsMessages():
            tray.show()
            tray.showMessage(
                self.i18n.t("Invitación de KatCraft"),
                message,
                QSystemTrayIcon.MessageIcon.Information,
                10_000,
            )
            if not self._tray_game_active:
                QTimer.singleShot(12_000, tray.hide)
        self.sound_manager.play_invite()

    def _on_up_to_date(self):
        self.settings_tab.set_update_status("KatLauncher está actualizado.")
        self.dashboard_tab.set_download_status(
            self.i18n.t("KatLauncher está actualizado."), 1, 1
        )

    def _on_update_check_failed(self, error: str, manual: bool):
        self.sound_manager.play_error()
        if manual:
            self.settings_tab.set_update_status(
                "No se pudo buscar actualizaciones: {error}",
                error=self.i18n.t(error),
            )

    def _download_update(self, info):
        self.update_controller.download(info)

    def _on_update_download_started(self, info):
        self.update_banner.show_downloading(info)
        self.settings_tab.set_update_progress(0, info.installer_size)
        self.dashboard_tab.set_download_status(
            self.i18n.t("Descargando actualización…"), 0, info.installer_size
        )

    def _on_update_download_progress(self, current: int, maximum: int):
        self.update_banner.set_progress(current, maximum)
        self.settings_tab.set_update_progress(current, maximum)
        self.dashboard_tab.set_download_status(
            self.i18n.t("Descargando actualización…"), current, maximum
        )

    def _on_update_download_cancelled(self):
        self.update_banner.setVisible(False)
        self.settings_tab.finish_update_download()
        self.settings_tab.set_update_status("Descarga de la actualización cancelada.")
        self.dashboard_tab.set_download_status(
            self.i18n.t("Descarga de la actualización cancelada."), 0, 1
        )

    def _on_update_download_failed(self, error: str):
        self.sound_manager.play_error()
        translated_error = self.i18n.t(error)
        self.update_banner.setVisible(False)
        self.settings_tab.finish_update_download()
        self.settings_tab.set_update_status(
            "No se pudo descargar la actualización: {error}", error=translated_error
        )
        self.dashboard_tab.set_download_status(translated_error, 0, 1)
        QMessageBox.warning(
            self,
            self.i18n.t("Actualización rechazada"),
            self.i18n.t(
                "La actualización no se instalará porque no pudo verificarse.\n\n{error}",
                error=translated_error,
            ),
        )

    def _on_update_ready(self, info, path: str):
        self.settings_tab.finish_update_download()
        self.sound_manager.play_operation_success()
        self.settings_tab.set_update_status(
            "KatLauncher {version} está descargado y verificado.", version=info.version
        )
        self.dashboard_tab.set_download_status(
            self.i18n.t(
                "KatLauncher {version} está descargado y verificado.",
                version=info.version,
            ), 1, 1,
        )
        answer = QMessageBox.question(
            self,
            self.i18n.t("Actualización lista"),
            self.i18n.t(
                "KatLauncher {version} está listo para instalarse. "
                "La aplicación se cerrará y volverá a abrirse cuando termine el instalador. "
                "Si Windows no puede completar la actualización, mostrará el error y "
                "KatLauncher intentará abrirse de nuevo.\n\n"
                "¿Instalar ahora?",
                version=info.version,
            ),
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.Yes,
        )
        if answer == QMessageBox.Yes:
            self._pending_update = (info, path)
            QTimer.singleShot(0, self.close)
        else:
            self.update_banner.show_available(info)

    def retranslate_ui(self, *_args):
        for route, widget, text in self._page_specs:
            index = self.tabs.indexOf(widget)
            if index >= 0:
                self.tabs.setTabText(index, self.i18n.t(text))
            button = self.modern_shell._buttons.get(route)
            if button is not None:
                translated = self.i18n.t(text)
                button.setToolTip(translated)
                button.setAccessibleName(translated)
        home_button = self.modern_shell._buttons.get(DashboardRoute.HOME)
        if home_button is not None:
            home_button.setToolTip(self.i18n.t("Inicio"))
            home_button.setAccessibleName(self.i18n.t("Inicio"))
        self.normal_shell.retranslate_ui()
        self.epic_shell.retranslate_ui()

    def _current_route(self) -> str:
        if self._active_shell is not None:
            return self._active_shell.current_route or DashboardRoute.HOME
        current = self.tabs.currentWidget()
        for route, widget, _label in self._page_specs:
            if widget is current:
                return route
        return DashboardRoute.HOME

    def _apply_theme_layout(self, theme):
        selected = coerce_theme(theme)
        if self._active_layout is selected:
            return
        current_route = self._current_route()
        for shell in (self.modern_shell, self.normal_shell, self.epic_shell):
            shell.unregister_page(DashboardRoute.HOME)
            for route, _widget, _label in self._page_specs:
                shell.unregister_page(route)
        while self.tabs.count():
            self.tabs.removeTab(0)

        if selected is ThemeName.CLASSIC:
            for _route, widget, label in self._page_specs:
                self.tabs.addTab(widget, self.i18n.t(label))
            self.view_stack.setCurrentWidget(self.tabs)
            target = next(
                (widget for route, widget, _label in self._page_specs
                 if route == current_route), self.play_tab
            )
            self.tabs.setCurrentWidget(target)
            self._active_shell = None
        else:
            shell = {
                ThemeName.XMB: self.modern_shell,
                ThemeName.NORMAL: self.normal_shell,
                ThemeName.EPIC: self.epic_shell,
            }[selected]
            shell.register_page(DashboardRoute.HOME, self.dashboard_tab)
            for route, widget, _label in self._page_specs:
                shell.register_page(route, widget)
            self.view_stack.setCurrentWidget(shell)
            target_route = current_route if current_route in shell._pages \
                else DashboardRoute.HOME
            if selected is ThemeName.XMB and target_route == DashboardRoute.HOME:
                shell.show_menu()
            else:
                shell.navigate(target_route)
            self._active_shell = shell
        self._active_layout = selected
        self._modern_layout = selected is not ThemeName.CLASSIC
        self.retranslate_ui()

    def _on_theme_changed(self, theme: str):
        self._apply_theme_layout(theme)

    def _navigate_route(self, route: str):
        route = str(route or "").lower()
        if self._active_shell is not None:
            self._active_shell.navigate(route)
            return
        if route == DashboardRoute.HOME:
            route = DashboardRoute.PLAY
        target = next(
            (widget for candidate, widget, _label in self._page_specs
             if candidate == route), None
        )
        if target is not None:
            self.tabs.setCurrentWidget(target)

    def _play_from_dashboard(self, profile_id: str):
        self._navigate_route(DashboardRoute.PLAY)
        self._sync_play_profile(profile_id)
        self.play_tab.play_selected()

    def _sync_play_profile(self, profile_id: str):
        index = self.play_tab.profile_combo.findData(profile_id)
        if index >= 0:
            self.play_tab.profile_combo.setCurrentIndex(index)

    def _on_modern_route_changed(self, route: str):
        if route == DashboardRoute.HOME:
            self.dashboard_tab.refresh_profiles()
            return
        widget = next(
            (page for candidate, page, _label in self._page_specs
             if candidate == route), None
        )
        self._refresh_page(widget)

    def on_profiles_changed(self):
        self._sync_bundled_content()
        self.play_tab.refresh_profiles()
        self.profiles_tab.refresh_list()
        self.mods_tab.refresh_profiles()
        self.skins_tab.refresh_profiles()
        self.modpacks_tab.refresh_installed()
        self.servers_tab.refresh_profiles()
        self.rooms_tab.refresh_profiles()
        self.accounts_tab.refresh_profiles()
        self.dashboard_tab.refresh_profiles()

    def on_settings_saved(self):
        settings = self.settings_manager.settings
        self._sync_bundled_content()
        self.sound_manager.set_enabled(settings.sound_effects_enabled)
        if settings.discord_client_id != self._discord_client_id_setting:
            self.discord_presence.close(timeout=0.15)
            self._discord_client_id_setting = settings.discord_client_id
            self.discord_presence = DiscordRichPresence(
                settings.discord_client_id or None,
                enabled=settings.discord_rich_presence,
            )
        else:
            self.discord_presence.set_enabled(settings.discord_rich_presence)
        if settings.discord_rich_presence:
            if self.play_tab._game_active and self.play_tab._active_profile is not None:
                profile = self.play_tab._active_profile
                self.discord_presence.show_playing(
                    profile.version,
                    loader=profile.loader,
                    language=self.i18n.language,
                )
            else:
                self.discord_presence.show_launcher(language=self.i18n.language)
        self.play_tab.refresh_settings()
        self.profiles_tab.refresh_settings()
        self.skins_tab.refresh_settings()
        self.social_tab.refresh_settings()
        self.social_tab.set_game_presence(
            self._kat_presence_profile,
            bool(self._kat_presence_profile),
        )
        self.modpacks_tab.refresh_settings()

    def _sync_bundled_content(self):
        """Mantiene MCKAT disponible sin impedir que el launcher arranque."""

        settings = self.settings_manager.settings
        if not getattr(settings, "auto_install_mckat_pack", True):
            return
        for profile in self.pm.list_profiles():
            if getattr(profile, "platform", "java") != "java":
                continue
            try:
                install_mckat_resource_pack(profile.game_dir)
            except OSError:
                # Se reintentará al crear/cambiar perfiles o guardar ajustes.
                continue

    def on_tab_changed(self, index):
        # refresca listas por si se editaron perfiles en otra pestaña
        self._refresh_page(self.tabs.widget(index))

    def _refresh_page(self, widget):
        if widget is self.mods_tab:
            self.mods_tab.refresh_profiles()
        elif widget is self.skins_tab:
            self.skins_tab.refresh_profiles()
        elif widget is self.screenshots_tab:
            self.screenshots_tab.refresh_profiles()
        elif widget is self.play_tab:
            self.play_tab.refresh_profiles()
        elif widget is self.modpacks_tab:
            self.modpacks_tab.refresh_installed()
        elif widget is self.profiles_tab:
            self.profiles_tab.refresh_list()
        elif widget is self.servers_tab:
            self.servers_tab.refresh_profiles()
        elif widget is self.rooms_tab:
            self.rooms_tab.refresh_profiles()
            self.rooms_tab.refresh()
        elif widget is self.accounts_tab:
            self.accounts_tab.refresh_profiles()
        elif widget is self.trophies_tab:
            self.trophies_tab.refresh()

    def unlock_trophy(self, trophy_id: str):
        unlocked = self.trophy_manager.unlock(trophy_id)
        if not unlocked:
            return
        self.trophies_tab.refresh()
        for trophy in unlocked:
            self.modern_shell.show_trophy(trophy)
            self.sound_manager.play_achievement()
        self.social_tab.sync_trophies()

    def _launch_server(self, profile_id: str, host: str, port: int):
        self._navigate_route(DashboardRoute.PLAY)
        self.play_tab.play_server(profile_id, host, port)

    def _join_room_from_katcraft(self, room: dict):
        self._restore_from_tray()
        self._navigate_route(DashboardRoute.ROOMS)
        self.rooms_tab.join_room(room)

    def on_game_started(self, profile):
        self._game_started_at = time.monotonic()
        self._kat_presence_profile = profile
        self.social_tab.set_game_presence(profile, True)
        self.social_tab.set_game_active(True)
        if profile is not None:
            self.discord_presence.show_playing(
                profile.version,
                loader=profile.loader,
                language=self.i18n.language,
            )
        if self.settings_manager.settings.minimize_on_launch:
            self._minimized_for_game = True
            # En Windows queda únicamente el gato en la bandeja; no estorba
            # en Alt+Tab ni encima de Minecraft.
            self._minimize_to_tray_for_game()
        if profile is not None:
            self.dashboard_tab.set_download_status(
                self.i18n.t("Minecraft está abierto con {profile}.", profile=profile.name),
                1, 1,
            )

    def on_game_finished(self):
        if self.play_tab.room_worker is None:
            self.katcraft_bridge.stop()
        self.social_tab.set_game_active(False)
        if self._game_started_at is not None:
            elapsed = int(max(0, time.monotonic() - self._game_started_at))
            self._game_started_at = None
            unlocked = self.trophy_manager.add_playtime(elapsed)
            if unlocked:
                self.trophies_tab.refresh()
                for trophy in unlocked:
                    self.modern_shell.show_trophy(trophy)
                    self.sound_manager.play_achievement()
                self.social_tab.sync_trophies()
            self.social_tab.record_playtime(elapsed)
        self.social_tab.set_game_presence(self._kat_presence_profile, False)
        self._kat_presence_profile = None
        self.discord_presence.show_launcher(language=self.i18n.language)
        if self._minimized_for_game:
            self._minimized_for_game = False
            self._tray_game_active = False
            self._restore_from_tray()
            if self._notification_tray is not None:
                self._notification_tray.hide()
        self.dashboard_tab.set_download_status(self.i18n.t("Todo está listo."), 1, 1)

    def closeEvent(self, event):
        self.alert_controller.stop_realtime()
        tabs = (
            self.play_tab, self.profiles_tab, self.modpacks_tab,
            self.mods_tab, self.skins_tab,
            self.news_tab, self.servers_tab, self.social_tab,
        )
        busy = any(getattr(tab, "has_running_workers", lambda: False)() for tab in tabs)
        busy = busy or self.update_controller.has_running_workers() \
            or self._launch_sequence_active
        if busy:
            QMessageBox.information(
                self,
                self.i18n.t("Operación en curso"),
                self.i18n.t(
                    "Espera a que terminen las descargas o cierra Minecraft antes de salir."
                ),
            )
            event.ignore()
            return
        if not self.social_tab.shutdown():
            QMessageBox.information(
                self, self.i18n.t("Operación en curso"),
                self.i18n.t("Kat Social todavía está cerrando su conexión. Intenta salir de nuevo."),
            )
            event.ignore()
            return
        self.katcraft_bridge.stop()
        if self._pending_update:
            info, path = self._pending_update
            try:
                update_manager.launch_update_installer(
                    path,
                    info,
                    language=self.i18n.language,
                )
            except update_manager.UpdateError as error:
                self._pending_update = None
                QMessageBox.warning(
                    self,
                    self.i18n.t("Error"),
                    self.i18n.t(str(error)),
                )
                event.ignore()
                return
        self.sound_manager.close()
        self.discord_presence.close(timeout=0.25)
        super().closeEvent(event)
