from __future__ import annotations

from PySide6.QtCore import Qt, QUrl, Signal
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import (
    QComboBox, QGroupBox, QHBoxLayout, QLabel, QLineEdit, QListWidget,
    QListWidgetItem, QMessageBox, QPushButton, QVBoxLayout, QWidget,
)

from ..core.account_manager import AccountManager
from ..core import skins_manager


class AccountsTab(QWidget):
    operation_succeeded = Signal()
    profiles_changed = Signal()

    def __init__(self, profile_manager, settings_manager, i18n, parent=None):
        super().__init__(parent)
        self.pm = profile_manager
        self.settings_manager = settings_manager
        self.i18n = i18n
        self.manager = AccountManager(default_nickname=settings_manager.settings.default_nickname)

        root = QHBoxLayout(self)
        left = QVBoxLayout()
        self.title_label = QLabel()
        self.title_label.setObjectName("bigTitle")
        left.addWidget(self.title_label)
        self.account_list = QListWidget()
        self.account_list.currentItemChanged.connect(self._selected_changed)
        left.addWidget(self.account_list)
        add_row = QHBoxLayout()
        self.nickname_edit = QLineEdit()
        self.nickname_edit.setMaxLength(16)
        self.nickname_edit.returnPressed.connect(self.add_account)
        self.add_button = QPushButton()
        self.add_button.clicked.connect(self.add_account)
        add_row.addWidget(self.nickname_edit, stretch=1)
        add_row.addWidget(self.add_button)
        left.addLayout(add_row)
        self.remove_button = QPushButton()
        self.remove_button.clicked.connect(self.remove_account)
        left.addWidget(self.remove_button)
        root.addLayout(left, stretch=2)

        right = QVBoxLayout()
        self.offline_box = QGroupBox()
        offline_layout = QVBoxLayout(self.offline_box)
        self.offline_info = QLabel()
        self.offline_info.setWordWrap(True)
        offline_layout.addWidget(self.offline_info)
        self.profile_combo = QComboBox()
        offline_layout.addWidget(self.profile_combo)
        self.apply_button = QPushButton()
        self.apply_button.clicked.connect(self.apply_to_profile)
        offline_layout.addWidget(self.apply_button)
        right.addWidget(self.offline_box)
        self.microsoft_box = QGroupBox("Microsoft")
        microsoft_layout = QVBoxLayout(self.microsoft_box)
        self.microsoft_info = QLabel()
        self.microsoft_info.setWordWrap(True)
        microsoft_layout.addWidget(self.microsoft_info)
        self.microsoft_button = QPushButton()
        self.microsoft_button.clicked.connect(
            lambda: QDesktopServices.openUrl(QUrl(
                "https://www.minecraft.net/es-es/store/minecraft-java-bedrock-edition-pc"
            ))
        )
        microsoft_layout.addWidget(self.microsoft_button)
        right.addWidget(self.microsoft_box)
        self.kat_box = QGroupBox("Kat Social · Google")
        kat_layout = QVBoxLayout(self.kat_box)
        self.kat_info = QLabel()
        self.kat_info.setWordWrap(True)
        kat_layout.addWidget(self.kat_info)
        right.addWidget(self.kat_box)
        right.addStretch()
        root.addLayout(right, stretch=3)

        self.i18n.language_changed.connect(self.retranslate_ui)
        self.retranslate_ui()
        self.refresh_profiles()
        self.refresh_accounts()

    def retranslate_ui(self, *_args):
        t = self.i18n.t
        self.title_label.setText(t("Cuentas"))
        self.nickname_edit.setPlaceholderText(t("Nuevo nickname offline (Enter)"))
        self.add_button.setText(t("Añadir"))
        self.remove_button.setText(t("Eliminar cuenta"))
        self.offline_box.setTitle(t("Cuenta local / servidor offline"))
        self.offline_info.setText(t(
            "Estas identidades no envían contraseñas ni tokens. Elige una y aplícala al perfil con el que jugarás."
        ))
        self.apply_button.setText(t("Usar esta cuenta en el perfil"))
        self.microsoft_info.setText(t(
            "Las cuentas Premium siguen el acceso oficial de Microsoft/Xbox. KatLauncher no "
            "pedirá tu contraseña ni incrustará un Client Secret; mientras se aprueba su acceso "
            "directo, este botón abre la ruta oficial de Java & Bedrock."
        ))
        self.microsoft_button.setText(t("Abrir acceso Premium oficial"))
        self.kat_info.setText(t(
            "Tu sesión de Google pertenece a Kat Social (amigos y chat), no sustituye una licencia de Minecraft."
        ))

    def refresh_profiles(self):
        current = self.profile_combo.currentData()
        self.profile_combo.clear()
        for profile in self.pm.list_profiles():
            self.profile_combo.addItem(f"{profile.name} · {profile.nickname}", profile.id)
        index = self.profile_combo.findData(current)
        if index >= 0:
            self.profile_combo.setCurrentIndex(index)

    def refresh_accounts(self):
        self.account_list.clear()
        for account in self.manager.list():
            marker = "✓ " if account.id == self.manager.selected_id else ""
            row = QListWidgetItem(f"{marker}{account.nickname}\noffline · {account.player_uuid}")
            row.setData(Qt.UserRole, account.id)
            self.account_list.addItem(row)
            if account.id == self.manager.selected_id:
                self.account_list.setCurrentItem(row)

    def _selected_id(self):
        row = self.account_list.currentItem()
        return row.data(Qt.UserRole) if row else None

    def _selected_changed(self, *_args):
        identifier = self._selected_id()
        if identifier and identifier != self.manager.selected_id:
            try:
                self.manager.select(identifier)
            except (OSError, ValueError) as error:
                QMessageBox.warning(self, self.i18n.t("Error"), str(error))
                return
            self.refresh_accounts()

    def add_account(self):
        try:
            self.manager.add_offline(self.nickname_edit.text().strip())
        except (OSError, ValueError) as error:
            QMessageBox.warning(self, self.i18n.t("Error"), self.i18n.t(str(error)))
            return
        self.nickname_edit.clear()
        self.refresh_accounts()
        self.operation_succeeded.emit()

    def remove_account(self):
        try:
            self.manager.remove(self._selected_id())
        except (OSError, ValueError) as error:
            QMessageBox.warning(self, self.i18n.t("Error"), self.i18n.t(str(error)))
            return
        self.refresh_accounts()
        self.operation_succeeded.emit()

    def apply_to_profile(self):
        profile_id = self.profile_combo.currentData()
        if not profile_id:
            return
        skin_migration = None
        try:
            account = self.manager.selected()
            profile = self.pm.get(profile_id)
            if profile is None:
                raise ValueError("El perfil seleccionado ya no existe.")
            old_nickname = profile.nickname
            if account.nickname != old_nickname and profile.skin_path:
                skin_migration = skins_manager.stage_nickname_skin_migration(
                    profile.game_dir, old_nickname, account.nickname, profile.skin_path
                )
            self.pm.update_profile(profile_id, nickname=account.nickname, offline_uuid_mode="minecraft")
        except (OSError, ValueError, KeyError) as error:
            if skin_migration:
                try:
                    skin_migration.rollback()
                except OSError:
                    pass
            QMessageBox.warning(self, self.i18n.t("Error"), self.i18n.t(str(error)))
            return
        if skin_migration is not None:
            try:
                skin_migration.commit()
            except OSError:
                pass
        self.refresh_profiles()
        self.profiles_changed.emit()
        self.operation_succeeded.emit()
        QMessageBox.information(
            self, self.i18n.t("Guardado"),
            self.i18n.t("El perfil ahora jugará como {nickname}.", nickname=account.nickname),
        )
