from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QListWidget, QListWidgetItem, QLabel,
    QComboBox, QPushButton, QFileDialog, QMessageBox, QCheckBox, QLineEdit,
    QDialog, QDialogButtonBox, QStackedWidget,
)
from PySide6.QtCore import Qt, QThread, QTimer, QUrl, Signal, Slot
from PySide6.QtGui import QDesktopServices
from dataclasses import replace
from pathlib import Path

from ..core.profile_manager import ProfileManager
from ..core import mcstat_api, skins_manager
from .workers import CustomSkinLoaderWorker, SharedSkinWorker
from .worker_registry import WorkerRegistryMixin
from .skin_3d_widget import SkinPreview2D, SkinPreview3D, TexturePreview2D


class SkinLookupWorker(QThread):
    completed = Signal(str)
    failed = Signal(str)

    def __init__(self, skins_dir: str, username: str):
        super().__init__()
        self.skins_dir = skins_dir
        self.username = username

    def run(self):
        try:
            self.completed.emit(
                skins_manager.download_skin_by_username(self.skins_dir, self.username)
            )
        except Exception as error:
            self.failed.emit(str(error))


class McStatSearchWorker(QThread):
    completed = Signal(dict)
    failed = Signal(str)

    def __init__(self, search: str, model: str, catalog: str = "skins"):
        super().__init__()
        self.search = search
        self.model = model
        self.catalog = catalog

    def run(self):
        try:
            if self.catalog == "capes":
                result = mcstat_api.list_capes(self.search)
            else:
                result = mcstat_api.list_skins(self.search, model=self.model)
            self.completed.emit(result)
        except Exception as error:
            self.failed.emit(str(error))


class McStatDownloadWorker(QThread):
    completed = Signal(str)
    failed = Signal(str)

    def __init__(self, item: dict, profile, catalog: str):
        super().__init__()
        self.item = item
        self.profile = profile
        self.catalog = catalog

    def run(self):
        try:
            if self.catalog == "capes":
                payload = mcstat_api.fetch_skin_data(self.item)
                path = skins_manager.install_local_cosmetic_data_for_profile(
                    self.profile.game_dir, self.profile.nickname, payload, "cape"
                )
            else:
                path = mcstat_api.download_skin(
                    self.item, self.profile.skins_dir
                )
            self.completed.emit(path)
        except Exception as error:
            self.failed.emit(str(error))


class McStatPreviewWorker(QThread):
    completed = Signal(bytes, str)
    failed = Signal(str, str)

    def __init__(self, item: dict):
        super().__init__()
        self.item = item
        self.item_id = str(item.get("id") or item.get("png_url") or "")

    def run(self):
        try:
            self.completed.emit(
                mcstat_api.fetch_skin_data(self.item), self.item_id
            )
        except Exception as error:
            self.failed.emit(str(error), self.item_id)


class McStatSkinDialog(QDialog):
    skin_imported = Signal(str)
    cape_imported = Signal(str)

    def __init__(self, profile, i18n, parent=None):
        super().__init__(parent)
        self.profile = profile
        self.i18n = i18n
        self.search_worker = None
        self.download_worker = None
        self.preview_worker = None
        self._preview_pending = None
        self._preview_cache: dict[str, bytes] = {}
        self.setWindowTitle(self.i18n.t("Biblioteca de skins · MCStat"))
        self.resize(720, 520)
        root = QVBoxLayout(self)
        search_row = QHBoxLayout()
        self.catalog_combo = QComboBox()
        self.catalog_combo.addItem(self.i18n.t("Skins"), "skins")
        self.catalog_combo.addItem(self.i18n.t("Capas"), "capes")
        self.catalog_combo.currentIndexChanged.connect(self._catalog_changed)
        self.search_edit = QLineEdit()
        self.search_edit.setPlaceholderText(self.i18n.t("Buscar skins (Enter)"))
        self.search_edit.returnPressed.connect(self.search)
        self.model_combo = QComboBox()
        self.model_combo.addItem(self.i18n.t("Todos los modelos"), "")
        self.model_combo.addItem("Classic", "classic")
        self.model_combo.addItem("Slim", "slim")
        self.search_button = QPushButton(self.i18n.t("Buscar"))
        self.search_button.clicked.connect(self.search)
        search_row.addWidget(self.catalog_combo)
        search_row.addWidget(self.search_edit, 1)
        search_row.addWidget(self.model_combo)
        search_row.addWidget(self.search_button)
        root.addLayout(search_row)
        self.list = QListWidget()
        self.list.currentItemChanged.connect(self.preview_selected)
        self.list.itemDoubleClicked.connect(lambda _item: self.import_selected())
        content = QHBoxLayout()
        content.addWidget(self.list, 1)
        preview_column = QVBoxLayout()
        self.preview_title = QLabel(self.i18n.t("Vista previa 2D"))
        self.preview_title.setAlignment(Qt.AlignCenter)
        self.preview_stack = QStackedWidget()
        self.skin_preview = SkinPreview2D()
        self.cape_preview = TexturePreview2D()
        self.preview_stack.addWidget(self.skin_preview)
        self.preview_stack.addWidget(self.cape_preview)
        preview_column.addWidget(self.preview_title)
        preview_column.addWidget(self.preview_stack, 1)
        content.addLayout(preview_column)
        root.addLayout(content, 1)
        self.status = QLabel(self.i18n.t(
            "Pulsa Enter para buscar. Doble clic instala la skin en el perfil."
        ))
        self.status.setWordWrap(True)
        root.addWidget(self.status)
        buttons = QDialogButtonBox(QDialogButtonBox.Close)
        self.import_button = buttons.addButton(
            self.i18n.t("Añadir al perfil"), QDialogButtonBox.ActionRole
        )
        self.import_button.clicked.connect(self.import_selected)
        buttons.rejected.connect(self.reject)
        root.addWidget(buttons)
        QTimer.singleShot(0, self.search)

    def _catalog(self) -> str:
        return str(self.catalog_combo.currentData() or "skins")

    def _catalog_changed(self, _index):
        is_capes = self._catalog() == "capes"
        self.model_combo.setVisible(not is_capes)
        self.preview_stack.setCurrentWidget(
            self.cape_preview if is_capes else self.skin_preview
        )
        self.search_edit.setPlaceholderText(self.i18n.t(
            "Buscar capas (Enter)" if is_capes else "Buscar skins (Enter)"
        ))
        self.search()

    def search(self):
        if self.search_worker is not None:
            return
        self.search_button.setEnabled(False)
        self.catalog_combo.setEnabled(False)
        self.list.clear()
        self.status.setText(self.i18n.t("Consultando la biblioteca de MCStat…"))
        self.search_worker = McStatSearchWorker(
            self.search_edit.text().strip(),
            str(self.model_combo.currentData() or ""),
            self._catalog(),
        )
        self.search_worker.completed.connect(self._search_completed)
        self.search_worker.failed.connect(self._failed)
        self.search_worker.start()

    def preview_selected(self, current, _previous=None):
        if current is None:
            self.skin_preview.clear_skin()
            self.cape_preview.clear_texture()
            self.preview_title.setText(self.i18n.t("Vista previa 2D"))
            return
        item = current.data(Qt.UserRole) or {}
        item_id = str(item.get("id") or item.get("png_url") or "")
        cached = self._preview_cache.get(item_id)
        if cached is not None:
            self._show_preview_payload(cached, item)
            self.preview_title.setText(
                str(item.get("name") or self.i18n.t("Vista previa 2D"))
            )
            return
        self.preview_title.setText(
            self.i18n.t("Cargando vista previa…")
        )
        if self.preview_worker is not None:
            self._preview_pending = item
            return
        self._start_preview(item)

    def _start_preview(self, item: dict):
        self._preview_pending = None
        self.preview_worker = McStatPreviewWorker(item)
        self.preview_worker.completed.connect(self._preview_completed)
        self.preview_worker.failed.connect(self._preview_failed)
        self.preview_worker.start()

    def _show_preview_payload(self, payload: bytes, item: dict) -> bool:
        if self._catalog() == "capes":
            return self.cape_preview.load_texture_data(payload)
        return self.skin_preview.load_skin_data(
            payload, slim=str(item.get("model") or "") == "slim"
        )

    @Slot(bytes, str)
    def _preview_completed(self, payload: bytes, item_id: str):
        self.preview_worker = None
        current = self.list.currentItem()
        current_data = current.data(Qt.UserRole) if current is not None else {}
        current_id = str(
            (current_data or {}).get("id")
            or (current_data or {}).get("png_url") or ""
        )
        if current_id == item_id:
            self._preview_cache[item_id] = payload
            if self._show_preview_payload(payload, current_data or {}):
                self.preview_title.setText(
                    str((current_data or {}).get("name") or
                        self.i18n.t("Vista previa 2D"))
                )
        pending = self._preview_pending
        if pending is not None:
            self._start_preview(pending)

    @Slot(str, str)
    def _preview_failed(self, error: str, _item_id: str):
        self.preview_worker = None
        self.skin_preview.clear_skin()
        self.cape_preview.clear_texture()
        self.preview_title.setText(self.i18n.t(
            "No se pudo cargar la vista previa."
        ))
        pending = self._preview_pending
        if pending is not None:
            self._start_preview(pending)

    @Slot(dict)
    def _search_completed(self, result: dict):
        self.search_worker = None
        self.search_button.setEnabled(True)
        self.catalog_combo.setEnabled(True)
        catalog = self._catalog()
        entries = result.get(catalog) or []
        for entry in entries:
            tags = ", ".join(entry.get("tags") or [])
            model = "" if catalog == "capes" else \
                f"  ·  {entry.get('model', 'classic')}"
            item = QListWidgetItem(
                f"{entry.get('name', 'MCStat')}{model}"
                f"\n♥ {entry.get('likes', 0)}  ↓ {entry.get('downloads', 0)}"
                + (f"  ·  {tags}" if tags else "")
            )
            item.setData(Qt.UserRole, entry)
            self.list.addItem(item)
        if self.list.count():
            self.list.setCurrentRow(0)
        cached = self.i18n.t(" · caché local") if result.get("cached") else ""
        message = (
            "{count} capas encontradas{cached}. Doble clic para instalar."
            if catalog == "capes"
            else "{count} skins encontradas{cached}. Doble clic para añadir."
        )
        self.status.setText(self.i18n.t(
            message, count=self.list.count(), cached=cached
        ))

    def import_selected(self):
        item = self.list.currentItem()
        if item is None or self.download_worker is not None:
            return
        self.import_button.setEnabled(False)
        self.catalog_combo.setEnabled(False)
        self.status.setText(self.i18n.t(
            "Descargando capa…" if self._catalog() == "capes"
            else "Descargando skin…"
        ))
        self.download_worker = McStatDownloadWorker(
            item.data(Qt.UserRole), self.profile, self._catalog()
        )
        self.download_worker.completed.connect(self._download_completed)
        self.download_worker.failed.connect(self._failed)
        self.download_worker.start()

    @Slot(str)
    def _download_completed(self, path: str):
        catalog = self._catalog()
        self.download_worker = None
        self.import_button.setEnabled(True)
        self.catalog_combo.setEnabled(True)
        if catalog == "capes":
            self.status.setText(self.i18n.t(
                "Capa instalada para este perfil con CustomSkinLoader."
            ))
            self.cape_imported.emit(path)
        else:
            self.status.setText(self.i18n.t(
                "Skin añadida. Puedes instalar otra o cerrar la biblioteca."
            ))
            self.skin_imported.emit(path)

    @Slot(str)
    def _failed(self, error: str):
        self.search_worker = None
        self.download_worker = None
        self.search_button.setEnabled(True)
        self.import_button.setEnabled(True)
        self.catalog_combo.setEnabled(True)
        self.status.setText(self.i18n.t(str(error)))

    def closeEvent(self, event):
        if self.search_worker is not None or self.download_worker is not None \
                or self.preview_worker is not None:
            self.status.setText(self.i18n.t(
                "Espera a que termine la operación antes de cerrar."
            ))
            event.ignore()
            return
        super().closeEvent(event)


class SkinsTab(WorkerRegistryMixin, QWidget):
    operation_succeeded = Signal()

    def __init__(
        self, profile_manager: ProfileManager, settings_manager, i18n,
        social_service=None, parent=None,
    ):
        super().__init__(parent)
        self._init_worker_registry()
        self.pm = profile_manager
        self.settings_manager = settings_manager
        self.i18n = i18n
        self.social_service = social_service

        layout = QVBoxLayout(self)
        self.intro_label = QLabel()
        layout.addWidget(self.intro_label)

        self.info_label = QLabel()
        self.info_label.setWordWrap(True)
        layout.addWidget(self.info_label)

        top_row = QHBoxLayout()
        self.profile_label = QLabel()
        top_row.addWidget(self.profile_label)
        self.profile_combo = QComboBox()
        self.profile_combo.currentIndexChanged.connect(self.refresh_skins)
        top_row.addWidget(self.profile_combo, stretch=1)
        layout.addLayout(top_row)

        lookup_row = QHBoxLayout()
        self.username_edit = QLineEdit()
        self.username_edit.setMaxLength(16)
        self.username_edit.setPlaceholderText("Usuario Premium (Enter)")
        self.username_edit.returnPressed.connect(self.on_lookup_username)
        self.lookup_btn = QPushButton("Copiar skin del usuario")
        self.lookup_btn.clicked.connect(self.on_lookup_username)
        self.namemc_btn = QPushButton("Explorar NameMC")
        self.namemc_btn.clicked.connect(self.open_namemc)
        self.library_btn = QPushButton("Biblioteca MCStat")
        self.library_btn.clicked.connect(self.open_mcstat_library)
        lookup_row.addWidget(self.username_edit, 1)
        lookup_row.addWidget(self.lookup_btn)
        lookup_row.addWidget(self.namemc_btn)
        lookup_row.addWidget(self.library_btn)
        layout.addLayout(lookup_row)

        body = QHBoxLayout()
        self.skins_list = QListWidget()
        self.skins_list.currentItemChanged.connect(self.show_preview)
        body.addWidget(self.skins_list, stretch=1)

        preview_col = QVBoxLayout()
        self.preview = SkinPreview3D()
        preview_col.addWidget(self.preview, stretch=1)
        model_row = QHBoxLayout()
        self.model_combo = QComboBox()
        self.model_combo.addItem("Classic · 4 px", False)
        self.model_combo.addItem("Slim · 3 px", True)
        self.model_combo.currentIndexChanged.connect(
            lambda _index: self.preview.set_slim(bool(self.model_combo.currentData()))
        )
        self.reset_view_btn = QPushButton()
        self.reset_view_btn.clicked.connect(self.preview.reset_view)
        model_row.addWidget(self.model_combo)
        model_row.addWidget(self.reset_view_btn)
        preview_col.addLayout(model_row)
        preview_col.addStretch()
        body.addLayout(preview_col)

        layout.addLayout(body, stretch=1)

        self.auto_csl_check = QCheckBox()
        self.auto_csl_check.setChecked(
            self.settings_manager.settings.auto_install_custom_skin_loader
        )
        layout.addWidget(self.auto_csl_check)

        self.status_label = QLabel("")
        self.status_label.setWordWrap(True)
        layout.addWidget(self.status_label)

        btn_row = QHBoxLayout()
        self.add_btn = QPushButton()
        self.add_btn.clicked.connect(self.on_add_skin)
        self.set_btn = QPushButton()
        self.set_btn.clicked.connect(self.on_set_active)
        self.remove_btn = QPushButton()
        self.remove_btn.clicked.connect(self.on_remove_skin)
        btn_row.addWidget(self.add_btn)
        btn_row.addWidget(self.set_btn)
        btn_row.addWidget(self.remove_btn)
        layout.addLayout(btn_row)

        cosmetic_row = QHBoxLayout()
        self.cape_btn = QPushButton()
        self.cape_btn.clicked.connect(lambda: self.on_add_cosmetic("cape"))
        self.remove_cape_btn = QPushButton()
        self.remove_cape_btn.clicked.connect(lambda: self.on_remove_cosmetic("cape"))
        self.elytra_btn = QPushButton()
        self.elytra_btn.clicked.connect(lambda: self.on_add_cosmetic("elytra"))
        self.remove_elytra_btn = QPushButton()
        self.remove_elytra_btn.clicked.connect(lambda: self.on_remove_cosmetic("elytra"))
        for button in (
            self.cape_btn, self.remove_cape_btn,
            self.elytra_btn, self.remove_elytra_btn,
        ):
            cosmetic_row.addWidget(button)
        layout.addLayout(cosmetic_row)

        self.csl_worker = None
        self.shared_worker = None
        self.lookup_worker = None
        self.i18n.language_changed.connect(self.retranslate_ui)
        self.retranslate_ui()
        self.refresh_profiles()

    def retranslate_ui(self, *_args):
        t = self.i18n.t
        self.intro_label.setText(t("Skins locales por perfil"))
        self.info_label.setText(t(
            "ℹ Al marcar una skin como 'activa', KatLauncher la instala en la carpeta local de CustomSkinLoader y fuerza su configuración a usar SOLO esa carpeta (sin consultar Mojang ni servidores de terceros por tu nickname). Esto evita que te aparezca la skin de otra cuenta real que use el mismo nombre que tú."
        ))
        self.profile_label.setText(t("Perfil:"))
        self.username_edit.setPlaceholderText(t("Usuario Premium (Enter)"))
        self.model_combo.setItemText(0, t("Classic · 4 px"))
        self.model_combo.setItemText(1, t("Slim · 3 px"))
        self.reset_view_btn.setText(t("Centrar vista 3D"))
        self.auto_csl_check.setText(t(
            "Auto-instalar CustomSkinLoader al marcar una skin como activa"
        ))
        self.add_btn.setText(t("➕ Añadir skin (.png)"))
        self.set_btn.setText(t("⭐ Marcar como activa"))
        self.remove_btn.setText(t("🗑 Eliminar"))
        self.lookup_btn.setText(t("Copiar skin del usuario"))
        self.namemc_btn.setText(t("Explorar NameMC"))
        self.library_btn.setText(t("Biblioteca MCStat"))
        self.cape_btn.setText(t("Añadir capa local"))
        self.remove_cape_btn.setText(t("Quitar capa"))
        self.elytra_btn.setText(t("Añadir élitros locales"))
        self.remove_elytra_btn.setText(t("Quitar élitros"))

    def refresh_settings(self):
        self.auto_csl_check.setChecked(
            self.settings_manager.settings.auto_install_custom_skin_loader
        )

    def refresh_profiles(self):
        current = self.profile_combo.currentData()
        self.profile_combo.blockSignals(True)
        self.profile_combo.clear()
        for p in self.pm.list_profiles():
            self.profile_combo.addItem(p.name, p.id)
        self.profile_combo.blockSignals(False)
        if current:
            idx = self.profile_combo.findData(current)
            if idx >= 0:
                self.profile_combo.setCurrentIndex(idx)
        self.refresh_skins()

    def _selected_profile(self):
        pid = self.profile_combo.currentData()
        return self.pm.get(pid) if pid else None

    def refresh_skins(self):
        self.skins_list.clear()
        profile = self._selected_profile()
        if not profile:
            return
        for skin in skins_manager.list_skins(profile.skins_dir):
            item = QListWidgetItem(skin.filename)
            item.setData(Qt.UserRole, skin.path)
            self.skins_list.addItem(item)

    def show_preview(self, current, previous):
        if not current:
            self.preview.clear_skin()
            return
        path = current.data(Qt.UserRole)
        if not self.preview.load_skin(path):
            self.status_label.setText(self.i18n.t("No se pudo cargar"))

    def on_add_skin(self):
        profile = self._selected_profile()
        if not profile:
            return
        files, _ = QFileDialog.getOpenFileNames(
            self, self.i18n.t("Selecciona imágenes PNG"), "", "Skins (*.png)"
        )
        added = 0
        failed = False
        for f in files:
            try:
                skins_manager.add_skin(profile.skins_dir, f)
                added += 1
            except Exception as e:
                failed = True
                QMessageBox.warning(self, self.i18n.t("Error"), self.i18n.t(str(e)))
        self.refresh_skins()
        if added and not failed:
            self.operation_succeeded.emit()

    def open_namemc(self):
        query = self.username_edit.text().strip()
        url = "https://namemc.com/" if not query else f"https://namemc.com/search?q={query}"
        QDesktopServices.openUrl(QUrl(url))

    def open_mcstat_library(self):
        profile = self._selected_profile()
        if profile is None:
            return
        dialog = McStatSkinDialog(profile, self.i18n, self)
        dialog.skin_imported.connect(self._on_mcstat_skin_imported)
        dialog.cape_imported.connect(self._on_mcstat_cape_imported)
        dialog.exec()

    @Slot(str)
    def _on_mcstat_skin_imported(self, path: str):
        self.refresh_skins()
        matches = self.skins_list.findItems(Path(path).name, Qt.MatchExactly)
        if matches:
            self.skins_list.setCurrentItem(matches[0])
        self.operation_succeeded.emit()

    @Slot(str)
    def _on_mcstat_cape_imported(self, path: str):
        self.status_label.setText(self.i18n.t(
            "Capa de MCStat instalada en {path}.", path=path
        ))
        self.operation_succeeded.emit()

    def on_lookup_username(self):
        profile = self._selected_profile()
        username = self.username_edit.text().strip()
        if not profile or not username or self.lookup_worker:
            return
        self.lookup_btn.setEnabled(False)
        self.username_edit.setEnabled(False)
        self.status_label.setText(self.i18n.t("Buscando skin pública de {username}...", username=username))
        self.lookup_worker = self._track_worker(
            SkinLookupWorker(profile.skins_dir, username)
        )
        self.lookup_worker.completed.connect(self._on_lookup_completed)
        self.lookup_worker.failed.connect(self._on_lookup_failed)
        self.lookup_worker.start()

    @Slot(str)
    def _on_lookup_completed(self, path):
        self.lookup_worker = None
        self.lookup_btn.setEnabled(True)
        self.username_edit.setEnabled(True)
        self.refresh_skins()
        matches = self.skins_list.findItems(Path(path).name, Qt.MatchExactly)
        if matches:
            self.skins_list.setCurrentItem(matches[0])
        self.status_label.setText(self.i18n.t(
            "Skin pública copiada. Revísala en 3D y pulsa Marcar como activa."
        ))
        self.operation_succeeded.emit()

    @Slot(str)
    def _on_lookup_failed(self, error):
        self.lookup_worker = None
        self.lookup_btn.setEnabled(True)
        self.username_edit.setEnabled(True)
        self.status_label.setText(self.i18n.t("No se pudo copiar la skin: {error}", error=error))

    def on_set_active(self):
        profile = self._selected_profile()
        item = self.skins_list.currentItem()
        if not profile or not item:
            return
        skin_source = item.data(Qt.UserRole)

        # Vista previa interna (KatLauncher)
        try:
            skins_manager.set_active_skin(profile.skins_dir, skin_source)
            self.pm.update_profile(profile.id, skin_path=skin_source)

        # Instalación real para CustomSkinLoader: copia la skin al path
        # legacy LocalSkin/skins/<nickname>.png y fuerza el loadlist a
        # 'solo local', para que nunca te traiga la skin de otra cuenta
        # que comparta tu nickname (esto es lo que causaba skins random
        # como la de Jack Black).
            shared_root = (
                self.social_service.shared_skin_root
                if self.social_service is not None and self.social_service.configured
                else ""
            )
            skins_manager.install_local_skin_for_profile(
                profile.game_dir, profile.nickname, skin_source, shared_root
            )
        except (OSError, ValueError) as error:
            QMessageBox.warning(self, self.i18n.t("Error"), self.i18n.t(str(error)))
            return
        self.status_label.setText(self.i18n.t(
            "⭐ '{name}' establecida como skin activa para este perfil.\nInstalada en: CustomSkinLoader/LocalSkin/skins/{nickname}.png",
            name=item.text(), nickname=profile.nickname,
        ))
        self.operation_succeeded.emit()

        if self.social_service is not None and self.social_service.session:
            self.status_label.setText(
                self.status_label.text()
                + self.i18n.t("\nPublicando en KatSkin para tus amigos...")
            )
            model = "slim" if bool(self.model_combo.currentData()) else "classic"
            self.shared_worker = self._track_worker(SharedSkinWorker(
                self.social_service, profile.nickname, skin_source, model
            ))
            self.shared_worker.published.connect(self._on_shared_published)
            self.shared_worker.failed.connect(self._on_shared_failed)
            self.shared_worker.start()
        else:
            self.status_label.setText(
                self.status_label.text()
                + self.i18n.t(
                    "\nInicia sesión en Kat Social para que otros KatLauncher vean esta skin."
                )
            )

        if not self.auto_csl_check.isChecked():
            return
        if profile.loader == "vanilla":
            self.status_label.setText(self.status_label.text() + self.i18n.t(
                "\n⚠ Para verla en juego necesitas usar un loader compatible e instalar CustomSkinLoader (pestaña Mods)."
            ))
            return
        if not profile.version:
            return

        self.status_label.setText(
            self.status_label.text() + self.i18n.t("\nComprobando CustomSkinLoader...")
        )
        self.set_btn.setEnabled(False)
        self.profile_combo.setEnabled(False)
        self.csl_worker = self._track_worker(CustomSkinLoaderWorker(replace(profile)))
        self.csl_worker.installed.connect(self._on_csl_installed)
        self.csl_worker.failed.connect(self._on_csl_failed)
        self.csl_worker.start()

    @Slot(str)
    def activate_from_katcraft(self, skin_source: str):
        """Aplica una skin solicitada dentro del juego sin abrir otro diálogo."""
        source = Path(str(skin_source or ""))
        profile = next((
            item for item in self.pm.list_profiles()
            if source.parent == Path(item.skins_dir)
        ), None)
        if profile is None or not source.is_file():
            return
        try:
            skins_manager.set_active_skin(profile.skins_dir, str(source))
            self.pm.update_profile(profile.id, skin_path=str(source))
            shared_root = (
                self.social_service.shared_skin_root
                if self.social_service is not None and self.social_service.configured
                else ""
            )
            skins_manager.install_local_skin_for_profile(
                profile.game_dir, profile.nickname, str(source), shared_root
            )
        except (OSError, ValueError):
            return
        self.refresh_skins()
        self.operation_succeeded.emit()
        if self.social_service is not None and self.social_service.session:
            self.shared_worker = self._track_worker(SharedSkinWorker(
                self.social_service, profile.nickname, str(source), "auto"
            ))
            self.shared_worker.published.connect(self._on_shared_published)
            self.shared_worker.failed.connect(self._on_shared_failed)
            self.shared_worker.start()

    @Slot(object)
    def _on_shared_published(self, _profile):
        self.shared_worker = None
        self.status_label.setText(
            self.status_label.text()
            + self.i18n.t("\n✅ KatSkin publicada y compartida.")
        )

    @Slot(str)
    def _on_shared_failed(self, error):
        self.shared_worker = None
        self.status_label.setText(
            self.status_label.text()
            + self.i18n.t(
                "\n⚠ La skin local funciona, pero KatSkin no pudo publicarse: {error}",
                error=self.i18n.t(str(error)),
            )
        )

    @Slot(str)
    def _on_csl_installed(self, path):
        self.csl_worker = None
        self.status_label.setText(self.i18n.t(
            "✅ CustomSkinLoader instalado ({filename}). Ya puedes lanzar el juego con tu skin activa.",
            filename=Path(path).name,
        ))
        self.set_btn.setEnabled(True)
        self.profile_combo.setEnabled(True)

    @Slot(str)
    def _on_csl_failed(self, error):
        self.csl_worker = None
        self.status_label.setText(self.i18n.t(
            "❌ No se pudo auto-instalar CustomSkinLoader: {error}",
            error=self.i18n.t(str(error))
        ))
        self.set_btn.setEnabled(True)
        self.profile_combo.setEnabled(True)

    def on_remove_skin(self):
        item = self.skins_list.currentItem()
        if not item:
            return
        profile = self._selected_profile()
        path = item.data(Qt.UserRole)
        try:
            is_active = bool(profile and Path(profile.skin_path) == Path(path))
            if is_active:
                skins_manager.clear_active_skin(
                    profile.skins_dir, profile.game_dir, profile.nickname
                )
                self.pm.update_profile(profile.id, skin_path="")
            skins_manager.remove_skin(path)
        except (OSError, ValueError) as error:
            QMessageBox.warning(self, self.i18n.t("Error"), self.i18n.t(str(error)))
            return
        self.refresh_skins()
        self.operation_succeeded.emit()

    def on_add_cosmetic(self, cosmetic: str):
        profile = self._selected_profile()
        if not profile:
            return
        label = "capa" if cosmetic == "cape" else "élitros"
        source, _ = QFileDialog.getOpenFileName(
            self, self.i18n.t(f"Selecciona PNG de {label}"), "", "PNG (*.png)"
        )
        if not source:
            return
        try:
            destination = skins_manager.install_local_cosmetic_for_profile(
                profile.game_dir, profile.nickname, source, cosmetic
            )
        except (OSError, ValueError) as error:
            QMessageBox.warning(self, self.i18n.t("Error"), self.i18n.t(str(error)))
            return
        self.status_label.setText(self.i18n.t(
            "Cosmético local instalado en {path}. Los demás jugadores necesitan un mod compatible para verlo.",
            path=destination,
        ))
        self.operation_succeeded.emit()

    def on_remove_cosmetic(self, cosmetic: str):
        profile = self._selected_profile()
        if not profile:
            return
        try:
            skins_manager.remove_local_cosmetic(
                profile.game_dir, profile.nickname, cosmetic
            )
        except (OSError, ValueError) as error:
            QMessageBox.warning(self, self.i18n.t("Error"), self.i18n.t(str(error)))
            return
        self.status_label.setText(self.i18n.t("Cosmético local eliminado."))
        self.operation_succeeded.emit()
