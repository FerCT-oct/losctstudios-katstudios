from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QListWidget, QListWidgetItem, QLabel,
    QComboBox, QPushButton, QFileDialog, QMessageBox, QLineEdit, QGroupBox,
    QSplitter, QDialog, QDialogButtonBox, QInputDialog
)
from PySide6.QtCore import Qt, Signal, Slot, QThread, QSize, QUrl
from PySide6.QtGui import QIcon, QPixmap, QDesktopServices
from pathlib import Path
from dataclasses import replace

from ..core.profile_manager import ProfileManager
from ..core import curseforge_api, mods_manager, modrinth_media
from .workers import (
    CurseForgeInstallWorker, CurseForgeSearchWorker, ModrinthSearchWorker,
    ModrinthInstallWorker, CustomSkinLoaderWorker, ModsUpdateWorker,
)
from .worker_registry import WorkerRegistryMixin


class RemoteCoverWorker(QThread):
    icon_ready = Signal(int, str, bytes)

    def __init__(self, hits):
        super().__init__()
        self.hits = list(hits)

    def run(self):
        for index, hit in enumerate(self.hits):
            if self.isInterruptionRequested():
                return
            try:
                url = str(hit.get("icon_url") or "")
                payload = (curseforge_api.fetch_icon(url)
                           if hit.get("provider") == "curseforge"
                           else modrinth_media.fetch_icon(url))
            except Exception:
                continue
            self.icon_ready.emit(index, url, payload)


class ModsTab(WorkerRegistryMixin, QWidget):
    operation_succeeded = Signal()
    mod_installed = Signal()

    def __init__(self, profile_manager: ProfileManager, i18n, parent=None):
        super().__init__(parent)
        self._init_worker_registry()
        self.pm = profile_manager
        self.i18n = i18n
        self._search_hits = []
        self.search_worker = None
        self.install_worker = None
        self.csl_worker = None
        self.update_worker = None
        self.cover_worker = None

        layout = QVBoxLayout(self)
        self.intro_label = QLabel()
        layout.addWidget(self.intro_label)

        top_row = QHBoxLayout()
        self.profile_label = QLabel()
        top_row.addWidget(self.profile_label)
        self.profile_combo = QComboBox()
        self.profile_combo.currentIndexChanged.connect(self.refresh_mods)
        top_row.addWidget(self.profile_combo, stretch=1)

        self.content_label = QLabel()
        top_row.addWidget(self.content_label)
        self.content_combo = QComboBox()
        self.content_combo.addItem("Mods", "mod")
        self.content_combo.addItem("Paquetes de recursos", "resourcepack")
        self.content_combo.addItem("Shaders", "shader")
        self.content_combo.currentIndexChanged.connect(self._on_content_changed)
        top_row.addWidget(self.content_combo)

        self.csl_button = QPushButton()
        self.csl_button.clicked.connect(self.on_install_customskinloader)
        top_row.addWidget(self.csl_button)
        self.update_all_button = QPushButton("Actualizar todos los mods")
        self.update_all_button.clicked.connect(self.on_update_all)
        top_row.addWidget(self.update_all_button)
        layout.addLayout(top_row)

        self.warning_label = QLabel()
        self.warning_label.setWordWrap(True)
        layout.addWidget(self.warning_label)

        self.status_label = QLabel("")
        self.status_label.setWordWrap(True)
        layout.addWidget(self.status_label)

        splitter = QSplitter(Qt.Horizontal)

        # --- Columna izquierda: mods instalados ---
        self.installed_box = QGroupBox()
        installed_layout = QVBoxLayout(self.installed_box)
        self.mods_list = QListWidget()
        installed_layout.addWidget(self.mods_list)

        btn_row = QHBoxLayout()
        self.add_btn = QPushButton()
        self.add_btn.clicked.connect(self.on_add_mod)
        self.toggle_btn = QPushButton()
        self.toggle_btn.clicked.connect(self.on_toggle_mod)
        self.remove_btn = QPushButton()
        self.remove_btn.clicked.connect(self.on_remove_mod)
        btn_row.addWidget(self.add_btn)
        btn_row.addWidget(self.toggle_btn)
        btn_row.addWidget(self.remove_btn)
        installed_layout.addLayout(btn_row)
        splitter.addWidget(self.installed_box)

        # --- Columna derecha: catálogos remotos ---
        self.modrinth_box = QGroupBox()
        modrinth_layout = QVBoxLayout(self.modrinth_box)

        provider_row = QHBoxLayout()
        self.provider_label = QLabel()
        self.provider_combo = QComboBox()
        self.provider_combo.addItem("Modrinth", "modrinth")
        self.provider_combo.addItem("CurseForge", "curseforge")
        self.provider_combo.currentIndexChanged.connect(self._on_provider_changed)
        self.curseforge_key_btn = QPushButton()
        self.curseforge_key_btn.clicked.connect(self.configure_curseforge_key)
        provider_row.addWidget(self.provider_label)
        provider_row.addWidget(self.provider_combo, 1)
        provider_row.addWidget(self.curseforge_key_btn)
        modrinth_layout.addLayout(provider_row)

        search_row = QHBoxLayout()
        self.search_edit = QLineEdit()
        self.search_edit.returnPressed.connect(self.on_search)
        self.search_btn = QPushButton()
        self.search_btn.clicked.connect(self.on_search)
        search_row.addWidget(self.search_edit, stretch=1)
        search_row.addWidget(self.search_btn)
        modrinth_layout.addLayout(search_row)

        self.results_list = QListWidget()
        self.results_list.setIconSize(QSize(56, 56))
        self.results_list.itemDoubleClicked.connect(self.show_project_details)
        modrinth_layout.addWidget(self.results_list, stretch=1)

        self.install_btn = QPushButton()
        self.install_btn.clicked.connect(self.on_install_selected)
        modrinth_layout.addWidget(self.install_btn)

        splitter.addWidget(self.modrinth_box)
        splitter.setStretchFactor(0, 1)
        splitter.setStretchFactor(1, 1)

        layout.addWidget(splitter, stretch=1)

        self.i18n.language_changed.connect(self.retranslate_ui)
        self.retranslate_ui()
        self.refresh_profiles()

    def retranslate_ui(self, *_args):
        t = self.i18n.t
        self.intro_label.setText(t(
            "Biblioteca Kat por perfil — mods, recursos y shaders desde Modrinth"
        ))
        self.profile_label.setText(t("Perfil:"))
        self.content_label.setText(t("Contenido:"))
        labels = {
            "mod": t("Mods"),
            "resourcepack": t("Paquetes de recursos"),
            "shader": t("Shaders"),
        }
        for index in range(self.content_combo.count()):
            self.content_combo.setItemText(
                index, labels.get(self.content_combo.itemData(index), "?")
            )
        self.csl_button.setText(t("🧑‍🎨 Auto-instalar CustomSkinLoader"))
        self.update_all_button.setText(t("Actualizar todos los mods"))
        self.warning_label.setText(t(
            "⚠ Los mods (y CustomSkinLoader) requieren un perfil con mod loader y una versión asignada (configúralo en la pestaña Perfiles)."
        ))
        self._update_content_labels()
        self.toggle_btn.setText(t("🔁 Activar/Desactivar"))
        self.remove_btn.setText(t("🗑 Eliminar"))
        self.provider_label.setText(t("Fuente:"))
        self.curseforge_key_btn.setText(t("Configurar API key"))
        self._update_provider_labels()
        self.search_btn.setText(t("🔍 Buscar"))
        self.install_btn.setText(t("⬇ Instalar seleccionado"))
        self._render_results()

    # ---------------------------------------------------------------
    def _project_type(self) -> str:
        return self.content_combo.currentData() or "mod"

    def _content_dir(self, profile) -> str:
        return mods_manager.content_directory(profile.game_dir, self._project_type())

    def _update_content_labels(self):
        if not hasattr(self, "installed_box"):
            return
        t = self.i18n.t
        project_type = self._project_type()
        titles = {
            "mod": t("Mods instalados"),
            "resourcepack": t("Paquetes de recursos instalados"),
            "shader": t("Shaders instalados"),
        }
        placeholders = {
            "mod": t("Nombre del mod, p. ej. 'Sodium'"),
            "resourcepack": t("Nombre del paquete de recursos"),
            "shader": t("Nombre del shader, p. ej. 'Complementary'"),
        }
        suffix = mods_manager.CONTENT_SUFFIXES[project_type]
        self.installed_box.setTitle(titles[project_type])
        self.search_edit.setPlaceholderText(placeholders[project_type])
        self.add_btn.setText(t("➕ Añadir {suffix}", suffix=suffix))

    def _on_content_changed(self, *_args):
        self._search_hits = []
        self.results_list.clear()
        self.status_label.clear()
        self._update_content_labels()
        self.refresh_mods()

    def _provider(self) -> str:
        return self.provider_combo.currentData() or "modrinth"

    def _update_provider_labels(self):
        if not hasattr(self, "provider_combo"):
            return
        provider_name = "CurseForge" if self._provider() == "curseforge" else "Modrinth"
        self.modrinth_box.setTitle(self.i18n.t(
            "Buscar en {provider}", provider=provider_name
        ))
        self.curseforge_key_btn.setVisible(self._provider() == "curseforge")

    def _on_provider_changed(self, *_args):
        self._search_hits = []
        self.results_list.clear()
        self.status_label.clear()
        self._update_provider_labels()

    def configure_curseforge_key(self):
        try:
            current = curseforge_api.api_key()
        except curseforge_api.CurseForgeError:
            current = ""
        value, accepted = QInputDialog.getText(
            self, self.i18n.t("API key de CurseForge"),
            self.i18n.t("Pega tu API key oficial (vacío = eliminar):"),
            QLineEdit.Password, current,
        )
        if not accepted:
            return
        try:
            curseforge_api.save_api_key(value)
            message = ("✅ API key de CurseForge guardada localmente."
                       if value.strip() else "API key de CurseForge eliminada.")
            self.status_label.setText(self.i18n.t(message))
        except Exception as error:
            self.status_label.setText(self.i18n.t("❌ {error}", error=str(error)))

    def refresh_profiles(self):
        current = self.profile_combo.currentData()
        self.profile_combo.blockSignals(True)
        self.profile_combo.clear()
        for p in self.pm.list_profiles():
            self.profile_combo.addItem(p.name, p.id)
        self.profile_combo.blockSignals(False)
        if current:
            idx = self.profile_combo.findData(current)
            if idx >= 0:
                self.profile_combo.setCurrentIndex(idx)
        self.refresh_mods()

    def _selected_profile(self):
        pid = self.profile_combo.currentData()
        return self.pm.get(pid) if pid else None

    def refresh_mods(self):
        self.mods_list.clear()
        profile = self._selected_profile()
        if not profile:
            return
        project_type = self._project_type()
        self.warning_label.setVisible(
            not profile.version
            or (project_type == "mod" and profile.loader == "vanilla")
        )
        content_dir = self._content_dir(profile)
        for mod in mods_manager.list_content(content_dir, project_type):
            status = "✅" if mod.enabled else "⏸"
            item = QListWidgetItem(f"{status}  {mod.filename}   ({mod.size_kb} KB)")
            item.setData(Qt.UserRole, mod.path)
            self.mods_list.addItem(item)
        is_mod = project_type == "mod"
        self.csl_button.setVisible(is_mod)
        self.update_all_button.setVisible(is_mod)

    # --- mods locales -------------------------------------------------
    def on_add_mod(self):
        profile = self._selected_profile()
        if not profile:
            return
        project_type = self._project_type()
        suffix = mods_manager.CONTENT_SUFFIXES[project_type]
        files, _ = QFileDialog.getOpenFileNames(
            self,
            self.i18n.t("Selecciona archivos {suffix}", suffix=suffix),
            "",
            f"Contenido (*{suffix})",
        )
        added = 0
        failed = False
        for f in files:
            try:
                mods_manager.add_content(
                    self._content_dir(profile), f, project_type
                )
                added += 1
            except Exception as e:
                failed = True
                QMessageBox.warning(self, self.i18n.t("Error"), self.i18n.t(str(e)))
        self.refresh_mods()
        if added and not failed:
            self.operation_succeeded.emit()

    def on_toggle_mod(self):
        item = self.mods_list.currentItem()
        if not item:
            return
        try:
            mods_manager.toggle_content(item.data(Qt.UserRole))
        except OSError as error:
            QMessageBox.warning(self, self.i18n.t("Error"), self.i18n.t(str(error)))
            return
        self.refresh_mods()
        self.operation_succeeded.emit()

    def on_remove_mod(self):
        item = self.mods_list.currentItem()
        if not item:
            return
        try:
            mods_manager.remove_mod(item.data(Qt.UserRole))
        except OSError as error:
            QMessageBox.warning(self, self.i18n.t("Error"), self.i18n.t(str(error)))
            return
        self.refresh_mods()
        self.operation_succeeded.emit()

    # --- búsqueda/instalación desde Modrinth --------------------------
    def _check_ready_for_modrinth(self, profile) -> bool:
        if not profile:
            self.status_label.setText(self.i18n.t("⚠ Selecciona un perfil primero."))
            return False
        if self._project_type() == "mod" and profile.loader == "vanilla":
            self.status_label.setText(self.i18n.t(
                "⚠ Cambia el perfil a un loader compatible para instalar mods."
            ))
            return False
        if not profile.version:
            self.status_label.setText(self.i18n.t(
                "⚠ Este perfil no tiene una versión de Minecraft asignada."
            ))
            return False
        return True

    def on_search(self):
        profile = self._selected_profile()
        if not self._check_ready_for_modrinth(profile):
            return
        query = self.search_edit.text().strip()
        if not query:
            return
        if self.cover_worker:
            self.cover_worker.requestInterruption()
        self._search_hits = []
        self.results_list.clear()
        self._set_remote_busy(True)
        provider = self._provider()
        provider_name = "CurseForge" if provider == "curseforge" else "Modrinth"
        self.status_label.setText(self.i18n.t(
            "Buscando '{query}' en {provider}...", query=query,
            provider=provider_name,
        ))
        worker_class = (CurseForgeSearchWorker if provider == "curseforge"
                        else ModrinthSearchWorker)
        self.search_worker = self._track_worker(
            worker_class(
                query, profile.loader, profile.version, self._project_type()
            )
        )
        self.search_worker.results.connect(self._on_search_results)
        self.search_worker.failed.connect(self._on_search_failed)
        self.search_worker.start()

    @Slot(list)
    def _on_search_results(self, hits):
        self.search_worker = None
        self._set_remote_busy(False)
        self._search_hits = hits
        self._render_results()
        self._start_cover_loading()
        if not hits:
            self.status_label.setText(self.i18n.t(
                "Sin resultados compatibles con este loader/versión."
            ))
            return
        self.status_label.setText(self.i18n.t("{count} resultados.", count=len(hits)))

    def _render_results(self):
        if not hasattr(self, "results_list"):
            return
        self.results_list.clear()
        for hit in self._search_hits:
            title = hit.get("title", "?")
            author = hit.get("author", "")
            downloads = hit.get("downloads", 0)
            item = QListWidgetItem(self.i18n.t(
                "{title}  —  {author}  ({downloads} descargas)",
                title=title, author=author, downloads=self.i18n.number(downloads),
            ))
            item.setData(Qt.UserRole, hit)
            item.setSizeHint(QSize(0, 68))
            self.results_list.addItem(item)

    def _start_cover_loading(self):
        if self.cover_worker:
            self.cover_worker.requestInterruption()
            self.cover_worker = None
        if not self._search_hits:
            return
        self.cover_worker = self._track_worker(RemoteCoverWorker(self._search_hits))
        self.cover_worker.icon_ready.connect(self._on_cover_ready)
        worker = self.cover_worker
        self.cover_worker.finished.connect(
            lambda worker=worker: self._on_covers_finished(worker)
        )
        self.cover_worker.start()

    @Slot(int, str, bytes)
    def _on_cover_ready(self, index, url, payload):
        if not 0 <= index < self.results_list.count():
            return
        hit = self.results_list.item(index).data(Qt.UserRole) or {}
        if str(hit.get("icon_url") or "") != url:
            return
        pixmap = QPixmap()
        if pixmap.loadFromData(payload):
            self.results_list.item(index).setIcon(QIcon(pixmap))

    def _on_covers_finished(self, worker):
        if self.cover_worker is worker:
            self.cover_worker = None

    def show_project_details(self, item):
        hit = item.data(Qt.UserRole) or {}
        provider = str(hit.get("provider") or "modrinth")
        provider_name = "CurseForge" if provider == "curseforge" else "Modrinth"
        title = str(hit.get("title") or provider_name)
        dialog = QDialog(self)
        dialog.setWindowTitle(self.i18n.t("Información de {title}", title=title))
        dialog.setMinimumSize(540, 390)
        layout = QVBoxLayout(dialog)

        heading = QHBoxLayout()
        cover = QLabel()
        cover.setFixedSize(96, 96)
        cover.setAlignment(Qt.AlignCenter)
        pixmap = item.icon().pixmap(96, 96)
        if not pixmap.isNull():
            cover.setPixmap(pixmap.scaled(
                96, 96, Qt.KeepAspectRatio, Qt.SmoothTransformation
            ))
        heading.addWidget(cover)
        heading_text = QLabel(
            f"{title}\n{self.i18n.t('por')} {hit.get('author') or '?'}"
        )
        heading_text.setStyleSheet("font-size: 18px; font-weight: 700;")
        heading_text.setWordWrap(True)
        heading.addWidget(heading_text, 1)
        layout.addLayout(heading)

        categories = ", ".join(str(value) for value in hit.get("categories", [])[:12])
        versions = ", ".join(str(value) for value in hit.get("versions", [])[-12:])
        details = QLabel(self.i18n.t(
            "{description}\n\nDescargas: {downloads}\nSeguidores: {followers}\nCategorías: {categories}\nVersiones: {versions}\nÚltima actualización: {updated}\n\nDoble clic muestra información; Instalar seleccionado realiza la instalación.",
            description=str(hit.get("description") or self.i18n.t("Sin descripción.")),
            downloads=self.i18n.number(hit.get("downloads", 0)),
            followers=self.i18n.number(hit.get("follows", 0)),
            categories=categories or "—",
            versions=versions or "—",
            updated=str(hit.get("date_modified") or "—"),
        ))
        details.setTextFormat(Qt.PlainText)
        details.setWordWrap(True)
        details.setTextInteractionFlags(Qt.TextSelectableByMouse)
        layout.addWidget(details, 1)

        buttons = QDialogButtonBox(QDialogButtonBox.Close)
        open_button = buttons.addButton(
            self.i18n.t("Abrir en {provider}", provider=provider_name),
            QDialogButtonBox.ActionRole,
        )
        slug = str(hit.get("slug") or "")
        project_type = self._project_type()
        if provider == "curseforge":
            project_url = str(hit.get("website_url") or "")
            open_button.setEnabled(project_url.startswith("https://www.curseforge.com/"))
        else:
            project_url = f"https://modrinth.com/{project_type}/{slug}"
            open_button.setEnabled(bool(slug) and all(
                character.isalnum() or character in "-_" for character in slug
            ))
        open_button.clicked.connect(
            lambda: QDesktopServices.openUrl(QUrl(project_url))
        )
        buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)
        dialog.exec()

    @Slot(str)
    def _on_search_failed(self, error):
        self.search_worker = None
        self._set_remote_busy(False)
        self.status_label.setText(self.i18n.t(
            "❌ Error buscando: {error}", error=self.i18n.t(str(error))
        ))

    def on_install_selected(self):
        profile = self._selected_profile()
        if not self._check_ready_for_modrinth(profile):
            return
        item = self.results_list.currentItem()
        if not item:
            self.status_label.setText(self.i18n.t(
                "⚠ Selecciona un mod de la lista de resultados."
            ))
            return
        hit = item.data(Qt.UserRole)
        provider = str(hit.get("provider") or "modrinth")
        project_id = hit.get("project_id") or hit.get("slug")
        project_type = self._project_type()
        self._set_remote_busy(True)
        self.status_label.setText(self.i18n.t("Instalando '{name}'...", name=hit.get("title", "?")))
        worker_class = (CurseForgeInstallWorker if provider == "curseforge"
                        else ModrinthInstallWorker)
        self.install_worker = self._track_worker(worker_class(
            project_id, profile.loader, profile.version,
            self._content_dir(profile), project_type,
        ))
        self.install_worker.status.connect(self.status_label.setText)
        self.install_worker.completed.connect(self._on_install_completed)
        self.install_worker.failed.connect(self._on_install_failed)
        self.install_worker.start()

    @Slot(dict)
    def _on_install_completed(self, report):
        self.install_worker = None
        self._set_remote_busy(False)
        dependency_count = len(report.get("dependencies", []))
        optional = report.get("optional", [])
        incompatible = report.get("incompatible", [])
        message = self.i18n.t(
            "✅ Instalado: {filename}. Dependencias instaladas: {count}.",
            filename=Path(report["primary_path"]).name,
            count=dependency_count,
        )
        if optional:
            message += " " + self.i18n.t(
                "Opcionales no instaladas: {count}.", count=len(optional)
            )
        if incompatible:
            message += " " + self.i18n.t(
                "Incompatibilidades declaradas: {items}.",
                items=", ".join(
                    item.get("file_name") or item.get("project_id")
                    or item.get("version_id") or "?"
                    for item in incompatible[:4]
                ),
            )
        self.status_label.setText(message)
        self.refresh_mods()
        self.operation_succeeded.emit()
        if self._project_type() == "mod":
            self.mod_installed.emit()

    @Slot(str)
    def _on_installed(self, path):
        """Compatibilidad con extensiones que aún emitan solo una ruta."""
        self._on_install_completed({
            "primary_path": path, "dependencies": [],
            "optional": [], "incompatible": [],
        })

    @Slot(str)
    def _on_install_failed(self, error):
        self.install_worker = None
        self._set_remote_busy(False)
        self.status_label.setText(self.i18n.t(
            "❌ Error instalando: {error}", error=self.i18n.t(str(error))
        ))

    # --- CustomSkinLoader ----------------------------------------------
    def on_install_customskinloader(self):
        profile = self._selected_profile()
        if self._project_type() != "mod":
            return
        if not self._check_ready_for_modrinth(profile):
            return
        self._set_remote_busy(True)
        self.status_label.setText(self.i18n.t(
            "Buscando e instalando CustomSkinLoader desde Modrinth..."
        ))
        self.csl_worker = self._track_worker(CustomSkinLoaderWorker(replace(profile)))
        self.csl_worker.installed.connect(self._on_csl_installed)
        self.csl_worker.failed.connect(self._on_csl_failed)
        self.csl_worker.start()

    def on_update_all(self):
        profile = self._selected_profile()
        if self._project_type() != "mod":
            return
        if not self._check_ready_for_modrinth(profile):
            return
        self._set_remote_busy(True)
        self.status_label.setText(self.i18n.t("Buscando actualizaciones de mods..."))
        self.update_worker = self._track_worker(ModsUpdateWorker(replace(profile)))
        self.update_worker.status.connect(self.status_label.setText)
        self.update_worker.completed.connect(self._on_update_all_completed)
        self.update_worker.failed.connect(self._on_update_all_failed)
        self.update_worker.start()

    @Slot(dict)
    def _on_update_all_completed(self, result):
        self.update_worker = None
        self._set_remote_busy(False)
        self.refresh_mods()
        self.status_label.setText(self.i18n.t(
            "Mods actualizados: {updated}. Al día: {current}. No reconocidos: {unknown}.",
            **result,
        ))
        self.operation_succeeded.emit()

    @Slot(str)
    def _on_update_all_failed(self, error):
        self.update_worker = None
        self._set_remote_busy(False)
        self.status_label.setText(self.i18n.t(
            "No se pudieron actualizar los mods: {error}", error=error
        ))

    @Slot(str)
    def _on_csl_installed(self, path):
        self.csl_worker = None
        self.status_label.setText(self.i18n.t(
            "✅ CustomSkinLoader instalado: {filename}", filename=Path(path).name
        ))
        self._set_remote_busy(False)
        self.refresh_mods()
        self.operation_succeeded.emit()

    @Slot(str)
    def _on_csl_failed(self, error):
        self.csl_worker = None
        self.status_label.setText(self.i18n.t(
            "❌ No se pudo instalar CustomSkinLoader: {error}",
            error=self.i18n.t(str(error))
        ))
        self._set_remote_busy(False)

    def _set_remote_busy(self, busy: bool):
        self.search_btn.setEnabled(not busy)
        self.install_btn.setEnabled(not busy)
        self.search_edit.setEnabled(not busy)
        self.results_list.setEnabled(not busy)
        self.profile_combo.setEnabled(not busy)
        self.content_combo.setEnabled(not busy)
        self.provider_combo.setEnabled(not busy)
        self.curseforge_key_btn.setEnabled(not busy)
        is_mod = self._project_type() == "mod"
        self.csl_button.setEnabled(not busy and is_mod)
        self.update_all_button.setEnabled(not busy and is_mod)
