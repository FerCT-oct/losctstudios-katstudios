"""KatLauncher package metadata."""

__version__ = "1.5.2.1"
