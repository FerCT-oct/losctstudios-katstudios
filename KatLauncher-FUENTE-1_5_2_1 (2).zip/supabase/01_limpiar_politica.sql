drop policy if exists kat_visible_messages on public.kat_messages;
select 'Política anterior eliminada; ahora ejecuta kat_social.sql' as status;
