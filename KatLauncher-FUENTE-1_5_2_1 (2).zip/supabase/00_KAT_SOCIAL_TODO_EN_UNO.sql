-- KATLAUNCHER - KAT SOCIAL TODO EN UNO
-- Compatible con proyecto nuevo o existente.
-- Idempotente: puede ejecutarse nuevamente sin borrar perfiles, mensajes,
-- amistades, publicaciones, skins ni trofeos.
-- Generado en orden: base + publicaciones + hotfix/KatSkin + trofeos/presencia
-- + version publica del launcher.

begin;

-- PostgreSQL no permite cambiar las columnas OUT de una función usando
-- CREATE OR REPLACE. Estas funciones solo exponen consultas; eliminarlas
-- temporalmente dentro de esta transacción no borra ninguna tabla ni dato.
drop function if exists public.kat_search_users(text);
drop function if exists public.kat_list_friends();
drop function if exists public.kat_list_friend_requests();
drop function if exists public.kat_list_global_messages();
drop function if exists public.kat_list_private_messages(uuid);
drop function if exists public.kat_list_posts();

-- ===========================================================================
-- INICIO: kat_social.sql
-- ===========================================================================

-- Kat Social 1.3.0 — esquema completo e idempotente para Supabase SQL Editor.
create table if not exists public.kat_profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  provider_id text unique not null,
  display_name text not null check (char_length(display_name) between 1 and 64),
  avatar_url text not null default '',
  role text not null default 'user' check (role in ('user','moderator','admin')),
  timeout_until timestamptz,
  banned boolean not null default false,
  created_at timestamptz not null default now(),
  last_seen timestamptz not null default now()
);
-- Migración desde la primera variante con Discord. CREATE TABLE IF NOT EXISTS
-- no agrega columnas nuevas a una tabla ya creada.
alter table public.kat_profiles add column if not exists provider_id text;
do $kat_provider_migration$
begin
  if exists (
    select 1 from information_schema.columns
    where table_schema='public' and table_name='kat_profiles' and column_name='discord_id'
  ) then
    execute 'update public.kat_profiles set provider_id=discord_id where provider_id is null';
  end if;
end
$kat_provider_migration$;
update public.kat_profiles set provider_id=id::text where provider_id is null;
alter table public.kat_profiles alter column provider_id set not null;
create unique index if not exists kat_profiles_provider_id_key on public.kat_profiles(provider_id);
alter table public.kat_profiles drop column if exists discord_id;
create table if not exists public.kat_friend_requests (
  id bigint generated always as identity primary key,
  sender uuid not null references public.kat_profiles(id) on delete cascade,
  receiver uuid not null references public.kat_profiles(id) on delete cascade,
  status text not null default 'pending' check (status in ('pending','accepted','rejected')),
  created_at timestamptz not null default now(), check (sender <> receiver)
);
create unique index if not exists kat_one_pending_request on public.kat_friend_requests(sender,receiver) where status='pending';
create table if not exists public.kat_friendships (
  user_a uuid not null references public.kat_profiles(id) on delete cascade,
  user_b uuid not null references public.kat_profiles(id) on delete cascade,
  created_at timestamptz not null default now(), primary key(user_a,user_b), check(user_a < user_b)
);
create table if not exists public.kat_blocks (
  blocker uuid not null references public.kat_profiles(id) on delete cascade,
  blocked uuid not null references public.kat_profiles(id) on delete cascade,
  created_at timestamptz not null default now(), primary key(blocker,blocked), check(blocker <> blocked)
);
create table if not exists public.kat_messages (
  id bigint generated always as identity primary key,
  sender uuid not null references public.kat_profiles(id) on delete cascade,
  recipient uuid references public.kat_profiles(id) on delete cascade,
  body text not null check(char_length(body) between 1 and 500),
  hidden boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists kat_messages_global on public.kat_messages(created_at desc) where recipient is null;
create index if not exists kat_messages_private on public.kat_messages(sender,recipient,created_at desc) where recipient is not null;
create table if not exists public.kat_reports (
  id bigint generated always as identity primary key,
  reporter uuid not null references public.kat_profiles(id) on delete cascade,
  message_id bigint not null references public.kat_messages(id) on delete cascade,
  reason text not null check(char_length(reason) between 3 and 300),
  status text not null default 'open' check(status in ('open','resolved','dismissed')),
  created_at timestamptz not null default now(), unique(reporter,message_id)
);

alter table public.kat_profiles enable row level security;
alter table public.kat_friend_requests enable row level security;
alter table public.kat_friendships enable row level security;
alter table public.kat_blocks enable row level security;
alter table public.kat_messages enable row level security;
alter table public.kat_reports enable row level security;
revoke all on public.kat_profiles, public.kat_friend_requests, public.kat_friendships,
  public.kat_blocks, public.kat_messages, public.kat_reports from anon, authenticated;
grant select on public.kat_messages to authenticated;
drop policy if exists kat_visible_messages on public.kat_messages;
create policy kat_visible_messages on public.kat_messages for select to authenticated using (
  not hidden and (recipient is null or auth.uid() in (sender,recipient)) and
  not exists(select 1 from public.kat_blocks b where
    (b.blocker=auth.uid() and b.blocked=sender) or (b.blocker=sender and b.blocked=auth.uid()))
);

create or replace function public.kat_upsert_profile() returns jsonb language plpgsql security definer set search_path=public,auth as $$
declare u auth.users; result public.kat_profiles;
begin
  select * into u from auth.users where id=auth.uid();
  if u.id is null then raise exception 'Sesión no válida'; end if;
  insert into public.kat_profiles(id,provider_id,display_name,avatar_url)
  values(u.id, coalesce(u.raw_user_meta_data->>'provider_id',u.raw_user_meta_data->>'sub',u.id::text),
    left(coalesce(u.raw_user_meta_data->>'full_name',u.raw_user_meta_data->>'name',u.raw_user_meta_data->>'user_name','Usuario'),64),
    coalesce(u.raw_user_meta_data->>'avatar_url',''))
  on conflict(id) do update set display_name=excluded.display_name, avatar_url=excluded.avatar_url, last_seen=now()
  returning * into result;
  return to_jsonb(result)-'banned'-'timeout_until';
end $$;

create or replace function public.kat_search_users(p_query text) returns table(id uuid,display_name text,avatar_url text)
language sql security definer set search_path=public as $$
  select p.id,p.display_name,p.avatar_url from public.kat_profiles p where p.id<>auth.uid() and not p.banned
  and p.display_name ilike '%'||left(trim(p_query),40)||'%'
  and not exists(select 1 from public.kat_blocks b where (b.blocker=auth.uid() and b.blocked=p.id) or (b.blocker=p.id and b.blocked=auth.uid()))
  order by p.display_name limit 20
$$;

create or replace function public.kat_send_friend_request(p_target uuid) returns void language plpgsql security definer set search_path=public as $$
declare reverse_request bigint;
begin
  if p_target=auth.uid() then raise exception 'No puedes agregarte a ti mismo'; end if;
  if exists(select 1 from public.kat_blocks where (blocker=auth.uid() and blocked=p_target) or (blocker=p_target and blocked=auth.uid())) then raise exception 'No se puede enviar la solicitud'; end if;
  if exists(select 1 from public.kat_friendships where user_a=least(auth.uid(),p_target) and user_b=greatest(auth.uid(),p_target)) then raise exception 'Ya son amigos'; end if;
  select id into reverse_request from public.kat_friend_requests
    where sender=p_target and receiver=auth.uid() and status='pending'
    order by created_at desc limit 1 for update;
  if reverse_request is not null then
    update public.kat_friend_requests set status='accepted' where id=reverse_request;
    insert into public.kat_friendships(user_a,user_b)
      values(least(auth.uid(),p_target),greatest(auth.uid(),p_target))
      on conflict do nothing;
    return;
  end if;
  insert into public.kat_friend_requests(sender,receiver)
    values(auth.uid(),p_target) on conflict do nothing;
end $$;

create or replace function public.kat_respond_friend_request(p_request bigint,p_accept boolean) returns void language plpgsql security definer set search_path=public as $$
declare s uuid;
begin
  update public.kat_friend_requests set status=case when p_accept then 'accepted' else 'rejected' end
    where id=p_request and receiver=auth.uid() and status='pending' returning sender into s;
  if s is null then raise exception 'Solicitud no disponible'; end if;
  if p_accept then insert into public.kat_friendships(user_a,user_b) values(least(s,auth.uid()),greatest(s,auth.uid())) on conflict do nothing; end if;
end $$;

create or replace function public.kat_list_friends() returns table(id uuid,display_name text,avatar_url text)
language sql security definer set search_path=public as $$
 select p.id,p.display_name,p.avatar_url from public.kat_friendships f join public.kat_profiles p
 on p.id=case when f.user_a=auth.uid() then f.user_b else f.user_a end
 where auth.uid() in(f.user_a,f.user_b) order by p.display_name
$$;
create or replace function public.kat_list_friend_requests() returns table(request_id bigint,id uuid,display_name text,avatar_url text)
language sql security definer set search_path=public as $$
 select r.id,p.id,p.display_name,p.avatar_url from public.kat_friend_requests r join public.kat_profiles p on p.id=r.sender
 where r.receiver=auth.uid() and r.status='pending' order by r.created_at desc
$$;

create or replace function public.kat_send_message(p_body text,p_recipient uuid default null) returns bigint language plpgsql security definer set search_path=public as $$
declare me public.kat_profiles; result bigint; clean text:=trim(p_body);
begin
 select * into me from public.kat_profiles where id=auth.uid();
 if me.banned or me.timeout_until>now() then raise exception 'No puedes enviar mensajes ahora'; end if;
 if char_length(clean) not between 1 and 500 then raise exception 'El mensaje debe tener entre 1 y 500 caracteres'; end if;
 if (select count(*) from public.kat_messages where sender=auth.uid() and created_at>now()-interval '10 seconds')>=5
 or (select count(*) from public.kat_messages where sender=auth.uid() and created_at>now()-interval '1 minute')>=30 then raise exception 'Demasiados mensajes; espera un momento'; end if;
 if p_recipient is not null and not exists(select 1 from public.kat_friendships where user_a=least(auth.uid(),p_recipient) and user_b=greatest(auth.uid(),p_recipient)) then raise exception 'Los mensajes privados son solo para amigos'; end if;
 if p_recipient is not null and exists(select 1 from public.kat_blocks where (blocker=auth.uid() and blocked=p_recipient) or (blocker=p_recipient and blocked=auth.uid())) then raise exception 'No se puede enviar el mensaje'; end if;
 insert into public.kat_messages(sender,recipient,body) values(auth.uid(),p_recipient,clean) returning id into result; return result;
end $$;

create or replace function public.kat_list_global_messages() returns table(id bigint,sender_id uuid,display_name text,body text,created_at timestamptz)
language sql security definer set search_path=public as $$
 select m.id,m.sender,p.display_name,m.body,m.created_at from (select * from public.kat_messages where recipient is null and not hidden order by created_at desc limit 100) m
 join public.kat_profiles p on p.id=m.sender where not exists(select 1 from public.kat_blocks b where (b.blocker=auth.uid() and b.blocked=m.sender) or (b.blocker=m.sender and b.blocked=auth.uid())) order by m.created_at
$$;
create or replace function public.kat_list_private_messages(p_friend uuid) returns table(id bigint,sender_id uuid,display_name text,body text,created_at timestamptz)
language sql security definer set search_path=public as $$
 select m.id,m.sender,p.display_name,m.body,m.created_at from (select * from public.kat_messages where not hidden and ((sender=auth.uid() and recipient=p_friend) or(sender=p_friend and recipient=auth.uid())) order by created_at desc limit 100) m join public.kat_profiles p on p.id=m.sender order by m.created_at
$$;

create or replace function public.kat_block_user(p_target uuid) returns void language plpgsql security definer set search_path=public as $$
begin
 insert into public.kat_blocks(blocker,blocked) values(auth.uid(),p_target) on conflict do nothing;
 delete from public.kat_friendships where user_a=least(auth.uid(),p_target) and user_b=greatest(auth.uid(),p_target);
 delete from public.kat_friend_requests where sender in(auth.uid(),p_target) and receiver in(auth.uid(),p_target);
end $$;
create or replace function public.kat_unblock_user(p_target uuid) returns void language sql security definer set search_path=public as $$ delete from public.kat_blocks where blocker=auth.uid() and blocked=p_target $$;
create or replace function public.kat_report_message(p_message bigint,p_reason text) returns void language plpgsql security definer set search_path=public as $$
begin
 if char_length(trim(p_reason)) not between 3 and 300 then raise exception 'Explica brevemente el motivo'; end if;
 insert into public.kat_reports(reporter,message_id,reason) values(auth.uid(),p_message,trim(p_reason));
end $$;
create or replace function public.kat_moderate_message(p_message bigint,p_hide boolean,p_timeout_minutes int default 0) returns void language plpgsql security definer set search_path=public as $$
declare target uuid;
begin
 if not exists(select 1 from public.kat_profiles where id=auth.uid() and role in('moderator','admin')) then raise exception 'No autorizado'; end if;
 update public.kat_messages set hidden=p_hide where id=p_message returning sender into target;
 if p_timeout_minutes>0 then update public.kat_profiles set timeout_until=now()+make_interval(mins=>least(p_timeout_minutes,10080)) where id=target; end if;
end $$;

do $$ declare f record; begin
  for f in select p.oid::regprocedure as signature from pg_proc p
    join pg_namespace n on n.oid=p.pronamespace
    where n.nspname='public' and p.proname like 'kat_%'
  loop
    execute format('revoke all on function %s from public, anon', f.signature);
    execute format('grant execute on function %s to authenticated', f.signature);
  end loop;
end $$;
do $kat_realtime$
begin
  alter publication supabase_realtime add table public.kat_messages;
exception
  when duplicate_object then null;
end
$kat_realtime$;

-- ---------------------------------------------------------------------------
-- Ampliación 1.3.0: identidad propia, avatares, presencia y privados sin leer.
-- Se mantiene aquí además de 03_kat_social_profiles.sql para que una instalación
-- nueva solo tenga que ejecutar este archivo.
-- ---------------------------------------------------------------------------
alter table public.kat_profiles add column if not exists avatar_path text not null default '';
alter table public.kat_profiles add column if not exists custom_display_name boolean not null default false;
alter table public.kat_profiles add column if not exists custom_avatar boolean not null default false;
alter table public.kat_profiles add column if not exists avatar_updated_at timestamptz;

update public.kat_profiles
set display_name = case
  when char_length(trim(display_name)) between 2 and 32 then left(trim(display_name), 32)
  else 'Usuario'
end;
alter table public.kat_profiles drop constraint if exists kat_profiles_display_name_check;
alter table public.kat_profiles add constraint kat_profiles_display_name_check
  check (char_length(display_name) between 2 and 32 and display_name !~ '[[:cntrl:]]');

create table if not exists public.kat_dm_reads (
  user_id uuid not null references public.kat_profiles(id) on delete cascade,
  friend_id uuid not null references public.kat_profiles(id) on delete cascade,
  last_read_at timestamptz not null default to_timestamp(0),
  primary key(user_id, friend_id),
  check(user_id <> friend_id)
);
alter table public.kat_dm_reads enable row level security;
revoke all on public.kat_dm_reads from anon, authenticated;

insert into storage.buckets(id, name, public, file_size_limit, allowed_mime_types)
values ('kat-avatars', 'kat-avatars', true, 2097152, array['image/png'])
on conflict(id) do update set
  public = excluded.public,
  file_size_limit = excluded.file_size_limit,
  allowed_mime_types = excluded.allowed_mime_types;

drop policy if exists kat_avatar_insert on storage.objects;
create policy kat_avatar_insert on storage.objects
for insert to authenticated with check (
  bucket_id = 'kat-avatars'
  and (storage.foldername(name))[1] = (select auth.uid()::text)
  and name = (select auth.uid()::text) || '/avatar.png'
  and storage.extension(name) = 'png'
);
drop policy if exists kat_avatar_select_owner on storage.objects;
create policy kat_avatar_select_owner on storage.objects
for select to authenticated using (
  bucket_id = 'kat-avatars' and owner_id = (select auth.uid()::text)
);
drop policy if exists kat_avatar_update on storage.objects;
create policy kat_avatar_update on storage.objects
for update to authenticated using (
  bucket_id = 'kat-avatars'
  and owner_id = (select auth.uid()::text)
  and name = (select auth.uid()::text) || '/avatar.png'
) with check (
  bucket_id = 'kat-avatars'
  and owner_id = (select auth.uid()::text)
  and name = (select auth.uid()::text) || '/avatar.png'
  and storage.extension(name) = 'png'
);
drop policy if exists kat_avatar_delete on storage.objects;
create policy kat_avatar_delete on storage.objects
for delete to authenticated using (
  bucket_id = 'kat-avatars'
  and owner_id = (select auth.uid()::text)
  and name = (select auth.uid()::text) || '/avatar.png'
);

create or replace function public.kat_upsert_profile() returns jsonb
language plpgsql security definer set search_path=public,auth as $$
declare
  u auth.users; result public.kat_profiles;
  provider_name text; provider_avatar text;
begin
  select * into u from auth.users where id=auth.uid();
  if u.id is null then raise exception 'Sesión no válida'; end if;
  provider_name := regexp_replace(trim(coalesce(
    u.raw_user_meta_data->>'full_name', u.raw_user_meta_data->>'name',
    u.raw_user_meta_data->>'user_name', 'Usuario'
  )), '\s+', ' ', 'g');
  if char_length(provider_name) not between 2 and 32 or provider_name ~ '[[:cntrl:]]' then
    provider_name := 'Usuario';
  end if;
  provider_avatar := coalesce(u.raw_user_meta_data->>'avatar_url', '');
  insert into public.kat_profiles(id, provider_id, display_name, avatar_url)
  values(u.id, coalesce(u.raw_user_meta_data->>'provider_id',
    u.raw_user_meta_data->>'sub', u.id::text), provider_name, provider_avatar)
  on conflict(id) do update set
    display_name=case when kat_profiles.custom_display_name
      then kat_profiles.display_name else excluded.display_name end,
    avatar_url=case when kat_profiles.custom_avatar
      then kat_profiles.avatar_url else excluded.avatar_url end,
    avatar_path=case when kat_profiles.custom_avatar
      then kat_profiles.avatar_path else '' end,
    last_seen=now()
  returning * into result;
  return to_jsonb(result)-'banned'-'timeout_until';
end $$;

create or replace function public.kat_set_display_name(p_display_name text) returns jsonb
language plpgsql security definer set search_path=public as $$
declare clean text; result public.kat_profiles;
begin
  clean := regexp_replace(trim(coalesce(p_display_name,'')), '\s+', ' ', 'g');
  if char_length(clean) not between 2 and 32 or clean ~ '[[:cntrl:]]' then
    raise exception 'El nick debe tener entre 2 y 32 caracteres';
  end if;
  update public.kat_profiles set display_name=clean,
    custom_display_name=true,last_seen=now()
  where id=auth.uid() returning * into result;
  if result.id is null then raise exception 'Perfil no disponible'; end if;
  return to_jsonb(result)-'banned'-'timeout_until';
end $$;

create or replace function public.kat_set_avatar(p_object_path text) returns jsonb
language plpgsql security definer set search_path=public,storage as $$
declare result public.kat_profiles;
begin
  if p_object_path <> auth.uid()::text || '/avatar.png' or not exists(
    select 1 from storage.objects where bucket_id='kat-avatars'
      and name=p_object_path and owner_id=auth.uid()::text
  ) then raise exception 'Avatar no válido'; end if;
  update public.kat_profiles set avatar_path=p_object_path,custom_avatar=true,
    avatar_updated_at=clock_timestamp(),last_seen=now()
  where id=auth.uid() returning * into result;
  if result.id is null then raise exception 'Perfil no disponible'; end if;
  return to_jsonb(result)-'banned'-'timeout_until';
end $$;

create or replace function public.kat_reset_profile(
  p_reset_name boolean default true,p_reset_avatar boolean default true
) returns jsonb language plpgsql security definer set search_path=public,auth as $$
declare u auth.users; result public.kat_profiles; provider_name text;
begin
  select * into u from auth.users where id=auth.uid();
  if u.id is null then raise exception 'Sesión no válida'; end if;
  provider_name := regexp_replace(trim(coalesce(
    u.raw_user_meta_data->>'full_name',u.raw_user_meta_data->>'name',
    u.raw_user_meta_data->>'user_name','Usuario'
  )), '\s+', ' ', 'g');
  if char_length(provider_name) not between 2 and 32 or provider_name ~ '[[:cntrl:]]' then
    provider_name := 'Usuario';
  end if;
  update public.kat_profiles set
    display_name=case when p_reset_name then provider_name else display_name end,
    custom_display_name=case when p_reset_name then false else custom_display_name end,
    avatar_url=case when p_reset_avatar
      then coalesce(u.raw_user_meta_data->>'avatar_url','') else avatar_url end,
    avatar_path=case when p_reset_avatar then '' else avatar_path end,
    custom_avatar=case when p_reset_avatar then false else custom_avatar end,
    avatar_updated_at=case when p_reset_avatar then clock_timestamp() else avatar_updated_at end,
    last_seen=now()
  where id=auth.uid() returning * into result;
  return to_jsonb(result)-'banned'-'timeout_until';
end $$;

create or replace function public.kat_touch_presence() returns jsonb
language plpgsql security definer set search_path=public as $$
declare result public.kat_profiles;
begin
  update public.kat_profiles set last_seen=now()
  where id=auth.uid() returning * into result;
  if result.id is null then raise exception 'Perfil no disponible'; end if;
  return to_jsonb(result)-'banned'-'timeout_until';
end $$;

create or replace function public.kat_mark_private_read(p_friend uuid,p_message bigint)
returns void language plpgsql security definer set search_path=public as $$
declare read_time timestamptz;
begin
  if not exists(select 1 from public.kat_friendships
    where user_a=least(auth.uid(),p_friend) and user_b=greatest(auth.uid(),p_friend)) then
    raise exception 'Conversación no disponible';
  end if;
  select created_at into read_time from public.kat_messages where id=p_message and (
    (sender=auth.uid() and recipient=p_friend) or
    (sender=p_friend and recipient=auth.uid()));
  if read_time is null then return; end if;
  insert into public.kat_dm_reads(user_id,friend_id,last_read_at)
  values(auth.uid(),p_friend,read_time)
  on conflict(user_id,friend_id) do update
    set last_read_at=greatest(kat_dm_reads.last_read_at,excluded.last_read_at);
end $$;

drop function if exists public.kat_search_users(text);
create function public.kat_search_users(p_query text)
returns table(id uuid,display_name text,avatar_url text,avatar_path text,
  avatar_updated_at timestamptz,online boolean)
language sql security definer set search_path=public as $$
  select p.id,p.display_name,p.avatar_url,p.avatar_path,p.avatar_updated_at,
    p.last_seen>now()-interval '90 seconds'
  from public.kat_profiles p where p.id<>auth.uid() and not p.banned
    and p.display_name ilike '%'||left(trim(p_query),40)||'%'
    and not exists(select 1 from public.kat_blocks b where
      (b.blocker=auth.uid() and b.blocked=p.id) or
      (b.blocker=p.id and b.blocked=auth.uid()))
  order by p.display_name limit 20
$$;

drop function if exists public.kat_list_friends();
create function public.kat_list_friends()
returns table(id uuid,display_name text,avatar_url text,avatar_path text,
  avatar_updated_at timestamptz,online boolean,unread_count bigint)
language sql security definer set search_path=public as $$
  select p.id,p.display_name,p.avatar_url,p.avatar_path,p.avatar_updated_at,
    p.last_seen>now()-interval '90 seconds',
    (select count(*) from public.kat_messages m
      where m.sender=p.id and m.recipient=auth.uid() and not m.hidden
        and m.created_at>coalesce((select r.last_read_at from public.kat_dm_reads r
          where r.user_id=auth.uid() and r.friend_id=p.id),to_timestamp(0)))
  from public.kat_friendships f join public.kat_profiles p
    on p.id=case when f.user_a=auth.uid() then f.user_b else f.user_a end
  where auth.uid() in(f.user_a,f.user_b) order by p.display_name
$$;

drop function if exists public.kat_list_friend_requests();
create function public.kat_list_friend_requests()
returns table(request_id bigint,id uuid,display_name text,avatar_url text,
  avatar_path text,avatar_updated_at timestamptz,online boolean)
language sql security definer set search_path=public as $$
  select r.id,p.id,p.display_name,p.avatar_url,p.avatar_path,p.avatar_updated_at,
    p.last_seen>now()-interval '90 seconds'
  from public.kat_friend_requests r join public.kat_profiles p on p.id=r.sender
  where r.receiver=auth.uid() and r.status='pending' order by r.created_at desc
$$;

drop function if exists public.kat_list_global_messages();
create function public.kat_list_global_messages()
returns table(id bigint,sender_id uuid,display_name text,avatar_url text,
  avatar_path text,avatar_updated_at timestamptz,body text,created_at timestamptz)
language sql security definer set search_path=public as $$
  select m.id,m.sender,p.display_name,p.avatar_url,p.avatar_path,p.avatar_updated_at,
    m.body,m.created_at
  from (select * from public.kat_messages where recipient is null and not hidden
    order by created_at desc limit 100) m
  join public.kat_profiles p on p.id=m.sender
  where not exists(select 1 from public.kat_blocks b where
    (b.blocker=auth.uid() and b.blocked=m.sender) or
    (b.blocker=m.sender and b.blocked=auth.uid()))
  order by m.created_at
$$;

drop function if exists public.kat_list_private_messages(uuid);
create function public.kat_list_private_messages(p_friend uuid)
returns table(id bigint,sender_id uuid,display_name text,avatar_url text,
  avatar_path text,avatar_updated_at timestamptz,body text,created_at timestamptz)
language sql security definer set search_path=public as $$
  select m.id,m.sender,p.display_name,p.avatar_url,p.avatar_path,p.avatar_updated_at,
    m.body,m.created_at
  from (select * from public.kat_messages where not hidden and (
    (sender=auth.uid() and recipient=p_friend) or
    (sender=p_friend and recipient=auth.uid()))
    order by created_at desc limit 100) m
  join public.kat_profiles p on p.id=m.sender order by m.created_at
$$;

do $$ declare f record; begin
  for f in select p.oid::regprocedure as signature from pg_proc p
    join pg_namespace n on n.oid=p.pronamespace
    where n.nspname='public' and p.proname like 'kat_%'
  loop
    execute format('revoke all on function %s from public, anon',f.signature);
    execute format('grant execute on function %s to authenticated',f.signature);
  end loop;
end $$;

select 'Kat Social 1.3.0 listo' as status;


-- FIN: kat_social.sql


-- ===========================================================================
-- INICIO: 04_kat_social_14.sql
-- ===========================================================================

-- Kat Social 1.4.0: publicaciones y rangos por tiempo jugado.
-- Ejecutar una vez después de kat_social.sql / 03_kat_social_profiles.sql.

alter table public.kat_profiles
  add column if not exists play_seconds bigint not null default 0
    check (play_seconds >= 0);
alter table public.kat_profiles
  add column if not exists play_credit_at timestamptz not null default now();

create table if not exists public.kat_posts (
  id bigint generated always as identity primary key,
  author uuid not null references public.kat_profiles(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 1000),
  hidden boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists kat_posts_created on public.kat_posts(created_at desc);
alter table public.kat_posts enable row level security;
revoke all on public.kat_posts from anon, authenticated;
grant select on public.kat_posts to authenticated;
drop policy if exists kat_visible_posts on public.kat_posts;
create policy kat_visible_posts on public.kat_posts for select to authenticated using (
  not hidden and not exists(select 1 from public.kat_blocks b where
    (b.blocker=auth.uid() and b.blocked=author) or
    (b.blocker=author and b.blocked=auth.uid()))
);

create or replace function public.kat_rank_name(p_seconds bigint) returns text
language sql immutable set search_path=public as $$
  select case
    when coalesce(p_seconds,0) >= 360000 then 'Leyenda cósmica'
    when coalesce(p_seconds,0) >= 180000 then 'Gato ancestral'
    when coalesce(p_seconds,0) >= 72000 then 'Explorador experto'
    when coalesce(p_seconds,0) >= 18000 then 'Aventurero'
    when coalesce(p_seconds,0) >= 3600 then 'Minero'
    else 'Recién llegado'
  end
$$;

create or replace function public.kat_add_playtime(p_seconds integer) returns jsonb
language plpgsql security definer set search_path=public as $$
declare result public.kat_profiles; elapsed integer; credited integer;
begin
  if auth.uid() is null then raise exception 'Sesión no válida'; end if;
  if p_seconds < 30 or p_seconds > 21600 then
    raise exception 'Duración de juego no válida';
  end if;
  select greatest(0,extract(epoch from (now()-play_credit_at))::integer)
    into elapsed from public.kat_profiles where id=auth.uid() for update;
  if elapsed is null then raise exception 'Perfil no disponible'; end if;
  credited:=least(p_seconds,elapsed+60);
  if credited < 30 then raise exception 'Sesión registrada demasiado pronto'; end if;
  update public.kat_profiles set
    play_seconds=play_seconds+credited, play_credit_at=now(), last_seen=now()
    where id=auth.uid() returning * into result;
  return to_jsonb(result)-'banned'-'timeout_until';
end $$;

create or replace function public.kat_create_post(p_body text) returns bigint
language plpgsql security definer set search_path=public as $$
declare clean text:=trim(p_body); result bigint; me public.kat_profiles;
begin
  select * into me from public.kat_profiles where id=auth.uid();
  if me.id is null or me.banned or me.timeout_until>now() then
    raise exception 'No puedes publicar ahora';
  end if;
  if char_length(clean) not between 1 and 1000 then
    raise exception 'La publicación debe tener entre 1 y 1000 caracteres';
  end if;
  if (select count(*) from public.kat_posts
      where author=auth.uid() and created_at>now()-interval '1 minute')>=4 then
    raise exception 'Demasiadas publicaciones; espera un momento';
  end if;
  insert into public.kat_posts(author,body) values(auth.uid(),clean)
    returning id into result;
  return result;
end $$;

create or replace function public.kat_list_posts()
returns table(id bigint,author_id uuid,display_name text,avatar_url text,
  avatar_path text,avatar_updated_at timestamptz,rank_name text,
  play_seconds bigint,body text,created_at timestamptz)
language sql security definer set search_path=public as $$
  select po.id,po.author,p.display_name,p.avatar_url,p.avatar_path,
    p.avatar_updated_at,public.kat_rank_name(p.play_seconds),p.play_seconds,
    po.body,po.created_at
  from (select * from public.kat_posts where not hidden
    order by created_at desc limit 100) po
  join public.kat_profiles p on p.id=po.author
  where not exists(select 1 from public.kat_blocks b where
    (b.blocker=auth.uid() and b.blocked=po.author) or
    (b.blocker=po.author and b.blocked=auth.uid()))
  order by po.created_at desc
$$;

drop function if exists public.kat_search_users(text);
create function public.kat_search_users(p_query text)
returns table(id uuid,display_name text,avatar_url text,avatar_path text,
  avatar_updated_at timestamptz,online boolean,rank_name text,play_seconds bigint)
language sql security definer set search_path=public as $$
  select p.id,p.display_name,p.avatar_url,p.avatar_path,p.avatar_updated_at,
    p.last_seen>now()-interval '90 seconds',public.kat_rank_name(p.play_seconds),
    p.play_seconds
  from public.kat_profiles p where p.id<>auth.uid() and not p.banned
    and p.display_name ilike '%'||left(trim(p_query),40)||'%'
    and not exists(select 1 from public.kat_blocks b where
      (b.blocker=auth.uid() and b.blocked=p.id) or
      (b.blocker=p.id and b.blocked=auth.uid()))
  order by p.display_name limit 20
$$;

drop function if exists public.kat_list_friends();
create function public.kat_list_friends()
returns table(id uuid,display_name text,avatar_url text,avatar_path text,
  avatar_updated_at timestamptz,online boolean,unread_count bigint,
  rank_name text,play_seconds bigint)
language sql security definer set search_path=public as $$
  select p.id,p.display_name,p.avatar_url,p.avatar_path,p.avatar_updated_at,
    p.last_seen>now()-interval '90 seconds',
    (select count(*) from public.kat_messages m
      where m.sender=p.id and m.recipient=auth.uid() and not m.hidden
        and m.created_at>coalesce((select r.last_read_at from public.kat_dm_reads r
          where r.user_id=auth.uid() and r.friend_id=p.id),to_timestamp(0))),
    public.kat_rank_name(p.play_seconds),p.play_seconds
  from public.kat_friendships f join public.kat_profiles p
    on p.id=case when f.user_a=auth.uid() then f.user_b else f.user_a end
  where auth.uid() in(f.user_a,f.user_b) order by p.display_name
$$;

do $$ declare f record; begin
  for f in select p.oid::regprocedure as signature from pg_proc p
    join pg_namespace n on n.oid=p.pronamespace
    where n.nspname='public' and p.proname like 'kat_%'
  loop
    execute format('revoke all on function %s from public, anon',f.signature);
    execute format('grant execute on function %s to authenticated',f.signature);
  end loop;
end $$;

do $$ begin
  alter publication supabase_realtime add table public.kat_posts;
exception when duplicate_object then null;
end $$;

select 'Kat Social 1.4.0 listo' as status;


-- FIN: 04_kat_social_14.sql


-- ===========================================================================
-- INICIO: 05_kat_social_hotfix_katskin.sql
-- ===========================================================================

-- KatLauncher hotfix: retención prudente de mensajes + KatSkin compartido.
-- Idempotente: se puede ejecutar de nuevo desde Supabase SQL Editor.

create table if not exists public.kat_skins (
  user_id uuid primary key references public.kat_profiles(id) on delete cascade,
  nickname text not null check (nickname ~ '^[A-Za-z0-9_]{1,16}$'),
  model text not null default 'auto' check (model in ('auto','classic','slim')),
  object_path text not null unique,
  sha256 text not null default '' check (sha256 = '' or sha256 ~ '^[0-9a-f]{64}$'),
  updated_at timestamptz not null default now()
);
create unique index if not exists kat_skins_nickname_key
  on public.kat_skins(lower(nickname));
alter table public.kat_skins enable row level security;
revoke all on public.kat_skins from anon, authenticated;
grant select on public.kat_skins to authenticated;
drop policy if exists kat_skin_select_own on public.kat_skins;
create policy kat_skin_select_own on public.kat_skins for select to authenticated
using(user_id=auth.uid());

insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values('kat-skins','kat-skins',true,2097152,array['image/png'])
on conflict(id) do update set
  public=excluded.public,
  file_size_limit=excluded.file_size_limit,
  allowed_mime_types=excluded.allowed_mime_types;

drop policy if exists kat_skin_insert on storage.objects;
create policy kat_skin_insert on storage.objects for insert to authenticated
with check (
  bucket_id='kat-skins'
  and exists(
    select 1 from public.kat_skins s
    where s.user_id=auth.uid() and s.object_path=name
  )
  and storage.extension(name)='png'
);
drop policy if exists kat_skin_select on storage.objects;
create policy kat_skin_select on storage.objects for select to authenticated
using(bucket_id='kat-skins' and owner_id=auth.uid()::text);
drop policy if exists kat_skin_update on storage.objects;
create policy kat_skin_update on storage.objects for update to authenticated
using(bucket_id='kat-skins' and owner_id=auth.uid()::text)
with check (
  bucket_id='kat-skins' and owner_id=auth.uid()::text
  and exists(
    select 1 from public.kat_skins s
    where s.user_id=auth.uid() and s.object_path=name
  )
);
drop policy if exists kat_skin_delete on storage.objects;
create policy kat_skin_delete on storage.objects for delete to authenticated
using(bucket_id='kat-skins' and owner_id=auth.uid()::text);

create or replace function public.kat_claim_skin_name(
  p_nickname text, p_model text default 'auto'
) returns jsonb language plpgsql security definer
set search_path=public,storage as $kat$
declare clean text:=trim(p_nickname); old_path text; result public.kat_skins;
begin
  if auth.uid() is null then raise exception 'Sesión no válida'; end if;
  if clean !~ '^[A-Za-z0-9_]{1,16}$' then raise exception 'Nickname no válido'; end if;
  if p_model not in ('auto','classic','slim') then raise exception 'Modelo no válido'; end if;
  if exists(
    select 1 from public.kat_skins
    where lower(nickname)=lower(clean) and user_id<>auth.uid()
  ) then raise exception 'Ese nickname ya pertenece a otro usuario de KatSkin'; end if;
  select object_path into old_path from public.kat_skins where user_id=auth.uid();
  if old_path is not null and old_path<>('skins/'||clean||'.png') then
    delete from storage.objects where bucket_id='kat-skins' and name=old_path;
  end if;
  insert into public.kat_skins(user_id,nickname,model,object_path)
  values(auth.uid(),clean,p_model,'skins/'||clean||'.png')
  on conflict(user_id) do update set
    nickname=excluded.nickname,model=excluded.model,
    object_path=excluded.object_path,sha256='',updated_at=now()
  returning * into result;
  return to_jsonb(result);
end
$kat$;

create or replace function public.kat_commit_skin(
  p_sha256 text, p_model text default 'auto'
) returns jsonb language plpgsql security definer set search_path=public as $kat$
declare result public.kat_skins;
begin
  if p_sha256 !~ '^[0-9a-f]{64}$' then raise exception 'Hash no válido'; end if;
  if p_model not in ('auto','classic','slim') then raise exception 'Modelo no válido'; end if;
  update public.kat_skins set sha256=p_sha256,model=p_model,updated_at=now()
    where user_id=auth.uid() returning * into result;
  if result.user_id is null then raise exception 'KatSkin no preparada'; end if;
  return to_jsonb(result);
end
$kat$;

-- Conserva todo lo reciente durante 7 días y, después, al menos los últimos
-- 100 globales o los últimos 100 de cada conversación privada.
create or replace function public.kat_prune_message_history()
returns trigger language plpgsql security definer set search_path=public as $kat$
begin
  if new.recipient is null then
    delete from public.kat_messages m
    where m.recipient is null and m.created_at<now()-interval '7 days'
      and m.id not in (
        select id from public.kat_messages
        where recipient is null order by created_at desc,id desc limit 100
      )
      and not exists(
        select 1 from public.kat_reports r
        where r.message_id=m.id and r.status='open'
      );
  else
    delete from public.kat_messages m
    where m.recipient is not null and m.created_at<now()-interval '7 days'
      and least(m.sender,m.recipient)=least(new.sender,new.recipient)
      and greatest(m.sender,m.recipient)=greatest(new.sender,new.recipient)
      and m.id not in (
        select id from public.kat_messages x
        where x.recipient is not null
          and least(x.sender,x.recipient)=least(new.sender,new.recipient)
          and greatest(x.sender,x.recipient)=greatest(new.sender,new.recipient)
        order by x.created_at desc,x.id desc limit 100
      )
      and not exists(
        select 1 from public.kat_reports r
        where r.message_id=m.id and r.status='open'
      );
  end if;
  return new;
end
$kat$;

drop trigger if exists kat_prune_messages_after_insert on public.kat_messages;
create trigger kat_prune_messages_after_insert
after insert on public.kat_messages for each row
execute function public.kat_prune_message_history();

revoke all on function public.kat_claim_skin_name(text,text) from public,anon;
revoke all on function public.kat_commit_skin(text,text) from public,anon;
grant execute on function public.kat_claim_skin_name(text,text) to authenticated;
grant execute on function public.kat_commit_skin(text,text) to authenticated;

select 'Kat Social hotfix + KatSkin listo' as status;


-- FIN: 05_kat_social_hotfix_katskin.sql


-- ===========================================================================
-- INICIO: 06_kat_trophies_presence.sql
-- ===========================================================================

-- KatLauncher: trofeos públicos, Platino y Kat Presence.
-- Ejecutar después de 05_kat_social_hotfix_katskin.sql.
-- Idempotente: puede ejecutarse nuevamente.

alter table public.kat_profiles
  add column if not exists platinum boolean not null default false;
alter table public.kat_profiles
  add column if not exists presence_enabled boolean not null default true;
alter table public.kat_profiles
  add column if not exists presence_active boolean not null default false;
alter table public.kat_profiles
  add column if not exists presence_loader text not null default '';
alter table public.kat_profiles
  add column if not exists presence_version text not null default '';
alter table public.kat_profiles
  add column if not exists presence_skin text not null default '';
alter table public.kat_profiles
  add column if not exists presence_updated_at timestamptz;

create table if not exists public.kat_user_trophies (
  user_id uuid not null references public.kat_profiles(id) on delete cascade,
  trophy_id text not null,
  unlocked_at timestamptz not null default now(),
  primary key(user_id,trophy_id),
  check(trophy_id in (
    'guide_complete','play_10h','play_50h','play_100h','first_friend',
    'first_update','first_mod','first_modpack','first_global','first_post','first_potato'
  ))
);
alter table public.kat_user_trophies enable row level security;
revoke all on public.kat_user_trophies from anon,authenticated;

create or replace function public.kat_trophy_title(p_id text) returns text
language sql immutable set search_path=public as $kat$
  select case p_id
    when 'guide_complete' then 'Disfruta de KatLauncher'
    when 'play_10h' then 'Aventurero de bronce'
    when 'play_50h' then 'Leyenda de oro'
    when 'play_100h' then 'Gato de diamante'
    when 'first_friend' then '¡Mejores Amigos para siempre!'
    when 'first_update' then '¡Actualizado!'
    when 'first_mod' then '¡Mirad, ahora la vaca tiene alas!'
    when 'first_modpack' then '¿Estoy en Minecraft?'
    when 'first_global' then '¡Miren, soy nuevo!'
    when 'first_post' then '¡Genial!'
    when 'first_potato' then 'Primero lo primero'
    else p_id
  end
$kat$;

create or replace function public.kat_trophy_tier(p_id text) returns text
language sql immutable set search_path=public as $kat$
  select case
    when p_id='play_100h' then 'diamante'
    when p_id in ('play_50h','first_update','first_modpack') then 'oro'
    when p_id in ('first_friend','first_post') then 'plata'
    else 'bronce'
  end
$kat$;

create or replace function public.kat_sync_trophies(p_trophies text[])
returns jsonb language plpgsql security definer set search_path=public as $kat$
declare result public.kat_profiles;
begin
  if auth.uid() is null then raise exception 'Sesión no válida'; end if;
  insert into public.kat_user_trophies(user_id,trophy_id)
  select auth.uid(),value
  from unnest(coalesce(p_trophies,array[]::text[])) as item(value)
  where value in (
    'guide_complete','play_10h','play_50h','play_100h','first_friend',
    'first_update','first_mod','first_modpack','first_global','first_post','first_potato'
  )
  on conflict do nothing;
  update public.kat_profiles set
    platinum=(
      select count(distinct trophy_id)=11
      from public.kat_user_trophies where user_id=auth.uid()
    ),
    last_seen=now()
  where id=auth.uid() returning * into result;
  if result.id is null then raise exception 'Perfil no disponible'; end if;
  return to_jsonb(result)-'banned'-'timeout_until';
end
$kat$;

create or replace function public.kat_set_presence(
  p_active boolean,p_loader text default '',p_version text default '',
  p_skin text default '',p_enabled boolean default true
) returns jsonb language plpgsql security definer set search_path=public as $kat$
declare result public.kat_profiles; clean_loader text:=lower(trim(p_loader));
begin
  if auth.uid() is null then raise exception 'Sesión no válida'; end if;
  if p_active and clean_loader not in ('vanilla','fabric','forge','quilt','neoforge')
    then raise exception 'Loader no válido'; end if;
  if p_active and (
    char_length(trim(p_version)) not between 1 and 40
    or trim(p_version) ~ '[[:cntrl:]]'
  ) then raise exception 'Versión no válida'; end if;
  if p_active and p_skin !~ '^[A-Za-z0-9_]{1,16}$'
    then raise exception 'Skin no válida'; end if;
  update public.kat_profiles set
    presence_enabled=coalesce(p_enabled,true),
    presence_active=coalesce(p_enabled,true) and coalesce(p_active,false),
    presence_loader=case when p_active then clean_loader else '' end,
    presence_version=case when p_active then trim(p_version) else '' end,
    presence_skin=case when p_active then p_skin else '' end,
    presence_updated_at=now(),last_seen=now()
  where id=auth.uid() returning * into result;
  if result.id is null then raise exception 'Perfil no disponible'; end if;
  return to_jsonb(result)-'banned'-'timeout_until';
end
$kat$;

create or replace function public.kat_touch_presence() returns jsonb
language plpgsql security definer set search_path=public as $kat$
declare result public.kat_profiles;
begin
  update public.kat_profiles set
    last_seen=now(),
    presence_updated_at=case when presence_active then now()
      else presence_updated_at end
  where id=auth.uid() returning * into result;
  if result.id is null then raise exception 'Perfil no disponible'; end if;
  return to_jsonb(result)-'banned'-'timeout_until';
end
$kat$;

create or replace function public.kat_get_public_profile(p_user uuid)
returns jsonb language plpgsql security definer set search_path=public as $kat$
declare p public.kat_profiles; result jsonb;
begin
  if auth.uid() is null then raise exception 'Sesión no válida'; end if;
  if exists(select 1 from public.kat_blocks b where
    (b.blocker=auth.uid() and b.blocked=p_user)
    or (b.blocker=p_user and b.blocked=auth.uid()))
  then raise exception 'Perfil no disponible'; end if;
  select * into p from public.kat_profiles where id=p_user and not banned;
  if p.id is null then raise exception 'Perfil no disponible'; end if;
  result:=jsonb_build_object(
    'id',p.id,'display_name',p.display_name,'avatar_url',p.avatar_url,
    'avatar_path',p.avatar_path,'avatar_updated_at',p.avatar_updated_at,
    'rank_name',public.kat_rank_name(p.play_seconds),
    'play_seconds',p.play_seconds,'platinum',p.platinum,
    'is_self',p.id=auth.uid(),
    'is_friend',exists(select 1 from public.kat_friendships f
      where f.user_a=least(auth.uid(),p.id) and f.user_b=greatest(auth.uid(),p.id)),
    'presence',jsonb_build_object(
      'enabled',p.presence_enabled,
      'active',p.presence_enabled and p.presence_active
        and p.presence_updated_at>now()-interval '90 seconds',
      'loader',p.presence_loader,'version',p.presence_version,
      'skin',p.presence_skin,'updated_at',p.presence_updated_at
    ),
    'badges',coalesce((
      select jsonb_agg(jsonb_build_object(
        'id',badge.id,'label',badge.label,'color',badge.color
      ) order by badge.position)
      from (values
        (1,'play_10h','Bronce · 10 horas','#cd7f32'),
        (2,'play_50h','Oro · 50 horas','#ffd700'),
        (3,'play_100h','Diamante · 100 horas','#64d8ff'),
        (4,'kat_platinum','Platino KatLauncher','#e5f4ff')
      ) as badge(position,id,label,color)
      where (badge.id='kat_platinum' and p.platinum) or exists(
        select 1 from public.kat_user_trophies bt
        where bt.user_id=p.id and bt.trophy_id=badge.id
      )
    ),'[]'::jsonb),
    'trophies',coalesce((
      select jsonb_agg(jsonb_build_object(
        'id',t.trophy_id,'title',public.kat_trophy_title(t.trophy_id),
        'tier',public.kat_trophy_tier(t.trophy_id),
        'unlocked_at',t.unlocked_at
      ) order by t.unlocked_at)
      from public.kat_user_trophies t where t.user_id=p.id
    ),'[]'::jsonb)
  );
  return result;
end
$kat$;

drop function if exists public.kat_search_users(text);
create function public.kat_search_users(p_query text)
returns table(id uuid,display_name text,avatar_url text,avatar_path text,
  avatar_updated_at timestamptz,online boolean,rank_name text,
  play_seconds bigint,platinum boolean)
language sql security definer set search_path=public as $kat$
  select p.id,p.display_name,p.avatar_url,p.avatar_path,p.avatar_updated_at,
    p.last_seen>now()-interval '90 seconds',public.kat_rank_name(p.play_seconds),
    p.play_seconds,p.platinum
  from public.kat_profiles p where p.id<>auth.uid() and not p.banned
    and p.display_name ilike '%'||left(trim(p_query),40)||'%'
    and not exists(select 1 from public.kat_blocks b where
      (b.blocker=auth.uid() and b.blocked=p.id)
      or (b.blocker=p.id and b.blocked=auth.uid()))
  order by p.display_name limit 20
$kat$;

drop function if exists public.kat_list_friends();
create function public.kat_list_friends()
returns table(id uuid,display_name text,avatar_url text,avatar_path text,
  avatar_updated_at timestamptz,online boolean,unread_count bigint,
  rank_name text,play_seconds bigint,platinum boolean)
language sql security definer set search_path=public as $kat$
  select p.id,p.display_name,p.avatar_url,p.avatar_path,p.avatar_updated_at,
    p.last_seen>now()-interval '90 seconds',
    (select count(*) from public.kat_messages m
      where m.sender=p.id and m.recipient=auth.uid() and not m.hidden
        and m.created_at>coalesce((select r.last_read_at from public.kat_dm_reads r
          where r.user_id=auth.uid() and r.friend_id=p.id),to_timestamp(0))),
    public.kat_rank_name(p.play_seconds),p.play_seconds,p.platinum
  from public.kat_friendships f join public.kat_profiles p
    on p.id=case when f.user_a=auth.uid() then f.user_b else f.user_a end
  where auth.uid() in(f.user_a,f.user_b) order by p.display_name
$kat$;

drop function if exists public.kat_list_friend_requests();
create function public.kat_list_friend_requests()
returns table(request_id bigint,id uuid,display_name text,avatar_url text,
  avatar_path text,avatar_updated_at timestamptz,online boolean,platinum boolean)
language sql security definer set search_path=public as $kat$
  select r.id,p.id,p.display_name,p.avatar_url,p.avatar_path,p.avatar_updated_at,
    p.last_seen>now()-interval '90 seconds',p.platinum
  from public.kat_friend_requests r join public.kat_profiles p on p.id=r.sender
  where r.receiver=auth.uid() and r.status='pending' order by r.created_at desc
$kat$;

drop function if exists public.kat_list_global_messages();
create function public.kat_list_global_messages()
returns table(id bigint,sender_id uuid,display_name text,avatar_url text,
  avatar_path text,avatar_updated_at timestamptz,body text,
  created_at timestamptz,platinum boolean)
language sql security definer set search_path=public as $kat$
  select m.id,m.sender,p.display_name,p.avatar_url,p.avatar_path,
    p.avatar_updated_at,m.body,m.created_at,p.platinum
  from (select * from public.kat_messages where recipient is null and not hidden
    order by created_at desc limit 100) m
  join public.kat_profiles p on p.id=m.sender
  where not exists(select 1 from public.kat_blocks b where
    (b.blocker=auth.uid() and b.blocked=m.sender)
    or (b.blocker=m.sender and b.blocked=auth.uid()))
  order by m.created_at
$kat$;

drop function if exists public.kat_list_private_messages(uuid);
create function public.kat_list_private_messages(p_friend uuid)
returns table(id bigint,sender_id uuid,display_name text,avatar_url text,
  avatar_path text,avatar_updated_at timestamptz,body text,
  created_at timestamptz,platinum boolean)
language sql security definer set search_path=public as $kat$
  select m.id,m.sender,p.display_name,p.avatar_url,p.avatar_path,
    p.avatar_updated_at,m.body,m.created_at,p.platinum
  from (select * from public.kat_messages where not hidden and (
    (sender=auth.uid() and recipient=p_friend)
    or (sender=p_friend and recipient=auth.uid())
  ) order by created_at desc limit 100) m
  join public.kat_profiles p on p.id=m.sender order by m.created_at
$kat$;

drop function if exists public.kat_list_posts();
create function public.kat_list_posts()
returns table(id bigint,author_id uuid,display_name text,avatar_url text,
  avatar_path text,avatar_updated_at timestamptz,rank_name text,
  play_seconds bigint,body text,created_at timestamptz,platinum boolean)
language sql security definer set search_path=public as $kat$
  select po.id,po.author,p.display_name,p.avatar_url,p.avatar_path,
    p.avatar_updated_at,public.kat_rank_name(p.play_seconds),p.play_seconds,
    po.body,po.created_at,p.platinum
  from (select * from public.kat_posts where not hidden
    order by created_at desc limit 100) po
  join public.kat_profiles p on p.id=po.author
  where not exists(select 1 from public.kat_blocks b where
    (b.blocker=auth.uid() and b.blocked=po.author)
    or (b.blocker=po.author and b.blocked=auth.uid()))
  order by po.created_at desc
$kat$;

do $kat_grants$
declare f record;
begin
  for f in select p.oid::regprocedure as signature from pg_proc p
    join pg_namespace n on n.oid=p.pronamespace
    where n.nspname='public' and p.proname like 'kat_%'
  loop
    execute format('revoke all on function %s from public,anon',f.signature);
    execute format('grant execute on function %s to authenticated',f.signature);
  end loop;
end
$kat_grants$;

select 'Kat Trofeos + Kat Presence listo' as status;


-- FIN: 06_kat_trophies_presence.sql


-- ===========================================================================
-- INICIO: 07_kat_launcher_version_profiles.sql
-- ===========================================================================

-- KatLauncher 1.4.1+: versión pública del cliente y perfil público robusto.
-- Ejecutar después de 06_kat_trophies_presence.sql.
-- Idempotente: se puede ejecutar nuevamente sin borrar datos.

alter table public.kat_profiles
  add column if not exists launcher_version text not null default '';

create or replace function public.kat_set_launcher_version(p_version text)
returns jsonb language plpgsql security definer set search_path=public as $kat$
declare result public.kat_profiles; clean text:=trim(coalesce(p_version,''));
begin
  if auth.uid() is null then raise exception 'Sesión no válida'; end if;
  if char_length(clean) not between 1 and 24
    or clean !~ '^[0-9A-Za-z][0-9A-Za-z.+_-]{0,23}$'
  then raise exception 'Versión de KatLauncher no válida'; end if;
  update public.kat_profiles
    set launcher_version=clean,last_seen=now()
    where id=auth.uid() returning * into result;
  if result.id is null then raise exception 'Perfil no disponible'; end if;
  return to_jsonb(result)-'banned'-'timeout_until';
end
$kat$;

create or replace function public.kat_get_public_profile(p_user uuid)
returns jsonb language plpgsql security definer set search_path=public as $kat$
declare p public.kat_profiles; result jsonb;
begin
  if auth.uid() is null then raise exception 'Sesión no válida'; end if;
  if exists(select 1 from public.kat_blocks b where
    (b.blocker=auth.uid() and b.blocked=p_user)
    or (b.blocker=p_user and b.blocked=auth.uid()))
  then raise exception 'Perfil no disponible'; end if;
  select * into p from public.kat_profiles where id=p_user and not banned;
  if p.id is null then raise exception 'Perfil no disponible'; end if;
  result:=jsonb_build_object(
    'id',p.id,'display_name',p.display_name,'avatar_url',p.avatar_url,
    'avatar_path',p.avatar_path,'avatar_updated_at',p.avatar_updated_at,
    'launcher_version',p.launcher_version,
    'rank_name',public.kat_rank_name(p.play_seconds),
    'play_seconds',p.play_seconds,'platinum',p.platinum,
    'is_self',p.id=auth.uid(),
    'is_friend',exists(select 1 from public.kat_friendships f
      where f.user_a=least(auth.uid(),p.id) and f.user_b=greatest(auth.uid(),p.id)),
    'presence',jsonb_build_object(
      'enabled',p.presence_enabled,
      'active',p.presence_enabled and p.presence_active
        and p.presence_updated_at>now()-interval '90 seconds',
      'loader',p.presence_loader,'version',p.presence_version,
      'skin',p.presence_skin,'updated_at',p.presence_updated_at
    ),
    'badges',coalesce((
      select jsonb_agg(jsonb_build_object(
        'id',badge.id,'label',badge.label,'color',badge.color
      ) order by badge.position)
      from (values
        (1,'play_10h','Bronce · 10 horas','#cd7f32'),
        (2,'play_50h','Oro · 50 horas','#ffd700'),
        (3,'play_100h','Diamante · 100 horas','#64d8ff'),
        (4,'kat_platinum','Platino KatLauncher','#e5f4ff')
      ) as badge(position,id,label,color)
      where (badge.id='kat_platinum' and p.platinum) or exists(
        select 1 from public.kat_user_trophies bt
        where bt.user_id=p.id and bt.trophy_id=badge.id
      )
    ),'[]'::jsonb),
    'trophies',coalesce((
      select jsonb_agg(jsonb_build_object(
        'id',t.trophy_id,'title',public.kat_trophy_title(t.trophy_id),
        'tier',public.kat_trophy_tier(t.trophy_id),
        'unlocked_at',t.unlocked_at
      ) order by t.unlocked_at)
      from public.kat_user_trophies t where t.user_id=p.id
    ),'[]'::jsonb)
  );
  return result;
end
$kat$;

revoke all on function public.kat_set_launcher_version(text) from public,anon;
grant execute on function public.kat_set_launcher_version(text) to authenticated;
revoke all on function public.kat_get_public_profile(uuid) from public,anon;
grant execute on function public.kat_get_public_profile(uuid) to authenticated;

select 'Perfiles públicos + versión de KatLauncher listos' as status;

-- FIN: 07_kat_launcher_version_profiles.sql

-- KatCraft 1.0: presencia dentro del juego, amigos e invitaciones.
-- Ejecutar después de 07_kat_launcher_version_profiles.sql.
-- Idempotente: no elimina mensajes, amistades, perfiles ni trofeos.

alter table public.kat_profiles
  add column if not exists game_nickname text not null default '',
  add column if not exists katcraft_active boolean not null default false,
  add column if not exists katcraft_loader text not null default '',
  add column if not exists katcraft_version text not null default '',
  add column if not exists katcraft_seen_at timestamptz;

create unique index if not exists kat_profiles_game_nickname_unique
  on public.kat_profiles(lower(game_nickname))
  where game_nickname <> '';

create table if not exists public.kat_game_invites (
  id bigint generated always as identity primary key,
  sender_id uuid not null references public.kat_profiles(id) on delete cascade,
  recipient_id uuid not null references public.kat_profiles(id) on delete cascade,
  server_host text not null check(char_length(server_host) between 1 and 253),
  server_port integer not null check(server_port between 1 and 65535),
  minecraft_version text not null default '',
  loader text not null default '',
  status text not null default 'pending'
    check(status in ('pending','accepted','rejected','expired')),
  created_at timestamptz not null default now(),
  expires_at timestamptz not null default now()+interval '10 minutes',
  check(sender_id<>recipient_id)
);

create index if not exists kat_game_invites_recipient
  on public.kat_game_invites(recipient_id,status,expires_at desc);

alter table public.kat_game_invites enable row level security;
revoke all on public.kat_game_invites from anon,authenticated;

create or replace function public.kat_set_katcraft_presence(
  p_nickname text,
  p_active boolean,
  p_loader text default '',
  p_version text default '',
  p_players text[] default array[]::text[]
) returns jsonb language plpgsql security definer set search_path=public as $kat$
declare
  clean_nickname text:=trim(coalesce(p_nickname,''));
  clean_players text[]:=coalesce(p_players,array[]::text[]);
  player_rows jsonb;
begin
  if auth.uid() is null then raise exception 'Sesión no válida'; end if;
  if clean_nickname !~ '^[A-Za-z0-9_]{1,16}$'
  then raise exception 'Nickname de Minecraft no válido'; end if;
  if cardinality(clean_players)>100
  then raise exception 'Demasiados jugadores'; end if;

  update public.kat_profiles
  set game_nickname=clean_nickname,
      katcraft_active=coalesce(p_active,false),
      katcraft_loader=left(trim(coalesce(p_loader,'')),24),
      katcraft_version=left(trim(coalesce(p_version,'')),40),
      katcraft_seen_at=now(),
      last_seen=now()
  where id=auth.uid();

  select coalesce(jsonb_agg(jsonb_build_object(
    'id',p.id,
    'nickname',p.game_nickname,
    'display_name',p.display_name,
    'platinum',p.platinum,
    'rank',case
      when p.platinum then 'platinum'
      when coalesce(p.play_seconds,0)>=360000 then 'diamond'
      when coalesce(p.play_seconds,0)>=180000 then 'gold'
      when coalesce(p.play_seconds,0)>=36000 then 'bronze'
      else 'kat' end,
    'trophies',coalesce((
      select jsonb_agg(jsonb_build_object(
        'id',t.trophy_id,
        'title',public.kat_trophy_title(t.trophy_id),
        'tier',public.kat_trophy_tier(t.trophy_id)
      ) order by t.unlocked_at)
      from public.kat_user_trophies t where t.user_id=p.id
    ),'[]'::jsonb)
  ) order by p.game_nickname),'[]'::jsonb)
  into player_rows
  from public.kat_profiles p
  where p.katcraft_active
    and p.katcraft_seen_at>now()-interval '90 seconds'
    and lower(p.game_nickname) in (
      select lower(value) from unnest(clean_players) value
    )
    and not p.banned;

  return jsonb_build_object('ok',true,'players',player_rows);
exception
  when unique_violation then
    raise exception 'Ese nickname ya está vinculado a otra cuenta de Kat Social';
end
$kat$;

create or replace function public.kat_list_katcraft_friends()
returns jsonb language sql security definer set search_path=public as $kat$
  select coalesce(jsonb_agg(jsonb_build_object(
    'id',p.id,
    'display_name',p.display_name,
    'online',p.last_seen>now()-interval '90 seconds',
    'katcraft',p.katcraft_active
      and p.katcraft_seen_at>now()-interval '90 seconds',
    'game_nickname',p.game_nickname,
    'loader',p.katcraft_loader,
    'version',p.katcraft_version,
    'platinum',p.platinum,
    'rank',case
      when p.platinum then 'platinum'
      when coalesce(p.play_seconds,0)>=360000 then 'diamond'
      when coalesce(p.play_seconds,0)>=180000 then 'gold'
      when coalesce(p.play_seconds,0)>=36000 then 'bronze'
      else 'kat' end,
    'trophies',coalesce((
      select jsonb_agg(jsonb_build_object(
        'id',t.trophy_id,
        'title',public.kat_trophy_title(t.trophy_id),
        'tier',public.kat_trophy_tier(t.trophy_id)
      ) order by t.unlocked_at)
      from public.kat_user_trophies t where t.user_id=p.id
    ),'[]'::jsonb)
  ) order by p.display_name),'[]'::jsonb)
  from public.kat_friendships f
  join public.kat_profiles p
    on p.id=case when f.user_a=auth.uid() then f.user_b else f.user_a end
  where auth.uid() in(f.user_a,f.user_b)
    and not p.banned
    and not exists(select 1 from public.kat_blocks b where
      (b.blocker=auth.uid() and b.blocked=p.id)
      or (b.blocker=p.id and b.blocked=auth.uid()))
$kat$;

create or replace function public.kat_send_game_invite(
  p_recipient uuid,
  p_host text,
  p_port integer default 25565,
  p_version text default '',
  p_loader text default ''
) returns jsonb language plpgsql security definer set search_path=public as $kat$
declare result public.kat_game_invites; clean_host text:=trim(coalesce(p_host,''));
begin
  if auth.uid() is null then raise exception 'Sesión no válida'; end if;
  if p_recipient is null or p_recipient=auth.uid()
  then raise exception 'Amigo no válido'; end if;
  if not exists(select 1 from public.kat_friendships f
    where f.user_a=least(auth.uid(),p_recipient)
      and f.user_b=greatest(auth.uid(),p_recipient))
  then raise exception 'Solo puedes invitar amigos'; end if;
  if char_length(clean_host) not between 1 and 253
    or clean_host !~ '^[0-9A-Za-z._:-]+$'
    or p_port not between 1 and 65535
  then raise exception 'Servidor no válido'; end if;

  update public.kat_game_invites set status='expired'
    where status='pending' and expires_at<=now();
  insert into public.kat_game_invites(
    sender_id,recipient_id,server_host,server_port,minecraft_version,loader
  ) values(
    auth.uid(),p_recipient,clean_host,p_port,
    left(trim(coalesce(p_version,'')),40),
    left(trim(coalesce(p_loader,'')),24)
  ) returning * into result;
  return to_jsonb(result);
end
$kat$;

create or replace function public.kat_list_game_invites()
returns jsonb language sql security definer set search_path=public as $kat$
  select coalesce(jsonb_agg(jsonb_build_object(
    'id',i.id,'sender_id',i.sender_id,'display_name',p.display_name,
    'server_host',i.server_host,'server_port',i.server_port,
    'minecraft_version',i.minecraft_version,'loader',i.loader,
    'created_at',i.created_at,'expires_at',i.expires_at
  ) order by i.created_at desc),'[]'::jsonb)
  from public.kat_game_invites i
  join public.kat_profiles p on p.id=i.sender_id
  where i.recipient_id=auth.uid() and i.status='pending'
    and i.expires_at>now()
    and not exists(select 1 from public.kat_blocks b where
      (b.blocker=auth.uid() and b.blocked=i.sender_id)
      or (b.blocker=i.sender_id and b.blocked=auth.uid()))
$kat$;

create or replace function public.kat_respond_game_invite(
  p_invite bigint,p_accept boolean
) returns jsonb language plpgsql security definer set search_path=public as $kat$
declare result public.kat_game_invites;
begin
  update public.kat_game_invites
    set status=case when expires_at<=now() then 'expired'
                    when coalesce(p_accept,false) then 'accepted'
                    else 'rejected' end
    where id=p_invite and recipient_id=auth.uid() and status='pending'
    returning * into result;
  if result.id is null then raise exception 'Invitación no disponible'; end if;
  return to_jsonb(result);
end
$kat$;

revoke all on function public.kat_set_katcraft_presence(
  text,boolean,text,text,text[]
) from public,anon;
revoke all on function public.kat_list_katcraft_friends() from public,anon;
revoke all on function public.kat_send_game_invite(
  uuid,text,integer,text,text
) from public,anon;
revoke all on function public.kat_list_game_invites() from public,anon;
revoke all on function public.kat_respond_game_invite(
  bigint,boolean
) from public,anon;

grant execute on function public.kat_set_katcraft_presence(
  text,boolean,text,text,text[]
) to authenticated;
grant execute on function public.kat_list_katcraft_friends() to authenticated;
grant execute on function public.kat_send_game_invite(
  uuid,text,integer,text,text
) to authenticated;
grant execute on function public.kat_list_game_invites() to authenticated;
grant execute on function public.kat_respond_game_invite(
  bigint,boolean
) to authenticated;

select 'KatCraft listo' as status;

-- FIN: 08_katcraft.sql

-- KatLauncher 1.5.1: directorio seguro de salas públicas.
-- Ejecutar después de 08_katcraft.sql.
-- Idempotente: no borra perfiles, mensajes, amistades, trofeos ni salas.

create table if not exists public.kat_rooms (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.kat_profiles(id) on delete cascade,
  name text not null check(char_length(name) between 2 and 48),
  description text not null default '' check(char_length(description)<=240),
  server_host text not null check(char_length(server_host) between 1 and 253),
  server_port integer not null check(server_port between 1 and 65535),
  minecraft_version text not null check(char_length(minecraft_version) between 1 and 40),
  loader text not null default 'vanilla' check(char_length(loader) between 1 and 24),
  loader_version text not null default '' check(char_length(loader_version)<=64),
  launcher_version text not null default '' check(char_length(launcher_version)<=24),
  modpack_id text not null default '' check(char_length(modpack_id)<=128),
  mods jsonb not null default '[]'::jsonb,
  visibility text not null default 'public'
    check(visibility in ('public','friends','private')),
  status text not null default 'online'
    check(status in ('starting','online','stopping','offline')),
  players_online integer not null default 0 check(players_online between 0 and 1000),
  players_max integer not null default 8 check(players_max between 1 and 1000),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  expires_at timestamptz not null default now()+interval '3 minutes',
  check(jsonb_typeof(mods)='array'),
  check(jsonb_array_length(mods)<=500)
);

alter table public.kat_rooms
  add column if not exists description text not null default '',
  add column if not exists loader_version text not null default '',
  add column if not exists launcher_version text not null default '',
  add column if not exists modpack_id text not null default '',
  add column if not exists mods jsonb not null default '[]'::jsonb,
  add column if not exists visibility text not null default 'public',
  add column if not exists status text not null default 'online',
  add column if not exists players_online integer not null default 0,
  add column if not exists players_max integer not null default 8,
  add column if not exists expires_at timestamptz not null
    default now()+interval '3 minutes';

create unique index if not exists kat_rooms_one_live_room_per_owner
  on public.kat_rooms(owner_id)
  where status in ('starting','online');
create index if not exists kat_rooms_public_directory
  on public.kat_rooms(visibility,status,expires_at desc);

alter table public.kat_rooms enable row level security;
revoke all on public.kat_rooms from anon,authenticated;

create or replace function public.kat_publish_room(
  p_name text,
  p_description text,
  p_host text,
  p_port integer,
  p_version text,
  p_loader text default 'vanilla',
  p_loader_version text default '',
  p_launcher_version text default '',
  p_modpack_id text default '',
  p_mods jsonb default '[]'::jsonb,
  p_visibility text default 'public',
  p_players_max integer default 8
) returns jsonb language plpgsql security definer set search_path=public as $kat$
declare
  clean_name text:=trim(coalesce(p_name,''));
  clean_description text:=trim(coalesce(p_description,''));
  clean_host text:=trim(coalesce(p_host,''));
  clean_loader text:=lower(trim(coalesce(p_loader,'vanilla')));
  clean_visibility text:=lower(trim(coalesce(p_visibility,'public')));
  clean_mods jsonb:=coalesce(p_mods,'[]'::jsonb);
  result public.kat_rooms;
begin
  if auth.uid() is null then raise exception 'Sesión no válida'; end if;
  if char_length(clean_name) not between 2 and 48
  then raise exception 'El nombre debe tener entre 2 y 48 caracteres'; end if;
  if char_length(clean_description)>240
  then raise exception 'La descripción es demasiado larga'; end if;
  if char_length(clean_host) not between 1 and 253
    or clean_host !~ '^[0-9A-Za-z._:-]+$'
    or p_port not between 1 and 65535
  then raise exception 'Servidor no válido'; end if;
  if char_length(trim(coalesce(p_version,''))) not between 1 and 40
  then raise exception 'Versión de Minecraft no válida'; end if;
  if clean_loader not in ('vanilla','fabric','forge','neoforge','quilt')
  then raise exception 'Loader no válido'; end if;
  if clean_visibility not in ('public','friends','private')
  then raise exception 'Visibilidad no válida'; end if;
  if jsonb_typeof(clean_mods)<>'array' or jsonb_array_length(clean_mods)>500
  then raise exception 'Lista de mods no válida'; end if;
  if coalesce(p_players_max,8) not between 1 and 1000
  then raise exception 'Límite de jugadores no válido'; end if;

  update public.kat_rooms
    set status='offline',expires_at=now(),updated_at=now()
    where owner_id=auth.uid() and status in ('starting','online');

  insert into public.kat_rooms(
    owner_id,name,description,server_host,server_port,minecraft_version,
    loader,loader_version,launcher_version,modpack_id,mods,visibility,
    status,players_online,players_max,expires_at
  ) values(
    auth.uid(),clean_name,clean_description,clean_host,p_port,
    left(trim(p_version),40),clean_loader,
    left(trim(coalesce(p_loader_version,'')),64),
    left(trim(coalesce(p_launcher_version,'')),24),
    left(trim(coalesce(p_modpack_id,'')),128),clean_mods,clean_visibility,
    'online',0,coalesce(p_players_max,8),now()+interval '3 minutes'
  ) returning * into result;
  return to_jsonb(result);
end
$kat$;

create or replace function public.kat_touch_room(
  p_room uuid,
  p_players integer default 0
) returns jsonb language plpgsql security definer set search_path=public as $kat$
declare result public.kat_rooms;
begin
  update public.kat_rooms
    set status='online',
        players_online=greatest(0,least(coalesce(p_players,0),players_max)),
        updated_at=now(),
        expires_at=now()+interval '3 minutes'
    where id=p_room and owner_id=auth.uid()
      and status in ('starting','online')
    returning * into result;
  if result.id is null then raise exception 'Sala no disponible'; end if;
  return to_jsonb(result);
end
$kat$;

create or replace function public.kat_unpublish_room(
  p_room uuid
) returns jsonb language plpgsql security definer set search_path=public as $kat$
declare result public.kat_rooms;
begin
  update public.kat_rooms
    set status='offline',updated_at=now(),expires_at=now()
    where id=p_room and owner_id=auth.uid()
    returning * into result;
  if result.id is null then raise exception 'Sala no disponible'; end if;
  return to_jsonb(result);
end
$kat$;

create or replace function public.kat_list_public_rooms(
  p_search text default '',
  p_limit integer default 50
) returns jsonb language sql security definer set search_path=public as $kat$
  select coalesce(jsonb_agg(row_data order by
    (row_data->>'players_online')::integer desc,
    row_data->>'updated_at' desc
  ),'[]'::jsonb)
  from (
    select jsonb_build_object(
      'id',r.id,
      'owner_id',r.owner_id,
      'owner_name',p.display_name,
      'owner_avatar',p.avatar_path,
      'owner_platinum',p.platinum,
      'name',r.name,
      'description',r.description,
      'host',r.server_host,
      'port',r.server_port,
      'minecraft_version',r.minecraft_version,
      'loader',r.loader,
      'loader_version',r.loader_version,
      'launcher_version',r.launcher_version,
      'modpack_id',r.modpack_id,
      'mods',r.mods,
      'players_online',r.players_online,
      'players_max',r.players_max,
      'updated_at',r.updated_at,
      'expires_at',r.expires_at
    ) row_data
    from public.kat_rooms r
    join public.kat_profiles p on p.id=r.owner_id
    where auth.uid() is not null
      and r.visibility='public'
      and r.status='online'
      and r.expires_at>now()
      and not p.banned
      and (
        trim(coalesce(p_search,''))=''
        or r.name ilike '%'||left(trim(p_search),64)||'%'
        or r.description ilike '%'||left(trim(p_search),64)||'%'
        or p.display_name ilike '%'||left(trim(p_search),64)||'%'
      )
      and not exists(select 1 from public.kat_blocks b where
        (b.blocker=auth.uid() and b.blocked=r.owner_id)
        or (b.blocker=r.owner_id and b.blocked=auth.uid()))
    order by r.players_online desc,r.updated_at desc
    limit greatest(1,least(coalesce(p_limit,50),100))
  ) directory
$kat$;

create or replace function public.kat_get_room(
  p_room uuid
) returns jsonb language sql security definer set search_path=public as $kat$
  select coalesce((
    select jsonb_build_object(
      'id',r.id,'owner_id',r.owner_id,'owner_name',p.display_name,
      'owner_platinum',p.platinum,'name',r.name,'description',r.description,
      'host',r.server_host,'port',r.server_port,
      'minecraft_version',r.minecraft_version,'loader',r.loader,
      'loader_version',r.loader_version,'launcher_version',r.launcher_version,
      'modpack_id',r.modpack_id,'mods',r.mods,
      'players_online',r.players_online,'players_max',r.players_max,
      'visibility',r.visibility,'status',r.status,'expires_at',r.expires_at
    )
    from public.kat_rooms r join public.kat_profiles p on p.id=r.owner_id
    where r.id=p_room and auth.uid() is not null and r.expires_at>now()
      and (r.visibility='public' or r.owner_id=auth.uid() or (
        r.visibility='friends' and exists(
          select 1 from public.kat_friendships f
          where f.user_a=least(auth.uid(),r.owner_id)
            and f.user_b=greatest(auth.uid(),r.owner_id)
        )
      ))
  ),'{}'::jsonb)
$kat$;

revoke all on function public.kat_publish_room(
  text,text,text,integer,text,text,text,text,text,jsonb,text,integer
) from public,anon;
revoke all on function public.kat_touch_room(uuid,integer) from public,anon;
revoke all on function public.kat_unpublish_room(uuid) from public,anon;
revoke all on function public.kat_list_public_rooms(text,integer) from public,anon;
revoke all on function public.kat_get_room(uuid) from public,anon;

grant execute on function public.kat_publish_room(
  text,text,text,integer,text,text,text,text,text,jsonb,text,integer
) to authenticated;
grant execute on function public.kat_touch_room(uuid,integer) to authenticated;
grant execute on function public.kat_unpublish_room(uuid) to authenticated;
grant execute on function public.kat_list_public_rooms(text,integer) to authenticated;
grant execute on function public.kat_get_room(uuid) to authenticated;

select 'Salas públicas KatLauncher 1.5.1 listas' as status;

-- FIN: 09_kat_rooms_151.sql

commit;

select 'KAT SOCIAL + KATCRAFT + SALAS 1.5.1 LISTOS' as status;
