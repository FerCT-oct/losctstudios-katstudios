-- KatCraft 1.0: presencia dentro del juego, amigos e invitaciones.
-- Ejecutar después de 07_kat_launcher_version_profiles.sql.
-- Idempotente: no elimina mensajes, amistades, perfiles ni trofeos.

alter table public.kat_profiles
  add column if not exists game_nickname text not null default '',
  add column if not exists katcraft_active boolean not null default false,
  add column if not exists katcraft_loader text not null default '',
  add column if not exists katcraft_version text not null default '',
  add column if not exists katcraft_seen_at timestamptz;

create unique index if not exists kat_profiles_game_nickname_unique
  on public.kat_profiles(lower(game_nickname))
  where game_nickname <> '';

create table if not exists public.kat_game_invites (
  id bigint generated always as identity primary key,
  sender_id uuid not null references public.kat_profiles(id) on delete cascade,
  recipient_id uuid not null references public.kat_profiles(id) on delete cascade,
  server_host text not null check(char_length(server_host) between 1 and 253),
  server_port integer not null check(server_port between 1 and 65535),
  minecraft_version text not null default '',
  loader text not null default '',
  status text not null default 'pending'
    check(status in ('pending','accepted','rejected','expired')),
  created_at timestamptz not null default now(),
  expires_at timestamptz not null default now()+interval '10 minutes',
  check(sender_id<>recipient_id)
);

create index if not exists kat_game_invites_recipient
  on public.kat_game_invites(recipient_id,status,expires_at desc);

alter table public.kat_game_invites enable row level security;
revoke all on public.kat_game_invites from anon,authenticated;

create or replace function public.kat_set_katcraft_presence(
  p_nickname text,
  p_active boolean,
  p_loader text default '',
  p_version text default '',
  p_players text[] default array[]::text[]
) returns jsonb language plpgsql security definer set search_path=public as $kat$
declare
  clean_nickname text:=trim(coalesce(p_nickname,''));
  clean_players text[]:=coalesce(p_players,array[]::text[]);
  player_rows jsonb;
begin
  if auth.uid() is null then raise exception 'Sesión no válida'; end if;
  if clean_nickname !~ '^[A-Za-z0-9_]{1,16}$'
  then raise exception 'Nickname de Minecraft no válido'; end if;
  if cardinality(clean_players)>100
  then raise exception 'Demasiados jugadores'; end if;

  update public.kat_profiles
  set game_nickname=clean_nickname,
      katcraft_active=coalesce(p_active,false),
      katcraft_loader=left(trim(coalesce(p_loader,'')),24),
      katcraft_version=left(trim(coalesce(p_version,'')),40),
      katcraft_seen_at=now(),
      last_seen=now()
  where id=auth.uid();

  select coalesce(jsonb_agg(jsonb_build_object(
    'id',p.id,
    'nickname',p.game_nickname,
    'display_name',p.display_name,
    'platinum',p.platinum,
    'rank',case
      when p.platinum then 'platinum'
      when coalesce(p.play_seconds,0)>=360000 then 'diamond'
      when coalesce(p.play_seconds,0)>=180000 then 'gold'
      when coalesce(p.play_seconds,0)>=36000 then 'bronze'
      else 'kat' end,
    'trophies',coalesce((
      select jsonb_agg(jsonb_build_object(
        'id',t.trophy_id,
        'title',public.kat_trophy_title(t.trophy_id),
        'tier',public.kat_trophy_tier(t.trophy_id)
      ) order by t.unlocked_at)
      from public.kat_user_trophies t where t.user_id=p.id
    ),'[]'::jsonb)
  ) order by p.game_nickname),'[]'::jsonb)
  into player_rows
  from public.kat_profiles p
  where p.katcraft_active
    and p.katcraft_seen_at>now()-interval '90 seconds'
    and lower(p.game_nickname) in (
      select lower(value) from unnest(clean_players) value
    )
    and not p.banned;

  return jsonb_build_object('ok',true,'players',player_rows);
exception
  when unique_violation then
    raise exception 'Ese nickname ya está vinculado a otra cuenta de Kat Social';
end
$kat$;

create or replace function public.kat_list_katcraft_friends()
returns jsonb language sql security definer set search_path=public as $kat$
  select coalesce(jsonb_agg(jsonb_build_object(
    'id',p.id,
    'display_name',p.display_name,
    'online',p.last_seen>now()-interval '90 seconds',
    'katcraft',p.katcraft_active
      and p.katcraft_seen_at>now()-interval '90 seconds',
    'game_nickname',p.game_nickname,
    'loader',p.katcraft_loader,
    'version',p.katcraft_version,
    'platinum',p.platinum,
    'rank',case
      when p.platinum then 'platinum'
      when coalesce(p.play_seconds,0)>=360000 then 'diamond'
      when coalesce(p.play_seconds,0)>=180000 then 'gold'
      when coalesce(p.play_seconds,0)>=36000 then 'bronze'
      else 'kat' end,
    'trophies',coalesce((
      select jsonb_agg(jsonb_build_object(
        'id',t.trophy_id,
        'title',public.kat_trophy_title(t.trophy_id),
        'tier',public.kat_trophy_tier(t.trophy_id)
      ) order by t.unlocked_at)
      from public.kat_user_trophies t where t.user_id=p.id
    ),'[]'::jsonb)
  ) order by p.display_name),'[]'::jsonb)
  from public.kat_friendships f
  join public.kat_profiles p
    on p.id=case when f.user_a=auth.uid() then f.user_b else f.user_a end
  where auth.uid() in(f.user_a,f.user_b)
    and not p.banned
    and not exists(select 1 from public.kat_blocks b where
      (b.blocker=auth.uid() and b.blocked=p.id)
      or (b.blocker=p.id and b.blocked=auth.uid()))
$kat$;

create or replace function public.kat_send_game_invite(
  p_recipient uuid,
  p_host text,
  p_port integer default 25565,
  p_version text default '',
  p_loader text default ''
) returns jsonb language plpgsql security definer set search_path=public as $kat$
declare result public.kat_game_invites; clean_host text:=trim(coalesce(p_host,''));
begin
  if auth.uid() is null then raise exception 'Sesión no válida'; end if;
  if p_recipient is null or p_recipient=auth.uid()
  then raise exception 'Amigo no válido'; end if;
  if not exists(select 1 from public.kat_friendships f
    where f.user_a=least(auth.uid(),p_recipient)
      and f.user_b=greatest(auth.uid(),p_recipient))
  then raise exception 'Solo puedes invitar amigos'; end if;
  if char_length(clean_host) not between 1 and 253
    or clean_host !~ '^[0-9A-Za-z._:-]+$'
    or p_port not between 1 and 65535
  then raise exception 'Servidor no válido'; end if;

  update public.kat_game_invites set status='expired'
    where status='pending' and expires_at<=now();
  insert into public.kat_game_invites(
    sender_id,recipient_id,server_host,server_port,minecraft_version,loader
  ) values(
    auth.uid(),p_recipient,clean_host,p_port,
    left(trim(coalesce(p_version,'')),40),
    left(trim(coalesce(p_loader,'')),24)
  ) returning * into result;
  return to_jsonb(result);
end
$kat$;

create or replace function public.kat_list_game_invites()
returns jsonb language sql security definer set search_path=public as $kat$
  select coalesce(jsonb_agg(jsonb_build_object(
    'id',i.id,'sender_id',i.sender_id,'display_name',p.display_name,
    'server_host',i.server_host,'server_port',i.server_port,
    'minecraft_version',i.minecraft_version,'loader',i.loader,
    'created_at',i.created_at,'expires_at',i.expires_at
  ) order by i.created_at desc),'[]'::jsonb)
  from public.kat_game_invites i
  join public.kat_profiles p on p.id=i.sender_id
  where i.recipient_id=auth.uid() and i.status='pending'
    and i.expires_at>now()
    and not exists(select 1 from public.kat_blocks b where
      (b.blocker=auth.uid() and b.blocked=i.sender_id)
      or (b.blocker=i.sender_id and b.blocked=auth.uid()))
$kat$;

create or replace function public.kat_respond_game_invite(
  p_invite bigint,p_accept boolean
) returns jsonb language plpgsql security definer set search_path=public as $kat$
declare result public.kat_game_invites;
begin
  update public.kat_game_invites
    set status=case when expires_at<=now() then 'expired'
                    when coalesce(p_accept,false) then 'accepted'
                    else 'rejected' end
    where id=p_invite and recipient_id=auth.uid() and status='pending'
    returning * into result;
  if result.id is null then raise exception 'Invitación no disponible'; end if;
  return to_jsonb(result);
end
$kat$;

revoke all on function public.kat_set_katcraft_presence(
  text,boolean,text,text,text[]
) from public,anon;
revoke all on function public.kat_list_katcraft_friends() from public,anon;
revoke all on function public.kat_send_game_invite(
  uuid,text,integer,text,text
) from public,anon;
revoke all on function public.kat_list_game_invites() from public,anon;
revoke all on function public.kat_respond_game_invite(
  bigint,boolean
) from public,anon;

grant execute on function public.kat_set_katcraft_presence(
  text,boolean,text,text,text[]
) to authenticated;
grant execute on function public.kat_list_katcraft_friends() to authenticated;
grant execute on function public.kat_send_game_invite(
  uuid,text,integer,text,text
) to authenticated;
grant execute on function public.kat_list_game_invites() to authenticated;
grant execute on function public.kat_respond_game_invite(
  bigint,boolean
) to authenticated;

select 'KatCraft listo' as status;
