-- KatLauncher 1.5.2.1: alertas remotas (banner o diálogo) sin hosting aparte.
-- Ejecutar después de 10_kat_groups_152.sql (o después de
-- 00_KAT_SOCIAL_TODO_EN_UNO.sql si usaste el paquete completo).
-- Idempotente: no toca perfiles, mensajes, amistades, trofeos, salas ni grupos.
--
-- El launcher lee esta tabla con la misma publishable key pública que ya
-- trae social_config.json, sin necesitar sesión iniciada. Escribir queda
-- bloqueado para el cliente: solo tools/kat_alert_sender.py, con la
-- service_role key guardada en tu equipo, puede publicar o retirar avisos.

create table if not exists public.kat_alerts (
  id text primary key,
  severity text not null default 'info'
    check (severity in ('info', 'warning', 'critical')),
  display text not null default 'banner'
    check (display in ('banner', 'dialog')),
  sound boolean not null default true,
  title_es text not null default '',
  title_en text not null default '',
  message_es text not null default '',
  message_en text not null default '',
  active boolean not null default true,
  published_at timestamptz not null default now()
);

alter table public.kat_alerts enable row level security;

-- Cualquiera puede LEER la alerta activa más reciente, sin iniciar sesión.
drop policy if exists "kat_alerts_public_read" on public.kat_alerts;
create policy "kat_alerts_public_read"
  on public.kat_alerts for select
  using (true);

-- Nadie escribe desde el cliente (ni anon ni un usuario logueado); solo la
-- service_role key, que ignora RLS, usada por tools/kat_alert_sender.py.
revoke insert, update, delete on public.kat_alerts from anon, authenticated;

-- Función que consulta el launcher: la alerta activa más reciente, o null.
create or replace function public.kat_get_active_alert()
returns jsonb
language sql
stable
security definer
set search_path = public
as $kat$
  select to_jsonb(row)
  from (
    select id, severity, display, sound,
           title_es, title_en, message_es, message_en, published_at
    from public.kat_alerts
    where active = true
    order by published_at desc
    limit 1
  ) as row;
$kat$;

grant execute on function public.kat_get_active_alert() to anon, authenticated;

-- Realtime: el aviso nuevo llega casi al instante en vez de esperar al
-- siguiente sondeo periódico.
do $$ begin
  alter publication supabase_realtime add table public.kat_alerts;
exception when duplicate_object then null; end $$;
