-- Kat Social 1.4.0: publicaciones y rangos por tiempo jugado.
-- Ejecutar una vez después de kat_social.sql / 03_kat_social_profiles.sql.

alter table public.kat_profiles
  add column if not exists play_seconds bigint not null default 0
    check (play_seconds >= 0);
alter table public.kat_profiles
  add column if not exists play_credit_at timestamptz not null default now();

create table if not exists public.kat_posts (
  id bigint generated always as identity primary key,
  author uuid not null references public.kat_profiles(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 1000),
  hidden boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists kat_posts_created on public.kat_posts(created_at desc);
alter table public.kat_posts enable row level security;
revoke all on public.kat_posts from anon, authenticated;
grant select on public.kat_posts to authenticated;
drop policy if exists kat_visible_posts on public.kat_posts;
create policy kat_visible_posts on public.kat_posts for select to authenticated using (
  not hidden and not exists(select 1 from public.kat_blocks b where
    (b.blocker=auth.uid() and b.blocked=author) or
    (b.blocker=author and b.blocked=auth.uid()))
);

create or replace function public.kat_rank_name(p_seconds bigint) returns text
language sql immutable set search_path=public as $$
  select case
    when coalesce(p_seconds,0) >= 360000 then 'Leyenda cósmica'
    when coalesce(p_seconds,0) >= 180000 then 'Gato ancestral'
    when coalesce(p_seconds,0) >= 72000 then 'Explorador experto'
    when coalesce(p_seconds,0) >= 18000 then 'Aventurero'
    when coalesce(p_seconds,0) >= 3600 then 'Minero'
    else 'Recién llegado'
  end
$$;

create or replace function public.kat_add_playtime(p_seconds integer) returns jsonb
language plpgsql security definer set search_path=public as $$
declare result public.kat_profiles; elapsed integer; credited integer;
begin
  if auth.uid() is null then raise exception 'Sesión no válida'; end if;
  if p_seconds < 30 or p_seconds > 21600 then
    raise exception 'Duración de juego no válida';
  end if;
  select greatest(0,extract(epoch from (now()-play_credit_at))::integer)
    into elapsed from public.kat_profiles where id=auth.uid() for update;
  if elapsed is null then raise exception 'Perfil no disponible'; end if;
  credited:=least(p_seconds,elapsed+60);
  if credited < 30 then raise exception 'Sesión registrada demasiado pronto'; end if;
  update public.kat_profiles set
    play_seconds=play_seconds+credited, play_credit_at=now(), last_seen=now()
    where id=auth.uid() returning * into result;
  return to_jsonb(result)-'banned'-'timeout_until';
end $$;

create or replace function public.kat_create_post(p_body text) returns bigint
language plpgsql security definer set search_path=public as $$
declare clean text:=trim(p_body); result bigint; me public.kat_profiles;
begin
  select * into me from public.kat_profiles where id=auth.uid();
  if me.id is null or me.banned or me.timeout_until>now() then
    raise exception 'No puedes publicar ahora';
  end if;
  if char_length(clean) not between 1 and 1000 then
    raise exception 'La publicación debe tener entre 1 y 1000 caracteres';
  end if;
  if (select count(*) from public.kat_posts
      where author=auth.uid() and created_at>now()-interval '1 minute')>=4 then
    raise exception 'Demasiadas publicaciones; espera un momento';
  end if;
  insert into public.kat_posts(author,body) values(auth.uid(),clean)
    returning id into result;
  return result;
end $$;

create or replace function public.kat_list_posts()
returns table(id bigint,author_id uuid,display_name text,avatar_url text,
  avatar_path text,avatar_updated_at timestamptz,rank_name text,
  play_seconds bigint,body text,created_at timestamptz)
language sql security definer set search_path=public as $$
  select po.id,po.author,p.display_name,p.avatar_url,p.avatar_path,
    p.avatar_updated_at,public.kat_rank_name(p.play_seconds),p.play_seconds,
    po.body,po.created_at
  from (select * from public.kat_posts where not hidden
    order by created_at desc limit 100) po
  join public.kat_profiles p on p.id=po.author
  where not exists(select 1 from public.kat_blocks b where
    (b.blocker=auth.uid() and b.blocked=po.author) or
    (b.blocker=po.author and b.blocked=auth.uid()))
  order by po.created_at desc
$$;

drop function if exists public.kat_search_users(text);
create function public.kat_search_users(p_query text)
returns table(id uuid,display_name text,avatar_url text,avatar_path text,
  avatar_updated_at timestamptz,online boolean,rank_name text,play_seconds bigint)
language sql security definer set search_path=public as $$
  select p.id,p.display_name,p.avatar_url,p.avatar_path,p.avatar_updated_at,
    p.last_seen>now()-interval '90 seconds',public.kat_rank_name(p.play_seconds),
    p.play_seconds
  from public.kat_profiles p where p.id<>auth.uid() and not p.banned
    and p.display_name ilike '%'||left(trim(p_query),40)||'%'
    and not exists(select 1 from public.kat_blocks b where
      (b.blocker=auth.uid() and b.blocked=p.id) or
      (b.blocker=p.id and b.blocked=auth.uid()))
  order by p.display_name limit 20
$$;

drop function if exists public.kat_list_friends();
create function public.kat_list_friends()
returns table(id uuid,display_name text,avatar_url text,avatar_path text,
  avatar_updated_at timestamptz,online boolean,unread_count bigint,
  rank_name text,play_seconds bigint)
language sql security definer set search_path=public as $$
  select p.id,p.display_name,p.avatar_url,p.avatar_path,p.avatar_updated_at,
    p.last_seen>now()-interval '90 seconds',
    (select count(*) from public.kat_messages m
      where m.sender=p.id and m.recipient=auth.uid() and not m.hidden
        and m.created_at>coalesce((select r.last_read_at from public.kat_dm_reads r
          where r.user_id=auth.uid() and r.friend_id=p.id),to_timestamp(0))),
    public.kat_rank_name(p.play_seconds),p.play_seconds
  from public.kat_friendships f join public.kat_profiles p
    on p.id=case when f.user_a=auth.uid() then f.user_b else f.user_a end
  where auth.uid() in(f.user_a,f.user_b) order by p.display_name
$$;

do $$ declare f record; begin
  for f in select p.oid::regprocedure as signature from pg_proc p
    join pg_namespace n on n.oid=p.pronamespace
    where n.nspname='public' and p.proname like 'kat_%'
  loop
    execute format('revoke all on function %s from public, anon',f.signature);
    execute format('grant execute on function %s to authenticated',f.signature);
  end loop;
end $$;

do $$ begin
  alter publication supabase_realtime add table public.kat_posts;
exception when duplicate_object then null;
end $$;

select 'Kat Social 1.4.0 listo' as status;
