-- KatLauncher 1.4.1+: versión pública del cliente y perfil público robusto.
-- Ejecutar después de 06_kat_trophies_presence.sql.
-- Idempotente: se puede ejecutar nuevamente sin borrar datos.

alter table public.kat_profiles
  add column if not exists launcher_version text not null default '';

create or replace function public.kat_set_launcher_version(p_version text)
returns jsonb language plpgsql security definer set search_path=public as $kat$
declare result public.kat_profiles; clean text:=trim(coalesce(p_version,''));
begin
  if auth.uid() is null then raise exception 'Sesión no válida'; end if;
  if char_length(clean) not between 1 and 24
    or clean !~ '^[0-9A-Za-z][0-9A-Za-z.+_-]{0,23}$'
  then raise exception 'Versión de KatLauncher no válida'; end if;
  update public.kat_profiles
    set launcher_version=clean,last_seen=now()
    where id=auth.uid() returning * into result;
  if result.id is null then raise exception 'Perfil no disponible'; end if;
  return to_jsonb(result)-'banned'-'timeout_until';
end
$kat$;

create or replace function public.kat_get_public_profile(p_user uuid)
returns jsonb language plpgsql security definer set search_path=public as $kat$
declare p public.kat_profiles; result jsonb;
begin
  if auth.uid() is null then raise exception 'Sesión no válida'; end if;
  if exists(select 1 from public.kat_blocks b where
    (b.blocker=auth.uid() and b.blocked=p_user)
    or (b.blocker=p_user and b.blocked=auth.uid()))
  then raise exception 'Perfil no disponible'; end if;
  select * into p from public.kat_profiles where id=p_user and not banned;
  if p.id is null then raise exception 'Perfil no disponible'; end if;
  result:=jsonb_build_object(
    'id',p.id,'display_name',p.display_name,'avatar_url',p.avatar_url,
    'avatar_path',p.avatar_path,'avatar_updated_at',p.avatar_updated_at,
    'launcher_version',p.launcher_version,
    'rank_name',public.kat_rank_name(p.play_seconds),
    'play_seconds',p.play_seconds,'platinum',p.platinum,
    'is_self',p.id=auth.uid(),
    'is_friend',exists(select 1 from public.kat_friendships f
      where f.user_a=least(auth.uid(),p.id) and f.user_b=greatest(auth.uid(),p.id)),
    'presence',jsonb_build_object(
      'enabled',p.presence_enabled,
      'active',p.presence_enabled and p.presence_active
        and p.presence_updated_at>now()-interval '90 seconds',
      'loader',p.presence_loader,'version',p.presence_version,
      'skin',p.presence_skin,'updated_at',p.presence_updated_at
    ),
    'badges',coalesce((
      select jsonb_agg(jsonb_build_object(
        'id',badge.id,'label',badge.label,'color',badge.color
      ) order by badge.position)
      from (values
        (1,'play_10h','Bronce · 10 horas','#cd7f32'),
        (2,'play_50h','Oro · 50 horas','#ffd700'),
        (3,'play_100h','Diamante · 100 horas','#64d8ff'),
        (4,'kat_platinum','Platino KatLauncher','#e5f4ff')
      ) as badge(position,id,label,color)
      where (badge.id='kat_platinum' and p.platinum) or exists(
        select 1 from public.kat_user_trophies bt
        where bt.user_id=p.id and bt.trophy_id=badge.id
      )
    ),'[]'::jsonb),
    'trophies',coalesce((
      select jsonb_agg(jsonb_build_object(
        'id',t.trophy_id,'title',public.kat_trophy_title(t.trophy_id),
        'tier',public.kat_trophy_tier(t.trophy_id),
        'unlocked_at',t.unlocked_at
      ) order by t.unlocked_at)
      from public.kat_user_trophies t where t.user_id=p.id
    ),'[]'::jsonb)
  );
  return result;
end
$kat$;

revoke all on function public.kat_set_launcher_version(text) from public,anon;
grant execute on function public.kat_set_launcher_version(text) to authenticated;
revoke all on function public.kat_get_public_profile(uuid) from public,anon;
grant execute on function public.kat_get_public_profile(uuid) to authenticated;

select 'Perfiles públicos + versión de KatLauncher listos' as status;
