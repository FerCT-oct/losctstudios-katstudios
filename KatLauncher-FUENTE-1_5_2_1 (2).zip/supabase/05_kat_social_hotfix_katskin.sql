-- KatLauncher hotfix: retención prudente de mensajes + KatSkin compartido.
-- Idempotente: se puede ejecutar de nuevo desde Supabase SQL Editor.

create table if not exists public.kat_skins (
  user_id uuid primary key references public.kat_profiles(id) on delete cascade,
  nickname text not null check (nickname ~ '^[A-Za-z0-9_]{1,16}$'),
  model text not null default 'auto' check (model in ('auto','classic','slim')),
  object_path text not null unique,
  sha256 text not null default '' check (sha256 = '' or sha256 ~ '^[0-9a-f]{64}$'),
  updated_at timestamptz not null default now()
);
create unique index if not exists kat_skins_nickname_key
  on public.kat_skins(lower(nickname));
alter table public.kat_skins enable row level security;
revoke all on public.kat_skins from anon, authenticated;
grant select on public.kat_skins to authenticated;
drop policy if exists kat_skin_select_own on public.kat_skins;
create policy kat_skin_select_own on public.kat_skins for select to authenticated
using(user_id=auth.uid());

insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values('kat-skins','kat-skins',true,2097152,array['image/png'])
on conflict(id) do update set
  public=excluded.public,
  file_size_limit=excluded.file_size_limit,
  allowed_mime_types=excluded.allowed_mime_types;

drop policy if exists kat_skin_insert on storage.objects;
create policy kat_skin_insert on storage.objects for insert to authenticated
with check (
  bucket_id='kat-skins'
  and exists(
    select 1 from public.kat_skins s
    where s.user_id=auth.uid() and s.object_path=name
  )
  and storage.extension(name)='png'
);
drop policy if exists kat_skin_select on storage.objects;
create policy kat_skin_select on storage.objects for select to authenticated
using(bucket_id='kat-skins' and owner_id=auth.uid()::text);
drop policy if exists kat_skin_update on storage.objects;
create policy kat_skin_update on storage.objects for update to authenticated
using(bucket_id='kat-skins' and owner_id=auth.uid()::text)
with check (
  bucket_id='kat-skins' and owner_id=auth.uid()::text
  and exists(
    select 1 from public.kat_skins s
    where s.user_id=auth.uid() and s.object_path=name
  )
);
drop policy if exists kat_skin_delete on storage.objects;
create policy kat_skin_delete on storage.objects for delete to authenticated
using(bucket_id='kat-skins' and owner_id=auth.uid()::text);

create or replace function public.kat_claim_skin_name(
  p_nickname text, p_model text default 'auto'
) returns jsonb language plpgsql security definer
set search_path=public,storage as $kat$
declare clean text:=trim(p_nickname); old_path text; result public.kat_skins;
begin
  if auth.uid() is null then raise exception 'Sesión no válida'; end if;
  if clean !~ '^[A-Za-z0-9_]{1,16}$' then raise exception 'Nickname no válido'; end if;
  if p_model not in ('auto','classic','slim') then raise exception 'Modelo no válido'; end if;
  if exists(
    select 1 from public.kat_skins
    where lower(nickname)=lower(clean) and user_id<>auth.uid()
  ) then raise exception 'Ese nickname ya pertenece a otro usuario de KatSkin'; end if;
  select object_path into old_path from public.kat_skins where user_id=auth.uid();
  if old_path is not null and old_path<>('skins/'||clean||'.png') then
    delete from storage.objects where bucket_id='kat-skins' and name=old_path;
  end if;
  insert into public.kat_skins(user_id,nickname,model,object_path)
  values(auth.uid(),clean,p_model,'skins/'||clean||'.png')
  on conflict(user_id) do update set
    nickname=excluded.nickname,model=excluded.model,
    object_path=excluded.object_path,sha256='',updated_at=now()
  returning * into result;
  return to_jsonb(result);
end
$kat$;

create or replace function public.kat_commit_skin(
  p_sha256 text, p_model text default 'auto'
) returns jsonb language plpgsql security definer set search_path=public as $kat$
declare result public.kat_skins;
begin
  if p_sha256 !~ '^[0-9a-f]{64}$' then raise exception 'Hash no válido'; end if;
  if p_model not in ('auto','classic','slim') then raise exception 'Modelo no válido'; end if;
  update public.kat_skins set sha256=p_sha256,model=p_model,updated_at=now()
    where user_id=auth.uid() returning * into result;
  if result.user_id is null then raise exception 'KatSkin no preparada'; end if;
  return to_jsonb(result);
end
$kat$;

-- Conserva todo lo reciente durante 7 días y, después, al menos los últimos
-- 100 globales o los últimos 100 de cada conversación privada.
create or replace function public.kat_prune_message_history()
returns trigger language plpgsql security definer set search_path=public as $kat$
begin
  if new.recipient is null then
    delete from public.kat_messages m
    where m.recipient is null and m.created_at<now()-interval '7 days'
      and m.id not in (
        select id from public.kat_messages
        where recipient is null order by created_at desc,id desc limit 100
      )
      and not exists(
        select 1 from public.kat_reports r
        where r.message_id=m.id and r.status='open'
      );
  else
    delete from public.kat_messages m
    where m.recipient is not null and m.created_at<now()-interval '7 days'
      and least(m.sender,m.recipient)=least(new.sender,new.recipient)
      and greatest(m.sender,m.recipient)=greatest(new.sender,new.recipient)
      and m.id not in (
        select id from public.kat_messages x
        where x.recipient is not null
          and least(x.sender,x.recipient)=least(new.sender,new.recipient)
          and greatest(x.sender,x.recipient)=greatest(new.sender,new.recipient)
        order by x.created_at desc,x.id desc limit 100
      )
      and not exists(
        select 1 from public.kat_reports r
        where r.message_id=m.id and r.status='open'
      );
  end if;
  return new;
end
$kat$;

drop trigger if exists kat_prune_messages_after_insert on public.kat_messages;
create trigger kat_prune_messages_after_insert
after insert on public.kat_messages for each row
execute function public.kat_prune_message_history();

revoke all on function public.kat_claim_skin_name(text,text) from public,anon;
revoke all on function public.kat_commit_skin(text,text) from public,anon;
grant execute on function public.kat_claim_skin_name(text,text) to authenticated;
grant execute on function public.kat_commit_skin(text,text) to authenticated;

select 'Kat Social hotfix + KatSkin listo' as status;
