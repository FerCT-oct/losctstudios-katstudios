-- Kat Social 1.3.0 — esquema completo e idempotente para Supabase SQL Editor.
create table if not exists public.kat_profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  provider_id text unique not null,
  display_name text not null check (char_length(display_name) between 1 and 64),
  avatar_url text not null default '',
  role text not null default 'user' check (role in ('user','moderator','admin')),
  timeout_until timestamptz,
  banned boolean not null default false,
  created_at timestamptz not null default now(),
  last_seen timestamptz not null default now()
);
-- Migración desde la primera variante con Discord. CREATE TABLE IF NOT EXISTS
-- no agrega columnas nuevas a una tabla ya creada.
alter table public.kat_profiles add column if not exists provider_id text;
do $kat_provider_migration$
begin
  if exists (
    select 1 from information_schema.columns
    where table_schema='public' and table_name='kat_profiles' and column_name='discord_id'
  ) then
    execute 'update public.kat_profiles set provider_id=discord_id where provider_id is null';
  end if;
end
$kat_provider_migration$;
update public.kat_profiles set provider_id=id::text where provider_id is null;
alter table public.kat_profiles alter column provider_id set not null;
create unique index if not exists kat_profiles_provider_id_key on public.kat_profiles(provider_id);
alter table public.kat_profiles drop column if exists discord_id;
create table if not exists public.kat_friend_requests (
  id bigint generated always as identity primary key,
  sender uuid not null references public.kat_profiles(id) on delete cascade,
  receiver uuid not null references public.kat_profiles(id) on delete cascade,
  status text not null default 'pending' check (status in ('pending','accepted','rejected')),
  created_at timestamptz not null default now(), check (sender <> receiver)
);
create unique index if not exists kat_one_pending_request on public.kat_friend_requests(sender,receiver) where status='pending';
create table if not exists public.kat_friendships (
  user_a uuid not null references public.kat_profiles(id) on delete cascade,
  user_b uuid not null references public.kat_profiles(id) on delete cascade,
  created_at timestamptz not null default now(), primary key(user_a,user_b), check(user_a < user_b)
);
create table if not exists public.kat_blocks (
  blocker uuid not null references public.kat_profiles(id) on delete cascade,
  blocked uuid not null references public.kat_profiles(id) on delete cascade,
  created_at timestamptz not null default now(), primary key(blocker,blocked), check(blocker <> blocked)
);
create table if not exists public.kat_messages (
  id bigint generated always as identity primary key,
  sender uuid not null references public.kat_profiles(id) on delete cascade,
  recipient uuid references public.kat_profiles(id) on delete cascade,
  body text not null check(char_length(body) between 1 and 500),
  hidden boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists kat_messages_global on public.kat_messages(created_at desc) where recipient is null;
create index if not exists kat_messages_private on public.kat_messages(sender,recipient,created_at desc) where recipient is not null;
create table if not exists public.kat_reports (
  id bigint generated always as identity primary key,
  reporter uuid not null references public.kat_profiles(id) on delete cascade,
  message_id bigint not null references public.kat_messages(id) on delete cascade,
  reason text not null check(char_length(reason) between 3 and 300),
  status text not null default 'open' check(status in ('open','resolved','dismissed')),
  created_at timestamptz not null default now(), unique(reporter,message_id)
);

alter table public.kat_profiles enable row level security;
alter table public.kat_friend_requests enable row level security;
alter table public.kat_friendships enable row level security;
alter table public.kat_blocks enable row level security;
alter table public.kat_messages enable row level security;
alter table public.kat_reports enable row level security;
revoke all on public.kat_profiles, public.kat_friend_requests, public.kat_friendships,
  public.kat_blocks, public.kat_messages, public.kat_reports from anon, authenticated;
grant select on public.kat_messages to authenticated;
drop policy if exists kat_visible_messages on public.kat_messages;
create policy kat_visible_messages on public.kat_messages for select to authenticated using (
  not hidden and (recipient is null or auth.uid() in (sender,recipient)) and
  not exists(select 1 from public.kat_blocks b where
    (b.blocker=auth.uid() and b.blocked=sender) or (b.blocker=sender and b.blocked=auth.uid()))
);

create or replace function public.kat_upsert_profile() returns jsonb language plpgsql security definer set search_path=public,auth as $$
declare u auth.users; result public.kat_profiles;
begin
  select * into u from auth.users where id=auth.uid();
  if u.id is null then raise exception 'Sesión no válida'; end if;
  insert into public.kat_profiles(id,provider_id,display_name,avatar_url)
  values(u.id, coalesce(u.raw_user_meta_data->>'provider_id',u.raw_user_meta_data->>'sub',u.id::text),
    left(coalesce(u.raw_user_meta_data->>'full_name',u.raw_user_meta_data->>'name',u.raw_user_meta_data->>'user_name','Usuario'),64),
    coalesce(u.raw_user_meta_data->>'avatar_url',''))
  on conflict(id) do update set display_name=excluded.display_name, avatar_url=excluded.avatar_url, last_seen=now()
  returning * into result;
  return to_jsonb(result)-'banned'-'timeout_until';
end $$;

create or replace function public.kat_search_users(p_query text) returns table(id uuid,display_name text,avatar_url text)
language sql security definer set search_path=public as $$
  select p.id,p.display_name,p.avatar_url from public.kat_profiles p where p.id<>auth.uid() and not p.banned
  and p.display_name ilike '%'||left(trim(p_query),40)||'%'
  and not exists(select 1 from public.kat_blocks b where (b.blocker=auth.uid() and b.blocked=p.id) or (b.blocker=p.id and b.blocked=auth.uid()))
  order by p.display_name limit 20
$$;

create or replace function public.kat_send_friend_request(p_target uuid) returns void language plpgsql security definer set search_path=public as $$
declare reverse_request bigint;
begin
  if p_target=auth.uid() then raise exception 'No puedes agregarte a ti mismo'; end if;
  if exists(select 1 from public.kat_blocks where (blocker=auth.uid() and blocked=p_target) or (blocker=p_target and blocked=auth.uid())) then raise exception 'No se puede enviar la solicitud'; end if;
  if exists(select 1 from public.kat_friendships where user_a=least(auth.uid(),p_target) and user_b=greatest(auth.uid(),p_target)) then raise exception 'Ya son amigos'; end if;
  select id into reverse_request from public.kat_friend_requests
    where sender=p_target and receiver=auth.uid() and status='pending'
    order by created_at desc limit 1 for update;
  if reverse_request is not null then
    update public.kat_friend_requests set status='accepted' where id=reverse_request;
    insert into public.kat_friendships(user_a,user_b)
      values(least(auth.uid(),p_target),greatest(auth.uid(),p_target))
      on conflict do nothing;
    return;
  end if;
  insert into public.kat_friend_requests(sender,receiver)
    values(auth.uid(),p_target) on conflict do nothing;
end $$;

create or replace function public.kat_respond_friend_request(p_request bigint,p_accept boolean) returns void language plpgsql security definer set search_path=public as $$
declare s uuid;
begin
  update public.kat_friend_requests set status=case when p_accept then 'accepted' else 'rejected' end
    where id=p_request and receiver=auth.uid() and status='pending' returning sender into s;
  if s is null then raise exception 'Solicitud no disponible'; end if;
  if p_accept then insert into public.kat_friendships(user_a,user_b) values(least(s,auth.uid()),greatest(s,auth.uid())) on conflict do nothing; end if;
end $$;

create or replace function public.kat_list_friends() returns table(id uuid,display_name text,avatar_url text)
language sql security definer set search_path=public as $$
 select p.id,p.display_name,p.avatar_url from public.kat_friendships f join public.kat_profiles p
 on p.id=case when f.user_a=auth.uid() then f.user_b else f.user_a end
 where auth.uid() in(f.user_a,f.user_b) order by p.display_name
$$;
create or replace function public.kat_list_friend_requests() returns table(request_id bigint,id uuid,display_name text,avatar_url text)
language sql security definer set search_path=public as $$
 select r.id,p.id,p.display_name,p.avatar_url from public.kat_friend_requests r join public.kat_profiles p on p.id=r.sender
 where r.receiver=auth.uid() and r.status='pending' order by r.created_at desc
$$;

create or replace function public.kat_send_message(p_body text,p_recipient uuid default null) returns bigint language plpgsql security definer set search_path=public as $$
declare me public.kat_profiles; result bigint; clean text:=trim(p_body);
begin
 select * into me from public.kat_profiles where id=auth.uid();
 if me.banned or me.timeout_until>now() then raise exception 'No puedes enviar mensajes ahora'; end if;
 if char_length(clean) not between 1 and 500 then raise exception 'El mensaje debe tener entre 1 y 500 caracteres'; end if;
 if (select count(*) from public.kat_messages where sender=auth.uid() and created_at>now()-interval '10 seconds')>=5
 or (select count(*) from public.kat_messages where sender=auth.uid() and created_at>now()-interval '1 minute')>=30 then raise exception 'Demasiados mensajes; espera un momento'; end if;
 if p_recipient is not null and not exists(select 1 from public.kat_friendships where user_a=least(auth.uid(),p_recipient) and user_b=greatest(auth.uid(),p_recipient)) then raise exception 'Los mensajes privados son solo para amigos'; end if;
 if p_recipient is not null and exists(select 1 from public.kat_blocks where (blocker=auth.uid() and blocked=p_recipient) or (blocker=p_recipient and blocked=auth.uid())) then raise exception 'No se puede enviar el mensaje'; end if;
 insert into public.kat_messages(sender,recipient,body) values(auth.uid(),p_recipient,clean) returning id into result; return result;
end $$;

create or replace function public.kat_list_global_messages() returns table(id bigint,sender_id uuid,display_name text,body text,created_at timestamptz)
language sql security definer set search_path=public as $$
 select m.id,m.sender,p.display_name,m.body,m.created_at from (select * from public.kat_messages where recipient is null and not hidden order by created_at desc limit 100) m
 join public.kat_profiles p on p.id=m.sender where not exists(select 1 from public.kat_blocks b where (b.blocker=auth.uid() and b.blocked=m.sender) or (b.blocker=m.sender and b.blocked=auth.uid())) order by m.created_at
$$;
create or replace function public.kat_list_private_messages(p_friend uuid) returns table(id bigint,sender_id uuid,display_name text,body text,created_at timestamptz)
language sql security definer set search_path=public as $$
 select m.id,m.sender,p.display_name,m.body,m.created_at from (select * from public.kat_messages where not hidden and ((sender=auth.uid() and recipient=p_friend) or(sender=p_friend and recipient=auth.uid())) order by created_at desc limit 100) m join public.kat_profiles p on p.id=m.sender order by m.created_at
$$;

create or replace function public.kat_block_user(p_target uuid) returns void language plpgsql security definer set search_path=public as $$
begin
 insert into public.kat_blocks(blocker,blocked) values(auth.uid(),p_target) on conflict do nothing;
 delete from public.kat_friendships where user_a=least(auth.uid(),p_target) and user_b=greatest(auth.uid(),p_target);
 delete from public.kat_friend_requests where sender in(auth.uid(),p_target) and receiver in(auth.uid(),p_target);
end $$;
create or replace function public.kat_unblock_user(p_target uuid) returns void language sql security definer set search_path=public as $$ delete from public.kat_blocks where blocker=auth.uid() and blocked=p_target $$;
create or replace function public.kat_report_message(p_message bigint,p_reason text) returns void language plpgsql security definer set search_path=public as $$
begin
 if char_length(trim(p_reason)) not between 3 and 300 then raise exception 'Explica brevemente el motivo'; end if;
 insert into public.kat_reports(reporter,message_id,reason) values(auth.uid(),p_message,trim(p_reason));
end $$;
create or replace function public.kat_moderate_message(p_message bigint,p_hide boolean,p_timeout_minutes int default 0) returns void language plpgsql security definer set search_path=public as $$
declare target uuid;
begin
 if not exists(select 1 from public.kat_profiles where id=auth.uid() and role in('moderator','admin')) then raise exception 'No autorizado'; end if;
 update public.kat_messages set hidden=p_hide where id=p_message returning sender into target;
 if p_timeout_minutes>0 then update public.kat_profiles set timeout_until=now()+make_interval(mins=>least(p_timeout_minutes,10080)) where id=target; end if;
end $$;

do $$ declare f record; begin
  for f in select p.oid::regprocedure as signature from pg_proc p
    join pg_namespace n on n.oid=p.pronamespace
    where n.nspname='public' and p.proname like 'kat_%'
  loop
    execute format('revoke all on function %s from public, anon', f.signature);
    execute format('grant execute on function %s to authenticated', f.signature);
  end loop;
end $$;
do $kat_realtime$
begin
  alter publication supabase_realtime add table public.kat_messages;
exception
  when duplicate_object then null;
end
$kat_realtime$;

-- ---------------------------------------------------------------------------
-- Ampliación 1.3.0: identidad propia, avatares, presencia y privados sin leer.
-- Se mantiene aquí además de 03_kat_social_profiles.sql para que una instalación
-- nueva solo tenga que ejecutar este archivo.
-- ---------------------------------------------------------------------------
alter table public.kat_profiles add column if not exists avatar_path text not null default '';
alter table public.kat_profiles add column if not exists custom_display_name boolean not null default false;
alter table public.kat_profiles add column if not exists custom_avatar boolean not null default false;
alter table public.kat_profiles add column if not exists avatar_updated_at timestamptz;

update public.kat_profiles
set display_name = case
  when char_length(trim(display_name)) between 2 and 32 then left(trim(display_name), 32)
  else 'Usuario'
end;
alter table public.kat_profiles drop constraint if exists kat_profiles_display_name_check;
alter table public.kat_profiles add constraint kat_profiles_display_name_check
  check (char_length(display_name) between 2 and 32 and display_name !~ '[[:cntrl:]]');

create table if not exists public.kat_dm_reads (
  user_id uuid not null references public.kat_profiles(id) on delete cascade,
  friend_id uuid not null references public.kat_profiles(id) on delete cascade,
  last_read_at timestamptz not null default to_timestamp(0),
  primary key(user_id, friend_id),
  check(user_id <> friend_id)
);
alter table public.kat_dm_reads enable row level security;
revoke all on public.kat_dm_reads from anon, authenticated;

insert into storage.buckets(id, name, public, file_size_limit, allowed_mime_types)
values ('kat-avatars', 'kat-avatars', true, 2097152, array['image/png'])
on conflict(id) do update set
  public = excluded.public,
  file_size_limit = excluded.file_size_limit,
  allowed_mime_types = excluded.allowed_mime_types;

drop policy if exists kat_avatar_insert on storage.objects;
create policy kat_avatar_insert on storage.objects
for insert to authenticated with check (
  bucket_id = 'kat-avatars'
  and (storage.foldername(name))[1] = (select auth.uid()::text)
  and name = (select auth.uid()::text) || '/avatar.png'
  and storage.extension(name) = 'png'
);
drop policy if exists kat_avatar_select_owner on storage.objects;
create policy kat_avatar_select_owner on storage.objects
for select to authenticated using (
  bucket_id = 'kat-avatars' and owner_id = (select auth.uid()::text)
);
drop policy if exists kat_avatar_update on storage.objects;
create policy kat_avatar_update on storage.objects
for update to authenticated using (
  bucket_id = 'kat-avatars'
  and owner_id = (select auth.uid()::text)
  and name = (select auth.uid()::text) || '/avatar.png'
) with check (
  bucket_id = 'kat-avatars'
  and owner_id = (select auth.uid()::text)
  and name = (select auth.uid()::text) || '/avatar.png'
  and storage.extension(name) = 'png'
);
drop policy if exists kat_avatar_delete on storage.objects;
create policy kat_avatar_delete on storage.objects
for delete to authenticated using (
  bucket_id = 'kat-avatars'
  and owner_id = (select auth.uid()::text)
  and name = (select auth.uid()::text) || '/avatar.png'
);

create or replace function public.kat_upsert_profile() returns jsonb
language plpgsql security definer set search_path=public,auth as $$
declare
  u auth.users; result public.kat_profiles;
  provider_name text; provider_avatar text;
begin
  select * into u from auth.users where id=auth.uid();
  if u.id is null then raise exception 'Sesión no válida'; end if;
  provider_name := regexp_replace(trim(coalesce(
    u.raw_user_meta_data->>'full_name', u.raw_user_meta_data->>'name',
    u.raw_user_meta_data->>'user_name', 'Usuario'
  )), '\s+', ' ', 'g');
  if char_length(provider_name) not between 2 and 32 or provider_name ~ '[[:cntrl:]]' then
    provider_name := 'Usuario';
  end if;
  provider_avatar := coalesce(u.raw_user_meta_data->>'avatar_url', '');
  insert into public.kat_profiles(id, provider_id, display_name, avatar_url)
  values(u.id, coalesce(u.raw_user_meta_data->>'provider_id',
    u.raw_user_meta_data->>'sub', u.id::text), provider_name, provider_avatar)
  on conflict(id) do update set
    display_name=case when kat_profiles.custom_display_name
      then kat_profiles.display_name else excluded.display_name end,
    avatar_url=case when kat_profiles.custom_avatar
      then kat_profiles.avatar_url else excluded.avatar_url end,
    avatar_path=case when kat_profiles.custom_avatar
      then kat_profiles.avatar_path else '' end,
    last_seen=now()
  returning * into result;
  return to_jsonb(result)-'banned'-'timeout_until';
end $$;

create or replace function public.kat_set_display_name(p_display_name text) returns jsonb
language plpgsql security definer set search_path=public as $$
declare clean text; result public.kat_profiles;
begin
  clean := regexp_replace(trim(coalesce(p_display_name,'')), '\s+', ' ', 'g');
  if char_length(clean) not between 2 and 32 or clean ~ '[[:cntrl:]]' then
    raise exception 'El nick debe tener entre 2 y 32 caracteres';
  end if;
  update public.kat_profiles set display_name=clean,
    custom_display_name=true,last_seen=now()
  where id=auth.uid() returning * into result;
  if result.id is null then raise exception 'Perfil no disponible'; end if;
  return to_jsonb(result)-'banned'-'timeout_until';
end $$;

create or replace function public.kat_set_avatar(p_object_path text) returns jsonb
language plpgsql security definer set search_path=public,storage as $$
declare result public.kat_profiles;
begin
  if p_object_path <> auth.uid()::text || '/avatar.png' or not exists(
    select 1 from storage.objects where bucket_id='kat-avatars'
      and name=p_object_path and owner_id=auth.uid()::text
  ) then raise exception 'Avatar no válido'; end if;
  update public.kat_profiles set avatar_path=p_object_path,custom_avatar=true,
    avatar_updated_at=clock_timestamp(),last_seen=now()
  where id=auth.uid() returning * into result;
  if result.id is null then raise exception 'Perfil no disponible'; end if;
  return to_jsonb(result)-'banned'-'timeout_until';
end $$;

create or replace function public.kat_reset_profile(
  p_reset_name boolean default true,p_reset_avatar boolean default true
) returns jsonb language plpgsql security definer set search_path=public,auth as $$
declare u auth.users; result public.kat_profiles; provider_name text;
begin
  select * into u from auth.users where id=auth.uid();
  if u.id is null then raise exception 'Sesión no válida'; end if;
  provider_name := regexp_replace(trim(coalesce(
    u.raw_user_meta_data->>'full_name',u.raw_user_meta_data->>'name',
    u.raw_user_meta_data->>'user_name','Usuario'
  )), '\s+', ' ', 'g');
  if char_length(provider_name) not between 2 and 32 or provider_name ~ '[[:cntrl:]]' then
    provider_name := 'Usuario';
  end if;
  update public.kat_profiles set
    display_name=case when p_reset_name then provider_name else display_name end,
    custom_display_name=case when p_reset_name then false else custom_display_name end,
    avatar_url=case when p_reset_avatar
      then coalesce(u.raw_user_meta_data->>'avatar_url','') else avatar_url end,
    avatar_path=case when p_reset_avatar then '' else avatar_path end,
    custom_avatar=case when p_reset_avatar then false else custom_avatar end,
    avatar_updated_at=case when p_reset_avatar then clock_timestamp() else avatar_updated_at end,
    last_seen=now()
  where id=auth.uid() returning * into result;
  return to_jsonb(result)-'banned'-'timeout_until';
end $$;

create or replace function public.kat_touch_presence() returns jsonb
language plpgsql security definer set search_path=public as $$
declare result public.kat_profiles;
begin
  update public.kat_profiles set last_seen=now()
  where id=auth.uid() returning * into result;
  if result.id is null then raise exception 'Perfil no disponible'; end if;
  return to_jsonb(result)-'banned'-'timeout_until';
end $$;

create or replace function public.kat_mark_private_read(p_friend uuid,p_message bigint)
returns void language plpgsql security definer set search_path=public as $$
declare read_time timestamptz;
begin
  if not exists(select 1 from public.kat_friendships
    where user_a=least(auth.uid(),p_friend) and user_b=greatest(auth.uid(),p_friend)) then
    raise exception 'Conversación no disponible';
  end if;
  select created_at into read_time from public.kat_messages where id=p_message and (
    (sender=auth.uid() and recipient=p_friend) or
    (sender=p_friend and recipient=auth.uid()));
  if read_time is null then return; end if;
  insert into public.kat_dm_reads(user_id,friend_id,last_read_at)
  values(auth.uid(),p_friend,read_time)
  on conflict(user_id,friend_id) do update
    set last_read_at=greatest(kat_dm_reads.last_read_at,excluded.last_read_at);
end $$;

drop function if exists public.kat_search_users(text);
create function public.kat_search_users(p_query text)
returns table(id uuid,display_name text,avatar_url text,avatar_path text,
  avatar_updated_at timestamptz,online boolean)
language sql security definer set search_path=public as $$
  select p.id,p.display_name,p.avatar_url,p.avatar_path,p.avatar_updated_at,
    p.last_seen>now()-interval '90 seconds'
  from public.kat_profiles p where p.id<>auth.uid() and not p.banned
    and p.display_name ilike '%'||left(trim(p_query),40)||'%'
    and not exists(select 1 from public.kat_blocks b where
      (b.blocker=auth.uid() and b.blocked=p.id) or
      (b.blocker=p.id and b.blocked=auth.uid()))
  order by p.display_name limit 20
$$;

drop function if exists public.kat_list_friends();
create function public.kat_list_friends()
returns table(id uuid,display_name text,avatar_url text,avatar_path text,
  avatar_updated_at timestamptz,online boolean,unread_count bigint)
language sql security definer set search_path=public as $$
  select p.id,p.display_name,p.avatar_url,p.avatar_path,p.avatar_updated_at,
    p.last_seen>now()-interval '90 seconds',
    (select count(*) from public.kat_messages m
      where m.sender=p.id and m.recipient=auth.uid() and not m.hidden
        and m.created_at>coalesce((select r.last_read_at from public.kat_dm_reads r
          where r.user_id=auth.uid() and r.friend_id=p.id),to_timestamp(0)))
  from public.kat_friendships f join public.kat_profiles p
    on p.id=case when f.user_a=auth.uid() then f.user_b else f.user_a end
  where auth.uid() in(f.user_a,f.user_b) order by p.display_name
$$;

drop function if exists public.kat_list_friend_requests();
create function public.kat_list_friend_requests()
returns table(request_id bigint,id uuid,display_name text,avatar_url text,
  avatar_path text,avatar_updated_at timestamptz,online boolean)
language sql security definer set search_path=public as $$
  select r.id,p.id,p.display_name,p.avatar_url,p.avatar_path,p.avatar_updated_at,
    p.last_seen>now()-interval '90 seconds'
  from public.kat_friend_requests r join public.kat_profiles p on p.id=r.sender
  where r.receiver=auth.uid() and r.status='pending' order by r.created_at desc
$$;

drop function if exists public.kat_list_global_messages();
create function public.kat_list_global_messages()
returns table(id bigint,sender_id uuid,display_name text,avatar_url text,
  avatar_path text,avatar_updated_at timestamptz,body text,created_at timestamptz)
language sql security definer set search_path=public as $$
  select m.id,m.sender,p.display_name,p.avatar_url,p.avatar_path,p.avatar_updated_at,
    m.body,m.created_at
  from (select * from public.kat_messages where recipient is null and not hidden
    order by created_at desc limit 100) m
  join public.kat_profiles p on p.id=m.sender
  where not exists(select 1 from public.kat_blocks b where
    (b.blocker=auth.uid() and b.blocked=m.sender) or
    (b.blocker=m.sender and b.blocked=auth.uid()))
  order by m.created_at
$$;

drop function if exists public.kat_list_private_messages(uuid);
create function public.kat_list_private_messages(p_friend uuid)
returns table(id bigint,sender_id uuid,display_name text,avatar_url text,
  avatar_path text,avatar_updated_at timestamptz,body text,created_at timestamptz)
language sql security definer set search_path=public as $$
  select m.id,m.sender,p.display_name,p.avatar_url,p.avatar_path,p.avatar_updated_at,
    m.body,m.created_at
  from (select * from public.kat_messages where not hidden and (
    (sender=auth.uid() and recipient=p_friend) or
    (sender=p_friend and recipient=auth.uid()))
    order by created_at desc limit 100) m
  join public.kat_profiles p on p.id=m.sender order by m.created_at
$$;

do $$ declare f record; begin
  for f in select p.oid::regprocedure as signature from pg_proc p
    join pg_namespace n on n.oid=p.pronamespace
    where n.nspname='public' and p.proname like 'kat_%'
  loop
    execute format('revoke all on function %s from public, anon',f.signature);
    execute format('grant execute on function %s to authenticated',f.signature);
  end loop;
end $$;

select 'Kat Social 1.3.0 listo' as status;
