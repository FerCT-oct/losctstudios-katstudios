-- KatLauncher: trofeos públicos, Platino y Kat Presence.
-- Ejecutar después de 05_kat_social_hotfix_katskin.sql.
-- Idempotente: puede ejecutarse nuevamente.

alter table public.kat_profiles
  add column if not exists platinum boolean not null default false;
alter table public.kat_profiles
  add column if not exists presence_enabled boolean not null default true;
alter table public.kat_profiles
  add column if not exists presence_active boolean not null default false;
alter table public.kat_profiles
  add column if not exists presence_loader text not null default '';
alter table public.kat_profiles
  add column if not exists presence_version text not null default '';
alter table public.kat_profiles
  add column if not exists presence_skin text not null default '';
alter table public.kat_profiles
  add column if not exists presence_updated_at timestamptz;

create table if not exists public.kat_user_trophies (
  user_id uuid not null references public.kat_profiles(id) on delete cascade,
  trophy_id text not null,
  unlocked_at timestamptz not null default now(),
  primary key(user_id,trophy_id),
  check(trophy_id in (
    'guide_complete','play_10h','play_50h','play_100h','first_friend',
    'first_update','first_mod','first_modpack','first_global','first_post','first_potato'
  ))
);
alter table public.kat_user_trophies enable row level security;
revoke all on public.kat_user_trophies from anon,authenticated;

create or replace function public.kat_trophy_title(p_id text) returns text
language sql immutable set search_path=public as $kat$
  select case p_id
    when 'guide_complete' then 'Disfruta de KatLauncher'
    when 'play_10h' then 'Aventurero de bronce'
    when 'play_50h' then 'Leyenda de oro'
    when 'play_100h' then 'Gato de diamante'
    when 'first_friend' then '¡Mejores Amigos para siempre!'
    when 'first_update' then '¡Actualizado!'
    when 'first_mod' then '¡Mirad, ahora la vaca tiene alas!'
    when 'first_modpack' then '¿Estoy en Minecraft?'
    when 'first_global' then '¡Miren, soy nuevo!'
    when 'first_post' then '¡Genial!'
    when 'first_potato' then 'Primero lo primero'
    else p_id
  end
$kat$;

create or replace function public.kat_trophy_tier(p_id text) returns text
language sql immutable set search_path=public as $kat$
  select case
    when p_id='play_100h' then 'diamante'
    when p_id in ('play_50h','first_update','first_modpack') then 'oro'
    when p_id in ('first_friend','first_post') then 'plata'
    else 'bronce'
  end
$kat$;

create or replace function public.kat_sync_trophies(p_trophies text[])
returns jsonb language plpgsql security definer set search_path=public as $kat$
declare result public.kat_profiles;
begin
  if auth.uid() is null then raise exception 'Sesión no válida'; end if;
  insert into public.kat_user_trophies(user_id,trophy_id)
  select auth.uid(),value
  from unnest(coalesce(p_trophies,array[]::text[])) as item(value)
  where value in (
    'guide_complete','play_10h','play_50h','play_100h','first_friend',
    'first_update','first_mod','first_modpack','first_global','first_post','first_potato'
  )
  on conflict do nothing;
  update public.kat_profiles set
    platinum=(
      select count(distinct trophy_id)=11
      from public.kat_user_trophies where user_id=auth.uid()
    ),
    last_seen=now()
  where id=auth.uid() returning * into result;
  if result.id is null then raise exception 'Perfil no disponible'; end if;
  return to_jsonb(result)-'banned'-'timeout_until';
end
$kat$;

create or replace function public.kat_set_presence(
  p_active boolean,p_loader text default '',p_version text default '',
  p_skin text default '',p_enabled boolean default true
) returns jsonb language plpgsql security definer set search_path=public as $kat$
declare result public.kat_profiles; clean_loader text:=lower(trim(p_loader));
begin
  if auth.uid() is null then raise exception 'Sesión no válida'; end if;
  if p_active and clean_loader not in ('vanilla','fabric','forge','quilt','neoforge')
    then raise exception 'Loader no válido'; end if;
  if p_active and (
    char_length(trim(p_version)) not between 1 and 40
    or trim(p_version) ~ '[[:cntrl:]]'
  ) then raise exception 'Versión no válida'; end if;
  if p_active and p_skin !~ '^[A-Za-z0-9_]{1,16}$'
    then raise exception 'Skin no válida'; end if;
  update public.kat_profiles set
    presence_enabled=coalesce(p_enabled,true),
    presence_active=coalesce(p_enabled,true) and coalesce(p_active,false),
    presence_loader=case when p_active then clean_loader else '' end,
    presence_version=case when p_active then trim(p_version) else '' end,
    presence_skin=case when p_active then p_skin else '' end,
    presence_updated_at=now(),last_seen=now()
  where id=auth.uid() returning * into result;
  if result.id is null then raise exception 'Perfil no disponible'; end if;
  return to_jsonb(result)-'banned'-'timeout_until';
end
$kat$;

create or replace function public.kat_touch_presence() returns jsonb
language plpgsql security definer set search_path=public as $kat$
declare result public.kat_profiles;
begin
  update public.kat_profiles set
    last_seen=now(),
    presence_updated_at=case when presence_active then now()
      else presence_updated_at end
  where id=auth.uid() returning * into result;
  if result.id is null then raise exception 'Perfil no disponible'; end if;
  return to_jsonb(result)-'banned'-'timeout_until';
end
$kat$;

create or replace function public.kat_get_public_profile(p_user uuid)
returns jsonb language plpgsql security definer set search_path=public as $kat$
declare p public.kat_profiles; result jsonb;
begin
  if auth.uid() is null then raise exception 'Sesión no válida'; end if;
  if exists(select 1 from public.kat_blocks b where
    (b.blocker=auth.uid() and b.blocked=p_user)
    or (b.blocker=p_user and b.blocked=auth.uid()))
  then raise exception 'Perfil no disponible'; end if;
  select * into p from public.kat_profiles where id=p_user and not banned;
  if p.id is null then raise exception 'Perfil no disponible'; end if;
  result:=jsonb_build_object(
    'id',p.id,'display_name',p.display_name,'avatar_url',p.avatar_url,
    'avatar_path',p.avatar_path,'avatar_updated_at',p.avatar_updated_at,
    'rank_name',public.kat_rank_name(p.play_seconds),
    'play_seconds',p.play_seconds,'platinum',p.platinum,
    'is_self',p.id=auth.uid(),
    'is_friend',exists(select 1 from public.kat_friendships f
      where f.user_a=least(auth.uid(),p.id) and f.user_b=greatest(auth.uid(),p.id)),
    'presence',jsonb_build_object(
      'enabled',p.presence_enabled,
      'active',p.presence_enabled and p.presence_active
        and p.presence_updated_at>now()-interval '90 seconds',
      'loader',p.presence_loader,'version',p.presence_version,
      'skin',p.presence_skin,'updated_at',p.presence_updated_at
    ),
    'badges',coalesce((
      select jsonb_agg(jsonb_build_object(
        'id',badge.id,'label',badge.label,'color',badge.color
      ) order by badge.position)
      from (values
        (1,'play_10h','Bronce · 10 horas','#cd7f32'),
        (2,'play_50h','Oro · 50 horas','#ffd700'),
        (3,'play_100h','Diamante · 100 horas','#64d8ff'),
        (4,'kat_platinum','Platino KatLauncher','#e5f4ff')
      ) as badge(position,id,label,color)
      where (badge.id='kat_platinum' and p.platinum) or exists(
        select 1 from public.kat_user_trophies bt
        where bt.user_id=p.id and bt.trophy_id=badge.id
      )
    ),'[]'::jsonb),
    'trophies',coalesce((
      select jsonb_agg(jsonb_build_object(
        'id',t.trophy_id,'title',public.kat_trophy_title(t.trophy_id),
        'tier',public.kat_trophy_tier(t.trophy_id),
        'unlocked_at',t.unlocked_at
      ) order by t.unlocked_at)
      from public.kat_user_trophies t where t.user_id=p.id
    ),'[]'::jsonb)
  );
  return result;
end
$kat$;

drop function if exists public.kat_search_users(text);
create function public.kat_search_users(p_query text)
returns table(id uuid,display_name text,avatar_url text,avatar_path text,
  avatar_updated_at timestamptz,online boolean,rank_name text,
  play_seconds bigint,platinum boolean)
language sql security definer set search_path=public as $kat$
  select p.id,p.display_name,p.avatar_url,p.avatar_path,p.avatar_updated_at,
    p.last_seen>now()-interval '90 seconds',public.kat_rank_name(p.play_seconds),
    p.play_seconds,p.platinum
  from public.kat_profiles p where p.id<>auth.uid() and not p.banned
    and p.display_name ilike '%'||left(trim(p_query),40)||'%'
    and not exists(select 1 from public.kat_blocks b where
      (b.blocker=auth.uid() and b.blocked=p.id)
      or (b.blocker=p.id and b.blocked=auth.uid()))
  order by p.display_name limit 20
$kat$;

drop function if exists public.kat_list_friends();
create function public.kat_list_friends()
returns table(id uuid,display_name text,avatar_url text,avatar_path text,
  avatar_updated_at timestamptz,online boolean,unread_count bigint,
  rank_name text,play_seconds bigint,platinum boolean)
language sql security definer set search_path=public as $kat$
  select p.id,p.display_name,p.avatar_url,p.avatar_path,p.avatar_updated_at,
    p.last_seen>now()-interval '90 seconds',
    (select count(*) from public.kat_messages m
      where m.sender=p.id and m.recipient=auth.uid() and not m.hidden
        and m.created_at>coalesce((select r.last_read_at from public.kat_dm_reads r
          where r.user_id=auth.uid() and r.friend_id=p.id),to_timestamp(0))),
    public.kat_rank_name(p.play_seconds),p.play_seconds,p.platinum
  from public.kat_friendships f join public.kat_profiles p
    on p.id=case when f.user_a=auth.uid() then f.user_b else f.user_a end
  where auth.uid() in(f.user_a,f.user_b) order by p.display_name
$kat$;

drop function if exists public.kat_list_friend_requests();
create function public.kat_list_friend_requests()
returns table(request_id bigint,id uuid,display_name text,avatar_url text,
  avatar_path text,avatar_updated_at timestamptz,online boolean,platinum boolean)
language sql security definer set search_path=public as $kat$
  select r.id,p.id,p.display_name,p.avatar_url,p.avatar_path,p.avatar_updated_at,
    p.last_seen>now()-interval '90 seconds',p.platinum
  from public.kat_friend_requests r join public.kat_profiles p on p.id=r.sender
  where r.receiver=auth.uid() and r.status='pending' order by r.created_at desc
$kat$;

drop function if exists public.kat_list_global_messages();
create function public.kat_list_global_messages()
returns table(id bigint,sender_id uuid,display_name text,avatar_url text,
  avatar_path text,avatar_updated_at timestamptz,body text,
  created_at timestamptz,platinum boolean)
language sql security definer set search_path=public as $kat$
  select m.id,m.sender,p.display_name,p.avatar_url,p.avatar_path,
    p.avatar_updated_at,m.body,m.created_at,p.platinum
  from (select * from public.kat_messages where recipient is null and not hidden
    order by created_at desc limit 100) m
  join public.kat_profiles p on p.id=m.sender
  where not exists(select 1 from public.kat_blocks b where
    (b.blocker=auth.uid() and b.blocked=m.sender)
    or (b.blocker=m.sender and b.blocked=auth.uid()))
  order by m.created_at
$kat$;

drop function if exists public.kat_list_private_messages(uuid);
create function public.kat_list_private_messages(p_friend uuid)
returns table(id bigint,sender_id uuid,display_name text,avatar_url text,
  avatar_path text,avatar_updated_at timestamptz,body text,
  created_at timestamptz,platinum boolean)
language sql security definer set search_path=public as $kat$
  select m.id,m.sender,p.display_name,p.avatar_url,p.avatar_path,
    p.avatar_updated_at,m.body,m.created_at,p.platinum
  from (select * from public.kat_messages where not hidden and (
    (sender=auth.uid() and recipient=p_friend)
    or (sender=p_friend and recipient=auth.uid())
  ) order by created_at desc limit 100) m
  join public.kat_profiles p on p.id=m.sender order by m.created_at
$kat$;

drop function if exists public.kat_list_posts();
create function public.kat_list_posts()
returns table(id bigint,author_id uuid,display_name text,avatar_url text,
  avatar_path text,avatar_updated_at timestamptz,rank_name text,
  play_seconds bigint,body text,created_at timestamptz,platinum boolean)
language sql security definer set search_path=public as $kat$
  select po.id,po.author,p.display_name,p.avatar_url,p.avatar_path,
    p.avatar_updated_at,public.kat_rank_name(p.play_seconds),p.play_seconds,
    po.body,po.created_at,p.platinum
  from (select * from public.kat_posts where not hidden
    order by created_at desc limit 100) po
  join public.kat_profiles p on p.id=po.author
  where not exists(select 1 from public.kat_blocks b where
    (b.blocker=auth.uid() and b.blocked=po.author)
    or (b.blocker=po.author and b.blocked=auth.uid()))
  order by po.created_at desc
$kat$;

do $kat_grants$
declare f record;
begin
  for f in select p.oid::regprocedure as signature from pg_proc p
    join pg_namespace n on n.oid=p.pronamespace
    where n.nspname='public' and p.proname like 'kat_%'
  loop
    execute format('revoke all on function %s from public,anon',f.signature);
    execute format('grant execute on function %s to authenticated',f.signature);
  end loop;
end
$kat_grants$;

select 'Kat Trofeos + Kat Presence listo' as status;
