-- KatLauncher 1.5.1: directorio seguro de salas públicas.
-- Ejecutar después de 08_katcraft.sql.
-- Idempotente: no borra perfiles, mensajes, amistades, trofeos ni salas.

create table if not exists public.kat_rooms (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.kat_profiles(id) on delete cascade,
  name text not null check(char_length(name) between 2 and 48),
  description text not null default '' check(char_length(description)<=240),
  server_host text not null check(char_length(server_host) between 1 and 253),
  server_port integer not null check(server_port between 1 and 65535),
  minecraft_version text not null check(char_length(minecraft_version) between 1 and 40),
  loader text not null default 'vanilla' check(char_length(loader) between 1 and 24),
  loader_version text not null default '' check(char_length(loader_version)<=64),
  launcher_version text not null default '' check(char_length(launcher_version)<=24),
  modpack_id text not null default '' check(char_length(modpack_id)<=128),
  mods jsonb not null default '[]'::jsonb,
  visibility text not null default 'public'
    check(visibility in ('public','friends','private')),
  status text not null default 'online'
    check(status in ('starting','online','stopping','offline')),
  players_online integer not null default 0 check(players_online between 0 and 1000),
  players_max integer not null default 8 check(players_max between 1 and 1000),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  expires_at timestamptz not null default now()+interval '3 minutes',
  check(jsonb_typeof(mods)='array'),
  check(jsonb_array_length(mods)<=500)
);

alter table public.kat_rooms
  add column if not exists description text not null default '',
  add column if not exists loader_version text not null default '',
  add column if not exists launcher_version text not null default '',
  add column if not exists modpack_id text not null default '',
  add column if not exists mods jsonb not null default '[]'::jsonb,
  add column if not exists visibility text not null default 'public',
  add column if not exists status text not null default 'online',
  add column if not exists players_online integer not null default 0,
  add column if not exists players_max integer not null default 8,
  add column if not exists expires_at timestamptz not null
    default now()+interval '3 minutes';

create unique index if not exists kat_rooms_one_live_room_per_owner
  on public.kat_rooms(owner_id)
  where status in ('starting','online');
create index if not exists kat_rooms_public_directory
  on public.kat_rooms(visibility,status,expires_at desc);

alter table public.kat_rooms enable row level security;
revoke all on public.kat_rooms from anon,authenticated;

create or replace function public.kat_publish_room(
  p_name text,
  p_description text,
  p_host text,
  p_port integer,
  p_version text,
  p_loader text default 'vanilla',
  p_loader_version text default '',
  p_launcher_version text default '',
  p_modpack_id text default '',
  p_mods jsonb default '[]'::jsonb,
  p_visibility text default 'public',
  p_players_max integer default 8
) returns jsonb language plpgsql security definer set search_path=public as $kat$
declare
  clean_name text:=trim(coalesce(p_name,''));
  clean_description text:=trim(coalesce(p_description,''));
  clean_host text:=trim(coalesce(p_host,''));
  clean_loader text:=lower(trim(coalesce(p_loader,'vanilla')));
  clean_visibility text:=lower(trim(coalesce(p_visibility,'public')));
  clean_mods jsonb:=coalesce(p_mods,'[]'::jsonb);
  result public.kat_rooms;
begin
  if auth.uid() is null then raise exception 'Sesión no válida'; end if;
  if char_length(clean_name) not between 2 and 48
  then raise exception 'El nombre debe tener entre 2 y 48 caracteres'; end if;
  if char_length(clean_description)>240
  then raise exception 'La descripción es demasiado larga'; end if;
  if char_length(clean_host) not between 1 and 253
    or clean_host !~ '^[0-9A-Za-z._:-]+$'
    or p_port not between 1 and 65535
  then raise exception 'Servidor no válido'; end if;
  if char_length(trim(coalesce(p_version,''))) not between 1 and 40
  then raise exception 'Versión de Minecraft no válida'; end if;
  if clean_loader not in ('vanilla','fabric','forge','neoforge','quilt')
  then raise exception 'Loader no válido'; end if;
  if clean_visibility not in ('public','friends','private')
  then raise exception 'Visibilidad no válida'; end if;
  if jsonb_typeof(clean_mods)<>'array' or jsonb_array_length(clean_mods)>500
  then raise exception 'Lista de mods no válida'; end if;
  if coalesce(p_players_max,8) not between 1 and 1000
  then raise exception 'Límite de jugadores no válido'; end if;

  update public.kat_rooms
    set status='offline',expires_at=now(),updated_at=now()
    where owner_id=auth.uid() and status in ('starting','online');

  insert into public.kat_rooms(
    owner_id,name,description,server_host,server_port,minecraft_version,
    loader,loader_version,launcher_version,modpack_id,mods,visibility,
    status,players_online,players_max,expires_at
  ) values(
    auth.uid(),clean_name,clean_description,clean_host,p_port,
    left(trim(p_version),40),clean_loader,
    left(trim(coalesce(p_loader_version,'')),64),
    left(trim(coalesce(p_launcher_version,'')),24),
    left(trim(coalesce(p_modpack_id,'')),128),clean_mods,clean_visibility,
    'online',0,coalesce(p_players_max,8),now()+interval '3 minutes'
  ) returning * into result;
  return to_jsonb(result);
end
$kat$;

create or replace function public.kat_touch_room(
  p_room uuid,
  p_players integer default 0
) returns jsonb language plpgsql security definer set search_path=public as $kat$
declare result public.kat_rooms;
begin
  update public.kat_rooms
    set status='online',
        players_online=greatest(0,least(coalesce(p_players,0),players_max)),
        updated_at=now(),
        expires_at=now()+interval '3 minutes'
    where id=p_room and owner_id=auth.uid()
      and status in ('starting','online')
    returning * into result;
  if result.id is null then raise exception 'Sala no disponible'; end if;
  return to_jsonb(result);
end
$kat$;

create or replace function public.kat_unpublish_room(
  p_room uuid
) returns jsonb language plpgsql security definer set search_path=public as $kat$
declare result public.kat_rooms;
begin
  update public.kat_rooms
    set status='offline',updated_at=now(),expires_at=now()
    where id=p_room and owner_id=auth.uid()
    returning * into result;
  if result.id is null then raise exception 'Sala no disponible'; end if;
  return to_jsonb(result);
end
$kat$;

create or replace function public.kat_list_public_rooms(
  p_search text default '',
  p_limit integer default 50
) returns jsonb language sql security definer set search_path=public as $kat$
  select coalesce(jsonb_agg(row_data order by
    (row_data->>'players_online')::integer desc,
    row_data->>'updated_at' desc
  ),'[]'::jsonb)
  from (
    select jsonb_build_object(
      'id',r.id,
      'owner_id',r.owner_id,
      'owner_name',p.display_name,
      'owner_avatar',p.avatar_path,
      'owner_platinum',p.platinum,
      'name',r.name,
      'description',r.description,
      'host',r.server_host,
      'port',r.server_port,
      'minecraft_version',r.minecraft_version,
      'loader',r.loader,
      'loader_version',r.loader_version,
      'launcher_version',r.launcher_version,
      'modpack_id',r.modpack_id,
      'mods',r.mods,
      'players_online',r.players_online,
      'players_max',r.players_max,
      'updated_at',r.updated_at,
      'expires_at',r.expires_at
    ) row_data
    from public.kat_rooms r
    join public.kat_profiles p on p.id=r.owner_id
    where auth.uid() is not null
      and r.visibility='public'
      and r.status='online'
      and r.expires_at>now()
      and not p.banned
      and (
        trim(coalesce(p_search,''))=''
        or r.name ilike '%'||left(trim(p_search),64)||'%'
        or r.description ilike '%'||left(trim(p_search),64)||'%'
        or p.display_name ilike '%'||left(trim(p_search),64)||'%'
      )
      and not exists(select 1 from public.kat_blocks b where
        (b.blocker=auth.uid() and b.blocked=r.owner_id)
        or (b.blocker=r.owner_id and b.blocked=auth.uid()))
    order by r.players_online desc,r.updated_at desc
    limit greatest(1,least(coalesce(p_limit,50),100))
  ) directory
$kat$;

create or replace function public.kat_get_room(
  p_room uuid
) returns jsonb language sql security definer set search_path=public as $kat$
  select coalesce((
    select jsonb_build_object(
      'id',r.id,'owner_id',r.owner_id,'owner_name',p.display_name,
      'owner_platinum',p.platinum,'name',r.name,'description',r.description,
      'host',r.server_host,'port',r.server_port,
      'minecraft_version',r.minecraft_version,'loader',r.loader,
      'loader_version',r.loader_version,'launcher_version',r.launcher_version,
      'modpack_id',r.modpack_id,'mods',r.mods,
      'players_online',r.players_online,'players_max',r.players_max,
      'visibility',r.visibility,'status',r.status,'expires_at',r.expires_at
    )
    from public.kat_rooms r join public.kat_profiles p on p.id=r.owner_id
    where r.id=p_room and auth.uid() is not null and r.expires_at>now()
      and (r.visibility='public' or r.owner_id=auth.uid() or (
        r.visibility='friends' and exists(
          select 1 from public.kat_friendships f
          where f.user_a=least(auth.uid(),r.owner_id)
            and f.user_b=greatest(auth.uid(),r.owner_id)
        )
      ))
  ),'{}'::jsonb)
$kat$;

revoke all on function public.kat_publish_room(
  text,text,text,integer,text,text,text,text,text,jsonb,text,integer
) from public,anon;
revoke all on function public.kat_touch_room(uuid,integer) from public,anon;
revoke all on function public.kat_unpublish_room(uuid) from public,anon;
revoke all on function public.kat_list_public_rooms(text,integer) from public,anon;
revoke all on function public.kat_get_room(uuid) from public,anon;

grant execute on function public.kat_publish_room(
  text,text,text,integer,text,text,text,text,text,jsonb,text,integer
) to authenticated;
grant execute on function public.kat_touch_room(uuid,integer) to authenticated;
grant execute on function public.kat_unpublish_room(uuid) to authenticated;
grant execute on function public.kat_list_public_rooms(text,integer) to authenticated;
grant execute on function public.kat_get_room(uuid) to authenticated;

select 'Salas públicas KatLauncher 1.5.1 listas' as status;
