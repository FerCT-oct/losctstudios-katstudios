#!/usr/bin/env python3
"""
KatLauncher - Launcher no oficial de Minecraft: Java Edition
Modo offline/nickname. Perfiles, gestión de mods (Modrinth) y skins locales.
"""
import os
import sys
import time
from pathlib import Path

from PySide6.QtCore import QLockFile, QTimer
from PySide6.QtWidgets import QApplication, QMessageBox
from PySide6.QtGui import QIcon

from katlauncher.gui.main_window import MainWindow
from katlauncher.gui.splash_screen import SplashScreen, LOGO_PATH
from katlauncher.core.profile_manager import ProfileManager
from katlauncher.core.settings_manager import SettingsManager
from katlauncher.gui.i18n import I18n
from katlauncher import __version__


def main():
    if "--version" in sys.argv:
        print(__version__)
        return 0

    smoke_test = "--smoke-test" in sys.argv
    updated_successfully = "--updated-successfully" in sys.argv
    internal_arguments = {"--smoke-test", "--updated-successfully"}
    qt_arguments = [arg for arg in sys.argv if arg not in internal_arguments]
    app = QApplication(qt_arguments)
    app.setApplicationName("KatLauncher")
    app.setApplicationVersion(__version__)
    settings_manager = SettingsManager()
    i18n = I18n(settings_manager.settings.language)
    instance_lock = None
    if not smoke_test:
        instance_lock = QLockFile(str(settings_manager.settings_file.parent / "katlauncher.lock"))
        instance_lock.setStaleLockTime(0)
        if not instance_lock.tryLock(100):
            QMessageBox.information(
                None,
                "KatLauncher",
                i18n.t("KatLauncher ya está abierto."),
            )
            return 5

    if LOGO_PATH.exists():
        app.setWindowIcon(QIcon(str(LOGO_PATH)))

    if smoke_test:
        # Prueba de release: construye la interfaz completa sin tocar la red.
        # La lista de versiones se sustituye solo durante este modo interno.
        os.environ["KATLAUNCHER_SMOKE_TEST"] = "1"
        import minecraft_launcher_lib as mll
        from pypresence import Presence
        from katlauncher.core import launcher_core
        if not LOGO_PATH.is_file() or QIcon(str(LOGO_PATH)).isNull():
            return 2
        if not mll.utils.get_library_version():
            return 3
        if Presence is None:
            return 6
        launcher_core.get_version_list = lambda *_args, **_kwargs: []
        profile_manager = ProfileManager()
        window = MainWindow(
            profile_manager=profile_manager,
            settings_manager=settings_manager,
            i18n=i18n,
        )
        window.show()
        deadline = time.monotonic() + 5
        while window.profiles_tab.has_running_workers() and time.monotonic() < deadline:
            app.processEvents()
            time.sleep(0.01)
        app.processEvents()
        routes = {route for route, _widget, _label in window._page_specs}
        required = {
            "play", "bedrock", "profiles", "downloads", "mods", "skins",
            "screenshots", "news",
            "servers", "rooms", "friends", "accounts", "trophies", "settings",
        }
        hosted_correctly = (
            required.issubset(set(window._active_shell._pages))
            if window._active_shell is not None
            else window.tabs.count() == len(required)
        )
        if routes != required or not hosted_correctly \
                or window.profiles_tab.has_running_workers():
            return 4
        window.close()
        app.processEvents()
        return 0

    splash = None
    if settings_manager.settings.show_splash:
        splash = SplashScreen(i18n)
        splash.show()
        app.processEvents()

    def step(text: str, progress: int, work=None):
        if splash:
            splash.set_status(text)
            splash.set_progress(progress)
            app.processEvents()
        if work:
            result = work()
        else:
            result = None
        if splash:
            time.sleep(0.25)  # da tiempo a que se vea cada paso
        return result

    step(i18n.t("Cargando configuración..."), 15)
    profile_manager = step(i18n.t("Cargando perfiles..."), 35, ProfileManager)

    def check_java():
        try:
            import minecraft_launcher_lib as mll
            mll.java_utils.find_system_java_versions()
        except Exception:
            pass

    step(i18n.t("Comprobando Java instalado..."), 60, check_java)

    window_holder = {}

    def build_window():
        window_holder["window"] = MainWindow(
            profile_manager=profile_manager,
            settings_manager=settings_manager,
            i18n=i18n,
        )

    step(i18n.t("Preparando la interfaz..."), 85, build_window)
    step(i18n.t("¡Listo!"), 100)

    window = window_holder["window"]
    if LOGO_PATH.exists():
        window.setWindowIcon(QIcon(str(LOGO_PATH)))
    window.show()
    if splash:
        splash.close()

    QTimer.singleShot(2000, window.start_auto_update_check)
    QTimer.singleShot(3500, window.start_alert_check)
    QTimer.singleShot(350, window.show_onboarding_if_needed)
    if updated_successfully:
        QTimer.singleShot(900, window.show_update_success_notification)

    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
