"""KatAlertSender — compone y publica alertas de KatLauncher en Supabase.

Herramienta de escritorio SEPARADA del launcher. Publica directamente en la
tabla ``public.kat_alerts`` del mismo proyecto de Supabase que ya usa Kat
Social (ver ``supabase/11_kat_alerts_1521.sql`` para crear la tabla una sola
vez).

No hay hosting que mantener: el launcher lee esa tabla con la publishable
key pública (ya está en ``social_config.json``). Para ESCRIBIR hace falta la
**service_role key** del proyecto (Supabase → Settings → API → service_role,
"secret"). Esa clave NUNCA va dentro de la app ni de ``social_config.json``
— vive solo en este equipo, en ``tools/kat_alert_sender_secrets.json``, y
solo la usa esta herramienta para publicar/retirar avisos.

Requiere PySide6 y requests (ya son dependencias del launcher):
    python tools/kat_alert_sender.py
"""
from __future__ import annotations

import json
import re
import sys
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path

import requests
from PySide6.QtCore import Qt
from PySide6.QtGui import QClipboard, QGuiApplication
from PySide6.QtWidgets import (
    QApplication, QCheckBox, QComboBox, QFrame, QGroupBox, QHBoxLayout,
    QLabel, QLineEdit, QMainWindow, QMessageBox, QPlainTextEdit, QPushButton,
    QRadioButton, QStatusBar, QTabWidget, QVBoxLayout, QWidget,
)

TOOL_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = TOOL_DIR.parent
SOCIAL_CONFIG_FILE = PROJECT_ROOT / "katlauncher" / "social_config.json"
DRAFT_FILE = TOOL_DIR / "kat_alert_sender_draft.json"
SECRETS_FILE = TOOL_DIR / "kat_alert_sender_secrets.json"
ASSET_SOUND = PROJECT_ROOT / "katlauncher" / "assets" / "error.mp3"

SEVERITY_LABELS = {
    "info": "Info · azul",
    "warning": "Advertencia · ámbar",
    "critical": "Crítico · rojo",
}
SEVERITY_COLORS = {
    "info": "#4f7bd8",
    "warning": "#d8a94f",
    "critical": "#e05d5d",
}
SLUG_RE = re.compile(r"[^a-z0-9]+")


def slugify(text: str) -> str:
    return SLUG_RE.sub("-", text.strip().lower()).strip("-")[:60]


def make_alert_id(title: str) -> str:
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    slug = slugify(title) or "alerta"
    return f"{stamp}-{slug}"


def load_project_url() -> str:
    try:
        data = json.loads(SOCIAL_CONFIG_FILE.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return ""
    return str(data.get("project_url", "")).rstrip("/")


@dataclass
class AlertDraft:
    title_es: str = ""
    title_en: str = ""
    message_es: str = ""
    message_en: str = ""
    severity: str = "info"
    display: str = "banner"
    sound: bool = True


class SoundPreview:
    """Reproduce el sonido de advertencia del launcher para probarlo antes
    de publicar. Solo funciona en Windows (misma API que usa KatLauncher);
    en otros sistemas se omite en silencio."""

    def __init__(self):
        self._backend = None
        if sys.platform == "win32":
            try:
                import ctypes

                self._winmm = ctypes.WinDLL("winmm")
                self._send = self._winmm.mciSendStringW
                self._send.argtypes = [
                    ctypes.c_wchar_p, ctypes.c_wchar_p, ctypes.c_uint, ctypes.c_void_p,
                ]
                self._send.restype = ctypes.c_uint
                self._backend = True
            except (AttributeError, OSError):
                self._backend = None

    @property
    def available(self) -> bool:
        return self._backend is not None and ASSET_SOUND.is_file()

    def play(self) -> None:
        if not self.available:
            return
        path_text = str(ASSET_SOUND)
        if '"' in path_text:
            return
        self._send('close katalertsender_preview', None, 0, None)
        self._send(f'open "{path_text}" type mpegvideo alias katalertsender_preview', None, 0, None)
        self._send('play katalertsender_preview from 0', None, 0, None)


class SupabaseAlertPublisher:
    """Publica directo en ``public.kat_alerts`` vía PostgREST, con la
    service_role key (nunca con la publishable key pública)."""

    def __init__(self, project_url: str, service_role_key: str):
        self.project_url = project_url.rstrip("/")
        self.service_role_key = service_role_key

    def _headers(self, *, prefer: str = "") -> dict:
        headers = {
            "apikey": self.service_role_key,
            "Authorization": f"Bearer {self.service_role_key}",
            "Content-Type": "application/json",
        }
        if prefer:
            headers["Prefer"] = prefer
        return headers

    def deactivate_current(self) -> None:
        response = requests.patch(
            f"{self.project_url}/rest/v1/kat_alerts?active=eq.true",
            headers=self._headers(),
            data=json.dumps({"active": False}),
            timeout=20,
        )
        response.raise_for_status()

    def publish(self, row: dict) -> None:
        self.deactivate_current()
        response = requests.post(
            f"{self.project_url}/rest/v1/kat_alerts",
            headers=self._headers(prefer="resolution=merge-duplicates,return=minimal"),
            data=json.dumps([row]),
            timeout=20,
        )
        response.raise_for_status()


class KatAlertSender(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("KatAlertSender — publicar aviso en KatLauncher")
        self.resize(760, 660)
        self.sound_preview = SoundPreview()
        self.project_url = load_project_url()
        self._build_ui()
        self._load_draft()
        self._load_secrets()
        self._refresh_preview()

    # ------------------------------------------------------------------ UI
    def _build_ui(self) -> None:
        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(18, 18, 18, 18)
        root.setSpacing(14)

        header = QLabel(
            "<b>Redactar alerta para KatLauncher</b><br>"
            "Se publica directo en Supabase; no hay ningún archivo que subir "
            "a mano. Se muestra como banner en el Dashboard o como cuadro de "
            "diálogo, según elijas abajo."
        )
        header.setWordWrap(True)
        root.addWidget(header)

        if not self.project_url:
            warning = QLabel(
                "⚠️ No encontré <code>project_url</code> en "
                "<code>katlauncher/social_config.json</code>. Complétalo "
                "primero (es la misma configuración de Kat Social)."
            )
            warning.setStyleSheet("color: #e05d5d;")
            warning.setWordWrap(True)
            root.addWidget(warning)

        form_row = QHBoxLayout()
        form_row.setSpacing(16)

        content_box = QGroupBox("Contenido")
        content_layout = QVBoxLayout(content_box)
        self.lang_tabs = QTabWidget()

        self.title_es = QLineEdit()
        self.title_es.setPlaceholderText("Ej: Mantenimiento programado")
        self.message_es = QPlainTextEdit()
        self.message_es.setPlaceholderText("Mensaje que verán los usuarios en español…")
        self.message_es.setFixedHeight(110)
        tab_es = QWidget()
        tab_es_layout = QVBoxLayout(tab_es)
        tab_es_layout.addWidget(QLabel("Título (ES)"))
        tab_es_layout.addWidget(self.title_es)
        tab_es_layout.addWidget(QLabel("Mensaje (ES)"))
        tab_es_layout.addWidget(self.message_es)
        self.lang_tabs.addTab(tab_es, "Español")

        self.title_en = QLineEdit()
        self.title_en.setPlaceholderText("e.g. Scheduled maintenance")
        self.message_en = QPlainTextEdit()
        self.message_en.setPlaceholderText("Optional — message shown in English…")
        self.message_en.setFixedHeight(110)
        tab_en = QWidget()
        tab_en_layout = QVBoxLayout(tab_en)
        tab_en_layout.addWidget(QLabel("Title (EN) — opcional"))
        tab_en_layout.addWidget(self.title_en)
        tab_en_layout.addWidget(QLabel("Message (EN) — opcional"))
        tab_en_layout.addWidget(self.message_en)
        self.lang_tabs.addTab(tab_en, "English")

        content_layout.addWidget(self.lang_tabs)
        form_row.addWidget(content_box, stretch=3)

        options_box = QGroupBox("Opciones")
        options_layout = QVBoxLayout(options_box)

        options_layout.addWidget(QLabel("Severidad"))
        self.severity_combo = QComboBox()
        for key, label in SEVERITY_LABELS.items():
            self.severity_combo.addItem(label, key)
        self.severity_combo.currentIndexChanged.connect(self._refresh_preview)
        options_layout.addWidget(self.severity_combo)

        self.severity_swatch = QFrame()
        self.severity_swatch.setFixedHeight(6)
        options_layout.addWidget(self.severity_swatch)

        options_layout.addWidget(QLabel("Cómo se muestra"))
        self.display_banner = QRadioButton("Banner en el Dashboard (no bloquea)")
        self.display_dialog = QRadioButton("Cuadro de diálogo (bloquea hasta que lo cierran)")
        self.display_banner.setChecked(True)
        self.display_banner.toggled.connect(self._refresh_preview)
        options_layout.addWidget(self.display_banner)
        options_layout.addWidget(self.display_dialog)

        self.sound_checkbox = QCheckBox("Reproducir sonido de advertencia")
        self.sound_checkbox.setChecked(True)
        options_layout.addWidget(self.sound_checkbox)

        self.preview_sound_button = QPushButton("🔊 Probar sonido")
        self.preview_sound_button.clicked.connect(self._on_preview_sound)
        if not self.sound_preview.available:
            self.preview_sound_button.setEnabled(False)
            self.preview_sound_button.setToolTip(
                "La vista previa de sonido solo funciona en Windows."
            )
        options_layout.addWidget(self.preview_sound_button)

        options_layout.addWidget(QLabel("Identificador único"))
        id_row = QHBoxLayout()
        self.id_field = QLineEdit()
        self.id_field.setPlaceholderText("Se genera automáticamente")
        self.regen_id_button = QPushButton("🔁")
        self.regen_id_button.setFixedWidth(32)
        self.regen_id_button.setToolTip("Regenerar identificador a partir del título")
        self.regen_id_button.clicked.connect(self._regenerate_id)
        id_row.addWidget(self.id_field)
        id_row.addWidget(self.regen_id_button)
        options_layout.addLayout(id_row)

        options_layout.addStretch()
        form_row.addWidget(options_box, stretch=2)
        root.addLayout(form_row)

        self.title_es.textChanged.connect(self._on_title_changed)
        self.title_es.textChanged.connect(self._refresh_preview)
        self.title_en.textChanged.connect(self._refresh_preview)
        self.message_es.textChanged.connect(self._refresh_preview)
        self.message_en.textChanged.connect(self._refresh_preview)
        self.id_field.textChanged.connect(self._refresh_preview)

        preview_box = QGroupBox("Fila que se va a publicar en kat_alerts")
        preview_layout = QVBoxLayout(preview_box)
        self.json_preview = QPlainTextEdit()
        self.json_preview.setReadOnly(True)
        self.json_preview.setFixedHeight(130)
        self.json_preview.setStyleSheet(
            "font-family: Consolas, monospace; font-size: 11px;"
        )
        preview_layout.addWidget(self.json_preview)
        root.addWidget(preview_box)

        credentials_box = QGroupBox(
            "Credencial de Supabase (service_role key — solo en este equipo)"
        )
        credentials_layout = QVBoxLayout(credentials_box)
        credentials_hint = QLabel(
            "Se encuentra en tu proyecto de Supabase → Settings → API → "
            "\"service_role\" (secret). Es distinta de la publishable key "
            "que ya usa el launcher, y NUNCA debe ir dentro de la app."
        )
        credentials_hint.setWordWrap(True)
        credentials_layout.addWidget(credentials_hint)
        key_row = QHBoxLayout()
        self.service_role_field = QLineEdit()
        self.service_role_field.setEchoMode(QLineEdit.Password)
        self.service_role_field.setPlaceholderText("service_role key…")
        key_row.addWidget(self.service_role_field)
        self.remember_key_checkbox = QCheckBox("Recordar en este equipo")
        key_row.addWidget(self.remember_key_checkbox)
        credentials_layout.addLayout(key_row)
        root.addWidget(credentials_box)

        actions_row = QHBoxLayout()
        self.preview_alert_button = QPushButton("👁️ Vista previa del aviso")
        self.preview_alert_button.clicked.connect(self._on_preview_alert)
        self.copy_button = QPushButton("📋 Copiar fila (JSON)")
        self.copy_button.clicked.connect(self._on_copy_json)
        self.publish_button = QPushButton("🚀 Publicar en Supabase")
        self.publish_button.clicked.connect(self._on_publish)
        self.retire_button = QPushButton("🧹 Retirar alerta activa")
        self.retire_button.clicked.connect(self._on_retire)
        for button in (
            self.preview_alert_button, self.copy_button,
            self.publish_button, self.retire_button,
        ):
            actions_row.addWidget(button)
        root.addLayout(actions_row)

        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)

    # -------------------------------------------------------------- helpers
    def _selected_severity(self) -> str:
        return self.severity_combo.currentData() or "info"

    def _selected_display(self) -> str:
        return "dialog" if self.display_dialog.isChecked() else "banner"

    def _on_title_changed(self, _text: str) -> None:
        if not self.id_field.text().strip():
            self.id_field.blockSignals(True)
            self.id_field.setText(make_alert_id(self.title_es.text()))
            self.id_field.blockSignals(False)

    def _regenerate_id(self) -> None:
        self.id_field.setText(make_alert_id(self.title_es.text()))
        self._refresh_preview()

    def _current_draft(self) -> AlertDraft:
        return AlertDraft(
            title_es=self.title_es.text().strip(),
            title_en=self.title_en.text().strip(),
            message_es=self.message_es.toPlainText().strip(),
            message_en=self.message_en.toPlainText().strip(),
            severity=self._selected_severity(),
            display=self._selected_display(),
            sound=self.sound_checkbox.isChecked(),
        )

    def _build_row(self, draft: AlertDraft) -> dict:
        alert_id = self.id_field.text().strip() or make_alert_id(draft.title_es)
        return {
            "id": alert_id,
            "severity": draft.severity,
            "display": draft.display,
            "sound": draft.sound,
            "title_es": draft.title_es,
            "title_en": draft.title_en,
            "message_es": draft.message_es,
            "message_en": draft.message_en,
            "active": True,
            "published_at": datetime.now(timezone.utc)
            .strftime("%Y-%m-%dT%H:%M:%SZ"),
        }

    def _refresh_preview(self, *_args) -> None:
        draft = self._current_draft()
        color = SEVERITY_COLORS.get(draft.severity, SEVERITY_COLORS["info"])
        self.severity_swatch.setStyleSheet(f"background-color: {color}; border-radius: 3px;")
        row = self._build_row(draft)
        self.json_preview.setPlainText(json.dumps(row, ensure_ascii=False, indent=2))
        self._save_draft(draft)

    def _validate(self, draft: AlertDraft) -> str:
        if not draft.title_es and not draft.title_en:
            return "Escribe al menos un título (ES o EN)."
        if not draft.message_es and not draft.message_en:
            return "Escribe al menos un mensaje (ES o EN)."
        if len(draft.title_es) > 140 or len(draft.title_en) > 140:
            return "El título no puede superar 140 caracteres."
        if len(draft.message_es) > 600 or len(draft.message_en) > 600:
            return "El mensaje no puede superar 600 caracteres."
        return ""

    def _current_publisher(self) -> SupabaseAlertPublisher | None:
        if not self.project_url:
            QMessageBox.warning(
                self, "Falta project_url",
                "Completa project_url en katlauncher/social_config.json primero.",
            )
            return None
        key = self.service_role_field.text().strip()
        if not key:
            QMessageBox.warning(
                self, "Falta la credencial",
                "Pega la service_role key de tu proyecto de Supabase.",
            )
            return None
        return SupabaseAlertPublisher(self.project_url, key)

    # --------------------------------------------------------------- acciones
    def _on_preview_sound(self) -> None:
        self.sound_preview.play()

    def _on_preview_alert(self) -> None:
        draft = self._current_draft()
        error = self._validate(draft)
        if error:
            QMessageBox.warning(self, "Falta completar", error)
            return
        if draft.sound:
            self.sound_preview.play()
        title = draft.title_es or draft.title_en
        message = draft.message_es or draft.message_en
        if draft.display == "dialog":
            icon = {
                "warning": QMessageBox.Warning,
                "critical": QMessageBox.Critical,
            }.get(draft.severity, QMessageBox.Information)
            box = QMessageBox(self)
            box.setIcon(icon)
            box.setWindowTitle(title)
            box.setText(message)
            box.exec()
        else:
            preview = QMessageBox(self)
            preview.setIcon(QMessageBox.Information)
            preview.setWindowTitle("Vista previa del banner")
            preview.setText(f"<b>{title}</b><br>{message}")
            preview.setInformativeText(
                "Así se vería como banner en el Dashboard "
                f"(severidad: {SEVERITY_LABELS[draft.severity]})."
            )
            preview.exec()

    def _on_copy_json(self) -> None:
        draft = self._current_draft()
        error = self._validate(draft)
        if error:
            QMessageBox.warning(self, "Falta completar", error)
            return
        row = self._build_row(draft)
        QGuiApplication.clipboard().setText(
            json.dumps(row, ensure_ascii=False, indent=2), QClipboard.Clipboard
        )
        self.status_bar.showMessage(
            "Fila copiada — pégala en el Table Editor de Supabase si prefieres hacerlo a mano.",
            6000,
        )

    def _on_publish(self) -> None:
        draft = self._current_draft()
        error = self._validate(draft)
        if error:
            QMessageBox.warning(self, "Falta completar", error)
            return
        publisher = self._current_publisher()
        if publisher is None:
            return
        row = self._build_row(draft)
        try:
            publisher.publish(row)
        except requests.RequestException as error:
            QMessageBox.critical(self, "Error al publicar", str(error))
            return
        self._maybe_save_secret()
        self.status_bar.showMessage(
            f"Publicado: {row['id']} — el launcher lo verá en el próximo sondeo "
            "o casi al instante si tiene Realtime activo.",
            8000,
        )

    def _on_retire(self) -> None:
        confirm = QMessageBox.question(
            self, "Retirar alerta",
            "Esto desactiva cualquier aviso actualmente activo en Supabase. "
            "¿Continuar?",
        )
        if confirm != QMessageBox.Yes:
            return
        publisher = self._current_publisher()
        if publisher is None:
            return
        try:
            publisher.deactivate_current()
        except requests.RequestException as error:
            QMessageBox.critical(self, "Error al retirar", str(error))
            return
        self._maybe_save_secret()
        self.status_bar.showMessage("Alerta activa retirada.", 6000)

    # ---------------------------------------------------------- persistencia
    def _save_draft(self, draft: AlertDraft) -> None:
        try:
            DRAFT_FILE.write_text(
                json.dumps(asdict(draft), ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
        except OSError:
            pass

    def _load_draft(self) -> None:
        if not DRAFT_FILE.is_file():
            return
        try:
            data = json.loads(DRAFT_FILE.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return
        if not isinstance(data, dict):
            return
        self.title_es.setText(str(data.get("title_es", "")))
        self.title_en.setText(str(data.get("title_en", "")))
        self.message_es.setPlainText(str(data.get("message_es", "")))
        self.message_en.setPlainText(str(data.get("message_en", "")))
        severity = str(data.get("severity", "info"))
        index = self.severity_combo.findData(severity)
        if index >= 0:
            self.severity_combo.setCurrentIndex(index)
        if str(data.get("display", "banner")) == "dialog":
            self.display_dialog.setChecked(True)
        else:
            self.display_banner.setChecked(True)
        self.sound_checkbox.setChecked(bool(data.get("sound", True)))

    def _maybe_save_secret(self) -> None:
        if not self.remember_key_checkbox.isChecked():
            return
        key = self.service_role_field.text().strip()
        if not key:
            return
        try:
            SECRETS_FILE.write_text(
                json.dumps({"service_role_key": key}, ensure_ascii=False),
                encoding="utf-8",
            )
        except OSError:
            pass

    def _load_secrets(self) -> None:
        if not SECRETS_FILE.is_file():
            return
        try:
            data = json.loads(SECRETS_FILE.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return
        if not isinstance(data, dict):
            return
        key = str(data.get("service_role_key", ""))
        if key:
            self.service_role_field.setText(key)
            self.remember_key_checkbox.setChecked(True)


def main() -> None:
    app = QApplication(sys.argv)
    window = KatAlertSender()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
