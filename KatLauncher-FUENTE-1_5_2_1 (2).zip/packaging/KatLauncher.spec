# -*- mode: python ; coding: utf-8 -*-
import os
import re
import tempfile
from pathlib import Path

from PyInstaller.utils.hooks import collect_data_files, collect_submodules


PACKAGING_DIR = Path(SPECPATH)
PROJECT_ROOT = PACKAGING_DIR.parent
VERSION_SOURCE = (PROJECT_ROOT / "katlauncher" / "__init__.py").read_text(encoding="utf-8")
VERSION_MATCH = re.search(
    r'^__version__\s*=\s*["\'](\d+\.\d+\.\d+(?:\.\d+)?)["\']', VERSION_SOURCE, re.M
)
if not VERSION_MATCH:
    raise ValueError("No se pudo leer __version__")
APP_VERSION = VERSION_MATCH.group(1)
_version_ints = [int(item) for item in APP_VERSION.split(".")]
while len(_version_ints) < 4:
    _version_ints.append(0)
VERSION_PARTS = tuple(_version_ints[:4])
VERSION_RESOURCE = Path(tempfile.gettempdir()) / f"KatLauncher-{APP_VERSION}-version_info.txt"
VERSION_RESOURCE.write_text(f"""VSVersionInfo(
  ffi=FixedFileInfo(
    filevers={VERSION_PARTS!r},
    prodvers={VERSION_PARTS!r},
    mask=0x3f,
    flags=0x0,
    OS=0x40004,
    fileType=0x1,
    subtype=0x0,
    date=(0, 0)
  ),
  kids=[
    StringFileInfo([
      StringTable(
        '040904B0',
        [
          StringStruct('FileDescription', 'KatLauncher - Launcher no oficial de Minecraft: Java Edition'),
          StringStruct('FileVersion', '{APP_VERSION}'),
          StringStruct('InternalName', 'KatLauncher'),
          StringStruct('OriginalFilename', 'KatLauncher.exe'),
          StringStruct('ProductName', 'KatLauncher'),
          StringStruct('ProductVersion', '{APP_VERSION}')
        ]
      )
    ]),
    VarFileInfo([VarStruct('Translation', [1033, 1200])])
  ]
)""", encoding="utf-8")

UPDATE_CHANNEL_FILE = Path(os.environ.get(
    "KATLAUNCHER_UPDATE_CHANNEL_FILE",
    PROJECT_ROOT / "katlauncher" / "update_channel.json",
))
SOCIAL_CONFIG_FILE = Path(os.environ.get(
    "KATLAUNCHER_SOCIAL_CONFIG_FILE",
    PROJECT_ROOT / "katlauncher" / "social_config.json",
))
CURSEFORGE_CONFIG_FILE = Path(os.environ.get(
    "KATLAUNCHER_CURSEFORGE_CONFIG_FILE",
    PROJECT_ROOT / "katlauncher" / "curseforge_config.json",
))
if not UPDATE_CHANNEL_FILE.is_file():
    raise ValueError("No se encontró update_channel.json")
if not SOCIAL_CONFIG_FILE.is_file():
    raise ValueError("No se encontró social_config.json")
if not CURSEFORGE_CONFIG_FILE.is_file():
    raise ValueError("No se encontró curseforge_config.json")

datas = [
    (str(PROJECT_ROOT / "katlauncher" / "assets" / "logo.png"),
     "katlauncher/assets"),
    (str(PROJECT_ROOT / "katlauncher" / "assets" / "success.mp3"),
     "katlauncher/assets"),
    (str(PROJECT_ROOT / "katlauncher" / "assets" / "cat_ringtone.mp3"),
     "katlauncher/assets"),
    (str(PROJECT_ROOT / "katlauncher" / "assets" / "update_success.wav"),
     "katlauncher/assets"),
    (str(PROJECT_ROOT / "katlauncher" / "assets" / "ui_click.mp3"),
     "katlauncher/assets"),
    (str(PROJECT_ROOT / "katlauncher" / "assets" / "soft_success.mp3"),
     "katlauncher/assets"),
    (str(PROJECT_ROOT / "katlauncher" / "assets" / "achievement.mp3"),
     "katlauncher/assets"),
    (str(PROJECT_ROOT / "katlauncher" / "assets" / "error.mp3"),
     "katlauncher/assets"),
    (str(PROJECT_ROOT / "katlauncher" / "assets" / "notification.mp3"),
     "katlauncher/assets"),
    (str(PROJECT_ROOT / "katlauncher" / "assets" / "invite.mp3"),
     "katlauncher/assets"),
    (str(PROJECT_ROOT / "katlauncher" / "assets" / "creeper.mp3"),
     "katlauncher/assets"),
    (str(PROJECT_ROOT / "katlauncher" / "assets" / "MCKAT.zip"),
     "katlauncher/assets"),
    (str(UPDATE_CHANNEL_FILE),
     "katlauncher"),
    (str(SOCIAL_CONFIG_FILE),
     "katlauncher"),
    (str(CURSEFORGE_CONFIG_FILE),
     "katlauncher"),
]
KATCRAFT_DIR = PROJECT_ROOT / "katlauncher" / "assets" / "katcraft"
if KATCRAFT_DIR.is_dir():
    for katcraft_jar in KATCRAFT_DIR.glob("KatCraft-*.jar"):
        datas.append((str(katcraft_jar), "katlauncher/assets/katcraft"))
KATGLOBAL_DIR = PROJECT_ROOT / "katlauncher" / "assets" / "katglobal"
if KATGLOBAL_DIR.is_dir():
    for katglobal_file in KATGLOBAL_DIR.rglob("*"):
        if katglobal_file.is_file():
            relative_parent = katglobal_file.parent.relative_to(KATGLOBAL_DIR)
            destination = Path("katlauncher/assets/katglobal") / relative_parent
            datas.append((str(katglobal_file), str(destination)))
datas += collect_data_files("minecraft_launcher_lib", includes=["version.txt"])
datas += collect_data_files("certifi", includes=["cacert.pem"])

a = Analysis(
    [str(PROJECT_ROOT / "main.py")],
    pathex=[str(PROJECT_ROOT)],
    binaries=[],
    datas=datas,
    hiddenimports=(
        collect_submodules("minecraft_launcher_lib")
        + collect_submodules("pypresence")
        + collect_submodules("supabase")
        + collect_submodules("keyring")
        + collect_submodules("inputs")
    ),
    hookspath=[str(PACKAGING_DIR / "hooks")],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="KatLauncher",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    console=False,
    disable_windowed_traceback=False,
    icon=str(PACKAGING_DIR / "KatLauncher.ico"),
    version=str(VERSION_RESOURCE) if os.name == "nt" else None,
    uac_admin=False,
    contents_directory="_internal",
)

coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=False,
    name="KatLauncher",
)
