#!/usr/bin/env sh
set -eu

SOURCE_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
TARGET_DIR="${XDG_DATA_HOME:-$HOME/.local/share}/KatLauncher"
BIN_DIR="$HOME/.local/bin"
APP_DIR="${XDG_DATA_HOME:-$HOME/.local/share}/applications"
ICON_DIR="${XDG_DATA_HOME:-$HOME/.local/share}/icons/hicolor/256x256/apps"

mkdir -p "$TARGET_DIR" "$BIN_DIR" "$APP_DIR" "$ICON_DIR"
cp -R "$SOURCE_DIR/app/." "$TARGET_DIR/"
chmod +x "$TARGET_DIR/KatLauncher"
ln -sf "$TARGET_DIR/KatLauncher" "$BIN_DIR/KatLauncher"
cp "$SOURCE_DIR/KatLauncher.desktop" "$APP_DIR/net.katlauncher.KatLauncher.desktop"
cp "$SOURCE_DIR/logo.png" "$ICON_DIR/net.katlauncher.KatLauncher.png"

printf '%s\n' "KatLauncher instalado. Si el menú no se actualiza todavía, cierra sesión y vuelve a entrar."
