#!/usr/bin/env bash
set -euo pipefail

if [[ "$(uname -s)" != "Linux" ]]; then
  echo "Este paquete debe compilarse dentro de Linux." >&2
  exit 2
fi

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
VERSION="$(sed -nE 's/^__version__ *= *["'"']([^"'"']+)["'"'].*/\1/p' "$ROOT/katlauncher/__init__.py")"
BUILD_ROOT="${KAT_BUILD_ROOT:-$ROOT/build-linux}"
VENV="$BUILD_ROOT/venv"
STAGE="$BUILD_ROOT/KatLauncher-$VERSION-linux-x86_64"
OUTPUT="$ROOT/outputs"

python3 -m venv "$VENV"
"$VENV/bin/python" -m pip install --upgrade pip
"$VENV/bin/python" -m pip install -r "$ROOT/requirements-linux.txt" -r "$ROOT/requirements-build.txt"
rm -rf "$ROOT/build" "$ROOT/dist" "$STAGE"
"$VENV/bin/pyinstaller" --noconfirm --clean "$ROOT/packaging/KatLauncher.spec"

mkdir -p "$STAGE/app" "$OUTPUT"
cp -R "$ROOT/dist/KatLauncher/." "$STAGE/app/"
cp "$ROOT/packaging/linux/install.sh" "$STAGE/install.sh"
cp "$ROOT/packaging/linux/KatLauncher.desktop" "$STAGE/KatLauncher.desktop"
cp "$ROOT/katlauncher/assets/logo.png" "$STAGE/logo.png"
chmod +x "$STAGE/install.sh" "$STAGE/app/KatLauncher"

tar -C "$BUILD_ROOT" -czf "$OUTPUT/KatLauncher-$VERSION-linux-x86_64.tar.gz" "$(basename "$STAGE")"
sha256sum "$OUTPUT/KatLauncher-$VERSION-linux-x86_64.tar.gz" > "$OUTPUT/KatLauncher-$VERSION-linux-x86_64.tar.gz.sha256"
echo "Creado: $OUTPUT/KatLauncher-$VERSION-linux-x86_64.tar.gz"
