# KatLauncher 1.5.0 — paquete de publicación

## Deploy completo para Netlify

Sube el contenido completo de `deploy-web-completo/`. Este directorio ya
incluye la página, estilos, scripts, video, imágenes, changelogs, encabezados
de Netlify y la carpeta `downloads`.

No despliegues únicamente `downloads`: esa carpeta es solo una parte del
sitio completo.

El instalador debe terminar disponible en:

`https://katlauncher.netlify.app/downloads/KatLauncher-Setup-1.5.0.exe`

El manifiesto debe terminar disponible en:

`https://katlauncher.netlify.app/downloads/KatLauncher-latest.json`

Cuando se actualice una versión, el deploy completo debe contener primero el
instalador nuevo y después su manifiesto coincidente. Así ningún cliente verá
una actualización cuyo EXE todavía no existe.

## Archivo privado de administración

`admin-supabase/08_katcraft.sql` no se sube a Netlify. Ejecútalo una sola vez
en Supabase SQL Editor con la cuenta administradora del proyecto. Es
idempotente y crea el estado, presencia e invitaciones de KatCraft.

## Cómo funciona KatCraft

El instalador lleva cuatro JAR firmemente empaquetados como recursos del
launcher. Al pulsar Jugar, KatLauncher detecta la versión y loader del perfil,
elige el JAR compatible y lo copia de forma atómica a la carpeta `mods`.
También borra versiones antiguas de KatCraft para evitar duplicados.

KatCraft se comunica únicamente con un servidor local temporal de KatLauncher
en `127.0.0.1`. Cada inicio usa un puerto y token aleatorios nuevos. El JAR no
contiene la clave de Supabase. El launcher conserva la sesión y realiza las
operaciones remotas.

Kat Social detecta invitaciones mientras el launcher está visible. Cuando
Minecraft está abierto y KatLauncher está en la bandeja, KatCraft consulta el
puente local y activa el mismo toast de Windows. El ID de invitación se
deduplica para que el sonido no se reproduzca dos veces.

## Salas Kat Global

En Jugar, el botón `Crear sala y jugar` permite seleccionar RAM y puerto.
KatLauncher pide la aceptación explícita de la EULA, descarga el servidor
oficial de la versión seleccionada, verifica su SHA-1 y lo ejecuta sin abrir
una consola. Cuando el servidor está listo, el anfitrión entra automáticamente
por `127.0.0.1`.

Con `Jugar por Internet` activado, Kat Global abre un túnel temporal y recibe
un dominio `*.e4mc.link`. KatCraft sustituye la dirección local por ese dominio
en las invitaciones, por lo que amigos de otros países pueden entrar sin abrir
puertos ni instalar programas externos. Si el relay falla, se conserva la
dirección LAN como respaldo.

Kat Global usa el protocolo e4mc/quiclime y código derivado bajo licencia MIT,
con el copyright y texto completo incluidos en el instalador. No se presenta
como un producto oficial de e4mc. La disponibilidad del relay es externa a
KatLauncher.

La sala usa `online-mode=false` para admitir los perfiles offline de
KatLauncher. Debe utilizarse únicamente con personas de confianza. El servidor
se apaga limpiamente al cerrar Minecraft.

## Compatibilidad incluida

- Fabric 1.21.1
- Quilt 1.21.1 mediante el JAR Fabric compatible
- Fabric 26.2
- Forge 1.20.1
- NeoForge 1.21.1

Vanilla muestra una advertencia porque no puede cargar JARs de mods.
