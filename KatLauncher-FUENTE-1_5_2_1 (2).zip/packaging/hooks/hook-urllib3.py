"""Evita recopilar backends opcionales que KatLauncher no habilita."""

# urllib3 importa estos módulos únicamente si el usuario instala extras de
# compresión, HTTP/2, SOCKS o TLS alternativo. El launcher usa requests con el
# backend estándar de Windows/OpenSSL incluido por Python.
excludedimports = [
    "OpenSSL",
    "backports",
    "brotli",
    "brotlicffi",
    "compression",
    "cryptography",
    "h2",
    "socks",
]
