"""Genera un ICO multirresolución a partir del logo PNG de KatLauncher."""
from pathlib import Path

from PIL import Image


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "katlauncher" / "assets" / "logo.png"
DESTINATION = Path(__file__).resolve().with_name("KatLauncher.ico")
SIZES = (16, 24, 32, 48, 64, 128, 256)


def main():
    image = Image.open(SOURCE).convert("RGBA")
    bounds = image.getchannel("A").getbbox()
    if not bounds:
        raise ValueError("El logo no contiene píxeles visibles.")
    artwork = image.crop(bounds)

    canvas_size = 1024
    margin = 72
    available = canvas_size - (margin * 2)
    scale = min(available / artwork.width, available / artwork.height)
    dimensions = (
        max(1, round(artwork.width * scale)),
        max(1, round(artwork.height * scale)),
    )
    artwork = artwork.resize(dimensions, Image.Resampling.LANCZOS)
    canvas = Image.new("RGBA", (canvas_size, canvas_size), (0, 0, 0, 0))
    position = (
        (canvas_size - artwork.width) // 2,
        (canvas_size - artwork.height) // 2,
    )
    canvas.alpha_composite(artwork, position)
    canvas.save(DESTINATION, format="ICO", sizes=[(size, size) for size in SIZES])
    print(DESTINATION)


if __name__ == "__main__":
    main()
