"""Prueba manual: descarga, inicia y detiene una sala oficial temporal."""
from __future__ import annotations

import argparse
import queue
import tempfile
import threading
import time
import types
import sys
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from katlauncher.core import room_server


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--java", required=True)
    parser.add_argument("--version", default="1.21.1")
    parser.add_argument("--timeout", type=int, default=120)
    args = parser.parse_args()

    with tempfile.TemporaryDirectory(prefix="kat-room-smoke-") as directory:
        root = Path(directory)
        profile = types.SimpleNamespace(
            id="smoke-room",
            version=args.version,
            game_dir=str(root / "client"),
        )
        with mock.patch.object(room_server, "ROOM_ROOT", root / "rooms"):
            server = room_server.DedicatedRoomServer(
                profile,
                ram_mb=1024,
                port=_free_port(),
                java_path=args.java,
            )
            server.prepare(status_cb=lambda value: print(value, flush=True))
            process = server.start()
            lines: queue.Queue[str | None] = queue.Queue()

            def read_output():
                try:
                    for line in process.stdout:
                        lines.put(line.rstrip())
                finally:
                    lines.put(None)

            threading.Thread(target=read_output, daemon=True).start()
            deadline = time.monotonic() + max(30, args.timeout)
            ready = False
            while time.monotonic() < deadline:
                try:
                    line = lines.get(timeout=1)
                except queue.Empty:
                    if process.poll() is not None:
                        break
                    continue
                if line is None:
                    break
                print(line, flush=True)
                if "Done (" in line:
                    ready = True
                    break
            server.stop()
            try:
                code = process.wait(timeout=30)
            except Exception:
                process.kill()
                process.wait(timeout=10)
                raise
            if not ready:
                raise RuntimeError(f"La sala no llegó al estado Done (código {code}).")
            if code != 0:
                raise RuntimeError(f"La sala se detuvo con código {code}.")
            print("ROOM_SMOKE_OK", flush=True)
    return 0


def _free_port() -> int:
    import socket

    probe = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    probe.bind(("127.0.0.1", 0))
    port = int(probe.getsockname()[1])
    probe.close()
    return port


if __name__ == "__main__":
    raise SystemExit(main())
