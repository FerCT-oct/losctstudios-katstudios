"""Smoke real y breve del relay Kat Global."""
from __future__ import annotations

import socket
import sys
import threading
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from katlauncher.core.katglobal import KatGlobalTunnel


PORT = 25579


def varint(value: int) -> bytes:
    result = bytearray()
    while True:
        current = value & 0x7f
        value >>= 7
        result.append(current | (0x80 if value else 0))
        if not value:
            return bytes(result)


def echo_once(ready: threading.Event):
    with socket.socket() as server:
        server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server.bind(("127.0.0.1", PORT))
        server.listen()
        ready.set()
        connection, _address = server.accept()
        with connection:
            payload = connection.recv(1024)
            connection.sendall(payload)


def minecraft_handshake(domain: str) -> bytes:
    host = domain.encode("utf-8")
    body = (
        varint(0)
        + varint(767)
        + varint(len(host))
        + host
        + (25565).to_bytes(2, "big")
        + varint(1)
    )
    return varint(len(body)) + body


def main():
    ready = threading.Event()
    server = threading.Thread(target=echo_once, args=(ready,), daemon=True)
    server.start()
    if not ready.wait(3):
        raise RuntimeError("El servidor local de prueba no inició.")
    java = (
        r"C:\Program Files\Pylo\MCreator\jdk\bin\java.exe"
    )
    tunnel = KatGlobalTunnel(java, PORT)
    try:
        domain = tunnel.start(timeout=45)
        packet = minecraft_handshake(domain)
        with socket.create_connection((domain, 25565), timeout=20) as client:
            client.sendall(packet)
            client.settimeout(20)
            echoed = client.recv(1024)
        if echoed != packet:
            raise RuntimeError("El relay no devolvió el paquete de prueba.")
        print("KATGLOBAL_SMOKE_OK", domain)
    finally:
        tunnel.stop()
    server.join(timeout=3)


if __name__ == "__main__":
    main()
