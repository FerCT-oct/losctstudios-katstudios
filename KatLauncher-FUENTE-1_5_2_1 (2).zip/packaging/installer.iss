#define MyAppName "KatLauncher"
#ifndef MyAppVersion
#define MyAppVersion "1.5.2.1"
#endif
#define MyAppExeName "KatLauncher.exe"

[Setup]
; Conserva la identidad del instalador 1.3.0 publicado por Oliver. Cambiarla
; crearía una segunda instalación en vez de actualizar KatLauncher.
AppId={{952FD63D-D991-49A2-9AE1-6D4F8E0B25FB}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppVerName={#MyAppName} {#MyAppVersion}
AppComments=Launcher no oficial de Minecraft: Java Edition con perfiles, contenido y Kat Social
AppPublisher=KatLauncher Project
AppPublisherURL=https://katlauncher.netlify.app
AppSupportURL=https://katlauncher.netlify.app
AppUpdatesURL=https://katlauncher.netlify.app
DefaultDirName={autopf}\{#MyAppName}
DefaultGroupName={#MyAppName}
AllowNoIcons=yes
PrivilegesRequired=admin
PrivilegesRequiredOverridesAllowed=commandline
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
; Compatible desde Windows 8.1 de 64 bits.
MinVersion=6.3
OutputDir=..\..\..\outputs
OutputBaseFilename=KatLauncher-Setup-{#MyAppVersion}
SetupIconFile=KatLauncher.ico
UninstallDisplayIcon={app}\{#MyAppExeName}
Compression=lzma2/ultra64
SolidCompression=yes
WizardStyle=modern
CloseApplications=yes
RestartApplications=no
UsePreviousAppDir=yes
UsePreviousTasks=yes
DirExistsWarning=no
VersionInfoVersion={#MyAppVersion}.0
VersionInfoDescription=KatLauncher Installer
VersionInfoProductName=KatLauncher
VersionInfoProductVersion={#MyAppVersion}
LicenseFile=..\LICENSE.txt
; /SMOKETEST=1 permite probar la extracción sin tocar la instalación real.
Uninstallable=not IsSmokeInstall

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"
Name: "spanish"; MessagesFile: "compiler:Languages\Spanish.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"; Flags: unchecked

[Files]
Source: "..\dist\KatLauncher\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{autoprograms}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; WorkingDir: "{app}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; WorkingDir: "{app}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "{cm:LaunchProgram,{#StringChange(MyAppName, '&', '&&')}}"; Flags: nowait postinstall skipifsilent
Filename: "{app}\{#MyAppExeName}"; Parameters: "--updated-successfully"; Flags: nowait; Check: ShouldRelaunch

[Code]
const
  SYNCHRONIZE = $00100000;
  WAIT_OBJECT_0 = 0;
  WAIT_TIMEOUT = 258;
  ERROR_INVALID_PARAMETER = 87;
  UPDATE_WAIT_MS = 120000;

function OpenProcess(DesiredAccess: DWORD; InheritHandle: Boolean;
  ProcessId: DWORD): THandle;
  external 'OpenProcess@kernel32.dll stdcall';
function WaitForSingleObject(Handle: THandle; Milliseconds: DWORD): DWORD;
  external 'WaitForSingleObject@kernel32.dll stdcall';
function CloseHandle(Handle: THandle): Boolean;
  external 'CloseHandle@kernel32.dll stdcall';

function IsAutoUpdate: Boolean;
begin
  Result := CompareText(ExpandConstant('{param:AUTOUPDATE|0}'), '1') = 0;
end;

function IsSmokeInstall: Boolean;
begin
  Result := CompareText(ExpandConstant('{param:SMOKETEST|0}'), '1') = 0;
end;

function MayRelaunch: Boolean;
begin
  Result := IsAutoUpdate and
    (CompareText(ExpandConstant('{param:NORELAUNCH|0}'), '1') <> 0);
end;

function ShouldRelaunch: Boolean;
begin
  Result := MayRelaunch;
end;

var
  AutoUpdateSucceeded: Boolean;

function InitializeSetup: Boolean;
var
  ProcessId: Integer;
  ProcessHandle: THandle;
  OpenError: Integer;
  WaitResult: DWORD;
begin
  Result := True;
  if not IsAutoUpdate then
    Exit;

  ProcessId := StrToIntDef(ExpandConstant('{param:WAITFORPID|0}'), 0);
  if ProcessId <= 0 then
  begin
    MsgBox('No se recibió un proceso válido para la actualización.', mbError, MB_OK);
    Result := False;
    Exit;
  end;

  ProcessHandle := OpenProcess(SYNCHRONIZE, False, ProcessId);
  if ProcessHandle = 0 then
  begin
    OpenError := DLLGetLastError;
    if OpenError = ERROR_INVALID_PARAMETER then
      Exit;  { KatLauncher ya terminó antes de que Setup abriera el proceso }
    MsgBox('No se pudo comprobar el cierre seguro de KatLauncher: ' +
      SysErrorMessage(OpenError), mbError, MB_OK);
    Result := False;
    Exit;
  end;

  try
    WaitResult := WaitForSingleObject(ProcessHandle, UPDATE_WAIT_MS);
    if WaitResult <> WAIT_OBJECT_0 then
    begin
      if WaitResult = WAIT_TIMEOUT then
        MsgBox('KatLauncher no terminó a tiempo. La actualización se canceló.', mbError, MB_OK)
      else
        MsgBox('No se pudo esperar el cierre seguro de KatLauncher.', mbError, MB_OK);
      Result := False;
    end;
  finally
    CloseHandle(ProcessHandle);
  end;
end;

procedure CurStepChanged(CurStep: TSetupStep);
begin
  if IsAutoUpdate and (CurStep = ssDone) then
    AutoUpdateSucceeded := True;
end;

procedure DeinitializeSetup;
var
  ResultCode: Integer;
  ApplicationPath: String;
begin
  if MayRelaunch and not AutoUpdateSucceeded then
  begin
    ApplicationPath := ExpandConstant('{app}\{#MyAppExeName}');
    if FileExists(ApplicationPath) then
      Exec(ApplicationPath, '', ExtractFileDir(ApplicationPath),
        SW_SHOWNORMAL, ewNoWait, ResultCode);
  end;
end;
