param(
    [string]$Python = "python",
    [string]$Iscc = "",
    [string]$UpdateManifestUrl = "",
    [string]$UpdateAllowedHosts = "",
    [string]$InstallerUrl = "",
    [string]$SocialProjectUrl = "",
    [string]$SocialPublishableKey = "",
    [string]$CurseForgeApiKey = "",
    [string]$ReleaseNotesEs = "Mejoras de estabilidad y seguridad.",
    [string]$ReleaseNotesEn = "Stability and security improvements."
)

$ErrorActionPreference = "Stop"
$ProjectRoot = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$DistRoot = Join-Path $ProjectRoot "dist"
$Bundle = Join-Path $DistRoot "KatLauncher"
$OutputRootCandidate = Join-Path $ProjectRoot "..\..\outputs"
New-Item -ItemType Directory -Path $OutputRootCandidate -Force | Out-Null
$OutputRoot = (Resolve-Path $OutputRootCandidate).Path
$VersionSource = Get-Content -LiteralPath (Join-Path $ProjectRoot "katlauncher\__init__.py") -Raw
$VersionMatch = [regex]::Match(
    $VersionSource, '__version__\s*=\s*["''](\d+\.\d+\.\d+)["'']'
)
if (-not $VersionMatch.Success) {
    throw "No se pudo leer la versión de katlauncher/__init__.py."
}
$AppVersion = $VersionMatch.Groups[1].Value
if ($ReleaseNotesEs.Length -gt 8000 -or $ReleaseNotesEn.Length -gt 8000) {
    throw "Las notas de versión no pueden superar 8000 caracteres."
}
$HasManifestUrl = -not [string]::IsNullOrWhiteSpace($UpdateManifestUrl)
$HasInstallerUrl = -not [string]::IsNullOrWhiteSpace($InstallerUrl)
$HasSocialUrl = -not [string]::IsNullOrWhiteSpace($SocialProjectUrl)
$HasSocialKey = -not [string]::IsNullOrWhiteSpace($SocialPublishableKey)
if ($HasSocialUrl -xor $HasSocialKey) {
    throw "-SocialProjectUrl y -SocialPublishableKey deben indicarse juntos."
}
if ($CurseForgeApiKey -match '[^\x21-\x7E]' -or $CurseForgeApiKey.Length -gt 512) {
    throw "-CurseForgeApiKey contiene caracteres no válidos o es demasiado larga."
}
if ($HasSocialUrl) {
    $SocialUri = $null
    if (-not [Uri]::TryCreate($SocialProjectUrl, [UriKind]::Absolute, [ref]$SocialUri) -or
            $SocialUri.Scheme -ne "https" -or
            -not $SocialUri.Host.EndsWith(".supabase.co", [StringComparison]::OrdinalIgnoreCase)) {
        throw "-SocialProjectUrl debe ser la URL HTTPS de un proyecto Supabase."
    }
    if (-not $SocialPublishableKey.StartsWith("sb_publishable_")) {
        throw "Usa la publishable key de Supabase, nunca una secret/service_role key."
    }
}
if ($HasManifestUrl -xor $HasInstallerUrl) {
    throw "-UpdateManifestUrl y -InstallerUrl deben indicarse juntos o dejarse ambos vacíos."
}
$ManifestUri = $null
$InstallerUri = $null
$Hosts = @(
    $UpdateAllowedHosts.Split(',') |
        ForEach-Object { $_.Trim().ToLowerInvariant() } |
        Where-Object { $_ }
)
if ($HasManifestUrl) {
    if (-not [Uri]::TryCreate($UpdateManifestUrl, [UriKind]::Absolute, [ref]$ManifestUri) -or
            $ManifestUri.Scheme -ne "https") {
        throw "-UpdateManifestUrl debe ser una URL HTTPS absoluta."
    }
    if (-not [Uri]::TryCreate($InstallerUrl, [UriKind]::Absolute, [ref]$InstallerUri) -or
            $InstallerUri.Scheme -ne "https" -or
            -not $InstallerUri.AbsolutePath.EndsWith(
                ".exe", [StringComparison]::OrdinalIgnoreCase
            )) {
        throw "-InstallerUrl debe ser una URL HTTPS que termine en .exe."
    }
    $GitHubHosts = @(
        "api.github.com", "github.com", "raw.githubusercontent.com",
        "objects.githubusercontent.com", "release-assets.githubusercontent.com"
    )
    $InstallerHostAllowed = (
        $InstallerUri.Host.Equals($ManifestUri.Host, [StringComparison]::OrdinalIgnoreCase) -or
        ($Hosts -contains $InstallerUri.Host.ToLowerInvariant()) -or
        (($GitHubHosts -contains $ManifestUri.Host.ToLowerInvariant()) -and
            ($GitHubHosts -contains $InstallerUri.Host.ToLowerInvariant()))
    )
    if (-not $InstallerHostAllowed) {
        throw "El host de -InstallerUrl debe aparecer en -UpdateAllowedHosts."
    }
}

if (-not $Iscc) {
    $Candidates = @(
        (Join-Path $env:LOCALAPPDATA "Programs\Inno Setup 6\ISCC.exe"),
        "${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe",
        "$env:ProgramFiles\Inno Setup 6\ISCC.exe"
    )
    $Iscc = $Candidates | Where-Object { $_ -and (Test-Path -LiteralPath $_) } |
        Select-Object -First 1
}
if (-not $Iscc -or -not (Test-Path -LiteralPath $Iscc)) {
    throw "No se encontró ISCC.exe. Instala Inno Setup 6 o usa -Iscc."
}

& $Python -m pip check
if ($LASTEXITCODE -ne 0) {
    throw "El entorno de Python tiene dependencias incompatibles."
}
$EscapedProjectRoot = $ProjectRoot.Replace("'", "''")
$TestCode = @"
import sys, unittest
sys.path.insert(0, r'$EscapedProjectRoot')
suite = unittest.defaultTestLoader.discover(r'$EscapedProjectRoot\tests')
result = unittest.TextTestRunner(verbosity=1).run(suite)
raise SystemExit(0 if result.wasSuccessful() else 1)
"@
& $Python -c $TestCode
if ($LASTEXITCODE -ne 0) {
    throw "Las pruebas automáticas fallaron."
}
& $Python -m compileall -q (Join-Path $ProjectRoot "main.py") `
    (Join-Path $ProjectRoot "katlauncher")
if ($LASTEXITCODE -ne 0) {
    throw "La validación de sintaxis falló."
}

$GeneratedChannel = $null
$GeneratedChannelDirectory = $null
$PreviousChannelFile = $env:KATLAUNCHER_UPDATE_CHANNEL_FILE
$GeneratedChannelDirectory = Join-Path ([IO.Path]::GetTempPath()) (
    "KatLauncher-update-channel-{0}" -f [Guid]::NewGuid().ToString("N")
)
[IO.Directory]::CreateDirectory($GeneratedChannelDirectory) | Out-Null
# PyInstaller conserva el nombre base del recurso. Debe llamarse exactamente
# update_channel.json porque esa es la ruta fija que abre update_manager.
$GeneratedChannel = Join-Path $GeneratedChannelDirectory "update_channel.json"
$ChannelManifestUrl = ""
$ChannelHosts = @()
if ($HasManifestUrl) {
    $ChannelManifestUrl = $UpdateManifestUrl
    $ChannelHosts = @($Hosts)
}
$ChannelJson = @{
    schema = 1
    manifest_url = $ChannelManifestUrl
    allowed_hosts = $ChannelHosts
} | ConvertTo-Json -Depth 4
[IO.File]::WriteAllText(
    $GeneratedChannel, $ChannelJson, (New-Object Text.UTF8Encoding($false))
)
$env:KATLAUNCHER_UPDATE_CHANNEL_FILE = $GeneratedChannel
$GeneratedSocial = Join-Path $GeneratedChannelDirectory "social_config.json"
$SocialJson = @{
    schema = 1
    project_url = $SocialProjectUrl.TrimEnd('/')
    publishable_key = $SocialPublishableKey
    provider = "google"
    redirect_url = "http://127.0.0.1:8765/katlauncher-auth"
} | ConvertTo-Json -Depth 3
[IO.File]::WriteAllText($GeneratedSocial, $SocialJson, (New-Object Text.UTF8Encoding($false)))
$PreviousSocialFile = $env:KATLAUNCHER_SOCIAL_CONFIG_FILE
$env:KATLAUNCHER_SOCIAL_CONFIG_FILE = $GeneratedSocial
$GeneratedCurseForge = Join-Path $GeneratedChannelDirectory "curseforge_config.json"
$CurseForgeJson = @{
    schema = 1
    api_key = $CurseForgeApiKey.Trim()
} | ConvertTo-Json -Depth 2
[IO.File]::WriteAllText(
    $GeneratedCurseForge, $CurseForgeJson, (New-Object Text.UTF8Encoding($false))
)
$PreviousCurseForgeFile = $env:KATLAUNCHER_CURSEFORGE_CONFIG_FILE
$env:KATLAUNCHER_CURSEFORGE_CONFIG_FILE = $GeneratedCurseForge

try {
    & $Python -m PyInstaller --noconfirm --clean `
        --distpath $DistRoot `
        --workpath (Join-Path $ProjectRoot "build") `
        (Join-Path $PSScriptRoot "KatLauncher.spec")
    if ($LASTEXITCODE -ne 0) {
        throw "PyInstaller terminó con código $LASTEXITCODE."
    }
}
finally {
    if ($null -eq $PreviousChannelFile) {
        Remove-Item Env:KATLAUNCHER_UPDATE_CHANNEL_FILE -ErrorAction SilentlyContinue
    }
    else {
        $env:KATLAUNCHER_UPDATE_CHANNEL_FILE = $PreviousChannelFile
    }
    if ($null -eq $PreviousSocialFile) {
        Remove-Item Env:KATLAUNCHER_SOCIAL_CONFIG_FILE -ErrorAction SilentlyContinue
    }
    else {
        $env:KATLAUNCHER_SOCIAL_CONFIG_FILE = $PreviousSocialFile
    }
    if ($null -eq $PreviousCurseForgeFile) {
        Remove-Item Env:KATLAUNCHER_CURSEFORGE_CONFIG_FILE -ErrorAction SilentlyContinue
    }
    else {
        $env:KATLAUNCHER_CURSEFORGE_CONFIG_FILE = $PreviousCurseForgeFile
    }
    if ($GeneratedChannel) {
        Remove-Item -LiteralPath $GeneratedChannel -Force -ErrorAction SilentlyContinue
    }
    if ($GeneratedSocial) {
        Remove-Item -LiteralPath $GeneratedSocial -Force -ErrorAction SilentlyContinue
    }
    if ($GeneratedChannelDirectory) {
        Remove-Item -LiteralPath $GeneratedChannelDirectory -Recurse -Force -ErrorAction SilentlyContinue
    }
}

$BundledChannel = Join-Path $Bundle "_internal\katlauncher\update_channel.json"
if (-not (Test-Path -LiteralPath $BundledChannel -PathType Leaf)) {
    throw "El EXE no contiene katlauncher/update_channel.json con el nombre esperado."
}
$BundledChannelData = Get-Content -LiteralPath $BundledChannel -Raw | ConvertFrom-Json
if (-not ($BundledChannelData.allowed_hosts -is [Array])) {
    throw "allowed_hosts debe ser una lista JSON, incluso cuando contiene un solo host."
}
if ($HasManifestUrl) {
    if ($BundledChannelData.manifest_url -ne $UpdateManifestUrl) {
        throw "El canal incluido en el EXE no coincide con -UpdateManifestUrl."
    }
    $BundledHosts = @($BundledChannelData.allowed_hosts)
    foreach ($ExpectedHost in $Hosts) {
        if ($BundledHosts -notcontains $ExpectedHost) {
            throw "El canal incluido en el EXE no contiene el host $ExpectedHost."
        }
    }
}
elseif ($BundledChannelData.manifest_url -ne "") {
    throw "Un build sin URLs debe incluir un canal de actualización vacío."
}
$RequiredRuntimeAssets = @(
    "_internal\katlauncher\assets\invite.mp3",
    "_internal\katlauncher\assets\katglobal\LICENSE-e4mc.txt",
    "_internal\katlauncher\assets\katglobal\lib\katglobal-1.0.0.jar",
    "_internal\katlauncher\assets\katglobal\lib\netty-incubator-codec-classes-quic-0.0.74.Final.e4mc.1.jar",
    "_internal\katlauncher\assets\katcraft\KatCraft-fabric-1.21.1-1.5.2.jar",
    "_internal\katlauncher\assets\katcraft\KatCraft-fabric-26.2-1.5.2.jar",
    "_internal\katlauncher\assets\katcraft\KatCraft-forge-1.20.1-1.5.2.jar",
    "_internal\katlauncher\assets\katcraft\KatCraft-neoforge-1.21.1-1.5.2.jar"
)
foreach ($RelativeAsset in $RequiredRuntimeAssets) {
    $BundledAsset = Join-Path $Bundle $RelativeAsset
    if (-not (Test-Path -LiteralPath $BundledAsset -PathType Leaf) -or
            (Get-Item -LiteralPath $BundledAsset).Length -lt 1024) {
        throw "Falta un recurso obligatorio dentro del EXE: $RelativeAsset"
    }
}

Copy-Item -LiteralPath (Join-Path $ProjectRoot "README.md") -Destination $Bundle -Force
Copy-Item -LiteralPath (Join-Path $ProjectRoot "THIRD_PARTY_NOTICES.txt") `
    -Destination $Bundle -Force
Copy-Item -LiteralPath (Join-Path $ProjectRoot "LICENSE.txt") -Destination $Bundle -Force
if (Test-Path -LiteralPath (Join-Path $ProjectRoot "CHANGELOG.md")) {
    Copy-Item -LiteralPath (Join-Path $ProjectRoot "CHANGELOG.md") -Destination $Bundle -Force
}
Copy-Item -LiteralPath (Join-Path $PSScriptRoot "licenses") `
    -Destination (Join-Path $Bundle "licenses") -Recurse -Force

# Exporta los textos exactos instalados de todo el stack de red/Supabase. No
# dependemos de resúmenes: el usuario recibe las licencias originales.
$EscapedLicenseDestination = (Join-Path $Bundle "licenses").Replace("'", "''")
$LicenseCode = @"
from importlib.metadata import PackageNotFoundError, distribution
from pathlib import Path
import shutil

destination = Path(r'$EscapedLicenseDestination')
destination.mkdir(parents=True, exist_ok=True)
packages = [
    'supabase', 'postgrest', 'realtime', 'storage3', 'supabase-auth',
    'supabase-functions', 'httpx', 'httpcore', 'anyio', 'h11', 'h2',
    'hpack', 'hyperframe', 'pydantic', 'pydantic_core', 'cryptography',
    'cffi', 'websockets', 'multidict', 'yarl', 'propcache', 'PyJWT',
    'deprecation', 'StrEnum', 'annotated-types', 'typing_extensions',
    'typing-inspection', 'pycparser', 'packaging',
]
supabase_fallback = None
try:
    supabase_dist = distribution('supabase')
    supabase_fallback = next(
        (supabase_dist.locate_file(item) for item in (supabase_dist.files or [])
         if Path(str(item)).name.lower() in ('license', 'license.txt', 'license.md')),
        None,
    )
except PackageNotFoundError:
    pass
for package in packages:
    try:
        dist = distribution(package)
    except PackageNotFoundError:
        raise SystemExit(f'Falta la distribución requerida para licencias: {package}')
    sources = []
    for item in dist.files or []:
        name = Path(str(item)).name.lower()
        if name.startswith(('license', 'licence', 'copying', 'notice')):
            source = Path(dist.locate_file(item))
            if source.is_file() and source not in sources:
                sources.append(source)
    if not sources and package in {
        'postgrest', 'realtime', 'storage3', 'supabase-auth', 'supabase-functions'
    } and supabase_fallback:
        sources = [Path(supabase_fallback)]
    for index, source in enumerate(sources, 1):
        safe_name = str(dist.metadata.get('Name') or package).replace('/', '-').replace(' ', '-')
        target = destination / f'{safe_name}-{dist.version}-{index}-{source.name}'
        shutil.copy2(source, target)
"@
& $Python -c $LicenseCode
if ($LASTEXITCODE -ne 0) {
    throw "No se pudieron reunir las licencias de dependencias."
}

$BuiltExe = Join-Path $Bundle "KatLauncher.exe"
$SmokeInfo = [System.Diagnostics.ProcessStartInfo]::new()
$SmokeInfo.FileName = $BuiltExe
$SmokeInfo.Arguments = "--smoke-test"
$SmokeInfo.WorkingDirectory = $Bundle
$SmokeInfo.UseShellExecute = $false
$SmokeInfo.CreateNoWindow = $true
$env:QT_QPA_PLATFORM = "offscreen"
$env:KATLAUNCHER_SMOKE_TEST = "1"
$SmokeProcess = [System.Diagnostics.Process]::Start($SmokeInfo)
if (-not $SmokeProcess.WaitForExit(60000)) {
    $SmokeProcess.Kill()
    throw "El EXE no terminó la prueba de inicio en 60 segundos."
}
$SmokeExitCode = $SmokeProcess.ExitCode
$SmokeProcess.Dispose()
if ($SmokeExitCode -ne 0) {
    throw "El EXE no superó la prueba de inicio (código $SmokeExitCode)."
}

& $Iscc "/DMyAppVersion=$AppVersion" (Join-Path $PSScriptRoot "installer.iss")
if ($LASTEXITCODE -ne 0) {
    throw "Inno Setup terminó con código $LASTEXITCODE."
}

$SetupPath = Join-Path $OutputRoot "KatLauncher-Setup-$AppVersion.exe"
if (-not (Test-Path -LiteralPath $SetupPath)) {
    throw "No se encontró el instalador compilado: $SetupPath"
}

# Comprueba también la copia extraída por el instalador. /SMOKETEST evita
# registrar o modificar la instalación normal de KatLauncher del usuario.
$BuildRoot = [IO.Path]::GetFullPath((Join-Path $ProjectRoot "build"))
$InstallerSmokeRoot = [IO.Path]::GetFullPath(
    (Join-Path $BuildRoot "installer-smoke\KatLauncher")
)
if (-not $InstallerSmokeRoot.StartsWith(
        $BuildRoot + [IO.Path]::DirectorySeparatorChar,
        [StringComparison]::OrdinalIgnoreCase
    )) {
    throw "La carpeta de prueba del instalador salió de build/."
}
$InstallerSmokeParent = Split-Path -Parent $InstallerSmokeRoot
if ([IO.Directory]::Exists($InstallerSmokeParent)) {
    [IO.Directory]::Delete($InstallerSmokeParent, $true)
}
[IO.Directory]::CreateDirectory($InstallerSmokeParent) | Out-Null
$InstallerSmokeLog = Join-Path $InstallerSmokeParent "install.log"
$InstallerInfo = [System.Diagnostics.ProcessStartInfo]::new()
$InstallerInfo.FileName = $SetupPath
$InstallerInfo.Arguments = (
    '/VERYSILENT /SUPPRESSMSGBOXES /NORESTART /NOICONS ' +
    '/NOCLOSEAPPLICATIONS /CURRENTUSER /SMOKETEST=1 ' +
    "/DIR=`"$InstallerSmokeRoot`" /LOG=`"$InstallerSmokeLog`""
)
$InstallerInfo.WorkingDirectory = $OutputRoot
$InstallerInfo.UseShellExecute = $false
$InstallerInfo.CreateNoWindow = $true
$InstallerProcess = [System.Diagnostics.Process]::Start($InstallerInfo)
if (-not $InstallerProcess.WaitForExit(180000)) {
    $InstallerProcess.Kill()
    throw "El instalador no terminó su prueba en 180 segundos."
}
$InstallerExitCode = $InstallerProcess.ExitCode
$InstallerProcess.Dispose()
if ($InstallerExitCode -ne 0) {
    throw "La instalación de prueba terminó con código $InstallerExitCode."
}
$InstalledExe = Join-Path $InstallerSmokeRoot "KatLauncher.exe"
if (-not (Test-Path -LiteralPath $InstalledExe)) {
    throw "El instalador no extrajo KatLauncher.exe."
}
if (Test-Path -LiteralPath (Join-Path $InstallerSmokeRoot "unins000.exe")) {
    throw "La instalación de prueba no debe registrar un desinstalador."
}
foreach ($RelativeAsset in $RequiredRuntimeAssets) {
    $InstalledAsset = Join-Path $InstallerSmokeRoot $RelativeAsset
    if (-not (Test-Path -LiteralPath $InstalledAsset -PathType Leaf) -or
            (Get-Item -LiteralPath $InstalledAsset).Length -lt 1024) {
        throw "El instalador no extrajo el recurso obligatorio: $RelativeAsset"
    }
}
$InstalledSmokeInfo = [System.Diagnostics.ProcessStartInfo]::new()
$InstalledSmokeInfo.FileName = $InstalledExe
$InstalledSmokeInfo.Arguments = "--smoke-test"
$InstalledSmokeInfo.WorkingDirectory = $InstallerSmokeRoot
$InstalledSmokeInfo.UseShellExecute = $false
$InstalledSmokeInfo.CreateNoWindow = $true
$InstalledSmokeProcess = [System.Diagnostics.Process]::Start($InstalledSmokeInfo)
if (-not $InstalledSmokeProcess.WaitForExit(60000)) {
    $InstalledSmokeProcess.Kill()
    throw "La copia instalada no terminó su prueba de inicio en 60 segundos."
}
$InstalledSmokeExitCode = $InstalledSmokeProcess.ExitCode
$InstalledSmokeProcess.Dispose()
if ($InstalledSmokeExitCode -ne 0) {
    throw "La copia instalada no arrancó (código $InstalledSmokeExitCode)."
}

$SetupItem = Get-Item -LiteralPath $SetupPath
$SetupHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $SetupPath).Hash.ToLowerInvariant()
$Manifest = [ordered]@{
    schema = 1
    channel = "stable"
    version = $AppVersion
    published_at = [DateTime]::UtcNow.ToString("yyyy-MM-ddTHH:mm:ssZ")
    installer = [ordered]@{
        url = if ($InstallerUrl) {
            $InstallerUrl
        }
        else {
            "https://example.invalid/KatLauncher-Setup-$AppVersion.exe"
        }
        size = [Int64]$SetupItem.Length
        sha256 = $SetupHash
    }
    notes = [ordered]@{
        es = $ReleaseNotesEs
        en = $ReleaseNotesEn
    }
}
if ($HasInstallerUrl) {
    $ManifestPath = Join-Path $OutputRoot "KatLauncher-latest.json"
}
else {
    $ManifestPath = Join-Path $OutputRoot (
        "KatLauncher-update-manifest-$AppVersion.template.json"
    )
}
$ManifestJson = $Manifest | ConvertTo-Json -Depth 6
[IO.File]::WriteAllText(
    $ManifestPath, $ManifestJson, (New-Object Text.UTF8Encoding($false))
)

Write-Host "Release de KatLauncher $AppVersion creada correctamente."
Write-Host "Instalador: $SetupPath"
Write-Host "SHA-256: $SetupHash"
Write-Host "Manifiesto: $ManifestPath"
