# Changelog de KatLauncher

## 1.5.2.1 — Aviso de ruta a 1.6.0 y sistema de alertas

- Nuevo banner en el dashboard anunciando que la versión 1.6.0 se acerca,
  para mantener informada a la comunidad mientras se prepara.
- El aviso se puede cerrar y queda recordado entre sesiones.
- Nuevo sistema de alertas remotas sobre **Supabase** (sin hosting aparte:
  usa el mismo proyecto que Kat Social). Puede mostrar un banner en el
  Dashboard o un cuadro de diálogo, con sonido de advertencia opcional,
  según severidad (info/advertencia/crítico). Se actualiza casi al instante
  vía Realtime, con sondeo cada 15 min como respaldo.
- Nueva herramienta de desarrollo `tools/kat_alert_sender.py` para redactar
  y publicar esas alertas directo en Supabase, sin tocar código ni subir
  archivos a mano.
- Nuevo `supabase/11_kat_alerts_1521.sql` con la tabla, función y políticas
  de RLS necesarias (ejecutar una sola vez en el SQL Editor del proyecto,
  después de los scripts existentes de Kat Social).

## 1.5.2 — Jaguar Rooms

- Salas privadas separadas de Kat Global, con nombre, descripción, mundo,
  Hardcore, continuar la sala anterior y reinicio desde KatCraft.
- Selector de mods de servidor con búsqueda y exclusión automática de mods
  exclusivos del cliente.
- Nuevos Tweaks de KatCraft: Keystrokes, contador FPS y Ultra Optimized.
- Jugadores Kat del servidor visibles dentro de KatCraft y solicitudes de
  amistad directas.
- KatSkin permite cambiar la skin desde Minecraft y muestra capa/élitros
  locales activos.
- Nuevo trofeo secreto «Primero lo primero» al comerse una patata, con toast
  estilo logro de Minecraft.
- Kat Social estrena chats de grupo privados con mensajes en tiempo real.
- Mejoras generales de navegación y estado persistente de las salas.

## 1.5.1 — Kat Rooms

- El creador de salas deja de aparecer en el launcher: ahora vive dentro de
  KatCraft y se abre con la tecla `K` desde Minecraft.
- Nuevo selector de mundos en KatCraft: permite crear un mundo nuevo, escoger
  un guardado del perfil o reutilizar una copia de servidor anterior.
- Los guardados existentes se convierten en servidor mediante una copia
  segura; KatLauncher nunca modifica el mundo original ni copia `session.lock`.
- Nuevo selector Hardcore al crear la sala, disponible en Fabric 1.21.1/26.2,
  Forge 1.20.1 y NeoForge 1.21.1.
- Nueva pestaña Salas públicas en XMBKat, Kat Normal, Kat Epic y Kat Classic,
  con búsqueda mediante Enter y conexión al doble clic.
- Las salas publican nombre, descripción, creador, jugadores, Minecraft,
  loader, versión del loader y manifiesto de mods en Kat Social.
- Si falta la instancia correcta, KatLauncher crea un perfil compatible antes
  de entrar.
- Servidores dedicados Fabric, Quilt, Forge y NeoForge con sincronización de
  mods aptos para servidor; Vanilla continúa usando el JAR firmado por Mojang.
- Panel del creador con registro, consola privada local y OP automático.
- KatCraft 1.5.1 añade directorio de salas, perfiles dentro del juego, tutorial,
  tono secreto, tecla K reforzada y etiquetas coloreadas por rango.
- El gato se dibuja en la esquina de la pantalla del inventario y ya no dentro
  del panel de ranuras.
- Directorio de salas con heartbeat, caducidad automática, bloqueos respetados
  y control de publicación exclusivo del dueño autenticado.

- KatCraft permite crear, configurar, entrar y detener salas Kat Global
  directamente desde Minecraft con la tecla `K`.
- Corregida la etiqueta `[KAT]` del TAB: el jugador local aparece de inmediato
  y los amigos con KatCraft se conservan al actualizar la presencia.
- Nuevo logo Kat con resplandor blur en la esquina de los inventarios.

## 1.5.0 — Kat Interfaces

- Nuevo Kat Global: crea una sala dedicada temporal en tu PC y recibe un
  dominio público para jugar con amigos de otros países sin abrir puertos.
- El túnel viene integrado, usa el protocolo e4mc/quiclime con su atribución
  MIT y se cierra automáticamente junto con la sala.
- Elige RAM, puerto y si deseas Internet; KatLauncher prepara el servidor
  oficial, lo inicia sin consola y abre Minecraft conectado.
- Las invitaciones de KatCraft comparten el dominio global. Si el relay no
  está disponible, la sala continúa automáticamente por LAN.
- Descarga segura del servidor oficial con HTTPS, límite de tamaño y
  verificación SHA-1 publicada por Mojang.
- KatCraft se instala automáticamente en cada perfil compatible y selecciona
  su JAR exacto para Fabric, Quilt, Forge o NeoForge.
- Etiqueta Kat, insignias, amigos, invitaciones desde Minecraft y skins
  compartidas entre jugadores que usan KatLauncher.
- Las invitaciones muestran un toast de Windows con nombre y servidor, usando
  un sonido exclusivo incluso cuando KatLauncher está oculto por el juego.
- Advertencia desactivable para perfiles Vanilla, donde KatCraft no puede
  cargarse sin un mod loader.
- Cuatro interfaces completas y seleccionables: XMBKat, Kat Normal, Kat Epic
  y Kat Classic. Kat Epic adapta la interfaz aportada por la comunidad sin
  duplicar datos ni funciones.
- Selector visual de interfaz dentro de la guía inicial, con vistas previas y
  aplicación inmediata.
- Kat Tutorial opcional, accesible desde Inicio, XMBKat, Kat Epic y
  Configuración, con navegación mediante flechas.
- Selector de color personalizado: el acento elegido se propaga por el
  launcher, botones, marcos, indicadores, avatares y fondo animado.
- Buscar actualizaciones es accesible desde Inicio, XMBKat, Kat Epic y
  Configuración.
- Biblioteca de skins MCStat lista para usar, con búsqueda, filtro Classic/Slim,
  instalación al doble clic y caché local para conexiones inestables.
- Nueva galería Capturas por perfil: miniaturas, vista completa, abrir, copiar y
  guardar una copia de cada screenshot.
- MCStat también permite buscar, previsualizar e instalar capas directamente
  en el perfil mediante CustomSkinLoader.
- KatSkin compartido se reafirma antes de cada inicio y conserva la copia local
  como respaldo, aunque Kat Social no estuviera conectado al elegir la skin.
- El visor 3D ahora renderiza las capas exteriores de skins modernas y el
  perfil de Kat Social deja de mostrar la textura 2D desplegada.
- Importación de capas, élitros y cosméticos más tolerante: valida el contenido
  real de la imagen y lo normaliza a PNG.
- Correcciones de navegación, señales de botones, persistencia de interfaz,
  traducciones ES/EN y compatibilidad con configuraciones anteriores.

## 1.4.2 — XMB Social Hotfix

- KatLauncher se oculta en la bandeja mientras Minecraft está abierto y vuelve
  automáticamente cuando termina el juego.
- Inicio rápido desde el XMB con icono de Minecraft y animación propia.
- Presentación de 5.4 segundos estilo Legacy Edition: logo de KatLauncher,
  transición y pantalla de Mojang Studios antes de arrancar el proceso.
- Todas las pantallas de Kat Modern se abren dentro del marco visual XMB.
- Corregido el fallo que impedía abrir perfiles públicos de Kat Social.
- Los perfiles muestran PFP, versión de KatLauncher, rango, presencia, placas
  y trofeos.
- Kat Social pausa refrescos y reconexiones durante el juego para no mostrar
  errores ni ventanas sobre Minecraft.
- Los errores HTML/Cloudflare se convierten en avisos cortos y comprensibles.
- Nuevo SQL todo-en-uno idempotente para instalar o actualizar Kat Social.

## 1.4.1 — XMB & Hot Fixies

- Interfaz inglesa completa para XMB, Trofeos, Kat Social, Bedrock y la guía.
- Pestaña Trofeos con diez logros, progreso de 10/50/100 horas y Platino.
- Trofeos sincronizados con Kat Social, placa pública y popup XMB automático.
- Perfiles sociales al doble clic con amistad, rangos, placas y trofeos.
- Kat Presence opcional con versión de Minecraft, loader y skin activa.
- XMB de pantalla completa fiel al prototipo: categorías centradas, elementos
  verticales, ondas, reloj, mouse, teclado, mando y apertura estilo PS3.
- Herramientas Debug del prototipo: popup de trofeo, fondo/tema aleatorio,
  ventana secundaria y prueba del easter egg.
- Kat Social elimina del servidor los mensajes de más de siete días, conservando
  al menos los 100 más recientes de cada ámbito y cualquier mensaje reportado.
- Copia local opcional y deduplicada del historial de Kat Social en SQLite.
- KatSkin comparte la skin activa entre usuarios de KatLauncher y conserva la
  skin local como respaldo cuando no hay conexión.
- Detección automática de mandos e instalación no bloqueante de Controlify en
  perfiles Fabric, Quilt, Forge y NeoForge compatibles.
- Navegación con mando en todas las pestañas y diálogos, no solamente en la XMB.
- A confirma, B vuelve, LB/RB cambia de sección y la cruceta/stick navega controles.
- Borde pulsante violeta/blanco para localizar el control seleccionado fuera del XMB.
- Teclado virtual completo para mando, con acciones Listo y Listo + Enter.
- Al pulsar Jugar con un mando detectado, KatLauncher pregunta antes de instalar
  Controlify en perfiles compatibles.
- Menú de clic derecho para consultar perfiles y acciones de usuario en Kat Social.
- Sonidos separados para clic, operación completada, trofeo, error, notificación,
  actualización y easter eggs.
- Nuevos secretos: siete clics rápidos en el logo y el código Konami con mando.

## 1.4.0 — Kat Beyond

- Asistente inicial y explicación clara del modo Java offline.
- Reparación con fallback local cuando no hay conexión.
- Página Bedrock con lanzamiento y acceso oficial Java & Bedrock.
- Navegación legible, cinco acentos y Rich Presence activo por defecto.
- Copia de skins Premium por usuario Mojang y acceso a NameMC.
- Capas y élitros locales mediante CustomSkinLoader.
- Texture pack MCKAT incluido e instalado sin sobrescribir cambios.
- Búsqueda, posts y rangos de tiempo jugado en Kat Social.
- Solicitudes cruzadas de amistad y refresco de operaciones corregidos.
- Exportación segura de carpetas a modpacks `.mrpack`.
- Actualización sobre el mismo AppId del instalador 1.3.0.
- Correcciones de loaders, botones, sesiones vencidas y traducciones.
- Carátulas y ficha de proyecto al hacer doble clic en Modrinth y CurseForge.
- Instalación transaccional de CurseForge con dependencias obligatorias y hashes.
- Java oficial administrado automáticamente (8/16/17/21/25), incluido Minecraft 26.x.
- Paquete portable para Linux x86_64 y sesión social mediante el llavero del escritorio.

## 1.3.0 — Kat Modern

- Nuevo dashboard Kat Modern y navegación lateral.
- Selector en vivo Kat Modern/Kat Classic.
- Biblioteca Modrinth para mods, resource packs y shaders.
- Instalador recursivo y transaccional de dependencias.
- Nick, PFP, presencia, timestamps y no-leídos en Kat Social.
- Renovación automática de JWT y envío/búsqueda con Enter.
- Noticias oficiales con imágenes y caché local.
- Servidores favoritos, ping y conexión directa.
- Cuentas offline múltiples por perfil.
- Visor de skins 3D Classic/Slim con textura pixelada.
- Migración segura de skins al cambiar nickname.
- Mejoras de cierre, rollback, validación, empaquetado y licencias.

## 1.2.2

- Se evitó que el refresco de Kat Social bloqueara el envío de mensajes.
- Mejoras para conexiones lentas.

## 1.2.1

- Kat Social con Google OAuth, amigos, chat global y mensajes privados.
- Actualización de mods, reparación de perfiles y acceso a carpetas.
